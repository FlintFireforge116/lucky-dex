# Clefairy v0.15 scene verification

Release gate: all 48 tests (26 original pack tests, 13 Clefairy browser tests,
8 motion tests and 1 pack-hash preservation test), syntax/preservation checks
and the debug APK build passed before the v0.15 version bump.
The final v0.15 tree also passed all 48 tests and syntax/preservation checks.
Its APK rebuilt successfully (versionCode 15, versionName 0.15.0).

## Scope and implementation

The accepted v0.14 pack opening is preserved. The new authoritative Clefairy
scene lives in `clefairy-scene.js` / `clefairy-scene.css`; `clefairy-flow.js`
owns memory-game sequence playback, selection feedback and cancellation.
50 legacy JavaScript renderer/game overrides, 253 obsolete scene selectors and
their conflicting animation keyframes were retired. No pose files were edited.

Scenery has no transform, camera animation or scene breathing. Persistent local
idle/star/song/moon image layers overlap for a 100 ms incoming crossfade and a
180 ms return to idle. Motion begins during the blend. Interrupted actions
retarget from the actual visible transform and opacity weights; no action swaps
the `src` of an already visible image.

The reflection gets the exact same rigid transform and pose weights in the same
frame, projected through a vertically mirrored/compressed parent, blurred,
opacity/mask attenuated and clipped below the waterline. The Moon pose's small
baked water fragment is clipped at render time. Spin never uses the contaminated
spin PNG: it rotates clean idle artwork through one eased 1050 ms full turn,
then settles upright. Interrupted twirls also make one full turn before a smooth
nearest-upright return. Normal action timelines are STAR 1500 ms, SONG 1750 ms,
MOON 1650 ms and SPIN 1450 ms including reaction/return.

STAR has a reaction/lift, travelling sky trail and later light response. SONG
has character-only bounce/sway and staggered rising notes. MOON lifts/holds,
blooms the existing moon position and lights the water/reflection. SPIN has
procedural gold trails/sparks split into rear and front depth planes. Idle has
only a 1.3 px vertical shift over 2.8 seconds, with no scaling or horizontal
motion. Reduced-motion suppresses idle/action movement and moving trails while
keeping pose fades and lighting.

## Verification coverage

- Full regression suite retains the original 26 pack tests unchanged.
- Clefairy tests cover both 360×800 and 412×915 mobile viewports, local artwork
  with network disabled, four distinct animated cues and debug save/game-state
  isolation, repeated actions, idle/reset/exit/navigation cancellation, missing
  action/idle assets and reduced motion.
- Per-frame browser samples compare character/reflection transforms and all
  pose opacity weights. A separate projection test verifies the reflected
  image's geometry and water clipping. Actual composited screenshot comparison
  found over 3300 visibly changed reflection pixels, not just a DOM rectangle.
- Canvas checks confirm moving gold pixels in both depth planes and staggered
  note painting; scene screenshots were visually inspected.
- Generated sequence playback waits for the whole scene cue plus a 220 ms gap.
  Selection highlights remain visible during both playback and player input.
  Reset/exit cancels asynchronous runs and prevents stale game resurrection.
- Backgrounding mid-sequence cancels pending work and replays the same existing
  round when returning; it does not add another round or award currency.
- Cash-out and completion formulas remain unchanged. Second Sight is restricted
  to unfinished input, closing an inherited completed-round double-bank path.
- Independent review findings were reproduced before fixing: stalled background
  recovery, nearly-two-turn Spin from a positive tilt, and repeated bank awards.

## Pack preservation checks

`tests/pack-preservation.test.cjs` locks SHA-256 hashes of the three v0.14 pack
module/style files and both original test files. `verify-pack-preservation.cjs`
also compares the accepted source baseline: 310 non-Clefairy application nodes,
69 pack CSS rules, non-Clefairy markup and 10 runtime/artwork files are preserved.
Only lifecycle entry points gained Clefairy cleanup; pack logic is unchanged.

## Reproduction

```sh
npm install
npm test
node --check app/src/main/assets/clefairy-scene.js
node --check app/src/main/assets/clefairy-flow.js
node --check app/src/main/assets/app-v013.js
node scripts/verify-pack-preservation.cjs <extracted-v0.14-source>
gradle --no-daemon :app:assembleDebug
```

Open Clefairy Match, then replay in the browser/WebView console:

```js
LuckyDexDebug.playClefairyAction('spin') // also star, song, moon, idle
```

It uses the production scene without changing score, rewards, game state or
save data. Replay is refused while generated-sequence playback owns the scene.
Optional screenshots/performance inspection: `node scripts/inspect-clefairy.cjs`.

## Limitations

No physical Android device was connected. Verification uses desktop Chromium
at mobile sizes plus a compiled, debug-signed Android APK, not an emulator or
physical WebView smoke run. Physical-device FPS and haptic feel remain unverified.
Cold first-layer rasterization produced large frame gaps in desktop headless
Chromium; CPU profiling showed rendering rather than timeline JavaScript work.
Assets are decoded before play, and the timeline starts on its first presented
frame with bounded advancement so a hitch cannot skip the cue. This can extend
the action's wall-clock duration on a slow renderer; it is not a 60 FPS guarantee.
