# Pack opening implementation ledger

Approved scope: pack opening only, deterministic newest-first set chronology,
cache-first offline artwork, and v0.14 only after all acceptance checks pass.

1. RED → GREEN: pure chronology/enrichment, artwork resolution, rarity/motion
   geometry, and cancellable lifecycle in `pack-opening.js`.
2. RED → GREEN: browser integration for shared-card flip, depth-split ribbons,
   gated navigation, Skip, local debug replay, and exactly-once economy.
3. Consolidate the active pack path; remove superseded pack JS/CSS while
   preserving Clefairy nodes/rules byte-for-byte. Keep v0.13 storage keys.
4. Run 360×800 and 412×915 smoke tests, IndexedDB cache/airplane-mode opening,
   cancellation/races, syntax checks, and `:app:assembleDebug`.
5. Review, fix any findings, then bump version only if every gate passes.

Review focus: exiting during preparation/tear/preload, repeated Skip/re-entry,
unusable release dates, stale source requests, unavailable/corrupt cached art.

Completed test-first implementation and one independent review/fix pass.
26 tests passed, including mobile/offline smoke tests; debug APK built before
the version was bumped. Superseded pack overrides were removed, not extended.
Clefairy preservation was checked against the original archive.
Portable JDK 17, Gradle 8.9 and Android SDK were provisioned under ignored .tools/.
Execution: inline; source package and approved chat design are the spec.
See pack-opening-verification.md for release verification and limitations.
