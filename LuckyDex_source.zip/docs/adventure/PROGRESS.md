# Adventure 2.0 ledger

Plan: `PLAN.md`; user brief: `REQUEST.md`. Baseline bc92ac9 / supplied v0.22.3 source hash5415bd0a023b928fcd362197a6bd92b4a37cce1e6d8bcd8812f5756f66dd4338.

Ruling: user explicitly authorized a major creative subsystem overhaul and extraction; proceed under the detailed brief without repeated design permission requests. Preserve shared systems and unchanged Arcade owners.

Ruling: choose coherent Gen III FRLG pixel assets. No optional sound dependency; haptics/motion provide the complete muted experience. New perks/field chain are run/session mechanics, not permanent currency.

Stage1 active: baseline audit agent is mapping exact current contracts/economy and removal sites. Essential assets are being rendered from authentic pret/pokefirered map/metatile resources with source notes. Root is specifying integration/state interfaces before implementing the controller.

Stages1–6 complete: audit, 829 local PNGs and all-species data, pure seeded model, battle reducer/presentation, controller, and core/DOM extraction are integrated. Logical asset/model/battle checkpoint: `4ce9b23`. Thirty bespoke events, seven run perks, persistent branching runs and all five bosses are implemented.

Stages7–8 complete: first whole suite passed 26 programs; additional file-origin test brings final suite to 27. Independent reviews and regressions repaired counters, discovery/legendary RNG coupling, import overwrite on pagehide, background CSS paths, reveal selector collision, Bag accessibility state and hotspot overlap. Repeated lifecycle/persistence and shared-system tests pass. Old Adventure-only CSS is removed, while shared rule bodies remain byte-identical.

Stage9 active: version0.23.0/code230 frozen after integration. Original-signer Android build succeeds. Final rebuilt APK, all-source payload comparison, 27-program suite and screenshot matrix are being exported. No Android device is available; native installation/runtime claims will remain explicitly unverified.

Final gate results: 27 test programs plus all three offline asset guards PASS. Screenshot matrix and four inspected contact sheets PASS at 360×800,393×873,412×915,320×640. Final Android build/signature PASS; all 5,108 source assets match the APK byte-for-byte. Signer/package/file origin are preserved. No connected ADB device; no native runtime claim. Export script requires a clean committed release, excludes signing keys and compares source ZIP/APK payloads before writing QA/hashes.
