# Pack opening v0.14 verification

## Acceptance evidence

- 26 automated tests: 11 unit/policy tests and 15 Chromium integration tests.
- Complete cached/offline pack opening at 360×800 and 412×915, with zero artwork
  HTTP attempts: tear, reveal, gated swipe, Skip, previous/next, Full Screen,
  summary, and exactly-once collection/economy updates.
- IndexedDB-first artwork online; network miss persists for subsequent offline
  use. Corrupt cached/network images fall through, and the offline-ready hint
  requires usable artwork rather than metadata alone.
- Real motion sampled during approach/settle/flip. Opposite face stays painted
  during the approach without revealing the card image early. Crown front-plane
  effects are drawn; all owned WAAPI/RAF work stops after ready or screen exit.
- Desktop headless Chromium Crown replay averaged 19.22 ms per RAF interval in
  the pre-version release run. This is a diagnostic, not a physical Android FPS
  guarantee. Canvas glow is batched, not repeatedly blurred per segment.
- Chronology integration tests cover detail enrichment, valid cached dates,
  unknown source order and offline cached catalog enrichment. A live TCGdex
  audit also verified dated newest-first ordering for Pocket and physical sets.
- Scope comparison to the v0.13 archive: 49 Clefairy/memory JavaScript nodes,
  228 CSS blocks, 7 scene assets, and Clefairy HTML are unchanged.
- JavaScript syntax checks and Gradle `:app:assembleDebug` passed before the
  version bump. All 26 tests and syntax/scope checks also passed on v0.14.
  The final v0.14 debug build succeeded (versionCode 14, versionName 0.14.0).

## Review fixes (reproduced by failing tests first)

1. Decode each network artwork candidate before caching, so corrupt high-quality
   artwork cannot prevent valid low-quality fallback.
2. Propagate cancellation through pack card-detail/artwork preparation; prevent
   pending tear/preload work from committing or resurrecting a closed pack.
3. Preserve valid catalog dates when a full-set cache date is unusable, and
   enrich offline catalogs from full sets already cached locally.
4. Keep both rotating approach faces painted with a back cover until settling.
5. Cancel the pack session when navigation leaves the Packs page.

## Compatibility and limitations

No save migration or cache-key changes. Existing odds/slot selection and reward
formulas are retained; debug replay has no save/economy effects. Common reveals
have no rarity flash/particles. Reduced-motion skips directly to ready.

No physical Android device was connected. Native haptic feel and on-device
WebView frame pacing remain unverified. Mobile/offline smoke tests are Chromium
tests, not an Android emulator run. The APK is a debug-signed build.

## Reproduction

```sh
npm install
npm test
node --check app/src/main/assets/app-v013.js
node --check app/src/main/assets/pack-opening.js
node --check app/src/main/assets/pack-flow.js
gradle --no-daemon :app:assembleDebug
```

Optional live chronology audit: `node scripts/audit-chronology.cjs` (network
required). Scope comparison: `node scripts/verify-scope.cjs <original-extracted-root>`.
Generated screenshots and chronology audit JSON are local verification artifacts,
not runtime dependencies.
