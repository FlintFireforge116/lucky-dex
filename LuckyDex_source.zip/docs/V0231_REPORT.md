# LuckyDex v0.23.1 — Arcade balance, Tile variety, card foil

This is a bounded polish release on top of v0.23.0 Adventure 2.0. Adventure ownership and mechanics are unchanged.

## Arcade economy

All active Arcade rewards now pass through `LuckyDexArcadePlatform.awardRun()` and one normalization table. The intent is comparable reward value for a representative successful run while preserving skill/difficulty scaling. Ball Drop's explicit 1000-coin jackpot remains an intentional rare exception.

Representative raw → balanced examples:

- Berry Picker: 100 → 100
- Tile Puzzle: 90 → 144
- Voltorb Flip: 1000 → 140
- Poké Ball Drop ordinary run: 90 → 117
- Berry Blender: 400 → 140
- Clefairy Match: 330 → 149
- Fossil Excavation: 180 → 81
- Unown Decoder: 1000 → 140
- Who's That Pokémon?: 1400 → 140

Partner helper bonuses still apply after normalization.

## Tile Puzzle content

The moving-picture puzzle now draws from 8 local backdrops, 16 actor/prop layouts and 8 prop sets. That creates 1,024 backdrop/layout/prop combinations before the caught-Pokémon selection is considered. The original three Amie backgrounds remain, joined by the five local Adventure environment scenes.

## Holo / Reverse Holo

`card-foil-v0231.js/css` provides one foil identity/rendering owner.

- Pack reveal: Holo/Reverse Holo cards visibly shimmer after reveal.
- Binder: foil cards shimmer in their portrait tile.
- Full-screen card modal: shimmer reacts to pointer/touch position.
- Pack summary: foil class remains visible.
- New physical pulls persist `foilCounts` (`normal`, `reverse`, `holo`) and a preferred `foilKind` on the owned-card record.
- Old saved printed Holo rarities can be inferred safely from `rarity` and gain Holo shimmer immediately.
- Historical Reverse Holo pulls from pre-v0.23.1 builds cannot be reconstructed because older builds did not persist the transient `_foil` slot marker; no fake migration is attempted.

Holo shimmer is concentrated over the approximate artwork window. Reverse Holo uses a distinct whole-card satin/rainbow treatment.

## Update compatibility

- package remains `com.example.luckydex`
- save key remains `luckyDexSave`
- WebView origin remains `file:///android_asset/index.html`
- Android version is `0.23.1` / `231`
- CI signing-secret path remains unchanged
