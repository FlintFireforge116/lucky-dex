# Pokémon Dash v2 Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Replace the current side-scrolling Dash presentation with a top-down Gen 3-inspired racer while adding Quick Race, 18 type leagues, four difficulty bands, larger racers, cup progression, and persistent trophies without regressing the proven sprint/stamina/course loop.

**Architecture:** Keep the current pure race physics in `arcade-dash.js`, but move static mode/difficulty/theme policy into a new `arcade-dash-config.js` and cup scoring into a new `arcade-dash-league.js`. Extend `arcade-dash-course.js` so seeded geometry remains deterministic while theme skins vary independently. Rebuild Dash's DOM/CSS/canvas presentation around a mode menu, difficulty-first racer picker, top-down renderer, and league standings flow.

**Tech Stack:** Vanilla JavaScript/CommonJS-compatible browser modules, HTML/CSS, Canvas 2D, Android WebView assets, Node `assert` test programs, existing offline LuckyDex Pokémon dataset/sprites.

**Spec:** `docs/superpowers/specs/2026-10-08-pokemon-dash-v2-design.md`

## Global Constraints

- Base release is LuckyDex `v0.29.2`; target release is `v0.30.0` with Android `versionCode 300` and `versionName '0.30.0'`.
- Preserve Android `applicationId 'com.example.luckydex'` and the existing `luckydex-dev.keystore` signer configuration.
- Do not add runtime network dependencies or new npm production dependencies; use `LuckyDexAdventureSpecies` and bundled normal/shiny racer sprites.
- Preserve `FINISH_DISTANCE = 1800`, current base pace compression, stamina drain/regeneration, sprint multiplier, obstacle frequency, boost frequency, and general race duration unless a top-down mapping-only change is needed.
- Keep three hidden racing lines internally; do not add free analogue steering in v2.
- Type Leagues use the same five AI entrants for all three races of a cup; League AI should be type-eligible where possible and difficulty-band compliant.
- Quick Race allows any caught Pokémon; Type Leagues require the player's racer to match the league type, including either type of a dual-type Pokémon.
- League race 1/2 give standings only; coins are awarded once after race 3 from the overall cup result.
- Existing Dash totals (`races`, `wins`, `podiums`, `bestTimeMs`, `lastRacerKey`) must migrate additively without reset.
- Keep all non-Dash minigames and existing God Pack behavior unchanged.

## Review Focus

1. **Missing/unknown species metadata:** a caught Pokémon with no `types` metadata must remain usable in Quick Race, must not unlock a Type League incorrectly, and must not crash racer rendering. Covered in Task 1 tests.
2. **Empty collection / no eligible league racer:** mode and league screens must render, with start disabled and a direct catch requirement instead of a dead-end or exception. Covered in Task 6 tests.
3. **Background/resume during a cup:** pausing during race 2 must preserve race state and accumulated standings without duplicate completion or rewards. Covered in Task 8 tests.
4. **Small phone viewport:** top HUD, 96–112 px racers, canvas, and Left/Sprint/Right controls must remain within the Dash panel without forced page scrolling. Covered by the Task 7 integration contract.
5. **Difficulty boundary values:** Pokémon exactly on 20/65, 55/100, 90/135, and 125/180 edges must produce stable fit/recommendation results and AI pools must stay inside configured ranges. Covered in Tasks 2 and 5 tests.

---

### Task 1: Extend Dash save migration and racer metadata

**Files:**
- Modify: `app/src/main/assets/arcade-platform.js` (`ARCADE_DEFAULTS`, `ensureArcadeState`, `dashRacers`)
- Modify: `tests/arcade-platform.test.cjs`

**Interfaces:**
- Produces: `dashRacers()` rows shaped as `{key,id,name,shiny,level,baseSpeed,types,image}` where `types` is a lowercase array from `LuckyDexAdventureSpecies.byId[id].types`, or `[]` when unavailable.
- Produces: migrated `state.arcade.dash` fields `lastQuickRacerKey`, `lastLeagueRacerKey`, `quickBestTimes`, and sparse `leagueRecords`, while preserving all legacy Dash fields.
- Consumes: existing `LuckyDexAdventureSpecies.byId` and `state.pokemon`.

- [ ] **Step 1: Write failing migration and racer-type tests**

Add assertions that:
- legacy `lastRacerKey:'25:n'` is preserved and seeds `lastQuickRacerKey` when the new field is absent;
- `quickBestTimes` contains `{easy:null,normal:null,hard:null,expert:null}` by default;
- `leagueRecords` defaults to `{}` and unknown future Dash fields survive migration;
- Pikachu returns `types:['electric']`, Charizard returns `['fire','flying']`, and a missing species entry returns `types:[]` without dropping the caught racer.

- [ ] **Step 2: Run the platform test and verify RED**

Run: `node tests/arcade-platform.test.cjs`
Expected: FAIL because the v2 Dash fields/types do not exist yet.

- [ ] **Step 3: Implement additive migration and type enrichment**

In `arcade-platform.js`:
- add `lastQuickRacerKey:null`, `lastLeagueRacerKey:null`, `quickBestTimes:{easy:null,normal:null,hard:null,expert:null}`, `leagueRecords:{}` to Dash defaults;
- in `ensureArcadeState`, if `lastQuickRacerKey` is absent but legacy `lastRacerKey` exists, copy that value into `lastQuickRacerKey` without deleting `lastRacerKey`;
- return `types:Array.isArray(species?.types)?species.types.map(x=>String(x).toLowerCase()):[]` from `dashRacers()`.

- [ ] **Step 4: Run the platform test and verify GREEN**

Run: `node tests/arcade-platform.test.cjs`
Expected: PASS.

- [ ] **Step 5: Checkpoint**

If executing in a git worktree, commit `arcade-platform.js` and its test as `feat: extend dash racer metadata and saves`. In a source-ZIP workspace without `.git`, record the completed task in the execution ledger instead.

---

### Task 2: Add Dash v2 difficulty, theme, recommendation, and reward policy

**Files:**
- Create: `app/src/main/assets/arcade-dash-config.js`
- Create: `tests/arcade-dash-config.test.cjs`
- Modify: `app/src/main/assets/index.html` (script load order only)

**Interfaces:**
- Produces: `LuckyDexDashConfig.TYPE_ORDER` with all 18 league types in spec order.
- Produces: `LuckyDexDashConfig.DIFFICULTIES` with exact Speed bands: Easy 20–65, Normal 55–100, Hard 90–135, Expert 125–180.
- Produces: `recommendedDifficulty(speed) -> 'easy'|'normal'|'hard'|'expert'`, `difficultyFit(speed,key) -> 'below'|'within'|'above'`, `quickReward(place,key) -> integer`, `leagueReward(place,key) -> integer`, `themeFor(type) -> theme object`.
- Produces: `LuckyDexDashConfig.LEAGUE_THEMES` for all 18 types, each with `label`, `surface`, `palette`, and `skins` keys for `rock`, `mud`, `speed-pad`, `stamina-pickup`.

- [ ] **Step 1: Write failing config tests**

Assert:
- all four bands match the spec exactly, including boundary inclusion;
- recommendations are `30→easy`, `90→normal`, `150→expert`; when overlapping bands are equally close by midpoint, choose the easier difficulty;
- `difficultyFit(20,'easy')`, `difficultyFit(65,'easy')`, `difficultyFit(55,'normal')`, `difficultyFit(100,'normal')`, `difficultyFit(90,'hard')`, `difficultyFit(135,'hard')`, `difficultyFit(125,'expert')`, and `difficultyFit(180,'expert')` are all `within`;
- exact Quick Race reward tables are Easy `[120,80,55,35,25,20]`, Normal `[150,100,70,45,30,25]`, Hard `[180,120,85,55,40,30]`, Expert `[240,160,110,70,50,40]` for places 1–6;
- `leagueReward(place,key) === quickReward(place,key) * 3`;
- all 18 types have distinct theme records and every theme defines all four skin categories.

- [ ] **Step 2: Run config tests and verify RED**

Run: `node tests/arcade-dash-config.test.cjs`
Expected: FAIL because `arcade-dash-config.js` does not exist.

- [ ] **Step 3: Implement the config module**

Define the exact difficulty bands, reward tables, AI policy values, recommendation algorithm (closest matching band midpoint, tie to easier; otherwise nearest band boundary), and all 18 theme records. Export to both `root.LuckyDexDashConfig` and CommonJS.

Use these AI policy bases:
- Easy: `reaction:0.65`, `avoidance:0.52`, `boostSeeking:0.35`, `sprintAggression:0.45`, `mistake:0.26`, `conserveAt:32`.
- Normal: `reaction:0.45`, `avoidance:0.70`, `boostSeeking:0.50`, `sprintAggression:0.56`, `mistake:0.15`, `conserveAt:24`.
- Hard: `reaction:0.28`, `avoidance:0.84`, `boostSeeking:0.66`, `sprintAggression:0.64`, `mistake:0.08`, `conserveAt:18`.
- Expert: `reaction:0.18`, `avoidance:0.94`, `boostSeeking:0.78`, `sprintAggression:0.72`, `mistake:0.035`, `conserveAt:14`.

- [ ] **Step 4: Load config before course/runtime and verify GREEN**

Add `<script src="arcade-dash-config.js"></script>` before `arcade-dash-course.js` and `arcade-dash.js` in `index.html`.

Run: `node tests/arcade-dash-config.test.cjs`
Expected: PASS.

- [ ] **Step 5: Checkpoint**

Commit as `feat: add dash v2 difficulty and theme policy` when git metadata is available; otherwise ledger the task.

---

### Task 3: Add pure Type League cup scoring and trophy state machine

**Files:**
- Create: `app/src/main/assets/arcade-dash-league.js`
- Create: `tests/arcade-dash-league.test.cjs`
- Modify: `app/src/main/assets/index.html` (script load order)

**Interfaces:**
- Consumes: `LuckyDexDashConfig` difficulty/type keys.
- Produces: `createCup({type,difficulty,player,aiRacers,seed}) -> cup` with stable six entrants, `raceIndex:0`, per-entrant `points`, `totalTimeMs`, `places`, and `completionHandled:false`.
- Produces: `recordRace(cup, results) -> cup`, where `results` contains all six `{key,place,timeMs}` entries.
- Produces: `standings(cup) -> ranked rows`, `trophyForPlace(place) -> 'gold'|'silver'|'bronze'|null`, `finishCupOnce(cup,fn) -> boolean`.

- [ ] **Step 1: Write failing league tests**

Assert:
- place points are exactly `10,6,4,3,2,1`;
- after three calls to `recordRace`, `raceIndex===3` and points sum correctly;
- equal points are broken by lower `totalTimeMs`;
- overall places 1/2/3 map to gold/silver/bronze and 4–6 to null;
- the same five AI entrant keys persist for all races in a cup;
- `finishCupOnce` calls its callback exactly once.

- [ ] **Step 2: Run league tests and verify RED**

Run: `node tests/arcade-dash-league.test.cjs`
Expected: FAIL because the league module does not exist.

- [ ] **Step 3: Implement the pure cup module**

Use no DOM or global save state. Validate type/difficulty against config, preserve entrant order, accumulate points/time, sort ties by total time then original entrant index, and expose the functions above through browser/CommonJS exports.

- [ ] **Step 4: Load league module before Dash runtime and verify GREEN**

Add `<script src="arcade-dash-league.js"></script>` after `arcade-dash-config.js` and before `arcade-dash.js`.

Run: `node tests/arcade-dash-league.test.cjs`
Expected: PASS.

- [ ] **Step 5: Checkpoint**

Commit as `feat: add dash type league scoring` when possible; otherwise ledger the task.

---

### Task 4: Convert course generation to deterministic themed semantics

**Files:**
- Modify: `app/src/main/assets/arcade-dash-course.js`
- Modify: `tests/arcade-dash-course.test.cjs`

**Interfaces:**
- Consumes: `LuckyDexDashConfig.themeFor(type)`.
- Produces: `generateCourse(seed,{theme='normal'}={})` while preserving one-argument backwards compatibility.
- Produces: course objects shaped `{id,effect,skin,lane,distance}` where `effect` is one of `rock|mud|speed-pad|stamina-pickup`; `skin` is theme-specific visual dressing.
- Preserves: `FINISH_DISTANCE=1800`, `LANE_COUNT=3`, deterministic geometry, no unavoidable three-lane hazard wall, and existing cluster spacing/density curve.

- [ ] **Step 1: Update course tests first**

Add/adjust assertions that:
- `generateCourse(123,{theme:'fire'})` is deeply equal across repeated calls;
- same seed with `fire` versus `water` has identical `lane`, `distance`, and `effect` sequences but different skin values where their theme mappings differ;
- no hazard wall uses `effect` semantics;
- one-argument `generateCourse(seed)` defaults to the Normal/classic route theme and still returns `FINISH_DISTANCE=1800`.

- [ ] **Step 2: Run course tests and verify RED**

Run: `node tests/arcade-dash-course.test.cjs`
Expected: FAIL because current objects use `type` and have no theme/skin.

- [ ] **Step 3: Implement themed semantic objects**

Keep the existing geometry RNG and density math unchanged. Rename object gameplay `type` to `effect`, attach the visual `skin` by theme, and make `isHazard` accept an effect string. Keep `objectsNear` unchanged.

- [ ] **Step 4: Run course tests and verify GREEN**

Run: `node tests/arcade-dash-course.test.cjs`
Expected: PASS.

- [ ] **Step 5: Checkpoint**

Commit as `feat: theme dash course generation` when possible; otherwise ledger the task.

---

### Task 5: Make race engine difficulty-aware and add top-down coordinate helpers

**Files:**
- Modify: `app/src/main/assets/arcade-dash.js` (pure race functions and AI field creation first; no DOM redesign yet)
- Modify: `tests/arcade-dash.test.cjs`

**Interfaces:**
- Consumes: `LuckyDexDashConfig`, themed `course.effect`, racer `types` from Task 1.
- Produces: `aiPool(player,seed,{difficulty='normal',type=null})` exported for tests; Quick Race uses any species in the configured Speed band, League uses species matching the league type and band.
- Produces: `createRaceState(...,{difficulty,mode,theme,course})` storing those values without changing shared stamina/pace rules.
- Produces: `laneToCanvasX(laneVisual,width)`, `distanceToCanvasY(racerDistance,playerDistance,height)`, and `racerPixelSize(width,height)` for renderer/test use.

- [ ] **Step 1: Write failing engine tests**

Add assertions that:
- Easy AI base Speeds are all 20–65; Normal 55–100; Hard 90–135; Expert 125–180;
- repeated `aiPool` calls with the same player/seed/options return the same five species in the same order;
- League `type:'fire'` AI all include Fire in their offline species metadata; Quick Race has no type restriction;
- if the exact type+band pool ever has fewer than five candidates, selection expands by nearest Speed distance while still preserving the type restriction rather than injecting wrong-type entrants;
- AI profiles use the chosen difficulty config and still consume finite stamina;
- `applyCourseObject` reads `obj.effect`;
- stepping a racer across a themed course object still applies the correct hazard/boost effect by hidden lane and distance, proving renderer conversion does not alter collision semantics;
- `laneToCanvasX(0,w) < laneToCanvasX(1,w) < laneToCanvasX(2,w)` and smooth `laneVisual=0.5` lands between lanes;
- with player anchored in the lower third, an opponent farther ahead maps to a smaller canvas Y and one behind maps to a larger Y;
- `racerPixelSize` clamps to 96–112 px.

- [ ] **Step 2: Run Dash engine tests and verify RED**

Run: `node tests/arcade-dash.test.cjs`
Expected: FAIL on new difficulty/effect/top-down helpers.

- [ ] **Step 3: Implement difficulty-aware AI and top-down helpers**

Keep `paceModifier`, `levelModifier`, stamina constants, sprint multiplier, `FINISH_DISTANCE`, and smooth `moveLane` behaviour intact. Generate AI from the offline species table with seeded selection. Do not add hidden AI speed multipliers or infinite stamina.

Define top-down mapping so the player anchor is `70%` of canvas height and hidden lane centers are `28%`, `50%`, `72%` of canvas width; use one shared distance-to-pixel scale constant so hazards and racers map through the same function.

- [ ] **Step 4: Run engine and course tests and verify GREEN**

Run: `node tests/arcade-dash.test.cjs && node tests/arcade-dash-course.test.cjs`
Expected: PASS.

- [ ] **Step 5: Checkpoint**

Commit as `feat: add dash difficulty ai and top down mapping` when possible; otherwise ledger the task.

---

### Task 6: Rebuild Dash mode, difficulty, league, and racer-selection UI flow

**Files:**
- Modify: `app/src/main/assets/index.html` (Dash shell only)
- Modify: `app/src/main/assets/arcade-dash.js` (menu/picker controllers)
- Modify: `app/src/main/assets/arcade-dash.css` (menu/picker styling)
- Modify: `app/src/main/assets/arcade-world.js` (Dash objective copy only)
- Modify: `app/src/main/assets/arcade-session.js` (Dash rule copy only)
- Modify: `tests/arcade-dash-integration.test.cjs`
- Create: `tests/arcade-dash-ui.test.cjs`

**Interfaces:**
- Consumes: Tasks 1–3 config/racer/cup interfaces.
- Produces: views `dashModeView`, `dashDifficultyView`, `dashLeagueView`, `dashPickerView`, `dashStandingsView`, `dashRaceView`.
- Produces: controls `dashQuickBtn`, `dashLeaguesBtn`, `dashDifficultyButtons`, `dashLeagueGrid`, `dashStartBtn`, `dashLeftBtn`, `dashSprintBtn`, `dashRightBtn`, `dashStandingsContinue`.
- Produces: runtime functions `showModeMenu()`, `chooseMode(mode)`, `chooseDifficulty(key)`, `chooseLeague(type)`, `eligibleRacersForCurrentMode(rows)`.

- [ ] **Step 1: Write failing source/UI contract tests**

Assert that:
- the new view/control IDs exist and old `dashUpBtn`/`dashDownBtn` are absent;
- Quick Race flow does not filter racers by type;
- selecting a Type League filters to Pokémon whose `types` includes that league type, including dual types;
- an empty collection disables starting and shows the existing catch-a-Pokémon empty state;
- a league with zero eligible racers remains visible and renders `Catch a <Type>-type Pokémon to enter.`;
- each league card can render its saved Easy/Normal/Hard/Expert trophy summary from `leagueRecords` without requiring the league to be entered;
- difficulty is chosen before racer selection and racer cards expose a recommendation/fit label based on `baseSpeed`;
- search/sort still work inside the filtered eligible racer set.

- [ ] **Step 2: Run UI/integration tests and verify RED**

Run: `node tests/arcade-dash-ui.test.cjs && node tests/arcade-dash-integration.test.cjs`
Expected: FAIL because the old single picker/up-down shell is still present.

- [ ] **Step 3: Replace the Dash HTML shell and controller flow**

Build the mode menu, difficulty screen, 18-league grid, filtered racer picker, standings panel, compact race HUD, and Left/Sprint/Right controls. Preserve `dashRacerSearch`, `dashRacerSort`, `dashRacerGrid`, `dashCanvas`, pause/unavailable/countdown overlays, and the shared Arcade exit mechanism where useful.

Use Quick Race flow: `mode → difficulty → racer → race`.
Use League flow: `mode → league → difficulty → eligible racer → race 1 → standings → race 2 → standings → race 3 → final standings`.

- [ ] **Step 4: Apply Gen 3-inspired menu/picker CSS and verify GREEN**

Replace modern dark dashboard cards with cream/light panels, dark pixel-style outlines, compact spacing, larger 64–72 px picker sprite previews, and type/difficulty badges. Keep page scrolling disabled within Dash's active layout on phone-sized viewports.

Run: `node tests/arcade-dash-ui.test.cjs && node tests/arcade-dash-integration.test.cjs`
Expected: PASS.

- [ ] **Step 5: Checkpoint**

Commit as `feat: rebuild dash v2 mode flow` when possible; otherwise ledger the task.

---

### Task 7: Replace side-scrolling renderer with top-down Gen 3-style course rendering

**Files:**
- Modify: `app/src/main/assets/arcade-dash.js` (`renderRace`, drawing helpers, `drawRacer`, `drawObject` replacement)
- Modify: `app/src/main/assets/arcade-dash.css` (race viewport/HUD/control layout)
- Modify: `app/src/main/assets/index.html` (`dashCanvas` dimensions/ARIA text)
- Modify: `tests/arcade-dash-integration.test.cjs`
- Create: `tests/arcade-dash-render-contract.test.cjs`

**Interfaces:**
- Consumes: Task 5 coordinate helpers and Task 4 `effect/skin/theme` course objects.
- Produces: top-down portrait-biased `540×720` canvas, player anchored at ~70% height, hidden lane centers, and 96–112 px racers with `imageSmoothingEnabled=false`.
- Produces: pixel-styled route renderer using reusable 32 px logical terrain/prop units; no external network art.

- [ ] **Step 1: Write failing renderer contract tests**

Source/integration assertions must verify:
- canvas internal size is `540×720` and CSS uses a portrait-biased race viewport;
- renderer calls `laneToCanvasX`, `distanceToCanvasY`, and `racerPixelSize` rather than horizontal `finishX`/laneY mapping;
- racer images are drawn at the helper's 96–112 px size with smoothing disabled;
- AI name labels are not painted above every racer; player receives a small marker/ring/cursor treatment;
- theme-specific `skin` drives obstacle/slow-zone/boost/pickup visuals;
- race HUD includes only compact position, progress, and stamina information above the canvas;
- mobile race layout keeps Left/Sprint/Right in one bottom control row and uses `overflow:hidden`/viewport sizing sufficient to avoid Dash-internal page scrolling at <=620 px width.

- [ ] **Step 2: Run renderer contracts and verify RED**

Run: `node tests/arcade-dash-render-contract.test.cjs && node tests/arcade-dash-integration.test.cjs`
Expected: FAIL because renderer is still horizontal/16:9/64 px.

- [ ] **Step 3: Implement the top-down pixel renderer**

Replace hills/sky/horizontal road drawing with vertically scrolling route rendering. Draw reusable pixel-style terrain strips, edges, fences/trees/props, themed surfaces, and themed course objects from the 18 theme configs. Use the same distance mapping for racers, hazards, boosts, finish line, and route props so collision visuals remain aligned.

Preserve active gameplay cadence: only coordinate/presentation changes are allowed unless a test demonstrates a top-down collision mismatch.

- [ ] **Step 4: Implement larger racer presentation and compact phone HUD**

Use 96–112 px racer sprites, subtle shadow, player marker, optional boost trail, and no large floating AI names. Style the race area so most vertical space belongs to the course and the bottom controls remain thumb-sized.

- [ ] **Step 5: Run renderer, engine, and integration tests and verify GREEN**

Run: `node tests/arcade-dash-render-contract.test.cjs && node tests/arcade-dash.test.cjs && node tests/arcade-dash-integration.test.cjs`
Expected: PASS.

- [ ] **Step 6: Checkpoint**

Commit as `feat: render dash as top down gba racer` when possible; otherwise ledger the task.

---

### Task 8: Integrate Quick Race and League runtime, persistence, lifecycle, and exactly-once rewards

**Files:**
- Modify: `app/src/main/assets/arcade-dash.js` (race orchestration/finalization)
- Modify: `app/src/main/assets/arcade-platform.js` (record persistence helpers only if needed)
- Modify: `tests/arcade-dash.test.cjs`
- Modify: `tests/arcade-dash-ui.test.cjs`
- Create: `tests/arcade-dash-league-integration.test.cjs`

**Interfaces:**
- Consumes: `LuckyDexDashLeague`, `LuckyDexDashConfig.quickReward/leagueReward`, migrated Dash save fields.
- Produces: Quick Race completion that updates totals + `quickBestTimes[difficulty]` and awards exactly once.
- Produces: League cup orchestration that records each race, shows standings after races 1/2, persists trophy/best points/best total time after race 3, and awards cup coins exactly once.
- Produces: `leagueRecords[type][difficulty] = {trophy,bestPoints,bestTotalTimeMs}` where trophy upgrades only (`null < bronze < silver < gold`) and never downgrades.

- [ ] **Step 1: Write failing runtime integration tests**

Cover:
- Quick Race awards the exact difficulty-scaled place reward once and updates only that difficulty's best time;
- every completed Dash race, including each race inside a League cup, increments legacy `races` and updates `wins`, `podiums`, and overall `bestTimeMs` consistently so v0.29.2 career totals keep meaning;
- Quick Race result actions preserve the selected difficulty for Replay, return to the filtered picker for Change Racer, and return to the Dash mode menu for Back;
- League races 1/2 award zero coins and preserve standings;
- race 3 awards exactly `leagueReward(overallPlace,difficulty)` once;
- gold/silver/bronze persist per type+difficulty and a later worse result does not downgrade an existing trophy;
- best points update on a higher score; equal points update best time only when total time is lower;
- final League standings expose the earned trophy and all six ranked cup entrants before returning to the mode menu;
- `lastQuickRacerKey` and `lastLeagueRacerKey` are stored independently;
- pausing/resuming a Quick Race still resets the frame clock without changing progress or duplicating rewards;
- pausing during league race 2, resuming, and finishing does not reset cup standings or duplicate any reward;
- abandoning a Quick Race or cup cannot pay out.

- [ ] **Step 2: Run runtime integration tests and verify RED**

Run: `node tests/arcade-dash-league-integration.test.cjs`
Expected: FAIL because current finalization knows only a single unscaled race.

- [ ] **Step 3: Implement mode-aware race orchestration**

Refactor current `startRace`/`finalizeRace` orchestration so the pure single-race engine remains reusable. Quick Race uses the classic Normal-route theme and calls its own finalizer; League uses the selected type theme, records one race into the active cup, and either shows standings/continues or finalizes the cup after race 3.

Use one seeded base cup field and derive each race seed deterministically from `cup.seed` and `raceIndex`, preserving the same five AI entrants across all three races while changing course layout.

- [ ] **Step 4: Implement persistence and lifecycle guarantees**

Keep current `visibilitychange`/`pagehide` pause behavior, reset frame timing on resume, and leave `activeCup` intact during temporary backgrounding. `close()` may abandon an unfinished cup; it must not award partial coins.

- [ ] **Step 5: Run all Dash tests and verify GREEN**

Run: `node tests/arcade-platform.test.cjs && node tests/arcade-dash-config.test.cjs && node tests/arcade-dash-league.test.cjs && node tests/arcade-dash-course.test.cjs && node tests/arcade-dash.test.cjs && node tests/arcade-dash-ui.test.cjs && node tests/arcade-dash-render-contract.test.cjs && node tests/arcade-dash-league-integration.test.cjs && node tests/arcade-dash-integration.test.cjs`
Expected: PASS.

- [ ] **Step 6: Checkpoint**

Commit as `feat: complete dash quick race and type leagues` when possible; otherwise ledger the task.

---

### Task 9: Release v0.30.0, regression verification, and source packaging

**Files:**
- Modify: `app/build.gradle`
- Modify: `package.json`
- Modify: `package-lock.json`
- Modify: `app/src/main/assets/index.html` (visible build labels)
- Modify: `app/src/main/assets/app-v0167.js` (`window.__LUCKYDEX_BUILD`)
- Create: `tests/v0300-release.test.cjs`
- Create: `TEST_REPORT_v0.30.0.md`
- Modify: `README.md`
- Modify: `CODEX_HANDOVER.md`

**Interfaces:**
- Produces: upgrade-compatible LuckyDex `v0.30.0`, `versionCode 300`, package/runtime/UI version alignment, and versioned source ZIP `LuckyDex_source_v0.30.0.zip`.

- [ ] **Step 1: Write failing v0.30.0 release contract**

Assert:
- `applicationId 'com.example.luckydex'` remains unchanged;
- `versionCode 300`, `versionName '0.30.0'`;
- `package.json`, `package-lock.json`, visible UI, and `window.__LUCKYDEX_BUILD` all equal `0.30.0`;
- permanent keystore configuration remains present;
- Dash config/course/league/runtime scripts load in dependency order.

- [ ] **Step 2: Run release test and verify RED**

Run: `node tests/v0300-release.test.cjs`
Expected: FAIL on v0.29.2 metadata.

- [ ] **Step 3: Update release metadata and documentation**

Set all version surfaces to `0.30.0`/`300`, update README/handover with Dash v2 mode controls, difficulty bands, league structure, save migration, and known test-environment limitations only if they are freshly reproduced.

- [ ] **Step 4: Run release test and verify GREEN**

Run: `node tests/v0300-release.test.cjs`
Expected: PASS.

- [ ] **Step 5: Run the full runnable regression suite and offline audits**

First run every Dash-specific command from Task 8. Then run `npm test` if dependencies/tooling are installed. If the container lacks Playwright/node modules or an inherited test fails, reproduce that exact failure against untouched v0.29.2 before classifying it as environmental/pre-existing; do not silently waive new regressions.

Run the offline asset audits directly if needed:
- `python3 scripts/fetch_arcade_v0200_assets.py --check`
- `python3 scripts/verify_v0223_venues.py`
- `python3 scripts/verify_adventure_assets.py`
- `python3 scripts/verify_fossil_museum_v0250_assets.py`

Expected: all Dash and newly touched integration tests PASS; offline asset audits PASS; any non-pass listed in `TEST_REPORT_v0.30.0.md` is proven inherited/environment-only against v0.29.2.

- [ ] **Step 6: Attempt Android source build verification when tooling exists**

Run `./gradlew :app:assembleDebug` if a wrapper exists, otherwise `gradle :app:assembleDebug` if Gradle is installed. If neither exists in the execution environment, record that limitation rather than claiming an APK build passed.

- [ ] **Step 7: Package and re-verify the source ZIP**

Create `/mnt/data/LuckyDex_source_v0.30.0.zip` from the project root, excluding `.git`, `.superpowers`, `node_modules`, transient build directories, and any earlier output ZIPs. Extract it to a fresh verification directory and rerun at minimum `node tests/v0300-release.test.cjs` plus the full Dash-specific test command from Task 8 against the extracted copy.

Expected: packaged-copy tests PASS.

- [ ] **Step 8: Final checkpoint**

If executing in git, commit release metadata/report as `release: LuckyDex v0.30.0`. Do not push or publish without the user's explicit request. In the extracted source workflow, return the versioned ZIP plus updated Termux commands that copy it to `~/lucky-dex/LuckyDex_source.zip`, then `git add`, `git commit -m "Update LuckyDex source to v0.30.0"`, and `git push`.
