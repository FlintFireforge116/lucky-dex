# LuckyDex v0.39.0 — Arcade Records & Game Review Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Add a shared Gen III-style post-run GAME REVIEW and ARCADE RECORDS system with ten recent completed runs per supported game, while retuning Rock Harden Normal and making Magikarp Quick Splash rebounds 16% faster.

**Architecture:** Extend the existing `arcade-session.js` result seam instead of replacing it. A new pure records core sanitizes review/history payloads, `arcade-records.js` owns persistence/adapters/navigation, game modules remain authoritative for run facts, and existing per-game state remains authoritative for permanent PBs/totals. History is display-only and can never replay rewards or achievement claims.

**Tech Stack:** Vanilla JavaScript/UMD modules, HTML/CSS, Node `.cjs` regression tests, Android WebView-compatible DOM APIs, existing LuckyDex save/state/reward infrastructure.

**Spec:** `docs/superpowers/specs/2026-10-11-arcade-records-game-review-v0390-design.md`

## Global Constraints

- Baseline is the verified v0.38.2 source; the filtered Bulk Dust Exchange from v0.38.2 must remain intact.
- Release target is **v0.39.0** with Android `versionCode 3900`.
- Persist at most **10 completed runs per game**, newest first; never synthesize old history from aggregate stats.
- Existing per-game PBs/totals/wins/trophies remain source-of-truth and must not move into a monolithic records schema.
- History/review actions are display-only: no reopen/replay/navigation path may duplicate coins, Dust, tickets, cards, boosters, items, stats, or achievement claims.
- Only legitimate completed/cashed-out runs are stored; abandoned/backed-out runs are not.
- Competitive scoreboards preserve the authoritative game ranking, including shared-rank ties; never re-rank display-rounded values.
- Result card reveals stay before GAME REVIEW exactly as current behavior.
- Achievement completion may be surfaced once after a run, but the result screen must never auto-claim it.
- Rock Harden target: Easy and Hard remain materially as-is; Normal targets `perfectRate: 0.40`, `missRate: 0.09`, `goodShare: 0.84`, with Good > Perfect over seeded samples.
- Magikarp Quick Splash target: successful Quick jumps use **0.84× normal flight duration**, preserve hold-to-height behavior, and use identical player/CPU physics.
- No online/global leaderboard, cloud telemetry, replay playback, trend charts, or unbounded history.
- Browser QA may be reported unavailable only when Playwright/browser support is genuinely unavailable in the extracted source environment.

## Review Focus

1. A malformed or maliciously huge stored history entry must be reduced to bounded scalar/row data and must not inflate save size or crash rendering; Task 1 pins this.
2. Re-entering results through replay/back/pause/resume or a duplicated completion callback must not append the same run twice; Tasks 1, 4, 5, 6 and 7 pin stable history IDs and dedupe behavior.
3. Reopening a stored run must never execute serialized callbacks or re-award anything; Tasks 1 and 4 pin read-only reconstruction and economy immutability.
4. Achievement snapshotting may be unavailable or an achievement may already be complete-but-unclaimed; GAME REVIEW must still render and only newly completed IDs may appear; Tasks 2 and 4 pin this.
5. Old saves may contain unknown future/removed game IDs and no `records` block; normalization must preserve unrelated/unknown state while current navigation omits unsupported IDs; Tasks 1 and 3 pin this.

---

### Task 1: Pure Review/History Model and Save Normalization

**Files:**
- Create: `app/src/main/assets/arcade-records-core.js`
- Modify: `app/src/main/assets/arcade-platform.js`
- Test: `tests/v0390-arcade-records-core.test.cjs`
- Test: `tests/v0390-arcade-records-state.test.cjs`

**Interfaces:**
- Consumes: existing `state.arcade` and `ensureArcadeState()` conventions.
- Produces from `LuckyDexArcadeRecordsCore`:
  - `normalizeReview(gameId, input) -> ReviewModel`
  - `historyEntryFromReview(review, {completedAt, entryId}) -> RunHistoryEntry|null`
  - `normalizeHistoryEntry(gameId, entry) -> RunHistoryEntry|null`
  - `appendHistory(store, gameId, entry, limit=10) -> {store, appended}`
  - `reviewFromHistory(gameId, entry) -> ReviewModel|null`
  - `newAchievements(beforeIds, afterRows) -> AchievementRow[]`
- Produces from `LuckyDexArcadePlatform`:
  - `normalizeArcadeRecords(value) -> {version:1,games:{[gameId]:{recent:RunHistoryEntry[]}}}`
  - `ensureArcadeState()` always returns normalized `records` without removing unknown unrelated `state.arcade` keys.

- [ ] **Step 1: Write failing pure-model tests**

Add tests asserting:
- competitive and solo review inputs normalize to scalar `primaryMetric`, bounded scoreboard/stats/PB/reward/achievement arrays;
- scoreboard order and supplied rank labels survive normalization unchanged;
- arbitrary nested objects/functions are stripped;
- strings are capped at 120 characters, scoreboard at 8 rows, stats at 12, PB rows at 8, achievements at 8, reward lines at 8;
- `historyEntryFromReview()` contains no callback/function fields;
- `reviewFromHistory()` marks the model read-only and cannot contain replay/change/back handlers;
- same `entryId` appended twice results in one stored row;
- 11 unique entries leave exactly the newest 10;
- malformed/oversized history becomes safe bounded data rather than throwing.

- [ ] **Step 2: Run pure-model tests and verify RED**

Run: `node tests/v0390-arcade-records-core.test.cjs`

Expected: FAIL because `arcade-records-core.js` and its exports do not exist.

- [ ] **Step 3: Implement the records core**

Implement the interfaces above with schema version `1`. `entryId` is required for persisted entries and is the dedupe key. Only approved scalar presentation fields are serialized; never serialize runtime objects, DOM nodes, callbacks, functions, or arbitrary nested payloads.

- [ ] **Step 4: Run pure-model tests and verify GREEN**

Run: `node tests/v0390-arcade-records-core.test.cjs`

Expected: PASS.

- [ ] **Step 5: Write failing save-normalization tests**

Add tests asserting:
- absent `records` becomes `{version:1,games:{}}`;
- non-array `recent` becomes `[]`;
- invalid rows are stripped and valid rows are capped at 10;
- unknown game IDs remain in normalized state;
- existing Dash/Kids Club/PB fields survive byte-for-byte-equivalent value normalization;
- malformed records do not disturb v0.38.2 Dust Exchange preferences or unrelated arcade keys.

- [ ] **Step 6: Run state tests and verify RED**

Run: `node tests/v0390-arcade-records-state.test.cjs`

Expected: FAIL because `normalizeArcadeRecords()` / `records` normalization is missing.

- [ ] **Step 7: Add `records` normalization to `arcade-platform.js`**

Add `ARCADE_DEFAULTS.records={version:1,games:{}}`, implement/export `normalizeArcadeRecords(value)`, and call it from `ensureArcadeState()` without moving existing permanent stats.

- [ ] **Step 8: Run Task 1 tests**

Run: `node tests/v0390-arcade-records-core.test.cjs && node tests/v0390-arcade-records-state.test.cjs`

Expected: PASS both.

- [ ] **Step 9: Commit**

```bash
git add app/src/main/assets/arcade-records-core.js app/src/main/assets/arcade-platform.js tests/v0390-arcade-records-core.test.cjs tests/v0390-arcade-records-state.test.cjs
git commit -m "feat: add arcade review history model"
```

### Task 2: Read-Only Arcade Achievement Snapshot API

**Files:**
- Modify: `app/src/main/assets/achievements-v0341.js`
- Test: `tests/v0390-arcade-achievement-review.test.cjs`

**Interfaces:**
- Consumes: current synchronized `ACHIEVEMENTS` catalogue and existing `achievementProgress()` runtime function.
- Produces from `LuckyDexAchievements`:
  - `snapshotCompletedArcadeIds() -> string[]`
  - `describeAchievementIds(ids) -> {id,name,icon,desc,hidden}[]`
- These functions are read-only and never claim rewards.

- [ ] **Step 1: Write failing achievement snapshot tests**

Test that the API:
- returns only completed `category:'arcade'` IDs;
- includes completed secret Arcade achievements;
- includes complete-but-unclaimed achievements in the snapshot so they are not falsely reported as new on later runs;
- `describeAchievementIds()` returns sanitized metadata only;
- does not mutate `achievementClaims`, coins, Dust or tickets;
- safely returns `[]` when runtime achievement state is unavailable.

- [ ] **Step 2: Run test and verify RED**

Run: `node tests/v0390-arcade-achievement-review.test.cjs`

Expected: FAIL because snapshot/describe exports do not exist.

- [ ] **Step 3: Implement the snapshot API**

Keep the existing catalogue/claim implementation authoritative. Add a runtime-safe read-only snapshot layer; do not duplicate thresholds or achievement definitions.

- [ ] **Step 4: Run test and verify GREEN**

Run: `node tests/v0390-arcade-achievement-review.test.cjs`

Expected: PASS.

- [ ] **Step 5: Commit**

```bash
git add app/src/main/assets/achievements-v0341.js tests/v0390-arcade-achievement-review.test.cjs
git commit -m "feat: expose arcade achievement snapshots"
```

### Task 3: Records Registry, Persistence Bridge and Permanent Record Adapters

**Files:**
- Create: `app/src/main/assets/arcade-records.js`
- Modify: `app/src/main/assets/index.html` (script load only in this task)
- Test: `tests/v0390-arcade-records-registry.test.cjs`

**Interfaces:**
- Consumes: Task 1 records core/platform normalizer and Task 2 achievement snapshot API.
- Produces `window.LuckyDexArcadeRecords`:
  - `SUPPORTED_GAME_IDS` exactly: `berryPicker,tilePuzzle,voltorb,ballDrop,berry,clefairy,fossil,unown,quiz,dash,ekansHoop,digDigDig,magikarpSplash,rockHarden`
  - `adapterFor(gameId)`
  - `captureAchievementSnapshot() -> string[]`
  - `commitReview(gameId, review, {achievementBefore=[], historyKey, completedAt=Date.now()}) -> ReviewModel`
  - `getRecent(gameId) -> RunHistoryEntry[]`
  - `getPermanent(gameId) -> RecordSection[]`
  - UI methods are added in Task 4.

`commitReview()` must enrich only with the newly completed achievement difference, append once by stable `historyKey`, call the existing `save()` after a successful history append, and still return a renderable review if persistence/snapshotting fails.

- [ ] **Step 1: Write failing registry/persistence tests**

Assert:
- all 14 supported finished games have adapters;
- `museum` activity is not treated as a completed-run game;
- each adapter reads meaningful permanent values from current existing state without inventing missing aggregates;
- unknown game IDs return no current adapter but remain untouched in `state.arcade.records`;
- `commitReview()` appends one entry, dedupes repeated `historyKey`, caps at 10 and saves only after append;
- persistence failure does not throw away the review model or alter already-awarded game state;
- completed achievement difference is attached once; unavailable achievement API yields no section without blocking history.

- [ ] **Step 2: Run test and verify RED**

Run: `node tests/v0390-arcade-records-registry.test.cjs`

Expected: FAIL because `arcade-records.js` is missing.

- [ ] **Step 3: Implement registry/adapters and persistence bridge**

Permanent adapters must use current durable fields. Initial cards must include the spec-listed Kids Club/Dash fields and use existing best/totals for the remaining games (`bestBerryPicker`, `bestTilePuzzle`, `voltorbLevel`, `bestBallDrop`, `ballDropJackpots`, `stats.perfectBerryRounds`, Clefairy existing best, `bestFossil`/museum exhibit totals, `bestUnown`, `bestQuiz`/`bestQuizEndless`). Omit unavailable metrics rather than synthesizing them.

- [ ] **Step 4: Load records scripts after platform/achievement dependencies**

Add `arcade-records-core.js` and `arcade-records.js` to `index.html` in dependency-safe order before game modules that call the bridge.

- [ ] **Step 5: Run test and verify GREEN**

Run: `node tests/v0390-arcade-records-registry.test.cjs`

Expected: PASS.

- [ ] **Step 6: Commit**

```bash
git add app/src/main/assets/arcade-records.js app/src/main/assets/index.html tests/v0390-arcade-records-registry.test.cjs
git commit -m "feat: add arcade records registry"
```

### Task 4: GAME REVIEW Sheet and ARCADE RECORDS Screen

**Files:**
- Modify: `app/src/main/assets/arcade-session.js`
- Modify: `app/src/main/assets/arcade-records.js`
- Create: `app/src/main/assets/arcade-records.css`
- Modify: `app/src/main/assets/index.html`
- Modify: `app/src/main/assets/arcade-world.js`
- Test: `tests/v0390-arcade-session-review.test.cjs`
- Test: `tests/v0390-arcade-records-ui.test.cjs`
- Test: `tests/v0390-arcade-records-browser.test.cjs`

**Interfaces:**
- Consumes: Task 3 `LuckyDexArcadeRecords` API.
- Extends `LuckyDexArcadeSession.showResult(gameId, opts)` with optional:
  - `review: ReviewInput`
  - `achievementBefore: string[]`
  - `historyKey: string`
- Produces `LuckyDexArcadeSession.showStoredReview(gameId, entry)` for read-only history display.
- Extends `LuckyDexArcadeRecords` with:
  - `open({gameId=null}={})`
  - `openGame(gameId)`
  - `openStoredRun(gameId, entryId)`
  - `close()`
  - `isOpen()`

- [ ] **Step 1: Write failing session-review tests**

Assert structured reviews render/model:
- title/difficulty or mode, main metric, scoreboard or solo block, stats, PB rows, reward summary, new achievements;
- authoritative scoreboard order/rank labels and ties are preserved;
- legacy v0.38.x result calls still normalize/render while games are migrated;
- card reveals still precede the summary;
- buttons are `PLAY AGAIN`, optional `CHANGE`, `RECORDS`, `BACK TO VENUE`;
- `RECORDS` targets the current `gameId` and does not append another history row;
- `showStoredReview()` is read-only and never runs replay/change/back reward callbacks.

- [ ] **Step 2: Run session test and verify RED**

Run: `node tests/v0390-arcade-session-review.test.cjs`

Expected: FAIL because structured review sections/records action/read-only path are absent.

- [ ] **Step 3: Upgrade `arcade-session.js` and result DOM**

Keep the card-reveal state machine. Add explicit DOM containers for scoreboard, stats, PB rows, reward rows and newly completed achievements. Structured result calls go through `commitReview()` once; legacy calls continue to work without fabricating history.

- [ ] **Step 4: Run session test and verify GREEN**

Run: `node tests/v0390-arcade-session-review.test.cjs`

Expected: PASS.

- [ ] **Step 5: Write failing Arcade Records UI/navigation tests**

Assert:
- Arcade hub/world exposes a visible `ARCADE RECORDS` action without removing venue controls;
- top-level screen shows all supported adapters and tracked run count;
- game detail shows permanent sections plus newest-first recent runs (max 10);
- empty history explains that detailed history starts with v0.39.0 while old permanent records remain;
- tapping a run calls read-only stored review;
- unsupported stored IDs are omitted from navigation;
- records opening/closing restores world/venue visibility correctly.

- [ ] **Step 6: Run records UI test and verify RED**

Run: `node tests/v0390-arcade-records-ui.test.cjs`

Expected: FAIL because records view/navigation markup does not exist.

- [ ] **Step 7: Implement the records screen and Gen III styling**

Add `arcadeRecordsView` markup, list/detail shells and `ARCADE RECORDS` world action. Use GBA/Gen III beveled panels, compact portrait cards, player-row highlight language and brief `NEW RECORD` pulse. Use internal vertical scrolling and no trend chart/modern glow/emoji medals.

- [ ] **Step 8: Run records UI test and verify GREEN**

Run: `node tests/v0390-arcade-records-ui.test.cjs`

Expected: PASS.

- [ ] **Step 9: Add browser/mobile regression test**

Cover target Android portrait sizing, 10-run list horizontal overflow, card reveal → GAME REVIEW → RECORDS, and replay/change/back navigation.

- [ ] **Step 10: Run browser test when available**

Run: `node tests/v0390-arcade-records-browser.test.cjs`

Expected: PASS when Playwright/browser support exists; otherwise explicit environment-unavailable output with no false PASS claim.

- [ ] **Step 11: Commit**

```bash
git add app/src/main/assets/arcade-session.js app/src/main/assets/arcade-records.js app/src/main/assets/arcade-records.css app/src/main/assets/arcade-world.js app/src/main/assets/index.html tests/v0390-arcade-session-review.test.cjs tests/v0390-arcade-records-ui.test.cjs tests/v0390-arcade-records-browser.test.cjs
git commit -m "feat: add arcade game review and records UI"
```

### Task 5: Competitive Review Migration — Dash, Dig, Magikarp and Rock Harden

**Files:**
- Modify: `app/src/main/assets/arcade-dash.js`
- Modify: `app/src/main/assets/arcade-dig-dig-dig.js`
- Modify: `app/src/main/assets/arcade-magikarp-splash.js`
- Modify: `app/src/main/assets/arcade-rock-harden.js`
- Test: `tests/v0390-competitive-reviews.test.cjs`

**Interfaces:**
- Consumes: Task 4 structured `showResult()` contract and Task 3 `captureAchievementSnapshot()`.
- Produces one stable `historyKey` per completed run, preferably from the authoritative round/race start timestamp/token.

- [ ] **Step 1: Write failing competitive review tests**

For each game assert legitimate completion supplies a structured review and stable history key, while abandon/close does not. Also assert:
- Dash Quick Race scoreboard contains all six racers in authoritative finish order, player row highlighted, final place/time and PB status;
- a completed three-race Dash Type League cup creates one league-mode review/history entry with final overall standings, trophy, points and total time; intermediate league races do not create separate history rows;
- Dig scoreboard contains all four racers, finisher time or final dig progress, shared rank semantics from the core;
- Magikarp scoreboard contains all four scores and shared ranks, plus player Quick-chain/performance stats;
- Rock Harden scoreboard contains all four scores plus HP/KO state and grade breakdown/Gold Rock result;
- reopening result or duplicate completion callback does not add a second recent row;
- one newly completed Arcade achievement appears once in the review and remains unclaimed.

- [ ] **Step 2: Run test and verify RED**

Run: `node tests/v0390-competitive-reviews.test.cjs`

Expected: FAIL because these games still send legacy result details rather than structured review/history.

- [ ] **Step 3: Migrate Dash and Dig**

Capture completed-achievement IDs immediately before authoritative completion-state mutation, then pass review facts after reward/stat completion. For Dash, retain the existing between-race standings screen; only Quick Race completion and final three-race League cup completion create history. Do not change reward calculations or race/dig mechanics.

- [ ] **Step 4: Run targeted test for Dash/Dig**

Run: `node tests/v0390-competitive-reviews.test.cjs`

Expected: Dash/Dig assertions PASS; Magikarp/Rock assertions still fail until Step 5.

- [ ] **Step 5: Migrate Magikarp and Rock Harden**

Use existing core rankings; never recompute ties from displayed values. Include already-awarded Gold Rock reward as display data only.

- [ ] **Step 6: Run test and verify GREEN**

Run: `node tests/v0390-competitive-reviews.test.cjs`

Expected: PASS.

- [ ] **Step 7: Run historical competitive regressions**

Run: `node tests/arcade-dash-v033-finish.test.cjs && node tests/v0360-dig-runtime.test.cjs && node tests/v0370-magikarp-runtime.test.cjs && node tests/v0380-rock-harden-runtime.test.cjs && node tests/v0380-rock-harden-gold-reward.test.cjs`

Expected: PASS.

- [ ] **Step 8: Commit**

```bash
git add app/src/main/assets/arcade-dash.js app/src/main/assets/arcade-dig-dig-dig.js app/src/main/assets/arcade-magikarp-splash.js app/src/main/assets/arcade-rock-harden.js tests/v0390-competitive-reviews.test.cjs
git commit -m "feat: add competitive arcade reviews"
```

### Task 6: Solo Review Migration — Amie, Game Corner and Performance Stage

**Files:**
- Modify: `app/src/main/assets/arcade-amie.js`
- Modify: `app/src/main/assets/arcade-classics.js`
- Modify: `app/src/main/assets/arcade-ball-drop.js`
- Modify: `app/src/main/assets/berry-blender.js`
- Modify: `app/src/main/assets/clefairy-memory.js`
- Test: `tests/v0390-solo-reviews-amie-corner-stage.test.cjs`

**Interfaces:**
- Consumes: structured review/history contract from Tasks 3–4.
- Produces stable completed-run history for `berryPicker`, `tilePuzzle`, `voltorb`, `ballDrop`, `berry`, `clefairy`.

- [ ] **Step 1: Write failing solo migration tests**

Assert each game produces only authoritative facts already available at completion:
- Berry Picker: served, score, best combo, misses, mode/PB comparison;
- Tile Puzzle: elapsed time, moves, mode/PB comparison;
- Voltorb Flip: level, bank/result, cleared/busted outcome;
- Ball Drop: balls/run outcome, coin haul, jackpots, card/booster/prize summary;
- Berry Blender: performance summary and timing/accuracy facts already emitted by the engine, payout;
- Clefairy: cash-out and failed-sequence endings both receive a review; store final completed round, sequence progress already available, bank/result, consolation/banked coins and PB.

Also assert no run is stored merely by opening/resetting/backing out, and repeated result display dedupes by stable history key.

- [ ] **Step 2: Run test and verify RED**

Run: `node tests/v0390-solo-reviews-amie-corner-stage.test.cjs`

Expected: FAIL because these games still send legacy/basic result data.

- [ ] **Step 3: Add stable run IDs where missing and migrate all six games**

Run IDs are presentation/history identity only and must not alter gameplay RNG or scoring. Capture achievement snapshot immediately before each authoritative completion-state update.

- [ ] **Step 4: Run test and verify GREEN**

Run: `node tests/v0390-solo-reviews-amie-corner-stage.test.cjs`

Expected: PASS.

- [ ] **Step 5: Run historical regressions**

Run: `node tests/v0223-berry-touch.test.cjs && node tests/v0253-tile-puzzle-scenes.test.cjs && node tests/arcade-ball-drop.test.cjs && node tests/arcade-classics.test.cjs && node tests/v0283-clefairy-pace.test.cjs && node tests/v0287-clefairy-reward.test.cjs`

Expected: PASS all six historical programs.

- [ ] **Step 6: Commit**

```bash
git add app/src/main/assets/arcade-amie.js app/src/main/assets/arcade-classics.js app/src/main/assets/arcade-ball-drop.js app/src/main/assets/berry-blender.js app/src/main/assets/clefairy-memory.js tests/v0390-solo-reviews-amie-corner-stage.test.cjs
git commit -m "feat: add amie and game corner reviews"
```

### Task 7: Solo Review Migration — Discovery and Ekans

**Files:**
- Modify: `app/src/main/assets/arcade-fossil-museum.js`
- Modify: `app/src/main/assets/arcade-unown.js`
- Modify: `app/src/main/assets/arcade-quiz.js`
- Modify: `app/src/main/assets/arcade-ekans-hoop.js`
- Test: `tests/v0390-solo-reviews-discovery-ekans.test.cjs`

**Interfaces:**
- Consumes: Tasks 3–4 review/history API.
- Produces stable completed-run history for `fossil`, `unown`, `quiz`, `ekansHoop`.

- [ ] **Step 1: Write failing tests**

Assert:
- Fossil Dig stores kept/total finds, lost count, collapse/manual/complete outcome, already-awarded haul/reward summary, and never treats Museum Collection browsing as a run;
- Unown stores streak, mode, score, bank/cashout-or-failure outcome and PB comparison;
- Quiz stores mode, correct answers, score, final timer/streak facts and PB/perfect status;
- Ekans stores score, hoop total, streak, shiny hits and difficulty/tier facts;
- legitimate cash-out (Fossil manual end, Unown cashout) is recordable; ordinary back/close is not;
- card reveal flows still precede the final review where applicable;
- repeated completion/result display dedupes.

- [ ] **Step 2: Run test and verify RED**

Run: `node tests/v0390-solo-reviews-discovery-ekans.test.cjs`

Expected: FAIL because structured review/history is missing.

- [ ] **Step 3: Migrate Fossil, Unown, Quiz and Ekans**

Use existing authoritative pending/result structures; do not fabricate unavailable stats or alter reward math.

- [ ] **Step 4: Run test and verify GREEN**

Run: `node tests/v0390-solo-reviews-discovery-ekans.test.cjs`

Expected: PASS.

- [ ] **Step 5: Run historical regressions**

Run: `node tests/v0350-ekans-runtime.test.cjs && node tests/v03511-ekans-achievements.test.cjs && node tests/v0258-dig-card-booster.test.cjs && node tests/v0274-arcade-card-reveal.test.cjs`

Expected: PASS.

- [ ] **Step 6: Commit**

```bash
git add app/src/main/assets/arcade-fossil-museum.js app/src/main/assets/arcade-unown.js app/src/main/assets/arcade-quiz.js app/src/main/assets/arcade-ekans-hoop.js tests/v0390-solo-reviews-discovery-ekans.test.cjs
git commit -m "feat: add discovery and ekans reviews"
```

### Task 8: Rock Harden Normal Rebalance and Magikarp Quick Acceleration

**Files:**
- Modify: `app/src/main/assets/arcade-rock-harden-core.js`
- Modify: `app/src/main/assets/arcade-magikarp-splash-core.js`
- Test: `tests/v0390-rock-magikarp-balance.test.cjs`

**Interfaces:**
- Consumes: existing deterministic seeded core APIs.
- Rock profile target: Normal `{perfectRate:0.40, missRate:0.09, goodShare:0.84}`; Easy/Hard target behavior retained.
- Magikarp produces `CONFIG.quickFlightScale=0.84`; every lane tracks whether its current airborne jump is Quick; `flightMsForHold(holdMs, quick=false)` applies the scale only when Quick.

- [ ] **Step 1: Write failing Rock balance tests**

Over deterministic representative seeded samples assert:
- Normal Perfect rate centers around approved target with an acceptance band wide enough for deterministic variance (35–45%);
- Normal miss rate 6–12%;
- Normal Good count > Perfect count;
- Hard remains materially more precise than Normal and Easy remains materially less precise;
- CPU decisions do not inspect player score/HP/action state.

- [ ] **Step 2: Run Rock test and verify RED**

Run: `node tests/v0390-rock-magikarp-balance.test.cjs`

Expected: Rock assertions FAIL against v0.38.2 Normal `.575/.07/.76` constants.

- [ ] **Step 3: Retune Rock Normal constants only**

Set Normal `perfectRate:.40`, `missRate:.09`, `goodShare:.84`. Keep existing lead-time ranges unless deterministic tests prove they cannot produce the selected grade reliably; any necessary lead-range change must be ledgered as a ruling during execution.

- [ ] **Step 4: Run Rock balance assertions and verify GREEN**

Run: `node tests/v0390-rock-magikarp-balance.test.cjs`

Expected: Rock assertions PASS; Magikarp Quick assertions remain RED until Step 6.

- [ ] **Step 5: Add failing Magikarp Quick physics assertions**

Assert for the same hold duration:
- normal and Quick jumps have identical `heightForHold()` peak intent;
- Quick total flight is `normal * 0.84` within floating tolerance;
- Quick reaches counter-hit time and landing earlier;
- player queued-Quick and CPU successful-Quick both use the exact same scaled flight function;
- Quick timing window remains 110 ms early / 90 ms late;
- 20-second cutoff and pause timestamp shifting remain correct.

- [ ] **Step 6: Implement Quick flight scaling**

Add `CONFIG.quickFlightScale=.84`, a current-jump Quick flag on each lane, and route trajectory/counter/landing calculations through `flightMsForHold(holdMs, lane.currentJumpQuick)`. Reset the flag on normal jumps; preserve it through queued Quick start. Do not change hold-to-height mapping.

- [ ] **Step 7: Run balance/physics test and verify GREEN**

Run: `node tests/v0390-rock-magikarp-balance.test.cjs`

Expected: PASS all Rock and Magikarp assertions.

- [ ] **Step 8: Run historical gameplay regressions**

Run: `node tests/v0370-magikarp-core.test.cjs && node tests/v0370-magikarp-cpu.test.cjs && node tests/v0370-magikarp-lifecycle.test.cjs && node tests/v0380-rock-harden-cpu.test.cjs && node tests/v0381-rock-harden-polish.test.cjs`

Expected: PASS after updating only assertions explicitly frozen to the superseded Normal/Quick timing contract; do not weaken unrelated floors.

- [ ] **Step 9: Commit**

```bash
git add app/src/main/assets/arcade-rock-harden-core.js app/src/main/assets/arcade-magikarp-splash-core.js tests/v0390-rock-magikarp-balance.test.cjs
git commit -m "balance: tune rock normal and quick splash"
```

### Task 9: Release Identity, Full Verification and Source Package

**Files:**
- Modify: `package.json`
- Modify: `package-lock.json`
- Modify: `app/build.gradle`
- Modify: `app/src/main/assets/app-v0167.js`
- Modify: `app/src/main/assets/index.html`
- Modify: `README.md`
- Modify historical release tests only where exact-version or exact-result-shell assumptions are intentionally superseded.
- Create: `tests/v0390-release.test.cjs`
- Create: `TEST_REPORT_v0.39.0.md`
- Create artifact: `/mnt/data/LuckyDex_source_v0.39.0.zip`

**Interfaces:**
- Consumes: all previous tasks plus the v0.38.2 Dust Exchange baseline.
- Produces: verified v0.39.0 source ZIP and test report.

- [ ] **Step 1: Write failing release identity/preservation test**

Assert:
- package/app/build/visible build markers all say `0.39.0`, Android versionCode is `3900`, asset-builder User-Agent is `LuckyDex-asset-builder/0.39.0`;
- new records scripts/styles are loaded exactly once;
- all 14 supported review adapters exist;
- v0.38.2 Dust filters/Keep N/Convert Filtered contract remains present;
- current Kids Club four-game selector and all seven Rock Harden achievements remain present.

- [ ] **Step 2: Run release test and verify RED**

Run: `node tests/v0390-release.test.cjs`

Expected: FAIL on v0.38.2 identity.

- [ ] **Step 3: Bump all release markers to v0.39.0 / 3900 and update README**

README release notes must mention GAME REVIEW, ARCADE RECORDS/10-run history, Rock Normal rebalance, Magikarp Quick acceleration, and retained filtered Bulk Dust Exchange.

- [ ] **Step 4: Run release test and verify GREEN**

Run: `node tests/v0390-release.test.cjs`

Expected: PASS.

- [ ] **Step 5: Run every v0.39.0 focused test**

Run:
```bash
node tests/v0390-arcade-records-core.test.cjs && \
node tests/v0390-arcade-records-state.test.cjs && \
node tests/v0390-arcade-achievement-review.test.cjs && \
node tests/v0390-arcade-records-registry.test.cjs && \
node tests/v0390-arcade-session-review.test.cjs && \
node tests/v0390-arcade-records-ui.test.cjs && \
node tests/v0390-competitive-reviews.test.cjs && \
node tests/v0390-solo-reviews-amie-corner-stage.test.cjs && \
node tests/v0390-solo-reviews-discovery-ekans.test.cjs && \
node tests/v0390-rock-magikarp-balance.test.cjs && \
node tests/v0390-release.test.cjs
```

Expected: PASS all 11 non-browser focused programs.

- [ ] **Step 6: Run full suite and classify environment-only browser gaps**

Run: `npm test`

Expected: entire suite PASS when Playwright/browser support is installed. If failure is solely missing Playwright/browser harness, record exact unavailable programs and separately run every non-browser `.cjs` program; all available programs must PASS. Any non-browser assertion failure is a product regression and must be fixed before release.

- [ ] **Step 7: Run offline integrity and syntax checks**

Run all existing Python asset verifiers from `scripts/run-tests.cjs`, plus `node --check` for every JavaScript file changed or created by v0.39.0.

Expected: PASS.

- [ ] **Step 8: Android build capability check**

If `gradlew` exists, run the project’s normal Android assemble task and require success. If no Gradle wrapper exists, record the limitation exactly; do not claim APK compilation.

- [ ] **Step 9: Final review focus pass**

Deliberately re-check:
1. malformed/huge history payloads;
2. duplicate completion through result reopen/pause/replay;
3. stored review economy immutability;
4. unavailable/already-complete achievement snapshot cases;
5. old save/unknown game IDs and mobile 10-run navigation.

Critical/Important findings require one RED→GREEN fix pass and a green full available suite. Deferred minors go in the report.

- [ ] **Step 10: Write `TEST_REPORT_v0.39.0.md`**

Include focused counts, full available regression counts, browser availability, Android build capability, balance sample results, history/dedupe coverage, Dust preservation, review findings/rulings/deferred minors.

- [ ] **Step 11: Package the source ZIP**

Create `/mnt/data/LuckyDex_source_v0.39.0.zip` excluding `.git`, `.superpowers`, `node_modules`, build output, Python caches, temp extraction folders and old ZIPs. Keep the approved spec and implementation plan under `docs/superpowers/` in the archive.

- [ ] **Step 12: Reopen and verify the exact archive**

Extract the ZIP to a fresh directory and rerun `v0390-release.test.cjs`, all 11 focused non-browser tests, syntax checks, and ZIP integrity. Compute SHA-256 only after those checks pass.

- [ ] **Step 13: Commit**

```bash
git add package.json package-lock.json app/build.gradle app/src/main/assets/app-v0167.js app/src/main/assets/index.html README.md tests TEST_REPORT_v0.39.0.md docs/superpowers
git commit -m "release: LuckyDex v0.39.0 arcade records"
```

## Delivery

Provide:
- `/mnt/data/LuckyDex_source_v0.39.0.zip`
- `/mnt/data/TEST_REPORT_v0.39.0.md`
- SHA-256
- exact unavailable browser/build limitations
- any execution rulings/deferred minors
- Termux update commands:

```bash
cd ~/lucky-dex

cp /sdcard/Download/LuckyDex_source_v0.39.0.zip LuckyDex_source.zip

git add LuckyDex_source.zip
git commit -m "Update LuckyDex source to v0.39.0 - Arcade Records and Game Review"
git push
```
