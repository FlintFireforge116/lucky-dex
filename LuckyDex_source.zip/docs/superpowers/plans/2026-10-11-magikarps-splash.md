# Magikarp's Splash Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Ship LuckyDex v0.37.0 with a faithful Pokémon Stadium Magikarp's Splash game recreated in Gen III style, plus a modest three-game Kids Club selector polish.

**Architecture:** Add an isolated DOM-free `arcade-magikarp-splash-core.js` for jump physics, timing windows, CPU simulation, ranking and payouts, plus a browser owner `arcade-magikarp-splash.js` for lifecycle, input, rendering, pause/resume, persistence and Arcade session integration. Reuse Berry Blender's proven timing/input patterns by convention only; do not import or modify Berry Blender. Shared changes are limited to Arcade state/session/world metadata, achievements, index shell/includes, Kids Club-specific selector styling, and release identity.

**Tech Stack:** Vanilla JavaScript, HTML/CSS, Android WebView, Node `assert` test files run through `node scripts/run-tests.cjs`; optional Playwright browser tests when the repo dev dependency is available.

**Spec:** `docs/superpowers/specs/2026-10-11-magikarps-splash-design.md`

## Global Constraints

- Target release is `v0.37.0` with Android `versionCode 3700`.
- Preserve Ekans' Hoop Hurl, Dig! Dig! Dig!, and Berry Blender behavior; do not refactor those owners/cores.
- Magikarp uses the local `arcade/sprites/actors/pokemon/129.png` Gen III sprite at native 44×57 aspect ratio; scaling must remain proportional and pixel-crisp.
- Round length is exactly 20,000 ms; after cutoff no new jumps start, but jumps already airborne may finish and score.
- Quick Splash input window is 110 ms before touchdown through 90 ms after touchdown.
- Short taps cannot score; a deliberate hold can reach the overhead counter; a jump can score at most once.
- CPU behavior must be seeded/repeatable and independent of player score, phase, lead, or chain: no rubber-banding.
- CPU common score bands over 20 seconds: Easy 12–18, Normal 19–24, Hard 25–29 with occasional ~30.
- Use placement rewards identical to Dig! Dig! Dig!: Easy `[80,55,35,20]`, Normal `[100,70,45,25]`, Hard `[130,90,60,35]` for places 1–4.
- Tie placement is shared-rank: place is `1 + number of competitors with a strictly higher score`; a player tied for top is therefore 1st.
- Persistence key is `state.arcade.magikarpSplash` with `gamesPlayed`, `wins`, `podiums`, `bestScore`, `bestScores`, `winsByDifficulty`, and `bestQuickChain`.
- Achievements are: first win, Hard win, score 25+, and Quick Splash chain 10+.
- Other Arcade venue selectors must render exactly as before; the sprite/tile selector treatment applies only to `stadiumKidsClub`.

## Review Focus

- A press that arrives during the 110/90 ms landing buffer must queue exactly one rebound, even if release/pointer events arrive in an unusual order; duplicate pointer/keyboard events must not double-launch.
- The 20,000 ms cutoff must reject grounded launches after time while still allowing an already-airborne final counter hit and landing before results lock.
- Backgrounding while held, airborne, or inside the Quick Splash window must freeze all player/CPU/timer deadlines and resume without creating a phantom score or missed window.
- Ties must award shared placement and matching payout/achievement semantics rather than silently demoting the player due to stable-sort order.
- Old saves with missing or partially malformed nested Magikarp fields must migrate without erasing unrelated Arcade data or producing `undefined` difficulty records.

---

### Task 1: DOM-free jump physics and player timing core

**Files:**
- Create: `app/src/main/assets/arcade-magikarp-splash-core.js`
- Create: `tests/v0370-magikarp-core.test.cjs`

**Interfaces:**
- Produces: `window.LuckyDexMagikarpSplashCore` / CommonJS export with `CONFIG`, `DIFFICULTIES`, `REWARDS`, `difficultyProfile(key)`, `createRound({difficulty,rng,nowMs})`, `pressPlayer(round,nowMs)`, `releasePlayer(round,nowMs)`, `advanceRound(round,nowMs,rng)`, `rankRound(round)`, `placeFor(round,id)`, and `rewardFor(place,difficulty)`.
- Player lane state must expose enough read-only render data for Task 5: `score`, `quickChain`, `bestQuickChain`, `phase`, `y`, `held`, `jumpStartedAt`, `expectedLandingAt`, `counterHitThisJump`, `lastImpactAt`, and `lastQuickAt`.

- [ ] **Step 1: Write failing core behavior tests**

Add tests proving:
- `CONFIG.roundMs === 20000`, `CONFIG.quickEarlyMs === 110`, `CONFIG.quickLateMs === 90`;
- a short tap never increments score;
- a deliberate hold reaches the counter and increments once;
- continued hold / repeated advancement cannot score a second time during the same jump;
- an input inside the landing window produces an immediate rebound and increments `quickChain`;
- an input outside the landing window does not create a Quick Splash and grounded recovery applies;
- `rewardFor()` returns the exact Dig reward tables;
- shared-rank placement returns 1st for a player tied for the highest score.

- [ ] **Step 2: Run core test and verify RED**

Run: `node tests/v0370-magikarp-core.test.cjs`

Expected: FAIL because `arcade-magikarp-splash-core.js` does not exist / required exports are missing.

- [ ] **Step 3: Implement minimal deterministic player jump core**

Implement the exported interfaces above. Use timestamp/delta-based deterministic physics; frame rate must not change score/timing outcomes. A press while grounded starts a jump, release stops hold boost, and a valid buffered landing press queues exactly one next jump. Cap hold boost so indefinite hold cannot create extra score opportunities.

- [ ] **Step 4: Re-run core test**

Run: `node tests/v0370-magikarp-core.test.cjs`

Expected: PASS.

- [ ] **Step 5: Run project suite**

Run: `npm test`

Expected: existing suite remains green, aside from the already-known environment-only Playwright limitation if dependencies are unavailable.

### Task 2: Seeded CPU opponents, cutoff, distributions and fair ranking

**Files:**
- Modify: `app/src/main/assets/arcade-magikarp-splash-core.js`
- Modify: `tests/v0370-magikarp-core.test.cjs`
- Create: `tests/v0370-magikarp-cpu.test.cjs`

**Interfaces:**
- Consumes: Task 1 core exports and lane model.
- Produces: `advanceRound()` that drives all three CPU lanes independently, enforces the 20-second launch cutoff/final-airborne completion rule, and exposes `round.finalized`, `round.finishedAt`, and deterministic ranking data.

- [ ] **Step 1: Write failing CPU/cutoff tests**

Add tests that prove:
- same seed + same timestamps produces identical CPU scores/chains;
- changing only player score/chain/phase does not alter CPU state under the same seed/timestamps;
- no CPU or player grounded jump may start after 20,000 ms;
- an already-airborne jump at 20,000 ms may still hit the counter and finish before `round.finalized` becomes true;
- results finalize only after every active airborne jump is resolved;
- over seeds 1–200, at least 70% of Easy scores land in 12–18 and median lies 14–16;
- at least 70% of Normal scores land in 19–24 and median lies 20–23;
- at least 70% of Hard scores land in 25–29, median lies 26–28, and at least one seed scores 30 or 31;
- target bands overlap naturally and scores are not hard-clamped.

- [ ] **Step 2: Run CPU test and verify RED**

Run: `node tests/v0370-magikarp-cpu.test.cjs`

Expected: FAIL because CPU simulation/cutoff behavior is not yet implemented.

- [ ] **Step 3: Implement CPU profiles and round finalization**

Drive each CPU from its own generated hold accuracy, landing accuracy, miss/hesitation behavior, and next-action deadlines. Never read `round.player` when choosing CPU actions. Keep all randomness routed through the supplied RNG.

- [ ] **Step 4: Run core + CPU tests**

Run: `node tests/v0370-magikarp-core.test.cjs && node tests/v0370-magikarp-cpu.test.cjs`

Expected: PASS.

- [ ] **Step 5: Run project suite**

Run: `npm test`

Expected: existing suite remains green, subject only to the environment Playwright caveat.

### Task 3: Save migration, Arcade session metadata and achievements

**Files:**
- Modify: `app/src/main/assets/arcade-platform.js`
- Modify: `app/src/main/assets/arcade-session.js`
- Modify: `app/src/main/assets/achievements-v0341.js`
- Create: `tests/v0370-magikarp-state-achievements.test.cjs`

**Interfaces:**
- Consumes: persistence shape from the spec.
- Produces: `state.arcade.magikarpSplash` with safe nested defaults and four achievements keyed from persisted values.

- [ ] **Step 1: Write failing migration/session/achievement tests**

Assert:
- `ensureArcadeState({})` creates the exact Magikarp record defaults;
- partial objects preserve valid existing values while filling `bestScores.easy|normal|hard` and `winsByDifficulty.easy|normal|hard`;
- unrelated Arcade state survives migration untouched;
- `GAME_RULES.magikarpSplash` describes a 20-second timing score attack and placement Lucky Coins;
- achievements exist for first win, Hard win, 25 score, and 10 Quick chain, and cannot trigger from missing/NaN values.

- [ ] **Step 2: Run state test and verify RED**

Run: `node tests/v0370-magikarp-state-achievements.test.cjs`

Expected: FAIL because Magikarp state/session/achievement entries do not exist.

- [ ] **Step 3: Add defaults, nested migration, session rule and achievements**

Use defaults:
`{gamesPlayed:0,wins:0,podiums:0,bestScore:0,bestScores:{easy:0,normal:0,hard:0},winsByDifficulty:{easy:0,normal:0,hard:0},bestQuickChain:0}`.

Achievement IDs/rewards:
- `magikarp_first_win` — 200 coins;
- `magikarp_hard_win` — 600 coins + 30 dust;
- `magikarp_score_25` — 900 coins + 60 dust;
- `magikarp_quick_10` — 700 coins + 40 dust.

- [ ] **Step 4: Run state test**

Run: `node tests/v0370-magikarp-state-achievements.test.cjs`

Expected: PASS.

- [ ] **Step 5: Run project suite**

Run: `npm test`

Expected: existing suite remains green, subject only to environment Playwright availability.

### Task 4: Third Kids Club registration, DOM shell and selector treatment

**Files:**
- Modify: `app/src/main/assets/arcade-world.js`
- Modify: `app/src/main/assets/arcade.css`
- Modify: `app/src/main/assets/index.html`
- Create: `tests/v0370-magikarp-integration.test.cjs`
- Create: `tests/v0370-kids-club-selector.test.cjs`

**Interfaces:**
- Consumes: future owner global `window.LuckyDexMagikarpSplash` from Task 5.
- Produces: game ID `magikarpSplash`, Kids Club order `['ekansHoop','digDigDig','magikarpSplash']`, owner resolver, exact Magikarp DOM IDs, script/style includes, and Kids Club-only selector cards.

- [ ] **Step 1: Write failing integration/selector tests**

Assert:
- `stadiumKidsClub.games` contains the exact three-game order and still includes Ekans/Dig;
- `GAME_NAMES.magikarpSplash === "Magikarp’s Splash"` and objective describes hold/landing rhythm;
- owner resolves to `window.LuckyDexMagikarpSplash`;
- the Magikarp stylesheet, core, and owner are included with core before owner and owner before `arcade-world.js`;
- `index.html` contains `magikarpSplashGame`, stage, HUD, four lanes, four score counters/switches, countdown, ready state, difficulty controls, one `magikarpSplashButton`, pause overlay, and standings/results staging IDs required by Task 5;
- Kids Club selector buttons include 23.png, 27.png, and 129.png plus concise mechanics; non-Kids-Club venue rendering remains the generic legacy markup.

- [ ] **Step 2: Run integration tests and verify RED**

Run: `node tests/v0370-magikarp-integration.test.cjs && node tests/v0370-kids-club-selector.test.cjs`

Expected: FAIL because the third game/shell/selector treatment does not exist.

- [ ] **Step 3: Register Magikarp and add shell/selector markup**

Keep `renderVenue()` generic for every other venue. Branch only for `id === 'stadiumKidsClub'`, adding the three local Pokémon sprite tiles while retaining `data-venue-game` so navigation remains unchanged.

- [ ] **Step 4: Run integration tests**

Run: `node tests/v0370-magikarp-integration.test.cjs && node tests/v0370-kids-club-selector.test.cjs`

Expected: PASS.

- [ ] **Step 5: Run project suite**

Run: `npm test`

Expected: existing suite remains green, subject only to environment Playwright availability.

### Task 5: Browser owner lifecycle, touch/keyboard input, pause and exactly-once completion

**Files:**
- Create: `app/src/main/assets/arcade-magikarp-splash.js`
- Create: `tests/v0370-magikarp-runtime.test.cjs`
- Create: `tests/v0370-magikarp-lifecycle.test.cjs`

**Interfaces:**
- Consumes: Task 1/2 core and Task 4 DOM IDs; `LuckyDexArcadeSession`, `LuckyDexArcadePlatform`, `LuckyDexArcadeWorld`.
- Produces: `window.LuckyDexMagikarpSplash` with `open()`, `close()`, `showReady({difficulty})`, `startRound({difficulty,countdownMs})`, `press()`, `release()`, `pause()`, `resume()`, `finishRound()`, `selectDifficulty(key)`, and `snapshot()`.

- [ ] **Step 1: Write failing runtime tests**

Assert:
- open mounts the Arcade session and enters ready state;
- `3→2→1→SPLASH!` countdown transitions to running;
- pointer press/release maps to core press/release;
- Space/A work and repeated OS keydown (`event.repeat === true`) does nothing;
- pointer cancel/up cannot synthesize duplicate launch events;
- render snapshot exposes player/CPU score, y/phase, timer, place, difficulty, quick chain and final state.

- [ ] **Step 2: Run runtime test and verify RED**

Run: `node tests/v0370-magikarp-runtime.test.cjs`

Expected: FAIL because owner does not exist.

- [ ] **Step 3: Implement owner ready/running/render/input loop**

Follow Berry Blender/Dig patterns: `requestAnimationFrame`, single owned loop, short-lived class feedback, no direct dependency on `LuckyDexBerryBlender`, and one-thumb pointer ownership on the SPLASH control.

- [ ] **Step 4: Run runtime test**

Run: `node tests/v0370-magikarp-runtime.test.cjs`

Expected: PASS.

- [ ] **Step 5: Write failing lifecycle/completion tests**

Assert:
- pause freezes timer, player physics, CPU deadlines, cutoff and Quick Splash windows;
- resume shifts all absolute deadlines by the paused duration;
- close/abandon before completion awards/persists nothing;
- completion increments `gamesPlayed`, podium/win counters, per-difficulty best score/win, and `bestQuickChain` correctly;
- payout uses shared placement + exact difficulty reward table;
- completion/save/award occurs exactly once even if `finishRound()` / late animation frames fire again;
- replay resets to a fresh 0-score round with the same chosen difficulty.

- [ ] **Step 6: Run lifecycle test and verify RED**

Run: `node tests/v0370-magikarp-lifecycle.test.cjs`

Expected: FAIL until lifecycle/completion code is implemented.

- [ ] **Step 7: Implement pause/resume and exactly-once completion**

Use the existing completion-guard pattern or equivalent owner-local guard. Show ranked four-player score details through `LuckyDexArcadeSession.showResult()` and route replay/back through the existing Kids Club owner contract.

- [ ] **Step 8: Run runtime + lifecycle tests**

Run: `node tests/v0370-magikarp-runtime.test.cjs && node tests/v0370-magikarp-lifecycle.test.cjs`

Expected: PASS.

- [ ] **Step 9: Run project suite**

Run: `npm test`

Expected: existing suite remains green, subject only to environment Playwright availability.

### Task 6: Gen III presentation, responsive four-lane layout and mobile QA guards

**Files:**
- Create: `app/src/main/assets/arcade-magikarp-splash.css`
- Modify: `app/src/main/assets/index.html` only if presentation-required class hooks were missing from Task 4
- Create: `tests/v0370-magikarp-presentation.test.cjs`
- Create: `tests/v0370-magikarp-browser.test.cjs`

**Interfaces:**
- Consumes: Task 4 DOM and Task 5 render classes/CSS custom properties.
- Produces: Gen III stage styling and browser/mobile validation.

- [ ] **Step 1: Write failing static presentation tests**

Assert:
- all four lane sprites use `arcade/sprites/actors/pokemon/129.png`;
- CSS preserves Magikarp's 44:57 aspect ratio using proportional dimensions and `image-rendering: pixelated` / project equivalent;
- `magikarpSplashButton` has at least a 64px visual height on mobile and `touch-action: none`;
- CSS includes distinct classes/hooks for held launch, counter hit, `+1`, Quick Splash, landing splash, countdown and finish state;
- lane grid uses four columns without fixed widths that force page-level horizontal scroll;
- no new rounded/glossy card treatment is introduced inside the gameplay field.

- [ ] **Step 2: Run presentation test and verify RED**

Run: `node tests/v0370-magikarp-presentation.test.cjs`

Expected: FAIL because Magikarp CSS is not implemented.

- [ ] **Step 3: Implement Gen III CSS**

Use existing local Hoenn/Gen III water tiles where compatible; use CSS/pixel primitives for platform, counter, switch and particles. Keep all sprite transforms proportional and use translate/rotate/squash container effects rather than independently stretching the image axes.

- [ ] **Step 4: Run static presentation test**

Run: `node tests/v0370-magikarp-presentation.test.cjs`

Expected: PASS.

- [ ] **Step 5: Add browser/mobile test**

When Playwright is available, verify at a representative Android portrait viewport that all four competitors and the SPLASH control fit without document-level horizontal scrolling, pointer input is owned by the game, and countdown → running → scoring/finish classes appear. If Playwright is unavailable, the test must report an explicit environment skip rather than a false pass.

- [ ] **Step 6: Run browser test**

Run: `node tests/v0370-magikarp-browser.test.cjs`

Expected: PASS when Playwright is installed; otherwise explicit `SKIP` for missing dependency only.

- [ ] **Step 7: Run focused v0.37.0 checks**

Run: `node tests/v0370-magikarp-core.test.cjs && node tests/v0370-magikarp-cpu.test.cjs && node tests/v0370-magikarp-state-achievements.test.cjs && node tests/v0370-magikarp-integration.test.cjs && node tests/v0370-kids-club-selector.test.cjs && node tests/v0370-magikarp-runtime.test.cjs && node tests/v0370-magikarp-lifecycle.test.cjs && node tests/v0370-magikarp-presentation.test.cjs && node tests/v0370-magikarp-browser.test.cjs`

Expected: all non-browser checks PASS; browser test PASS or explicit environment-only SKIP.

### Task 7: Release identity, documentation and historical-test future-proofing

**Files:**
- Modify: `package.json`
- Modify: `app/build.gradle`
- Modify: `app/src/main/assets/app-v0167.js`
- Modify: `app/src/main/assets/index.html`
- Modify: `README.md`
- Create: `tests/v0370-release.test.cjs`
- Modify: historical release/integration tests only where they incorrectly assert an exact old version or exactly two Kids Club games

**Interfaces:**
- Produces: coherent `0.37.0` / `3700` release identity without weakening historical feature floors.

- [ ] **Step 1: Write failing release test**

Assert `package.json` version `0.37.0`, Gradle `versionCode 3700` / `versionName '0.37.0'`, `window.__LUCKYDEX_BUILD='0.37.0'`, visible title/version strings `v0.37.0`, and User-Agent release marker `0.37.0`.

- [ ] **Step 2: Run release test and verify RED**

Run: `node tests/v0370-release.test.cjs`

Expected: FAIL on current v0.36.1 markers.

- [ ] **Step 3: Bump release identity and README**

README top section must summarize Magikarp's Splash, Gen III Kids Club selector polish, verification status, and link to `TEST_REPORT_v0.37.0.md` once produced.

- [ ] **Step 4: Run release test**

Run: `node tests/v0370-release.test.cjs`

Expected: PASS.

- [ ] **Step 5: Run full suite and inspect failures**

Run: `npm test`

Expected: real regressions = 0. If historical tests fail only because they freeze `0.36.1` or exactly two Kids Club entries, update those assertions to enforce their original minimum behavior while permitting later versions/games; do not suppress gameplay assertions.

### Task 8: Final verification, report and source package

**Files:**
- Create: `TEST_REPORT_v0.37.0.md`
- Create outside repo root: `/mnt/data/LuckyDex_source_v0.37.0.zip`

**Interfaces:**
- Consumes: completed v0.37.0 tree.
- Produces: verified source archive, report, checksum, and established Termux upload command.

- [ ] **Step 1: Run final focused verification**

Run the nine v0.37.0 tests from Task 6 plus `tests/arcade-platform.test.cjs`, `tests/arcade-session.test.cjs`, Dig v0.36.0/v0.36.1 tests, Ekans integration/runtime tests, and Berry touch regression.

Expected: all available non-browser tests PASS; any browser skip is explicitly limited to unavailable Playwright.

- [ ] **Step 2: Run full available regression suite**

Run: `npm test`

Expected: 0 product assertion failures. If the environment cannot install Playwright, separately run every non-Playwright test and record exact PASS/SKIP counts in the report.

- [ ] **Step 3: Check Android build capability**

If `./gradlew` exists, run the repo's Android build/test target used by prior releases. If the wrapper is absent, record that as a source-bundle environment limitation; do not claim APK compilation passed.

- [ ] **Step 4: Write `TEST_REPORT_v0.37.0.md`**

Include focused counts, wider regression counts, browser/Gradle environment limitations, CPU distribution sample results, release identity, and any final-review rulings/deferred minors.

- [ ] **Step 5: Perform final whole-change review**

Review against the spec and this plan with special attention to the five Review Focus items. Any Critical/Important finding gets one RED→GREEN fix pass plus a green regression run before packaging.

- [ ] **Step 6: Package source**

Create `/mnt/data/LuckyDex_source_v0.37.0.zip` from the verified tree, excluding `.git`, `node_modules`, build outputs, caches, temporary workspaces and previous packaged ZIPs.

- [ ] **Step 7: Reopen and verify archive**

Verify ZIP integrity and inspect version markers/files from inside the archive, including `0.37.0`, `3700`, Magikarp core/owner/CSS/tests, design/spec/plan, and `TEST_REPORT_v0.37.0.md`.

- [ ] **Step 8: Produce checksum and Termux block**

Compute SHA-256 and provide:

```bash
cd ~/lucky-dex

cp /sdcard/Download/LuckyDex_source_v0.37.0.zip LuckyDex_source.zip

git add LuckyDex_source.zip
git commit -m "Update LuckyDex source to v0.37.0 - Magikarps Splash"
git push
```
