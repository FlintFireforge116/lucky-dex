# LuckyDex v0.25.5 — lifecycle, Wild chain persistence + archaeology art

LuckyDex v0.25.5 is a focused stability/content patch on top of v0.25.4.

## Changes

- Backgrounding the Android app / opening Recent Apps no longer exits the active Arcade minigame. The WebView is paused without navigating back to the venue, so in-memory game progress remains on screen when the app resumes.
- Wild Roam FIELD CHAIN is now durable per destination instead of living only inside the disposable roam screen.
- Catching a Pokémon extends the chain by one.
- Knocking out the wild Pokémon, fleeing/running away, or losing the party resets that destination's chain to zero.
- Leaving Wild Roam, changing pages, opening menus, or returning later does not itself break the chain.
- Existing v0.25.4 active-roam chains are migrated into the durable destination record on first load.
- Comet Shard and the complete Relic family (Copper, Silver, Gold, Vase, Band, Statue, Crown) now use their real packaged Pokémon item sprites rather than simplified LuckyDex stand-ins.
- Fossil Dig and the Museum share the same v0.25.5 local item-art namespace.

## Android identity

- applicationId: `com.example.luckydex`
- versionCode / versionName: `255` / `0.25.5`
- permanent keystore SHA256: `90de91cea469f0eec5fbd69389cf03adc94ced396fa2ec85e2a51d2365a4f6d3`

Use the existing GitHub Actions workflow to build the APK. This source archive retains the permanent LuckyDex signer so it updates the existing installation.
