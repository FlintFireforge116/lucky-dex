## v0.40.24 — Sushi-Go-Round

Sushi-Go-Round joins Stadium Kids Club as the ninth minigame. Four Lickitung sit around a circular conveyor carrying twelve plates. The player owns one station and taps EAT as plates arrive, choosing between eight food values while trying to build same-sushi chains up to x5. Hot Tea is worth very little and stuns Lickitung for 1.8 seconds, breaking the rhythm of greedy eating.

Rounds last one minute. Easy, Normal and Hard CPUs differ in willingness to eat, value awareness, combo preference and hot-food avoidance. Results award Lucky Coins by place and feed the standard Game Review, durable Arcade Records and five Sushi-Go-Round achievements: Big Spender, Conveyor Connoisseur, Sushi Master, Same Again! and High Roller.

Existing Kids Club games, including the v0.40.23 top-down Run, Rattata, Run redesign, are preserved.

See `TEST_REPORT_v0.40.24.md` for verification details.
