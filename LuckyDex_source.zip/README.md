## v0.40.10 — Authentic Kanto journey maps

Kanto Adventure locations now resolve to canonical FireRed/LeafGreen map captures for every authored journey stop, with intelligent cropping for long routes and the existing packaged scenes retained as offline/error fallbacks. The Kanto journey map likewise prefers canonical region art with a local fallback.

This pass also removes the obsolete Gold Rock secret achievement (including stale saved claims and old Arcade review rows), removes the Gold Rock square outline, and clarifies that Shiny Unown can award any TCG/TCGP card beginning with its letter rather than implying a shiny card reward.

## v0.40.9 — Rare reward reveals and test odds polish

Shiny Unown now uses a sprite-only shiny treatment with no circular halo and keeps
won card reveals banked until the Arcade result sheet. Tile Puzzle card, booster
and Mystery Gift rewards use the same pre-results reveal stage; presents use a
small transparent in-game-style gift marker and identify their actual contents
instead of the generic `Puzzle Present` label.

Settings also expose saved Gold Rock (vanilla 10%), Fossil Dig card (15%) and
Fossil Dig booster (4%) odds alongside the v0.40.8 rare-event controls. Production
defaults remain unchanged and saved attempts continue to obey the existing
ROLL ONCE -> PERSIST -> CLAIM ONCE contract. See `TEST_REPORT_v0.40.9.md`.

## v0.40.3 — Authored Adventure scenes and navigation

Adventure locations now use bounded 4:3 native scene windows, distinct early
settlement compositions and a static packaged player marker. Route 124 has an
intentional shoreline and water-rock composition. Local destination actions
suppress duplicate footer travel; unchallenged Gyms can return to their cities
without advancing, healing or paying rewards. Concise world objectives replace
engine-gating copy. The first Johto badge now reads clearly through Route 32.

Accepted Battle, Party, Moves/TM, Mart, Wild Hunt and regional engine code remain
unchanged. See `TEST_REPORT_v0.40.3.md`, `docs/ADVENTURE_SCENE_NAV_FLOW_V0403.md`,
`docs/ADVENTURE_LOCATION_SCENES_V0403.md` and the independent review.
Run `node scripts/adventure3-test-inventory.cjs --output=artifacts/v0403` for the
focused gate, or add `--all` to continue through all historical programs.
Use `scripts/adventure-scene-nav-acceptance-v0403.cjs` for the actual first Gym to
Route 32 viewport matrix. The scene builder and pixel verifier run offline from
packaged pinned inputs. Android builds use the original development signer;
set `LUCKYDEX_PYTHON` to installed Python before `scripts/build-android-v0403.ps1`.

## v0.40.2 — Adventure places and travel

Adventure now presents named places with native Gen III vignettes, valid local
choices, a separate Party/Bag/Map strip and explicit travel to the next destination.
Johto’s first chapter passes through Routes 30 and 31, Sprout Tower, Violet City
and Violet Gym on the existing persistent node IDs. Routine messages stay local,
can be dismissed, and clear on travel. Homes and supported Centers provide optional
recovery; healing never gates a Gym. Accepted v0.40.1 Battle, Party, TM and Mart
implementations remain intact.

See `TEST_REPORT_v0.40.2.md`, `docs/ADVENTURE_LOCATION_FLOW_V0402.md`,
`docs/ADVENTURE_LOCATION_SCENES_V0402.md`, and the independent review. The scene
builder uses the packaged pinned Emerald source cache; no network is needed.
Run `node scripts/adventure3-test-inventory.cjs --output=artifacts/v0402` for the
focused gate or add `--all` for the continuing historical inventory. The latter
retains the documented inherited failures. Set `NODE_PATH` to the installed
Playwright runtime when it is not installed locally, and `LUCKYDEX_PYTHON` to an
installed Python executable for the Android build. Chrome browser QA does not
replace physical Android/WebView testing.

## v0.40.1 — Gen III Adventure menus

Adventure now uses compact handheld-style windows: fast 2×2 battle moves with
one detail strip, custom paged Pokémon/TM pickers, three selectable Party slots,
and MOVES / LEARN / TM CASE tabs. Routine interactions return to real-location
menus with brief inline feedback; Gym and League milestones retain results.
Town, route and special-area actions are contextual, with concise place/next/
party status and substantially less scrolling. The v0.40.0 mechanics, journey
saves, claim protections, transactions, local assets and signer are retained.

See `TEST_REPORT_v0.40.1.md` and `docs/ADVENTURE_UX_V0401.md`. On Windows, set
`LUCKYDEX_PYTHON` to an installed Python executable before building. The Gradle
catalog task retains supplied JSON bytes when regenerated data is identical.
The historical full runner still includes inherited failures; the focused
Adventure inventory is the release regression gate, not a claim that all old
Arcade/browser fixtures pass.

## v0.40.0 — Adventure 3.0

One Adventure home now owns persistent Kanto, Johto and Hoenn journeys, Wild Hunt, Party, Bag, Moves and Poké Mart. Authored locations and permanent badges replace disposable regional runs. Defeat returns to a safe checkpoint; already claimed rewards stay claimed. Old Expedition is retired without paying unclaimed rewards. Move priority and Speed now determine normal battle order.

See `TEST_REPORT_v0.40.0.md`, `docs/ADVENTURE_JOURNEYS_V040.md`, `docs/ADVENTURE_BALANCE_V040.md`, and `docs/ADVENTURE_BATTLE_V040.md`.

## v0.39.1 — On-device Arcade & Pack stability

- Repairs the shared Arcade RUN / REWARD / LIVE strip and Berry Picker phone layout so the playfield owns the available height instead of the HUD.
- Fossil Dig is scroll-safe on short phones and uses Cranidos as the Oreburgh header mascot instead of the tiny Odd Keystone item sprite.
- Ekans’ Hoop Hurl now has a visible 3-2-1 countdown; no Diglett/Dugtrio targets spawn until it reaches zero.
- Dig! Dig! Dig! removes the 4-second grace cutoff: the race clock keeps running after the player finishes and the review waits for all four racers to finish.
- Retires the old Poké Ball Drop 5/10 Jackpot achievements so they cannot appear in unrelated GAME REVIEW sheets.
- Pack preparation retries recoverable collation failures, records the failing set/phase for diagnostics, explicitly confirms that preparation failures spend nothing, and revalidates the entitlement at the charge boundary.

See `TEST_REPORT_v0.39.1.md` for verification and environment limitations.

## v0.39.0 — Arcade Records & Game Review

- Every finished Arcade game now feeds a shared **GAME REVIEW** screen with the meaningful scoreboard or run facts for that game, while reward/card reveal settlement remains unchanged.
- The Arcade hub adds **ARCADE RECORDS** with permanent PB/career summaries plus the **10 most recent completed runs per game**. Stored reviews are read-only and cannot re-award rewards or achievements.
- Competitive reviews use the authoritative finish/standing order from each game; Pokémon Dash Type League stores one review for the completed three-race cup rather than one per race.
- Rock Harden Normal CPU timing is rebalanced to roughly 40% Perfect / 9% misses, making Good the more common successful Normal result while Hard remains the mastery tier.
- A successful Magikarp Quick Splash now uses **84% of normal flight duration** with the same height mapping and timing windows, so clean rebounds can genuinely recover ground.
- Clefairy failed sequences now end on a GAME REVIEW instead of silently auto-resetting.
- v0.38.2's filtered bulk Dust Exchange is retained unchanged: Set/Rarity/Dust/name filters, remembered Keep Copies, protected-card exclusion and atomic **CONVERT FILTERED** confirmation.

See `TEST_REPORT_v0.39.0.md` for verification and environment limitations.

## v0.38.2 — Filtered bulk Dust Exchange

- Dust Exchange adds Set, Rarity, Dust Value and name/collector-number filters with AND-combined matching.
- A remembered **Keep Copies** value (default 3, minimum 1) controls bulk salvage: only filtered eligible copies above that keep count are converted.
- **Convert Filtered** shows live card-type/copy/Dust totals and requires a detailed confirmation listing every affected card before mutation.
- The confirmation is an atomic snapshot: if collection counts or Dust values change before confirmation, the batch aborts rather than converting a different set of cards.
- Achievement Reward/protected cards remain excluded; the existing per-card quantity/MAX conversion remains available.
- Filters reset whenever Dust Exchange is reopened; the Keep Copies preference persists in the save.

See `TEST_REPORT_v0.38.2.md` for verification and environment limitations.

## v0.38.1 — Rock Harden phone polish

Rock Harden joins Pokémon Stadium · Kids Club as a Gen III/GBA-style survival game. Each round randomly assigns four unique Pokémon from the curated cocoon/armoured roster, with identical mechanics for every species. Late Harden timing earns Perfect / Good / Safe grades while continuous Harden drains HP. A rare 10% Gold Rock can award Coins, Dust, a Pack Ticket, a random tier-weighted card, or a sealed booster when blocked with a Perfect Harden.

Card and booster prizes reuse LuckyDex's existing Fossil Dig rarity/eligibility resolver paths, with an offline-safe fallback so an earned Gold Rock prize cannot disappear because a resolver fails.

See `TEST_REPORT_v0.38.1.md` for verification and environment limitations once the release report is generated.

## v0.37.1 — Kids Club achievement expansion

- Dig! Dig! Dig! adds Excavation Crew (25 races), Three Layers Down (win on Easy/Normal/Hard), and the secret Mole Machine mastery challenge for a 7.50-second-or-faster finish.
- Magikarp’s Splash adds Splash Veteran (10 wins), Master of the Pond (win on Easy/Normal/Hard), and the secret Thirty Splash Salute for scoring 30+ in one round.
- Existing Dig and Magikarp achievements remain intact; the expansion uses already-persisted stats, so no gameplay or save migration changes are required.

See `TEST_REPORT_v0.37.1.md` for verification and environment limitations.

## v0.37.0 — Magikarp’s Splash

- Adds Magikarp’s Splash as the third Pokémon Stadium Kids Club game: a faithful 20-second hold-and-landing timing challenge rebuilt in Gen III Hoenn style.
- Four Magikarp compete simultaneously with Easy/Normal/Hard COM opponents, shared-rank ties, placement rewards, Quick Splash chains and fair seeded CPU behavior with no rubber-banding.
- Uses the local Gen III #129 sprite and local Hoenn water tiles with crisp pixel scaling, switch impacts, +1 feedback, landing splashes and a one-thumb SPLASH control.
- Kids Club now has a dedicated three-game Gen III selector for Ekans’ Hoop Hurl, Dig! Dig! Dig! and Magikarp’s Splash; other Arcade venues retain their existing selector treatment.
- Persistence tracks wins, podiums, best scores by difficulty and best Quick Splash chain, with four new Arcade achievements.

See `TEST_REPORT_v0.37.0.md` for verification and environment limitations.

## v0.36.1 — Dig! Dig! Dig! difficulty & Gen III polish

- Hard Kids Club difficulty is now a genuine high-speed challenge: COM Sandshrew use a much tighter independent cadence with fewer errors/hesitations, while Easy and Normal retain their v0.36.0 balance. No rubber-banding was added.
- All four Sandshrew now show short alternating dig poses and per-hit dirt bursts instead of static/latched feedback.
- The race shafts gain clearer depth treatment and incremental progress strips, while the NEXT prompt now highlights the required L/R control.
- The 80-dig breakthrough uses the local Gen III animated shore-water tile and a short Sandshrew finish pop instead of the previous flat blue block.
- Mobile touch ownership, 35×39 native sprite proportions, persistence, rewards and Kids Club routing are unchanged.

See `TEST_REPORT_v0.36.1.md` for verification and environment limitations.

## v0.34.7 — Pocket bonus-card collation generalisation

- Pocket +1-card behavior is now data-driven across every applicable set instead of being hard-coded to Fantastical Parade.
- Wisdom of Sea and Sky (`A4`) and Secluded Springs (`A4a`) use their 8.330% sixth-card variants and restrict those bonus-only baby Pokémon to the bonus position.
- Mega Rising through Team Rocket’s Ambition use the 5.238% sixth-card mechanic; One Shiny / Two Shiny cards are bonus-only in those products.
- Mega Shine additionally allows its bonus-only immersive Mew #086 in the sixth slot with a dedicated branch alongside its shiny pool.
- Deluxe Pack: Mega (`B4b`) remains a four-card pack normally, with a 1.666% chance of a fifth Two Shiny card. Deluxe Pack: ex (`A4b`) remains four cards with no +1 variant.
- LuckyDex deliberately keeps its own God Pack rule at 1/1,000. Authentic pack mechanics are retained without importing Pocket's pack timers, paid access or monetisation limits.

See `TEST_REPORT_v0.34.7.md` for verification and environment limitations.

## v0.34.6 — Fantastical Parade bonus + legacy WotC collation

- Fantastical Parade regular packs now have the authentic 5.238% chance to add a sixth bonus card.
- The sixth slot is restricted to One Shiny / Two Shiny cards, weighted 68.18% / 31.82%.
- Jungle and Fossil use canonical collector-number rarity bands during collation, preventing bad upstream metadata from leaking extra rares into common/uncommon slots.
- Offline Pocket packs preserve a legitimate sixth bonus card instead of truncating back to five.

See `TEST_REPORT_v0.34.6.md` for verification and environment limitations.

## v0.34.5 — Live pack collation hardening

- Fixed the live descriptor picker so a failed slot match stays rejected instead of being converted to `true` by the fallback expression.
- Classic WotC boosters now enforce Common/Uncommon/Rare membership at the final card-selection step, including fallback selection.
- 30th Celebration's guaranteed Pikachu slot can no longer silently fall back to an arbitrary set card; if no valid Pikachu candidate exists, pack construction fails safely instead of shipping an invalid pack.
- The same hard constraints apply to online, offline-cached and stored booster openings because all three use the shared descriptor picker.

See `TEST_REPORT_v0.34.5.md` for verification and environment limitations.


## v0.34.4 — Pack collation tightening

- WotC-era 11-card boosters now enforce 7 Common + 3 Uncommon + exactly 1 Rare/Holo-or-better slot without rarity leakage.
- 30th Celebration now opens as 4 general foil cards + 1 guaranteed Pikachu Rare + 1 guaranteed foil Basic Energy.
- The guaranteed Pikachu slot recognizes both the printed `Pikachu Rare` label and collector numbers 23–52, so catalogue rarity flattening cannot break the guarantee.
- 30th Celebration Basic Energy inserts use the MEE 009–016 identities/artwork.


Physical TCG boosters now resolve through a data-driven product policy instead of set-size heuristics: classic 11-card, e-Card/EX 9-card, standard 10-card and special-product profiles have their own collation and Lucky Coin prices. Trainer/Radiant/Galarian/Shiny/Classic subsets feed their real parent products instead of appearing as fake standalone boosters. Online and offline openings share the same slot policy; TCG Pocket keeps its separate positional 4/5-card branch, while God Pack remains a 1/1,000 pack-level event.

The rarity classifier now audits historic, modern and Pocket labels, gives LEGEND a dedicated top-end historical chase treatment, and separates reveal drama so Illustration Rare is clearly above Ultra Rare and Double Rare, with SIR/Secret/Gold/Crown escalating further. Global Link Trades rotate on each local clock hour. Pokémon Dash gets faster steering response, sprint re-arm/recovery, racer separation, one-shot berry pickups, position/final-stretch feedback and distinct authored mechanics across all 18 Type League courses while keeping the v0.34.0 Gen III visual foundation.

See `TEST_REPORT_v0.34.4.md` for exact verification and environment limitations.


## v0.34.2 — Card Binder set picker

Replaces the Android-native set dropdown with a LuckyDex-styled in-app picker. The selected set is now a compact binder panel with completion treatment; tapping it opens a searchable, scrollable TCG/TCGP-specific set list with friendly release dates, completion counts and progress bars. The old native select remains hidden as the filtering source of truth for compatibility.


## v0.30.0 — Pokémon Dash v2

Pokémon Dash is now a top-down, Gen 3-inspired pixel racer. Quick Race supports all caught Pokémon across Easy/Normal/Hard/Expert Speed bands. Type Leagues cover all 18 types as three-race cups with type-eligible entrants, persistent trophies, standings, and difficulty-scaled rewards. The race keeps the v0.29 pacing, 1800-distance course, stamina/sprint loop, boosts, hazards and hidden three-line collision model while rendering racers at 96–112 px on a 540×720 course.

Dash save migration is additive: legacy races/wins/podiums/best time and last racer are preserved, with separate Quick/League racer memory, Quick best times by difficulty, and sparse league records added. All Dash assets remain offline.
# LuckyDex

## v0.34.1 — Collection, Arcade visibility & achievement expansion

Card Binder now restores its card-set selector after leaving Sealed Packs, and the Arcade location grid fits all nine venues into two rows so Pokémon Dash remains visible on phone screens. The Profile Challenge Log now supports category filtering and a large data-driven achievement catalogue: 110 authored achievements plus automatic completion achievements for every loaded physical TCG set and every built-in TCG Pocket set. Achievement rewards can now include Dust alongside the existing Lucky Coins, Tickets, fragments and card rewards. Existing claim state remains ID-based and is preserved across the additive expansion.

The v0.34.0 Pokémon Dash Emerald course overhaul is otherwise unchanged in this patch. See `TEST_REPORT_v0.34.1.md` for verification and environment limitations.

## v0.34.0 — Emerald course overhaul

All 18 Pokémon Dash courses now use locally decoded Pokémon Emerald tiles and complete environmental sprites, with eight reusable course sections, genuine Mossdeep boost pads and previews rendered from playable course frames. Held steering responds immediately; one viewport shell owns the HUD, course and controls. The v0.33.1 Dust, Ball Drop, pack safety/diagnostics and Adventure work is preserved.

See `TEST_REPORT_v0.34.0.md`, `docs/DASH_GEN3_ASSETS.md`, and `docs/DASH_V034_AUDIT_PLAN.md` for verification, provenance and limitations.

## v0.33.1 — Stability & Dust exchange patch
Dust Exchange now supports choosing any spare-copy quantity while always protecting the final binder copy. Ball Drop now has finite reward-resolution deadlines plus a 20-second simulated-flight failsafe so Ball Rain cannot hold a turn open indefinitely. Pack opening now contains cinematic frame failures, blocks concurrent rapid card navigation, records pack-specific recovery breadcrumbs, and falls back to a static reveal/summary instead of allowing a reveal error to escape.

## v0.33.0 — Pokémon Dash finishing pass
Dash now owns the full phone viewport, uses a more compact HUD/menu layout, animates racers by movement profile, preserves species size differences within fair bounds, adds soft racer contact and visible course collision feedback, and uses the packaged Oran Berry as the stamina pickup. Electric/Steel barriers and Fire rocks now reuse adapted Pokémon Emerald metatiles rather than placeholder-looking objects. See `TEST_REPORT_v0.33.0.md` and `docs/DASH_ASSET_SOURCES.md`.

## v0.32.0 — Regional Adventure and sloped Ball Drop
Three regional campaigns (Kanto, Johto, Hoenn), real moves and PP, persistent EXP, level-up learning and TMs; additive save migration. Ball Drop uses matching sloped bumpers. Six further regions are explicitly not populated. See TEST_REPORT_v0.32.0.md and docs/ADVENTURE_BALANCE_V032.md.


## v0.31.0 — Gen III Dash polish
Hard Speed classes, varied AI pace profiles, local pixel route assets, proportional sprites and compact mobile menus. See TEST_REPORT_v0.31.0.md and docs/DASH_ASSET_SOURCES.md.


## v0.29.2 God Pack production polish

- God Pack is now live at its real **1/1,000** production rate.
- The temporary 100% validation override is disabled.
- The full-screen reveal now simply says **GOD PACK**; the extra explanatory lines were removed.
- The weaker Lucky Pack has been rebalanced from ~1/2,000 to **1/500**, so it is correctly more common than a God Pack.
- GOD PACK COMPLETE remains on the end summary.
- Android identity remains `com.example.luckydex`; versionCode 293 / versionName 0.29.2.
