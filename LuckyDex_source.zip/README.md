# LuckyDex v0.25.9 — global excavation cards + real booster artwork

LuckyDex v0.25.9 builds on the canonical v0.25.7 source and preserves the existing Android update identity.

## Changes

- Buried loose TCG cards remain a 15% dig-site find, but now draw from the complete physical card catalogue rather than cards already owned, cached or previously opened. Promo and one-off cards are valid loose excavation finds too.
- Full physical booster packs remain a separate rarer 4% dig-site find and now draw from the complete booster-eligible catalogue rather than discovered/opened sets.
- Booster artwork no longer depends on the usually-empty `set.boosters[].artwork_front` field. A dedicated v0.25.9 resolver uses real packshots from the `1niceroli/ptcg-assets` catalogue.
- GitHub Actions generates a complete English booster-art URL index before running the regression suite/build. Base Set also ships with three known packshot URLs as an immediate fallback, and the runtime can query/cache a missing set's packshots if needed.
- Card Shop packs and excavated booster finds use the same artwork resolver and retain the old-style pointed sealed-pack wrapper.
- Existing v0.25.7 sprite-shaped fossil recovery masks, archaeology assets and v0.25.8 15%/4% reward rates remain intact.

## Android identity

- applicationId: `com.example.luckydex`
- versionCode / versionName: `259` / `0.25.9`
- permanent keystore SHA256: `90de91cea469f0eec5fbd69389cf03adc94ced396fa2ec85e2a51d2365a4f6d3`

The package ID and permanent signer are unchanged from v0.25.7. Android therefore treats the v0.25.9 APK as an update, provided the installed copy was signed with the same LuckyDex key.

Use the existing GitHub Actions workflow to generate the full booster-art index, run the Playwright/browser regression suite, verify the signer and build the APK.
