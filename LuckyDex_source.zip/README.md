## v0.40.21 — Snore War Endless + Dynamo/Snore achievements

- Added a MATCH / ENDLESS selector to Snore War.
- Match mode preserves v0.40.20 timing and survival rules byte-for-behaviour: all 96 centre timings compare at 0 ms delta against the previous build.
- Endless continues until the player records a third miss. CPU Drowzee keep playing/sleeping in the background but cannot end the run.
- Endless keeps accelerating beyond Match's 720 ms full pendulum period to a finite 560 ms cap, reached after the additional Endless ramp.
- Endless HUD uses STREAK instead of PLACE and the Game Review focuses on hits, misses, accuracy, best streak and fastest pendulum reached.
- Added durable Endless records: runs, best hits, best streak and fastest pendulum period.
- Added five Thundering Dynamo achievements and six Snore War achievements, including 100-hit and hidden 200-hit Endless milestones.
- Existing saves migrate additively with zero/default Endless record fields.

See `TEST_REPORT_v0.40.21.md`.
