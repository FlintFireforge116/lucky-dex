# Lucky Dex v0.16.0 — Gen III Berry Blender Rebuild

This build moves Pokémon TCG Pocket pack data away from the lagging TCGdex Pocket feed and onto a dedicated, current Pocket catalogue.

- all current Pocket expansions are available through B4b Deluxe Pack: Mega
- Paldean Wonders and other Pocket cards use deterministic real artwork URLs instead of LOCAL CARD PREVIEW
- Pocket card IDs stay compatible with the existing TCGdex-style `SET-###` IDs to avoid duplicate collection entries
- Pocket rarity codes are translated to Lucky Dex rarity labels for pack balance and reveal effects
- Deluxe Pack: ex and Deluxe Pack: Mega use their 4-card format with a Four Diamond+ guaranteed hit
- card artwork has multiple fallbacks and remains eligible for the existing offline image cache
- physical Pokémon TCG data and all v0.15.4 reveal fixes are preserved

## v0.16.0

- Rebuilt Berry Blender around the actual Generation III Emerald mechanics: 7.03 RPM minimum speed, retail Best/Good/Miss timing windows, 4-player speed divisors, high-speed behavior, passive slowdown, progress growth, NPC timing profiles, and retail-style spin-down.
- New Lilycove Contest Hall presentation with four stations (YOU / MISTER / LADDIE / LASSIE), GBA-style progress bar, live RPM display, ◎ / ○ / × feedback, high-RPM shake, hit particles, and 3-2-1-START countdown.
- Player can press repeatedly just like the original; mistimed presses now genuinely slow the machine rather than being ignored.
- Results now show placement, Best/Good/Miss counts, maximum RPM and blend time while retaining Lucky Dex Arcade rewards.

## v0.15.9
Fixed a startup-order TDZ crash that was aborting initialization and making Starter, Wild Search, Expeditions and pack-set loading appear frozen. Android version metadata is now 0.15.8 / code 158.

## v0.16.1

- Berry Blender player target is now highlighted directly on the wheel: the full GOOD arc is gold, the central BEST slice is brighter, the marker pulses as the pointer enters the timing window, and the YOU station is visually distinct.
- Added a new Trade tab with a simulated Link Trade board.
- Five fake trainers refresh every four real-world hours (00:00 / 04:00 / 08:00 / 12:00 / 16:00 / 20:00 local time).
- Trade generation is discovery-safe: unopened sets never appear. Existing saves infer discovered sets from the binder, and discovered-set history persists after trades.
- Same Set and Across Sets modes are available, plus Physical / Pocket filtering and board search.
- Trainers normally request an equivalent rarity; occasional one-tier up/down bargains create good and bad deals.
- Requested cards always come from cards the player currently owns, with duplicates preferred when available. Trading the final copy requires confirmation.
- Accepted trades remove one requested copy and add the offered card to the binder; completed offers stay completed until the next clock refresh.
