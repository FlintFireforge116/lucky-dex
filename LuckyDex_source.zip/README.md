## v0.42.3 — Portrait Target Range correction

Based only on the supplied v0.42.2 archive. Target Range now looks down a
portrait range from a low foreground Pokémon, with distance-driven target depth,
slower flight, a precise reticle and an oscillating timed-release meter. Hold and
drag on the control pad or scene; release in the gold band. A fixed low neutral
aim allows an upward thumb stroke to reach near and far targets without auto-aim.

All 18 type attacks, Goldenrod modes, rewards, records and progression are
preserved. See `TEST_REPORT_v0.42.3.md` for exact tests, inherited failures,
offline visual evidence and environment limitations. Runtime is fully local;
Playwright is a development-only dependency. Android identity remains
`com.example.luckydex`, versionName `0.42.3`, versionCode `4203`.

## v0.40.25 — Sushi-Go-Round three-ring redesign

Sushi-Go-Round now uses a cleaner three-ring shared conveyor built around direct plate selection instead of a single fixed EAT station. All four Lickitung remain fixed around a smaller table; plates move continuously and in sync, the player taps any glowing plate currently in reach, and the old centre copy / on-plate names and prices / oversized EAT control are removed. A compact side menu carries the value information instead.

The belt has been slowed from the original stepped 6.24 s lap equivalent to a smooth 7.2 s lap. Three staggered rings provide multiple choices at each station while preserving the existing 60-second scoring, combo, hot-tea, records, rewards and achievement rules. CPU decision cadence was retuned for the wider choice set so Normal remains competitive rather than allowing CPUs to vacuum all three rings.

See `TEST_REPORT_v0.40.25.md` for verification details.
