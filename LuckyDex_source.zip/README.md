# LuckyDex v0.25.4 — Fossil Dig card odds + authentic item-art cleanup

LuckyDex v0.25.4 is a focused Fossil Dig/Museum patch on top of v0.25.3.

## Buried TCG cards
- A dig wall now gets one independent **4% chance** to include a buried TCG card (about 1 in 25 dig sites).
- The card is placed as one of the wall's normal 3–6 finds and still has to be fully excavated and banked before entering Card Collection.
- Buried-card rarity now uses the shared v0.25.3 canonical card classifier and can reach **tier 6 / Secret Rare**.
- Buried-card tier roll: 49.5% tier 0, 28% tier 1, 15% tier 2, 5% tier 3, 1.5% tier 4, 0.5% tier 5 and **0.5% tier 6**.
- A Secret Rare underground therefore remains exceptionally rare: 4% wall chance × 0.5% Secret tier = 0.02% of dig sites before catalogue-availability effects (about 1 in 5,000).
- Dug cards remain unbanked until the dig is safely ended/completed and remain subject to the existing cave-in loss rules.

## Fossil Dig + Museum item art
- The active excavation/museum catalogue now points to `arcade/fossil-museum-v0254/items/` for its local item art.
- Removed the remaining custom painted/generic fossil and evolution-stone stand-ins from the active catalogue.
- Classic and later fossils now use proper Pokémon fossil/item pixel sprites, including the Galar fossil fragments.
- Fire, Water, Thunder, Leaf and Moon Stones use their actual evolution-stone art rather than generic coloured placeholders.
- Odd Keystone, Hard Stone and Everstone likewise use their proper item sprites.
- Existing pixel-art treasure, Ball, relic and card sprites are retained where they were already appropriate.
- The same item mapping is used by Fossil Dig and Museum, so a recovered item no longer changes visual identity between the two screens.
- Nearest-neighbour/pixelated rendering and the existing excavation footprints are retained; visual sprite identity is independent from how many wall tiles an object occupies.

## Android update identity
- applicationId: `com.example.luckydex`
- versionCode / versionName: `254` / `0.25.4`
- Permanent keystore is unchanged from the canonical LuckyDex signer.

## Build
Use the existing GitHub Actions workflow to build the Android APK. This archive retains `app/luckydex-dev.keystore`, so v0.25.4 can update the permanent-signer LuckyDex installation.

See `V0254_REPORT.md` and `TEST_REPORT_v0.25.4.md` for implementation and verification details.
