## v0.40.22 — Run, Rattata, Run + Snore War 500-hit prestige

- Added **Run, Rattata, Run** as the eighth Pokémon Stadium / Kids Club game.
- Four Rattata race on one obstacle course: mash **RUN** to build momentum and tap **JUMP** to clear six hurdles.
- Hitting a hurdle causes a 650 ms stumble and sharply reduces momentum; clean jumps preserve race speed.
- Easy / Normal / Hard CPUs differ through run cadence, jump reliability and hesitation.
- Once the first Rattata finishes, remaining racers receive a 3-second finish window.
- Added full Lucky Coin rewards, Game Review, Arcade Records and additive save migration.
- Added five Run, Rattata, Run achievements: first win, Hard win, all difficulties, flawless winning run and a 10.00-second speed challenge.
- Added hidden Snore War Endless prestige achievement **Sleep Is For The Weak** for 500 hits, rewarding 5,000 Lucky Coins, 300 dust and 3 Pack Tickets.
- Existing Snore War Match/Endless and Thundering Dynamo behaviour are preserved.

See `TEST_REPORT_v0.40.22.md`.
