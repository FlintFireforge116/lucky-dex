# Lucky Dex v0.8 — Moon Stage + Pack Polish

This build focuses on visual polish rather than feature growth.

## Highlights
- Clefairy Match now uses a generated anime-style moonlit landscape asset rather than CSS-built scenery.
- Clefairy remains a separate animated layer so STAR / SONG / MOON / SPIN can animate independently.
- Spin animates the actual Clefairy character wrapper as well as the water reflection.
- Physical/Pocket set pickers are sorted by release date (oldest to newest) rather than alphabetically.
- High-rarity pack reveals use sparkle particles, light bursts/rays and stronger haptics instead of giant BIG HIT labels.
- Pack reveal layout has safer spacing around the SHOP control and smaller card presentation.
- Pack summaries use a compact 3-column card grid so the cards and CTA fit the mobile UI much better.
- Existing save data remains compatible.
