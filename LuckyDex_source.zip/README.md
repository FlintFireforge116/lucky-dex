## v0.40.20 — Snore War live-place + round-length tuning

- Fixed Snore War live PLACE so awake racers rank by hits, then fewer misses, then best streak. A recovered COM can no longer sit above a clearly stronger live performance just because it slept more recently.
- Final Snore War results still lock the winner first and use elimination/sleep timing to order the remaining racers by survival.
- A miss now sleeps Drowzee for exactly two centre crossings total, including the missed crossing, instead of effectively three. This reduces three-way overlap and makes rounds last longer without changing CPU accuracy or pendulum speed.
- Preserves the v0.40.18 smooth-pendulum fix and v0.40.19 live START-panel visibility fix.

See `TEST_REPORT_v0.40.20.md`.
