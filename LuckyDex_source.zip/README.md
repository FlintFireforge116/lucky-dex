# LuckyDex v0.24.3 — release chronology + permanent update identity

This patch builds on v0.24.1 without changing the Android install identity or save key.

- Package identity: `com.example.luckydex`
- versionCode / versionName: `243` / `0.24.3`
- Save key remains `luckyDexSave`
- Existing GitHub signing workflow / `LUCKYDEX_KEYSTORE_BASE64` contract is unchanged.

## Packs changes

- Set selection is now an accordion. The selected set stays visible; tapping it opens a large Search/Sort set chooser, and choosing a set collapses it again.
- The set chooser gets the available card height instead of a tiny permanent scrolling strip.
- Release Date sorting migrates to newest-first once in v0.24.2.
- Known physical-set chronology corrections are pinned for 30th Celebration (2026-09-16) and Scarlet & Violet—151 (2023-09-22) so stale catalogue metadata cannot invert them.
- Pack format display is reduced to `10-card booster`, `5-card Pocket pack`, or `4-card Deluxe Pocket pack` only; the rarity-recipe text and large yellow count badge were removed.
- Packs now explains the existing economy: duplicate pulls automatically become Card Dust, and 100 Dust exchanges for one Pack Ticket.
- No manual destroy-card-for-Dust action was added; the existing duplicate conversion remains the Dust source.


## v0.24.3 permanent update identity
- Physical release sorting uses exact known dates and catalogue chronology instead of alphabetic fallback when source dates are partial.
- The original LuckyDex development signer is bundled and pinned by SHA-256/certificate fingerprint. CI and Gradle fail rather than producing an APK with a different signer.
