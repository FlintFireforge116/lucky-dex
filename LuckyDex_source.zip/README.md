# Lucky Dex v0.4 — Game Feel, World & Challenges

Lucky Dex is a lightweight personal Pokémon collection / arcade / adventure app. v0.4 is a presentation-and-depth pass over the v0.3 game loop rather than another proof-of-concept feature dump.

Core loop:

**Play → earn Lucky Coins/resources → battle & catch Pokémon → strengthen a team → explore expeditions → earn/open packs → complete collection challenges → unlock more.**

## v0.4 highlights

### Pokémon-game UI pass
- Stronger Pokédex/game-console visual language across panels, buttons, zones, resources and navigation.
- New launcher icon.
- Arcade games now open as dedicated full-screen experiences and use Android immersive mode while playing.
- Bottom navigation and page scrolling are suppressed during an Arcade game.

### Arcade makeover
- **Voltorb Flip** now looks like a proper Game Corner board: chunky card tiles, Poké Ball backs, Voltorb reveals and styled clue plaques.
- **Clefairy Match** is now a moon-stage memory game with Clefairy presentation and Pokémon-themed STAR / SONG / MOON / SPIN pads instead of plain directional arrows.
- **Berry Blend** is now a circular spinning blender. The berry wheel visibly rotates, reverses direction on alternating rounds and speeds up. Stop the golden slice under the pointer for high scores.
- Existing helper abilities still apply: Electric Static Scan, Psychic Second Sight, Grass Gentle Hands, Water Cool Blend, Pickup, etc.

### Expeditions rebuilt
- Expeditions are now **7-room routes** with a proper route-map presentation.
- Room types include wild battles, Trainer battles, rare encounters, supply caches, random events, rest camps and bosses.
- Choose which team member leads the next room from the expedition screen.
- Switch Pokémon in battle. Switching costs a turn, so the opponent gets a response.
- Added Potions, usable during expedition battles, and added Potions to the Poké Mart.
- Retreat early at almost any safe point and keep Pokémon, coins and supplies already found; only the clear reward is lost.
- First-clear Pack Ticket rewards remain.
- Bosses are now themed to their route rather than just being a random rare encounter.

Current routes:
- **Viridian Trail** — boss Pinsir
- **Mt. Moon Caverns** — boss Aerodactyl
- **Lavender Haunted House** — boss Gengar
- **Seafoam Shore** — boss Lapras
- **Cinnabar Crater** — boss Charizard

### Haunted House / world content
- Added **Haunted House** as a rank-gated Ghost/Psychic/Dark hunting zone.
- Added a dedicated **Lavender Haunted House** expedition with spooky events and Gengar boss encounter.
- Visiting and clearing the Haunted House feeds the permanent challenge system.

### Daily Board 2.0
Instead of the same three tasks every day, Lucky Dex now deterministically picks three daily goals from a pool appropriate to your Trainer Rank, including:
- catch Pokémon
- win battles
- earn Arcade Coins
- clear an expedition
- open a pack
- catch a Ghost type
- make a Great/Ultra Ball catch
- hit perfect Berry Blend rounds

Completing all three pays **1 Pack Ticket + 300 Lucky Coins + Trainer XP**.

### Permanent Challenge Log
The Profile now has an Achievement / Challenge Log with active, completed and secret tabs. Rewards include Lucky Coins, Pack Tickets and **Shiny Charm Fragments**.

Implemented challenges include:
- catch your first shiny
- own 10 different Ghost types
- complete the Kanto Pokédex
- complete Celestial Storm
- pull a Gold/Crown TCG Pocket card
- visit the Lavender Haunted House
- clear the Haunted House
- open 25 / 100 packs
- earn 10,000 Arcade Coins
- catch 5 shinies
- several hidden achievements, including repeated Zubat encounters, failed catches and loaded packs

Three Shiny Charm Fragments improve the effective shiny rate. The Hunt screen shows the effective rate.

### Collection / compatibility
- v0.1–v0.3 local saves migrate forward.
- Existing Pokémon/cards/coins/XP/team data are preserved.
- Older owned Pokémon with missing type/stat metadata are gradually hydrated from PokéAPI so type-based achievements remain accurate.
- Broken card art now explicitly renders the in-app placeholder even when a card has no image URL at all.

## Testing performed
- JavaScript syntax check with Node.
- Static HTML/JS ID consistency check.
- Headless Chromium smoke test with mocked PokéAPI/TCGdex data through starter selection, Arcade, Berry Blend, Profile challenges, Haunted House expedition and route rendering.
- Separate logic test for achievement claiming, rotating daily completion, Trainer-battle capture lockout, Crown/Gold card tracking, card-art fallback and expedition retreat.
- Visual smoke screenshots generated for Voltorb Flip, Clefairy Match, Berry Blend and Profile / Challenge UI at a 390×844 mobile viewport.

## Building on GitHub
The existing repository workflow watches a root file named exactly `LuckyDex_source.zip`.

1. Upload/replace `LuckyDex_source.zip` in the repository root **without deleting the old file first**.
2. Commit to `main`.
3. GitHub Actions automatically runs **Build Lucky Dex APK**.
4. Open the successful run and download **LuckyDex-APK**.
5. Extract and install `LuckyDex-debug.apk` over the existing app to retain local save data.

## Data/assets
The APK stays small by loading artwork/data at runtime:
- Pokémon sprites and Pokémon data: PokéAPI / PokeAPI sprites.
- Pokémon TCG and TCG Pocket sets/cards: TCGdex.

Network access is required for uncached remote art/data. Gameplay/save state is local to the app.

## Personal fan project
Pokémon, Pokémon TCG, characters, names, artwork and related trademarks belong to their respective rights holders. This project is intended as a personal fan-made app.
