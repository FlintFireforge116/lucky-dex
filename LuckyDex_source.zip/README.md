# LuckyDex v0.25.0 — Fossil Dig + Oreburgh Mining Museum

This source adds the first major Arcade minigame overhaul: Fossil Dig is now a layered Sinnoh-Underground-style excavation game, and Oreburgh Mining Museum is a persistent collection room that physically fills with recovered archaeological exhibits.

## v0.25.0 highlights
- 12×9 layered excavation wall with 3–6 non-overlapping multi-tile finds.
- Pickaxe: precise 3-depth hit for 3 wall stability.
- Hammer: 3×3 area hit for 8 wall stability.
- Wall collapse replaces the old fixed dig-count system; only fully excavated items survive.
- Fossils, Odd Keystone, Relics, stones, Balls, treasures, Lucky Coin caches and rare buried TCG cards can appear.
- First archaeological copies auto-donate to the persistent museum; later copies sell for Lucky Coins.
- Adventure Balls route to the existing inventory; buried cards route to the normal card binder without opening a pack.
- Oreburgh Mining Museum is one top-down room with no controllable avatar. Blank display cases fill only when an exhibit is discovered, and occupied exhibits can be tapped for original LuckyDex flavour text and excavation count.
- The room uses the supplied authentic DPPt Oreburgh reference, with central player/guide sprites removed and authentic case artwork reused for additional empty display space.
- Existing saves gain only `arcade.museum.exhibits`; all existing cards, Pokémon, inventory, profile and Arcade data are preserved.

## Android update identity
- applicationId: `com.example.luckydex`
- versionCode / versionName: `250` / `0.25.0`
- Permanent keystore and certificate are unchanged from the recovered canonical signer.

## Build
Use the existing GitHub Actions workflow to build the Android APK. This archive intentionally keeps the permanent `app/luckydex-dev.keystore` required for in-place updates.

See `V0250_REPORT.md` and `TEST_REPORT_v0.25.0.md` for implementation and verification details.
