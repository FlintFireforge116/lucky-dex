# LuckyDex v0.24.4 — complete pack chronology + permanent Android signer

This source is the v0.24.4 follow-up to the Packs accordion work.

## Pack chronology
- Physical Pack browsing now uses an explicit release-date registry with 247 set-name/alias entries.
- Dates are exact ISO `YYYY-MM-DD` values and take precedence over incomplete remote metadata.
- Release Date sorting is therefore chronological rather than falling back to alphabetical ordering when a remote set has no date.
- The card-art index build consumes the same registry and fails if any validated set remains without a full date.

## Permanent Android update identity
- applicationId: `com.example.luckydex`
- versionCode / versionName: `244` / `0.24.4`
- save key: `luckyDexSave`
- canonical signing keystore: `app/luckydex-dev.keystore`
- keystore SHA-256: `90de91cea469f0eec5fbd69389cf03adc94ced396fa2ec85e2a51d2365a4f6d3`
- certificate SHA-256: `06:9B:44:0B:7D:31:5E:FB:A1:F1:54:73:10:9A:E3:D9:45:AD:1F:A8:05:9E:6A:A2:62:72:6C:98:6D:39:8A:6A`

Gradle refuses to build if the canonical keystore is missing, so future builds cannot silently switch back to a runner-generated debug signer.

If the APK currently installed on a phone was signed by an earlier ephemeral GitHub runner key, Android cannot update it with the recovered canonical signer. That device may require one final reinstall. After v0.24.4 is installed with this canonical signer, later builds that preserve it can update in place.
