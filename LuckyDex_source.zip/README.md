# Lucky Dex v0.15.2 — Pack Artwork Reliability Fix

This build keeps the Codex pack/Clefairy animation work from v0.15.1 and fixes the missing-card-art regression seen in newer physical sets.

## v0.15.2 changes
- Bundles a deterministic artwork bridge for **30th Classic Collection**, including the Metagross case that previously rendered `LOCAL CARD PREVIEW`.
- Adds a direct-number artwork bridge for **30th Celebration**.
- Prefers the maintained alternate artwork source for physical cards when available, while retaining TCGdex as a fallback.
- Displays a verified remote `<img>` URL immediately and performs offline blob caching in the background, instead of blocking the reveal on a cross-origin image fetch.
- Increases image decode grace time for mobile connections.
- Extends alternate catalogue metadata timeouts for slower connections.
- Keeps the existing `file://` app origin so current localStorage save data remains compatible, while allowing the packaged app to reach its HTTPS card-data fallbacks.
- Existing pack-opening animation, Clefairy animation, collection data, economy and offline cache remain intact.
