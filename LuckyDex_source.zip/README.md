# LuckyDex v0.24.8 — promo economy + acquisition cleanup

This source is the v0.24.8 follow-up to the Promo Vault and manual Dust Exchange work. Physical TCG cards keep their explicit acquisition route—normal booster, Dust-funded Promo Vault, or curated Achievement Reward—while promo prices and salvage values now scale with card quality and achievement-only promo buckets are removed from purchasable/tradeable lists.

## Pack chronology
- Physical Pack browsing now uses an explicit release-date registry with 247 set-name/alias entries.
- Dates are exact ISO `YYYY-MM-DD` values and take precedence over incomplete remote metadata.
- Release Date sorting is therefore chronological rather than falling back to alphabetical ordering when a remote set has no date.
- The card-art index build consumes the same registry and fails if any validated set remains without a full date.


## Promo acquisition and Dust rules
- Ancient Mew is reserved for the Kanto-completion achievement.
- One Victory Medal is reserved for the Game Corner achievement.
- Ordinary promo/special-distribution cards remain collectible through Promo Vault using Card Dust.
- Miscellaneous, Victory Medals, Poké Card Creator Pack, World Collection, and dedicated promo series are excluded from the normal booster catalogue.
- Achievement cards display together under a virtual `Achievement Rewards` binder group while retaining their original card IDs and source metadata.

- Promo Dust bands: standard `350 / 100`, enhanced `600 / 175`, elite `900 / 275`, premium `1300 / 450` (purchase / salvage).
- Manual Dust conversion still preserves the final copy of every card; Achievement Reward cards cannot be converted.
- `Miscellaneous` is hidden from Promo Vault and Trade because its Ancient Mew content is achievement-only.
- Promo series that contain usable ordinary promos remain available, including non-achievement Victory Medal cards.

## Permanent Android update identity
- applicationId: `com.example.luckydex`
- versionCode / versionName: `248` / `0.24.8`
- save key: `luckyDexSave`
- canonical signing keystore: `app/luckydex-dev.keystore`
- keystore SHA-256: `90de91cea469f0eec5fbd69389cf03adc94ced396fa2ec85e2a51d2365a4f6d3`
- certificate SHA-256: `06:9B:44:0B:7D:31:5E:FB:A1:F1:54:73:10:9A:E3:D9:45:AD:1F:A8:05:9E:6A:A2:62:72:6C:98:6D:39:8A:6A`

Gradle refuses to build if the canonical keystore is missing, so future builds cannot silently switch back to a runner-generated debug signer.

If the APK currently installed on a phone was signed by an earlier ephemeral GitHub runner key, Android cannot update it with the recovered canonical signer. That device may require one final reinstall. After v0.24.4 (or later) is installed with this canonical signer, v0.24.5 and later builds that preserve it can update in place.
