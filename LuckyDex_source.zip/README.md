# Lucky Dex v0.16.4 — Card Identity & Berry Target Fix

This hotfix replaces v0.16.3's unsafe collector-number artwork guessing with identity-verified card art resolution.

- pack reveals no longer infer a physical card image from a set code plus the local card number; this was the cause of names such as **Erika's Jigglypuff** being paired with unrelated **Fuecoco ex** artwork
- cross-catalogue set matching now requires an exact set ID, exact code, or exact normalized set name before card artwork is accepted
- 30th Classic Collection uses its explicit 30-card identity bridge (for example Erika's Jigglypuff -> `me55c-69`)
- McDonald's Collection 2023 has a verified 15-card number/name bridge (for example Sandaconda #10 -> `mcd23-10`) so those cards no longer fall back to LOCAL CARD PREVIEW
- other missing physical art can fall back to an exact-set, exact-name Scrydex lookup; failed identity matching leaves a placeholder rather than showing the wrong card
- the one-time v0.16.4 migration invalidates cross-catalogue artwork saved by v0.16.3 and starts a fresh offline-art database, preventing previously cached mismatches from surviving the update
- Berry Blender's GOOD/BEST arcs still come from the scoring constants, but the floating TAP ZONE pill has been replaced by a small fixed notch at the exact midpoint of the real scoring window

## Previous release notes

This build moves Pokémon TCG Pocket pack data away from the lagging TCGdex Pocket feed and onto a dedicated, current Pocket catalogue.

- all current Pocket expansions are available through B4b Deluxe Pack: Mega
- Paldean Wonders and other Pocket cards use deterministic real artwork URLs instead of LOCAL CARD PREVIEW
- Pocket card IDs stay compatible with the existing TCGdex-style `SET-###` IDs to avoid duplicate collection entries
- Pocket rarity codes are translated to Lucky Dex rarity labels for pack balance and reveal effects
- Deluxe Pack: ex and Deluxe Pack: Mega use their 4-card format with a Four Diamond+ guaranteed hit
- card artwork has multiple fallbacks and remains eligible for the existing offline image cache
- physical Pokémon TCG data and all v0.15.4 reveal fixes are preserved

## v0.16.3

- Physical TCG artwork now has a deterministic current-set fallback using the printed set code and collector number, so newly released sets/promos no longer depend on every upstream catalogue updating at the same time. The fix is shared by pack reveals, binder/modal rendering and Trade.
- Pokémon TCG alternate-set matching now prefers exact set IDs/codes before fuzzy name matching, reducing wrong/missing artwork on similarly named sets.
- Berry Blender's highlighted GOOD/BEST arcs are generated from the same timing constants as scoring; the TAP ZONE label is centred on the actual window, and the blender itself can be tapped as the A input.
- Trade now uses the app's internal scroll layout (so accept controls cannot disappear behind the bottom navigation), has a tighter mobile layout, and attempts to fill all five trainer slots when the discovered card pool permits.
- Trade collection changes are committed before the exchange animation, accept buttons lock during processing, and the animation is presentation-only, preventing interrupted animations from losing a completed trade.

## v0.16.0

- Rebuilt Berry Blender around the actual Generation III Emerald mechanics: 7.03 RPM minimum speed, retail Best/Good/Miss timing windows, 4-player speed divisors, high-speed behavior, passive slowdown, progress growth, NPC timing profiles, and retail-style spin-down.
- New Lilycove Contest Hall presentation with four stations (YOU / MISTER / LADDIE / LASSIE), GBA-style progress bar, live RPM display, ◎ / ○ / × feedback, high-RPM shake, hit particles, and 3-2-1-START countdown.
- Player can press repeatedly just like the original; mistimed presses now genuinely slow the machine rather than being ignored.
- Results now show placement, Best/Good/Miss counts, maximum RPM and blend time while retaining Lucky Dex Arcade rewards.

## v0.15.9
Fixed a startup-order TDZ crash that was aborting initialization and making Starter, Wild Search, Expeditions and pack-set loading appear frozen. Android version metadata is now 0.15.8 / code 158.


## v0.16.2

- Trade cards now include a prominent full-width ACCEPT TRADE action.
- Simulated trainers can request any card from a set the player has opened, not only cards already owned; unavailable requests are visible but cannot be accepted until owned.
- Completing a trade now plays a short exchange animation: the two cards cross with light streaks and sparkles, then the received card spins/flips into view.
- v0.16.1 Berry Blender target clarity and all existing systems are preserved.

## v0.16.1

- Berry Blender player target is now highlighted directly on the wheel: the full GOOD arc is gold, the central BEST slice is brighter, the marker pulses as the pointer enters the timing window, and the YOU station is visually distinct.
- Added a new Trade tab with a simulated Link Trade board.
- Five fake trainers refresh every four real-world hours (00:00 / 04:00 / 08:00 / 12:00 / 16:00 / 20:00 local time).
- Trade generation is discovery-safe: unopened sets never appear. Existing saves infer discovered sets from the binder, and discovered-set history persists after trades.
- Same Set and Across Sets modes are available, plus Physical / Pocket filtering and board search.
- Trainers normally request an equivalent rarity; occasional one-tier up/down bargains create good and bad deals.
- Requested cards always come from cards the player currently owns, with duplicates preferred when available. Trading the final copy requires confirmation.
- Accepted trades remove one requested copy and add the offered card to the binder; completed offers stay completed until the next clock refresh.
