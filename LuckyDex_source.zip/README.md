# LuckyDex v0.25.1 — Fossil Dig + Oreburgh Mining Museum

LuckyDex v0.25.1 polishes the v0.25.0 Fossil Dig / Oreburgh Museum overhaul while preserving the same persistent museum collection and save data.

## v0.25.1 polish
- Intact/chipped rock at depths 4, 3 and 2 is now fully opaque; buried objects only begin showing through on the final depth-1 layer.
- Added a proper **END DIG** action with an in-app **KEEP DIGGING / END & COLLECT** confirmation.
- Manual ending keeps only fully excavated finds and produces a distinct `DIG ENDED` result.
- Museum room renders closer to the phone edges for a larger view.
- The extra glass display that overlapped the lower entrance has been relocated to clear floor space, with its geology exhibits moved to match.

## Fossil Dig / Museum foundation
- 12×9 layered excavation wall with 3–6 non-overlapping multi-tile finds.
- Pickaxe: precise 3-depth hit for 3 wall stability.
- Hammer: 3×3 area hit for 8 wall stability.
- Wall collapse replaces the old fixed dig-count system; only fully excavated items survive.
- Fossils, Odd Keystone, Relics, stones, Balls, treasures, Lucky Coin caches and rare buried TCG cards can appear.
- First archaeological copies auto-donate to the persistent museum; later copies sell for Lucky Coins.
- Adventure Balls route to the existing inventory; buried cards route to the normal card binder without opening a pack.
- Oreburgh Mining Museum is one top-down room with no controllable avatar. Blank display cases fill only when an exhibit is discovered, and occupied exhibits can be tapped for LuckyDex flavour text and excavation count.

## Android update identity
- applicationId: `com.example.luckydex`
- versionCode / versionName: `251` / `0.25.1`
- Permanent keystore and certificate are unchanged from the recovered canonical signer.

## Build
Use the existing GitHub Actions workflow to build the Android APK. This archive intentionally keeps the permanent `app/luckydex-dev.keystore` required for in-place updates.

See `V0251_REPORT.md` and `TEST_REPORT_v0.25.1.md` for implementation and verification details.
