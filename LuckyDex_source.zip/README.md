# LuckyDex v0.25.8 — buried cards, booster finds and pack presentation

LuckyDex v0.25.8 builds directly on the canonical v0.25.7 source while preserving the existing Android update identity.

## Changes

- Buried loose TCG cards now appear on 15% of dig sites.
- Full random physical booster packs are a separate rarer find at 4% of dig sites.
- A recovered booster uses the existing physical pack-building rules and adds the resulting cards to the binder.
- Buried boosters show the selected booster artwork inside an old-style pointed sealed-pack wrapper.
- The normal sealed-pack presentation uses the same pointed wrapper treatment with available booster artwork.
- Existing v0.25.7 sprite-shaped recovery masks and archaeology assets remain intact.

## Android identity

- applicationId: `com.example.luckydex`
- versionCode / versionName: `258` / `0.25.8`
- permanent keystore SHA256: `90de91cea469f0eec5fbd69389cf03adc94ced396fa2ec85e2a51d2365a4f6d3`

The package ID and permanent signer are unchanged from v0.25.7. Android therefore treats the v0.25.8 APK as an update, provided the installed copy was signed with the same LuckyDex key.

Use the existing GitHub Actions workflow to run the full Playwright/browser regression suite, verify the signer and build the APK.
