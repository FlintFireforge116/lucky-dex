# LuckyDex 0.21.0 recovery candidate

Recovery source for the supplied Android/WebView project. The active Arcade has one navigation owner and ten game owners/adapters; essential scene assets and sprites are committed locally. The APK retains the original package ID, file origin and save schema.

See [recovery report](docs/RECOVERY_REPORT.md), [asset audit](docs/ASSET_AUDIT.md), [game references](docs/GAME_REFERENCES.md), [runtime ownership](docs/RUNTIME_OWNERS.md), and [Android build evidence](docs/ANDROID_BUILD.md).

## Development checks

Requires Node 22+, Python 3.10+ and a Chromium browser:

```
npm ci
npx playwright install chromium
npm test
```

On Windows, tests use installed Chrome by default; set `LUCKYDEX_BROWSER` to another Chromium executable. On other platforms, tests use Playwright Chromium. The suite tests actual production scripts with remote requests blocked and writes phone screenshots to `artifacts/qa/`. No Android bridge is mocked to establish native device behavior.

```
python scripts/fetch_arcade_v0200_assets.py --check
gradle --no-daemon :app:assembleDebug
```

Build requirements: Java 17+, Gradle 8.9+, Android platform 35. The source package excludes signing keys and tool caches. A supplied local `app/luckydex-dev.keystore` preserves the development signing identity. CI can restore the same key from `LUCKYDEX_KEYSTORE_BASE64`; without it, CI uses Android's ephemeral debug signer and cannot update an existing installation. The artifact supplied with this recovery uses the original provided signer.

## Source history

[Previous release notes](docs/RELEASE_HISTORY.md) and the original prompt/handover documents are historical records. The current recovery requirements are in [RECOVERY_REQUEST.md](docs/RECOVERY_REQUEST.md). Historical runtime layers are preserved in the Git baseline commit rather than loaded in the APK.
