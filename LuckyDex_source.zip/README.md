# Lucky Dex v0.15.5 — Complete TCG Pocket Source

This build moves Pokémon TCG Pocket pack data away from the lagging TCGdex Pocket feed and onto a dedicated, current Pocket catalogue.

- all current Pocket expansions are available through B4b Deluxe Pack: Mega
- Paldean Wonders and other Pocket cards use deterministic real artwork URLs instead of LOCAL CARD PREVIEW
- Pocket card IDs stay compatible with the existing TCGdex-style `SET-###` IDs to avoid duplicate collection entries
- Pocket rarity codes are translated to Lucky Dex rarity labels for pack balance and reveal effects
- Deluxe Pack: ex and Deluxe Pack: Mega use their 4-card format with a Four Diamond+ guaranteed hit
- card artwork has multiple fallbacks and remains eligible for the existing offline image cache
- physical Pokémon TCG data and all v0.15.4 reveal fixes are preserved
