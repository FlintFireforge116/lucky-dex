# Lucky Dex v0.3 — Game Loop Update

Lucky Dex is a lightweight personal Pokémon collection/arcade/adventure app. v0.3 turns the v0.1/v0.2 collection proof-of-concept into a small playable game loop:

**Play → earn Lucky Coins/resources → battle & catch Pokémon → buy/open packs → strengthen a team → unlock harder zones/expeditions.**

## v0.3 highlights

### Adventure & catching
- Wild encounters now use a lightweight battle system instead of instant catches.
- Your active team Pokémon has level, HP, Attack, Defence, Speed, actual Pokémon types, and a type move.
- Wild Pokémon have levels, HP and types. Type effectiveness affects damage.
- Weaken wild Pokémon before throwing a ball; the displayed catch chance updates with HP, ball quality and berries.
- Poké Ball / Great Ball / Ultra Ball inventory and a Lucky Coin supply shop.
- Berries improve the next catch attempt.
- Four zones with Trainer Rank unlocks: Meadow, Cave, Coast and Volcano.
- Four five-room Expeditions with battles, supply caches, rare rooms and bosses. Team HP persists across a run.
- First clear of each expedition awards a Pack Ticket.
- Fresh saves choose a starter (Bulbasaur, Charmander, Squirtle or Pikachu).

### Pokémon progression
- Caught Pokémon now have levels and XP.
- Duplicate catches give progression to that Pokémon.
- Three-Pokémon Adventure Team configurable from the Pokédex.
- Pokémon detail screen shows battle stats, types, level/XP and Arcade helper ability.
- Helper abilities currently include Static Scan (Electric), Second Sight (Psychic), Gentle Hands (Grass), Cool Blend (Water), Pickup (Meowth/Persian), and a neutral fallback.

### Lucky Dex Arcade
- **Voltorb Flip:** 5×5 risk/reward board with row/column clues, multipliers, cash-out and Electric helper scan.
- **Clefairy Match:** escalating memory sequence with push-your-luck banking and Psychic replay helper.
- **Berry Blend:** five-round timing game with Grass timing assistance and Water payout bonus.
- Arcade play earns Lucky Coins and Trainer XP. There are no ads, energy timers or real-money purchases.

### Pack economy
- Packs are no longer infinitely free.
- One free daily pack, then Pack Tickets, then Lucky Coin prices (Physical TCG 600 / TCG Pocket 450).
- Duplicates generate Card Dust; 100 Dust can be exchanged for a Pack Ticket.
- Existing rarity-aware pack generation, foil tear animation, individual card flips and full-screen cards remain.
- Card image loading now falls back high → low → an in-app placeholder instead of leaving a broken-image icon.

### Progression & retention
- Trainer Rank increases from XP and unlocks zones, expeditions and better balls.
- Rank-ups award coins; every fifth rank also gives a Pack Ticket.
- Daily board: catch 3 Pokémon, earn 500 Arcade Coins, clear 1 Expedition → Pack Ticket + 250 Coins.
- Pokédex generation completion milestones and card-set completion milestones grant Lucky Coins / tickets.
- Profile tracks battle, expedition, arcade, catch, pack and collection stats.

## Save migration
v0.1/v0.2 local WebView storage is migrated to v0.3. Existing Pokémon, shinies, cards, pack stats and collection progress are preserved. Older caught Pokémon receive sensible starting levels, and an initial team is chosen automatically from the existing collection.

## Data/assets
The APK stays small by loading artwork/data at runtime:
- Pokémon sprites and Pokémon data: PokéAPI / PokeAPI sprites.
- Pokémon TCG and TCG Pocket sets/cards: TCGdex.

Network access is required for uncached remote art/data. Gameplay/save state is local to the app.

## Building on GitHub
The repository workflow expects a root file named exactly `LuckyDex_source.zip`.

1. Replace/upload `LuckyDex_source.zip` in the repository root.
2. Commit to `main`.
3. GitHub Actions automatically runs **Build Lucky Dex APK**.
4. Open the successful run and download the **LuckyDex-APK** artifact.
5. Extract and install `LuckyDex-debug.apk`.

## Personal fan project
Pokémon, Pokémon TCG, characters, names, artwork and related trademarks belong to their respective rights holders. This project is intended as a personal fan-made app.
