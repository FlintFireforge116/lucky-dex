## v0.44.0 — Pokémon sleeve catalogue

Based solely on the supplied v0.43.1 source. Profile → Customise now contains 202 offline sleeve designs: 114 physical TCG, all 78 reference TCG Pocket designs, and 10 illustrated LuckyDex originals. Search, source/theme filters and larger previews support phone browsing. All 30 legacy IDs remain valid; four starter sleeves remain free. Small themed reward groups use existing saved Adventure, collection, TCG, Arcade and Goldenrod evidence, with secret requirements concealed until discovery. Shared pack and Trade backs follow the equipped sleeve.

Android identity remains `com.example.luckydex`, versionName `0.44.0`, versionCode `4400`. See `TEST_REPORT_v0.44.0.md` for checks and inherited baseline test failures, `docs/COSMETICS_SOURCES_v0440.md` for provenance, and `docs/COSMETICS_PROGRESSION_v0440.md` for durable unlock rules. No publication or external repository change is part of this delivery.

## v0.43.1 — Impact Trial low-Defense expression

Impact Trial now gives very low-Defense Pokémon a much heavier Harden workload and much harsher unblocked damage, while preserving zero damage for perfect Harden clears. Defense below 20 no longer flattens to the same effective value, and tournament CPU scoring uses the same low-end separation.

Android identity remains `com.example.luckydex`, versionName `0.43.1`, versionCode `4301`. See `TEST_REPORT_v0.43.1.md` for verification details.

## v0.43.0 — Goldenrod stat expression and Type Cup trophies

Goldenrod stats now use one steep, diminishing shared curve but express themselves physically in each event: Speed changes Dash pace/acceleration, Attack sets Power Trial ceiling, Defense changes Impact workload/mitigation, and Sp. Atk changes Target Range projectile power/trajectory. CPU rivals use the same stat curve. The Trophy Cabinet now exposes separate Type Cup trophy tracks, and Target Range removes the incorrect prop/tree treatment.

Android identity remains `com.example.luckydex`, versionName `0.43.0`, versionCode `4300`. See `TEST_REPORT_v0.43.0.md` for verification details.

## v0.42.4 — Target Range tournament balance

Based only on the supplied v0.42.3 source archive. This is a bounded balance
release: Target Range shooting, visuals, controls, Golden Target behavior and the
shared Goldenrod tournament rules are unchanged. Only Target Range simulated
opponent scoring was retuned so Rookie is forgiving without becoming automatic,
with a clearer step-up through Poké, Great, Ultra and Master.

In the deterministic balance sample used by the regression suite, Rookie AI has
a median round score of about 71 (90th percentile about 85, rare maximum about
97). A 75-point player round takes a Rookie podium in roughly 70% of sampled
fields; a 90-point round wins roughly 91%, leaving occasional standout rivals.
Later rounds receive only modest score escalation because they already contain
more player targets.

See `TEST_REPORT_v0.42.4.md` for exact verification and environment limitations.
Android identity remains `com.example.luckydex`, versionName `0.42.4`, versionCode
`4204`.

## v0.40.25 — Sushi-Go-Round three-ring redesign

Sushi-Go-Round now uses a cleaner three-ring shared conveyor built around direct plate selection instead of a single fixed EAT station. All four Lickitung remain fixed around a smaller table; plates move continuously and in sync, the player taps any glowing plate currently in reach, and the old centre copy / on-plate names and prices / oversized EAT control are removed. A compact side menu carries the value information instead.

The belt has been slowed from the original stepped 6.24 s lap equivalent to a smooth 7.2 s lap. Three staggered rings provide multiple choices at each station while preserving the existing 60-second scoring, combo, hot-tea, records, rewards and achievement rules. CPU decision cadence was retuned for the wider choice set so Normal remains competitive rather than allowing CPUs to vacuum all three rings.

See `TEST_REPORT_v0.40.25.md` for verification details.