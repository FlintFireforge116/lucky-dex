## v0.50.2 — Dream World mechanics polish

Wailord’s Water Spout now uses only the left/right controls for movement. Pokémon caught on the water stream stay attached to Wailord until the player presses the new SHOOT button, then launch using their catch position for trajectory; any Pokémon splashing into the water still resets the combo/multiplier. Normal remains a 15-ball clear. Ice Cream Scoop has replaced the old aggregate lean/topple thresholds with per-scoop physics bodies: every scoop carries its own position, velocity, rotation and angular velocity, support is evaluated from the loaded stack’s centre of mass, and scoops roll/slip/fall individually when physical support is lost. Existing achievements and forceable rare-event settings are unchanged. Android identity remains `com.example.luckydex`, versionName `0.50.2`, versionCode `5002`. No Codex was used.

## v0.50.1 — Dream World visual polish

Dream World now uses original Pokémon Dream World artwork for the venue and both minigame playfields, with the bundled venue SVG retained as an offline fallback. Ice Cream Scoop adds a Combee supervisor/20-inch target treatment, stronger contrast, non-selectable game UI and slightly more sensitive lean/collapse tuning. Wailord’s Water Spout uses the Dream World sea presentation, darker readable HUD/panels, smaller/cleaner Wailord staging and removes the tiny moving Pokémon name tags. Rare-event settings and all existing achievements remain unchanged. Android identity remains `com.example.luckydex`, versionName `0.50.1`, versionCode `5001`. No Codex was used.

## v0.49.0 — Dream World · Ice Cream Scoop

Dream World is now a dedicated Arcade location with **Ice Cream Scoop** as its first activity. Scoops sweep across the screen and must be dropped onto the growing tower; overlap, cumulative lean and difficulty-specific stability determine whether the scoop lands or the tower collapses. Easy / Normal / Hard each change speed, scoop width and stability. Runs track height, score, perfects, streaks and difficulty bests in Arcade Records.

A rare **Dream Scoop** can appear during a run, with Off / Vanilla 2% / Test 25% / Always controls in Settings. Landing it safely grants a reserved-safe random Arcade prize and unlocks a hidden achievement. Six Ice Cream Scoop achievements ship with the game, including height, Hard-mode, perfect-chain, Dream Scoop and full 20-scoop tower goals. Android identity remains `com.example.luckydex`, versionName `0.49.0`, versionCode `4900`. No Codex was used.

---

## v0.48.2 — Slot icon art pass

The Mauville Slot Machine now uses actual dedicated slot symbol art for the non-Pokémon reels instead of plain text glyphs: custom Red 7, Blue 7, Cherry, Replay and Power icons now render in the reels and paytable, while Azurill, Lotad and Pikachu continue to use the in-game Pokémon sprites. A dedicated Prize / Mystery Gift icon is also shown in win and jackpot result banners so rewards read more cleanly at a glance. Android identity remains `com.example.luckydex`, versionName `0.48.2`, versionCode `4802`. No Codex was used.

## v0.48.1 — Game Corner consolidation + spinning Slot Machine reels

Arcade navigation is restored to the venue carousel from v0.47.4. Only the Game Corners are consolidated: Arcade now has one top-level **Game Corner** venue, which opens a regional submenu for **Goldenrod** (Voltorb Flip), **Celadon** (Poké Ball Drop), and **Mauville** (Roulette + Slot Machine). Existing game IDs, saves, records, achievements and mechanics are unchanged.

The Mauville Slot Machine now uses continuously scrolling vertical reel strips while each reel is live, with each stopped reel snapping to its real resolved position. The redundant 1 / 2 / 3 coin labels and large spinning/instruction panel were removed; stake controls now show only 25 / 50 / 75 Lucky Coins and the cabinet keeps only compact result feedback. Android identity remains `com.example.luckydex`, versionName `0.48.1`, versionCode `4801`. No Codex was used.

---

## v0.48.0 — Mauville Slot Machine + unified Arcade browser

The existing Game Corner now includes a Gen III-inspired Mauville Slot Machine with 1/2/3-coin betting (scaled to 25/50/75 Lucky Coins), the original five payline progression, manual left-to-right reel stopping, up-to-four-symbol regular reel slip, instant Reel Time stopping, scaled Gen III payout ratios, Pika Power, Replay, machine luck, Red/Blue 7 state changes, permanent records and achievements. Rare Reel Time remains forceable from Settings at Off / 2% / 25% / 100%, and interrupted paid spins are refunded safely.

Arcade now opens directly to one **All Games** catalogue. **Locations** is a secondary browser that groups those same games by their existing venues. Launching through either route preserves the same saves, records, achievements and game IDs, while Back returns to the route the player came from. Android identity remains `com.example.luckydex`, versionName `0.48.0`, versionCode `4800`. No Codex was used.

## v0.47.2 — Mauville Roulette table polish

Roulette now gives the wheel the visual priority it needs on phones: the larger wheel sits above the complete betting mat, the four Pokémon are interleaved around the 12 slots, and Pokémon sprites are no longer enclosed by decorative circles. The wheel itself now spins for just over three seconds while the ball travels in the opposite direction before settling. Colour and Pokémon group bets highlight every currently valid covered slot on both the mat and wheel.

A rare **Golden Ball** can appear on any spin and awards a bonus equal to 10× the current stake in addition to any normal winning payout. Golden Balls persist visibly in their settled pocket for the six-ball table, have permanent records and a hidden achievement, and can be forced from Settings at Off / 2% / 25% / 100%. Android identity remains `com.example.luckydex`, versionName `0.47.2`, versionCode `4702`. No Codex was used.

## v0.45.4 — Elemental Gauntlet attack-system rewrite

Elemental Gauntlet no longer reskins the same lane/circle hazards. Each element now has genuinely different mechanics: Fire uses falling meteors and sweeping fire fronts with safe gaps; Water uses riptides and whirlpools; Electric uses branching bolt strikes and chain-lightning arcs; Ice uses diagonal shard volleys and crystalline freeze bursts; Psychic uses expanding mind waves and full-arena angled psi beams.

The old fixed group/cluster cadence has also been removed. Easy, Normal, Hard and Goldenrod divisions now use continuously varying stochastic attack gaps with overlapping telegraphs and occasional bursts, so there is no repeating attack/rest beat to learn. The finite passive Sp. Def shield and 30 HP reserve remain unchanged, as do Prismatic Storm controls, records and achievements. Android identity remains `com.example.luckydex`, versionName `0.45.4`, versionCode `4504`. Codex was not used.

## v0.45.3 — Elemental Gauntlet endurance pass

Elemental Gauntlet's passive Sp. Def shield is now a finite run-long resource: it never regenerates between hits, waves or downtime. Hard has been extended into sustained bullet-hell phases rather than short bursts, rising from roughly 27 hazards / 8 seconds in Fire to 42 hazards / 12 seconds in Psychic. Normal and Easy are also longer, while Hard retains its clustered, overlapping attack timing and bespoke elemental visuals.

## v0.45.1 — Elemental Gauntlet intensity pass

Elemental Gauntlet now plays as a proper escalating bullet-hell survival event. The old generic Defend meter has become a real rechargeable shield whose maximum strength scales directly with the chosen Pokémon’s base Special Defense. Shielded impacts consume that pool before HP, can visibly break through, and high-Sp. Def Pokémon therefore have much more emergency protection without replacing skilled dodging.

Attack density and timing have been rebuilt, especially on Hard: hazards arrive in overlapping clusters rather than isolated single telegraphs, later waves carry substantially more pressure, and Hard is intentionally a survival-grade step above Normal. Each element now has distinct attack presentation and geometry: flame bursts / fire walls, rushing water / water orbs, jagged lightning bolts / electric fields, ice shards / beams, and expanding psychic shockwaves / unstable psychic orbs. The existing Prismatic Storm settings control, records, Goldenrod integration and seven Elemental Gauntlet achievements remain intact.

Android identity remains `com.example.luckydex`, versionName `0.45.1`, versionCode `4501`. This was implemented directly in the supplied v0.45.0 source; Codex was not used.

## v0.45.0 — Elemental Gauntlet (Special Defense)

Elemental Gauntlet is now the fifth playable Pokémon Challenge Course / Goldenrod event. Choose a caught Pokémon and survive five telegraphed special-attack waves — Fire, Water, Electric, Ice and Psychic — by dragging clear of danger or holding Defend when trapped. Player execution remains decisive: a clean dodge always takes zero damage, while the Pokémon’s real base Special Defense strongly changes the cost of getting hit. Exhibition supports Easy / Normal / Hard, and the existing three-round Division Cup / Type Cup framework supports the new event with seeded CPU scoring and trophies.

A rare **Prismatic Storm** mixes elemental hazards through all five waves and awards a reserved-safe rare prize when cleared. Its normal chance is 2%, with Off / 2% / 25% / 100% controls in Settings for testing. Seven achievements cover first play, 10 plays, full clear, Hard clear, flawless clear, Prismatic survival and a Master Division win. Permanent records track clears, best scores, remaining HP, perfect waves, dodges, defended hits, damage and Prismatic results. Existing Goldenrod Grand Champion requirements are deliberately unchanged so previously earned achievements are not invalidated.

Android identity remains `com.example.luckydex`, versionName `0.45.0`, versionCode `4500`. See `TEST_REPORT_v0.45.0.md` for verification and environment limitations. This pass was edited directly from the supplied v0.44.0 source; Codex was not used.

## v0.44.0 — Pokémon sleeve catalogue

Based solely on the supplied v0.43.1 source. Profile → Customise now contains 202 offline sleeve designs: 114 physical TCG, all 78 reference TCG Pocket designs, and 10 illustrated LuckyDex originals. Search, source/theme filters and larger previews support phone browsing. All 30 legacy IDs remain valid; four starter sleeves remain free. Small themed reward groups use existing saved Adventure, collection, TCG, Arcade and Goldenrod evidence, with secret requirements concealed until discovery. Shared pack and Trade backs follow the equipped sleeve.

Android identity remains `com.example.luckydex`, versionName `0.44.0`, versionCode `4400`. See `TEST_REPORT_v0.44.0.md` for checks and inherited baseline test failures, `docs/COSMETICS_SOURCES_v0440.md` for provenance, and `docs/COSMETICS_PROGRESSION_v0440.md` for durable unlock rules. No publication or external repository change is part of this delivery.

## v0.43.1 — Impact Trial low-Defense expression

Impact Trial now gives very low-Defense Pokémon a much heavier Harden workload and much harsher unblocked damage, while preserving zero damage for perfect Harden clears. Defense below 20 no longer flattens to the same effective value, and tournament CPU scoring uses the same low-end separation.

Android identity remains `com.example.luckydex`, versionName `0.43.1`, versionCode `4301`. See `TEST_REPORT_v0.43.1.md` for verification details.

## v0.43.0 — Goldenrod stat expression and Type Cup trophies

Goldenrod stats now use one steep, diminishing shared curve but express themselves physically in each event: Speed changes Dash pace/acceleration, Attack sets Power Trial ceiling, Defense changes Impact workload/mitigation, and Sp. Atk changes Target Range projectile power/trajectory. CPU rivals use the same stat curve. The Trophy Cabinet now exposes separate Type Cup trophy tracks, and Target Range removes the incorrect prop/tree treatment.

Android identity remains `com.example.luckydex`, versionName `0.43.0`, versionCode `4300`. See `TEST_REPORT_v0.43.0.md` for verification details.

## v0.42.4 — Target Range tournament balance

Based only on the supplied v0.42.3 source archive. This is a bounded balance
release: Target Range shooting, visuals, controls, Golden Target behavior and the
shared Goldenrod tournament rules are unchanged. Only Target Range simulated
opponent scoring was retuned so Rookie is forgiving without becoming automatic,
with a clearer step-up through Poké, Great, Ultra and Master.

In the deterministic balance sample used by the regression suite, Rookie AI has
a median round score of about 71 (90th percentile about 85, rare maximum about
97). A 75-point player round takes a Rookie podium in roughly 70% of sampled
fields; a 90-point round wins roughly 91%, leaving occasional standout rivals.
Later rounds receive only modest score escalation because they already contain
more player targets.

See `TEST_REPORT_v0.42.4.md` for exact verification and environment limitations.
Android identity remains `com.example.luckydex`, versionName `0.42.4`, versionCode
`4204`.

## v0.40.25 — Sushi-Go-Round three-ring redesign

Sushi-Go-Round now uses a cleaner three-ring shared conveyor built around direct plate selection instead of a single fixed EAT station. All four Lickitung remain fixed around a smaller table; plates move continuously and in sync, the player taps any glowing plate currently in reach, and the old centre copy / on-plate names and prices / oversized EAT control are removed. A compact side menu carries the value information instead.

The belt has been slowed from the original stepped 6.24 s lap equivalent to a smooth 7.2 s lap. Three staggered rings provide multiple choices at each station while preserving the existing 60-second scoring, combo, hot-tea, records, rewards and achievement rules. CPU decision cadence was retuned for the wider choice set so Normal remains competitive rather than allowing CPUs to vacuum all three rings.

See `TEST_REPORT_v0.40.25.md` for verification details.