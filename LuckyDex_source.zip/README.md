## v0.42.5 — Shared Goldenrod Pokémon picker search and sort

Based on v0.42.4. The shared Goldenrod Challenge Course Pokémon picker now has a compact Search + Sort toolbar used by Dash, Power Trial, Impact Trial and Target Range across Exhibition, Division Cups and Type Cups. Sort labels adapt to each event's relevant stat, with highest/lowest stat, level, name and Pokédex-number choices. Competitive cups group eligible Pokémon first before applying the chosen sort, while search matches Pokémon names or Pokédex numbers.

This is a bounded picker usability release; tournament rules, event mechanics, AI balance, rewards and save progression are unchanged. See `TEST_REPORT_v0.42.5.md` for verification details. Android identity remains `com.example.luckydex`, versionName `0.42.5`, versionCode `4205`.

## v0.42.4 — Target Range tournament balance

Based only on the supplied v0.42.3 source archive. This is a bounded balance
release: Target Range shooting, visuals, controls, Golden Target behavior and the
shared Goldenrod tournament rules are unchanged. Only Target Range simulated
opponent scoring was retuned so Rookie is forgiving without becoming automatic,
with a clearer step-up through Poké, Great, Ultra and Master.

In the deterministic balance sample used by the regression suite, Rookie AI has
a median round score of about 71 (90th percentile about 85, rare maximum about
97). A 75-point player round takes a Rookie podium in roughly 70% of sampled
fields; a 90-point round wins roughly 91%, leaving occasional standout rivals.
Later rounds receive only modest score escalation because they already contain
more player targets.

See `TEST_REPORT_v0.42.4.md` for exact verification and environment limitations.
Android identity remains `com.example.luckydex`, versionName `0.42.4`, versionCode
`4204`.

## v0.40.25 — Sushi-Go-Round three-ring redesign

Sushi-Go-Round now uses a cleaner three-ring shared conveyor built around direct plate selection instead of a single fixed EAT station. All four Lickitung remain fixed around a smaller table; plates move continuously and in sync, the player taps any glowing plate currently in reach, and the old centre copy / on-plate names and prices / oversized EAT control are removed. A compact side menu carries the value information instead.

The belt has been slowed from the original stepped 6.24 s lap equivalent to a smooth 7.2 s lap. Three staggered rings provide multiple choices at each station while preserving the existing 60-second scoring, combo, hot-tea, records, rewards and achievement rules. CPU decision cadence was retuned for the wider choice set so Normal remains competitive rather than allowing CPUs to vacuum all three rings.

See `TEST_REPORT_v0.40.25.md` for verification details.
