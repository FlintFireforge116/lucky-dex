# LuckyDex v0.25.6 — tighter Fossil Dig reveal thresholds

LuckyDex v0.25.6 is a focused Fossil Dig usability patch on top of v0.25.5.

## Changes

- Artifacts are now counted as recovered once 75% of their occupied excavation cells are fully cleared.
- This keeps the existing shaped masks, but no longer forces you to clear the final empty-looking edge/corner cell when the object is visibly exposed.
- Small 2×2-style finds can therefore count at 3/4 cleared cells; larger finds keep proportionally more of their shape requirement.
- The dig UI no longer labels finds as `UNBANKED`. Recovered finds still remain mechanically at risk until you leave or finish the dig.
- The End Dig confirmation now explains delayed collection without the extra status label.

## Android identity

- applicationId: `com.example.luckydex`
- versionCode / versionName: `256` / `0.25.6`
- permanent keystore SHA256: `90de91cea469f0eec5fbd69389cf03adc94ced396fa2ec85e2a51d2365a4f6d3`

Use the existing GitHub Actions workflow to build the APK. This source archive retains the permanent LuckyDex signer so it updates the existing installation.
