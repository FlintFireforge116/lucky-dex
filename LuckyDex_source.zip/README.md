# LuckyDex v0.26.3 — booster-art build reliability + pack-summary fit

LuckyDex v0.26.3 builds on v0.26.2, fixes the GitHub Actions booster-art rate-limit failure, and preserves the existing Android update identity.

## Changes

- Fossil Dig loose-card finds remain **15%** and draw from the complete physical TCG catalogue, independent of cards or sets already owned/opened.
- Fossil Dig sealed-booster finds remain the rarer **4%** reward and draw from the complete genuine physical booster catalogue, independent of player discovery.
- Real physical booster packshots are materialised into `app/src/main/assets/booster-art-v0260/` during the GitHub build. The APK uses those local assets at runtime; it does not query GitHub for booster artwork on the phone.
- The artwork build walks the English set catalogue, picks one representative real packshot for every set that actually has a booster packshot, and refuses the build if Base Set coverage is missing.
- Card Shop packs and reward packs use the same local artwork system and old-style pointed sealed-pack wrapper.
- Successfully recovered booster rewards are banked immediately as sealed inventory before the reward decision, so they are not lost if the opener is closed or interrupted.
- At the end of a dig, each surviving booster offers **Open Now** or **Save for Later**.
- Collection now includes **Sealed Packs**, showing the real pack artwork, set name, quantity owned and an **Open Pack** button.
- Opening a stored booster costs nothing. The sealed copy is only consumed when the wrapper is actually torn; backing out beforehand keeps it unopened.
- The normal Pack Shop remains buy-and-open only. There is no Buy & Save option.
- The sealed-pack API is reusable for future minigame rewards.
- Existing sprite-shaped Fossil Dig recovery masks, authentic archaeology assets and the current cave-in risk rules remain intact.

## Android identity

- applicationId: `com.example.luckydex`
- versionCode / versionName: `263` / `0.26.3`
- permanent keystore SHA256: `90de91cea469f0eec5fbd69389cf03adc94ced396fa2ec85e2a51d2365a4f6d3`
- signing certificate SHA256: `06:9B:44:0B:7D:31:5E:FB:A1:F1:54:73:10:9A:E3:D9:45:AD:1F:A8:05:9E:6A:A2:62:72:6C:98:6D:39:8A:6A`

The package ID and permanent signer are unchanged from the existing LuckyDex line, so the generated APK remains an in-place update for an installation signed with that same key.

Upload this source to GitHub and use the existing **Build Lucky Dex APK** workflow. The workflow materialises the complete local booster artwork, installs the browser-test dependencies, runs the regression suite, verifies the permanent signer, and builds the APK.

## v0.26.2 patch

- Gradle `preBuild` now materialises physical booster artwork during GitHub Actions even when the outer repository workflow only unzips the source and calls Gradle.
- Physical packshot materialisation accepts WebP, PNG and JPEG sources, so PNG-only sets such as Perfect Order are included.
- Pack-complete summaries use full-card `contain` rendering, three columns on phones, and a non-overlaying exit button.
