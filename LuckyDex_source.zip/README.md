# Lucky Dex v0.5 — Native-feeling App Flow

Lucky Dex v0.5 is the UI/flow overhaul. The goal is that the Android build behaves like a small Pokémon game rather than a long webpage inside a WebView.

## v0.5 highlights

- New full-screen **title screen** with PRESS TO START, Trainer Rank and current party sprites.
- First-time **starter selection is its own Professor’s Lab screen**. It can no longer sit above the Expedition list in the same scroll.
- Adventure now opens to a proper **menu hub**: Hunt Pokémon, Explore Routes, Manage Team and Bag/Supplies. Hunt and Expedition selection are dedicated sub-screens.
- **Battles and Expedition encounters are full-screen overlays** and always start at the top of the display. Android/back navigation returns through the app state instead of browser-like scrolling.
- Expedition map remains available between rooms; battle screen supports switching partners, items and retreating.
- **Pack Shop is a fixed one-screen menu**. Opening a pack moves to a dedicated full-screen reveal flow; the shop itself does not require scrolling.
- Physical Pokémon TCG boosters are now **10 cards**: 4 Common, 3 Uncommon, 2 reverse-foil slots and at least 1 Rare-or-higher foil slot. TCG Pocket remains a 5-card format.
- Pack opening is one-card-at-a-time to avoid a tall webpage of cards. Pack summary scrolls only after the pack is complete.
- **Card artwork fallback is stronger:** TCGdex remains primary; when an English physical card has no usable TCGdex scan, Lucky Dex matches the set against the open Pokémon TCG data catalogue and falls back to `images.pokemontcg.io`. Existing broken stored physical cards can self-repair when rendered.
- **Voltorb Flip** now gives an unmistakable full-screen CLEAR / VOLTORB result instead of silently starting another board. Revealed Voltorb uses a large pixel sprite.
- **Clefairy Match** shows STAR / SONG / MOON / SPIN symbols during playback and player input. Pressed pads flash yellow so taps are visible.
- **Berry Blender rewritten:** one-direction continuous spin, accelerates to a peak and then decelerates to a stop. Tap MIX as the moving arrow crosses the fixed marker for PERFECT / GOOD / MISS, with speed, hit and combo feedback.
- Collection/Profile/Arcade hubs keep their own internal scrolling where content genuinely needs it, while the app shell itself stays locked to the screen.
- Android WebView overscroll/scrollbars removed and system bar colours matched to Lucky Dex.
- v0.1–v0.4 saves migrate forward without resetting collection/progression.

## Build

The existing GitHub Actions workflow watches `LuckyDex_source.zip`. Upload this ZIP over the existing file (do not delete it first) and commit to `main`; GitHub will build the APK automatically.

Fan-made personal project. Pokémon, Pokémon TCG and related artwork/trademarks remain property of their respective rights holders.
