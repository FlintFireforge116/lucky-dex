# Lucky Dex v0.15.4 — Pack Flight Orientation Hotfix

Fixes the v0.15.3 reveal regression where fractional travelling rotations left completed cards parked at a diagonal and could expose the card back after the reveal.

- all travel rotations now terminate on whole 360-degree turns
- completed cards are normalised to a canonical upright transform
- common/uncommon reveals remain restrained
- higher rarity tiers retain progressively deeper approach, more turns, stronger payoff and longer timing
- existing v0.15.3 art-resolution fixes are preserved
