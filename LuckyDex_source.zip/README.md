# Lucky Dex v0.2

A lightweight personal Pokémon collecting app for Android built around two loops: hunting Pokémon/shinies and opening Pokémon card packs.

## v0.2 highlights

- **Rarity-aware card packs.** v0.1 sampled every card uniformly, which made special cards far too common. v0.2 builds five rarity slots and heavily gates the high-rarity slot.
- **Interactive pack opening.** Prepare a pack, tap the foil to tear it, then tap each face-down card to reveal it. Tap an already-revealed card again for a full-screen view.
- **Full-screen card viewer** from both pack reveals and the binder.
- **Pokémon zones:** Meadow, Cave, Coast and Volcano. Each zone lazily builds a themed encounter pool from PokéAPI type data.
- **Real encounter flow:** search the zone → meet a wild Pokémon → throw a Poké Ball → catch animation → collection.
- **Less spammy hunting.** Search and capture animations create pacing instead of every tap immediately awarding a Pokémon.
- **Rebalanced encounters.** The v0.2 default shiny rate is 1/2048 and the legendary gate is about 1/400. The old 1/512 option remains in Settings.
- **Collection filters and progress:** Pokédex by generation, card binder by sets you have actually started, plus shiny/rare/duplicate filters.
- **Old save migration.** Existing v0.1 Pokémon/cards are retained. A v0.1 save still on the old default 1/512 shiny rate is migrated to the new 1/2048 default.

## Data / assets

The APK stays small because artwork is loaded at runtime:

- Pokémon names, type pools and sprites: PokéAPI / PokeAPI sprites repository.
- Pokémon TCG and Pokémon TCG Pocket set/card metadata and images: TCGdex.

Progress is stored locally in Android WebView localStorage.

## APK build

The repository workflow watches `LuckyDex_source.zip`. Replacing that ZIP on `main` triggers **Build Lucky Dex APK** automatically. When the run succeeds, download the `LuckyDex-APK` artifact and install the APK inside it.

This is a fan-made personal project. Pokémon and related artwork/trademarks remain property of their respective rights holders.
