# Lucky Dex v0.1

A lightweight personal Pokémon collection app built around two loops:

- **Shiny Hunt** — random encounters using PokéAPI pixel sprites, configurable shiny odds, rare-hit tracking, persistent collection.
- **Pack Opening** — physical Pokémon TCG + Pokémon TCG Pocket set/card data and artwork from TCGdex, with a persistent binder and duplicate counts.

## Build as Android APK

1. Open this folder in Android Studio.
2. Let Android Studio install/sync Android SDK 35 + Gradle dependencies if prompted.
3. Choose **Build > Build APK(s)**.
4. The debug APK will appear under `app/build/outputs/apk/debug/`.

No external app dependencies are required beyond the standard Android Gradle plugin.

## Data / assets

The app intentionally does **not** bundle thousands of Pokémon/card images. It loads them at runtime so the APK stays small:

- Pokémon sprites: PokeAPI sprites GitHub repository.
- Pokémon TCG / TCG Pocket cards and set metadata: TCGdex API/assets.

The app caches the collection/save locally through WebView localStorage, so progress persists between launches. Network access is required for uncached artwork and live card/set data.

## Notes

This is a fan-made personal project. Pokémon and related artwork/trademarks remain property of their respective rights holders. Do not redistribute copyrighted artwork as your own.

## Build the APK in GitHub (no PC required)

This repository includes `.github/workflows/build-apk.yml`.

Every push to `main` automatically builds a debug APK in GitHub Actions. On a phone:

1. Open the repository on GitHub.
2. Tap **Actions** → **Build Lucky Dex APK**.
3. Open the newest successful run.
4. Under **Artifacts**, download **LuckyDex-APK**.
5. Extract the downloaded ZIP and install `LuckyDex-v0.1-debug.apk`.

Android may ask you to allow installs from your browser/files app the first time.
