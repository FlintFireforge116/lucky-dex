# Lucky Dex v0.14 — Pack Opening

Pack-opening-only update. Clefairy Match is unchanged.

- Deterministic newest-first set ordering with release-date enrichment and caching;
  unknown dates remain last in source order.
- IndexedDB/local artwork before network before placeholder. Cached packs open
  completely in airplane mode; corrupt images do not suppress usable fallback.
- Continuous XYZ perspective approach, slight overshoot/settle, then a shared-card
  Y flip. High-tier ribbons cross front/rear canvas planes, intensify during the
  flip, emit sparks, and fade. Skip and screen exit cancel owned animations.
- Existing pack balancing, economy, save schema and v0.13 cache keys retained.

## Tests and build

With Node and Chrome installed:

```sh
npm install
npm test
```

Browser tests use installed Chrome (`CHROME_PATH` can override its path), or
Playwright Chromium. If neither is installed, run `npx playwright install chromium`.
Tests mock external services and cover 360×800 and 412×915 viewports, IndexedDB
artwork, offline full-pack flow, chronology, duplicate commits and cancellation.

Build with Java 17, Gradle 8.9 and Android SDK 35:

```sh
gradle --no-daemon :app:assembleDebug
```

APK: `app/build/outputs/apk/debug/app-debug.apk`. The existing GitHub Actions
workflow also builds it. The portable tools used locally are not in the source ZIP.

## Local visual replay

In the WebView/browser console:

```js
LuckyDexDebug.playPackTier('crown')
```

Also accepts `common`, `rare`, `one-star`, `two-star`, `three-star`, or 0–5.
Replay uses local artwork and does not consume currency or write save data.

See `docs/pack-opening-verification.md` for evidence and device-testing limitations.
