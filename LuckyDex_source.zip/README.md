# LuckyDex v0.23.1 — current baseline

Current release: **v0.23.1 / versionCode 231**. Adventure 2.0 from v0.23.0 remains the active Adventure architecture. This polish release normalizes Arcade rewards, expands Tile Puzzle to a large local scene pool, and adds persistent visible Holo/Reverse-Holo shimmer across pack reveal, binder and card modal. See `docs/V0230_REPORT.md` for Adventure 2.0 and `docs/V0231_REPORT.md` for this release.

The package remains `com.example.luckydex`; save origin/key and original-signer update path are unchanged.

---

# LuckyDex v0.22.3 — targeted phone fixes

This pass starts from the supplied v0.22.2 source and retains its runtime owners, restored Clefairy/Blender/Tile Puzzle behavior, Android inset strategy, package ID, file storage origin, save key and signing identity.

- World/venue artwork is a contained 40% usable-height header, with controls/cards below it and location-specific cropping. Seven headers use authentic menu/title/building art; the approved Moon scene is retained.
- Berry Picker uses larger lower berries, larger touch targets, reliable drag and tap-to-feed fallback, and a separate helper row that does not cover Start.
- Fossil Dig is 6 columns × 7 rows of independent square cells. Each covered rock reveals one immutable soil/metal/complete-fossil result and costs one of 12 digs. Namespaced cell states prevent full-row strips.
- Ball Drop preserves radius 30, three balls and payouts; clearance and a local low-progress watchdog prevent wedges.

See [v0.22.3 report](docs/V0223_REPORT.md), [venue provenance](docs/V0223_VENUE_SOURCES.md), [Berry details](docs/V0223_BERRY.md), and [Ball physics evidence](docs/V0223_BALL.md).

Development verification: Node 22+, Python 3.10+, `python -m pip install -r requirements-dev.txt`, `npm ci`, `npx playwright install chromium`, `npm test`. The APK has no Python/Node/Pillow runtime dependency. Test images and contact sheets are in `artifacts/v0223/qa/`.

The signed local APK uses the existing development key. Keys are excluded from Git/source exports. CI can restore the same key from its existing secret; an ephemeral fallback key cannot update an existing install.

The notes below describe earlier releases and are historical, not the current UI contract.

---

# LuckyDex

## v0.22.2 device geometry + touch hotfix

- Android system-bar insets now resize the WebView viewport instead of padding it, so fixed app/Arcade chrome cannot render underneath Samsung status or navigation bars.
- Berry Picker uses a dedicated touch-event drag path for Android WebView in addition to mouse/stylus Pointer Events.
- Fossil Dig is now a clear 6×7 one-tap board: each square reveals exactly one final result (soil, metal, or a complete fossil), with 12 digs.
- Arcade world and venue art use full-scene cover composition instead of landscape strips surrounded by blurred filler.

# LuckyDex 0.22.1 phone UI focus
## v0.22.1 phone UI focus
- Berry Picker now uses captured touch pointers so drag-and-drop remains reliable after the finger leaves the berry button in Android WebView.
- Berry Service is laid out as a portrait game scene: the stage takes the remaining screen height, customers are smaller, the tree is visually dominant, and the help text overlays the scene rather than stealing vertical space.
- All Arcade games are top-composed full-height app screens instead of vertically centred web panels; short-phone spacing is compacted and scrollbars are hidden.
- Extra bottom breathing room protects primary controls from gesture/navigation areas.
- Regression coverage now checks every Arcade primary control at phone sizes and requires Berry Picker to dominate the viewport.


Targeted follow-up to the v0.21 recovery baseline. This release keeps the v0.21 single-owner runtime architecture while restoring the preferred Moon Stage Clefairy memory game and historical Berry Blender presentation/mechanics, removing Head It from active play, simplifying Fossil Excavation, enlarging Poké Ball Drop, improving Tile Puzzle reference scenes, making the Arcade world/venues fill the Android-safe usable app area, and switching Kalos world art away from the Berry Picker gameplay screenshot.

The active Arcade now has nine visible games: Berry Picker, Tile Puzzle, Voltorb Flip, Poké Ball Drop, Berry Blender, Clefairy Match, Fossil Excavation, Unown Decoder, and Who's That Pokémon. Legacy save fields remain tolerated so old saves can migrate without discarding retired-game data. Settings now includes Import Save alongside Export Save.

The package identity remains `com.example.luckydex`, the WebView origin remains `file:///android_asset/index.html`, and the primary save key remains `luckyDexSave`. These invariants are intentional so an APK signed with the same existing certificate can update an installed copy without resetting its WebView data.

## Development checks

Requires Node 22+, Python 3.10+ and a Chromium browser:

```
npm ci
npx playwright install chromium
npm test
```

On Windows, tests use installed Chrome by default; set `LUCKYDEX_BROWSER` to another Chromium executable. On other platforms, tests use Playwright Chromium. The suite tests actual production scripts with remote requests blocked and writes phone screenshots to `artifacts/qa/`. No Android bridge is mocked to establish native device behavior.

```
python scripts/fetch_arcade_v0200_assets.py --check
gradle --no-daemon :app:assembleDebug
```

Build requirements: Java 17+, Gradle 8.9+, Android platform 35. The source package excludes signing keys and tool caches. The distributable source ZIP deliberately excludes `*.keystore`. CI should restore the existing LuckyDex development signing identity from `LUCKYDEX_KEYSTORE_BASE64`; without that secret, an ephemeral debug signer cannot update an installation signed with the established certificate.

## Source history

[Previous release notes](docs/RELEASE_HISTORY.md) and the original prompt/handover documents are historical records. The current recovery requirements are in [RECOVERY_REQUEST.md](docs/RECOVERY_REQUEST.md). Historical runtime layers are preserved in the Git baseline commit rather than loaded in the APK.
