# LuckyDex 0.22.0 targeted restore

Targeted follow-up to the v0.21 recovery baseline. This release keeps the v0.21 single-owner runtime architecture while restoring the preferred Moon Stage Clefairy memory game and historical Berry Blender presentation/mechanics, removing Head It from active play, simplifying Fossil Excavation, enlarging Poké Ball Drop, improving Tile Puzzle reference scenes, making the Arcade world/venues fill the Android-safe usable app area, and switching Kalos world art away from the Berry Picker gameplay screenshot.

The active Arcade now has nine visible games: Berry Picker, Tile Puzzle, Voltorb Flip, Poké Ball Drop, Berry Blender, Clefairy Match, Fossil Excavation, Unown Decoder, and Who's That Pokémon. Legacy save fields remain tolerated so old saves can migrate without discarding retired-game data. Settings now includes Import Save alongside Export Save.

The package identity remains `com.example.luckydex`, the WebView origin remains `file:///android_asset/index.html`, and the primary save key remains `luckyDexSave`. These invariants are intentional so an APK signed with the same existing certificate can update an installed copy without resetting its WebView data.

## Development checks

Requires Node 22+, Python 3.10+ and a Chromium browser:

```
npm ci
npx playwright install chromium
npm test
```

On Windows, tests use installed Chrome by default; set `LUCKYDEX_BROWSER` to another Chromium executable. On other platforms, tests use Playwright Chromium. The suite tests actual production scripts with remote requests blocked and writes phone screenshots to `artifacts/qa/`. No Android bridge is mocked to establish native device behavior.

```
python scripts/fetch_arcade_v0200_assets.py --check
gradle --no-daemon :app:assembleDebug
```

Build requirements: Java 17+, Gradle 8.9+, Android platform 35. The source package excludes signing keys and tool caches. The distributable source ZIP deliberately excludes `*.keystore`. CI should restore the existing LuckyDex development signing identity from `LUCKYDEX_KEYSTORE_BASE64`; without that secret, an ephemeral debug signer cannot update an installation signed with the established certificate.

## Source history

[Previous release notes](docs/RELEASE_HISTORY.md) and the original prompt/handover documents are historical records. The current recovery requirements are in [RECOVERY_REQUEST.md](docs/RECOVERY_REQUEST.md). Historical runtime layers are preserved in the Git baseline commit rather than loaded in the APK.
