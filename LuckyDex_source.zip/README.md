## v0.40.23 — Run, Rattata, Run top-down readability redesign

Run, Rattata, Run now uses a single top-down four-lane course, adapting Pokémon Dash's world-to-screen camera approach so the player's Rattata stays low on screen and incoming hurdles travel clearly toward the player. Hurdles share one honest world position across all lanes, lane markings and shadows improve depth readability, airborne Rattata lift/scale away from their ground shadow, and the finish line appears in the same scrolling world.

The v0.40.22 gameplay core is intentionally unchanged: run cadence, momentum, six hurdle distances, jump duration, stumble penalty, CPU difficulty, three-second finish window, rewards, records and achievements retain the same rules.

See `TEST_REPORT_v0.40.23.md` for verification details.
