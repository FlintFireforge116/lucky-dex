# LuckyDex v0.25.3 — Rarity truth, fullscreen Oreburgh Museum + curated Tile Puzzle

LuckyDex v0.25.3 focuses on three areas: authoritative card rarity/finish handling, a proper fullscreen pixel-art Oreburgh Museum, and a curated Tile Puzzle image library.

## Card rarity + Secret Rare overhaul
- Card rarity and card finish are now separate concepts. A Common Reverse Holo stays **Common** with a **Reverse Holo** finish instead of being promoted to Rare because it shines.
- Source card/set rarity metadata is authoritative when available. Name/regex inference is retained only as a fallback for incomplete legacy data.
- Pack reveal impact, collection rarity labels, Dust tiers, Rare Hits and trade rarity matching consume the same normalized rarity model.
- **Secret Rare is a maximum-impact chase class** with explicit `SECRET RARE` reveal wording rather than the old generic `SPECIAL PULL` treatment.
- Gold/Hyper/Crown Secret cards retain both traits; e.g. Gold Secret can present as `GOLD SECRET RARE — JACKPOT` rather than losing the Secret classification.
- Promo remains its own trade/economy class, preserving the v0.24.x promo rules.

## Oreburgh Museum + mining visuals
- Museum Collection remains museum-only landscape, but the museum is now a true fullscreen scene rather than a landscape web page with a permanent side information column.
- Exhibit title/count/back controls and item plaque are overlays on the room; closing the plaque returns immediately to the full room.
- Exhibit placement continues to use only the nine genuine Oreburgh display surfaces: three rear cabinets, three right cases, two inner cases and the central pedestal.
- Active excavation/museum item art now uses a coherent offline pixel-art set. The v0.25.2 painterly mining stand-ins are no longer active.
- Classic fossils use authentic Platinum Underground-style sprites where available locally; later fossils, relics and stones remain coherent pixel assets with nearest-neighbour scaling.
- Existing v0.25.2 unbanked-haul, cave-in loss, End Dig, reward routing and museum persistence behaviour is retained.

## Tile Puzzle
- Removed the synthetic Tile Puzzle image generator that pasted Pokémon and berry/item sprites over arbitrary backdrops.
- Tile Puzzle now selects from a curated offline scene library of recognisable Pokémon game locations/scenes.
- Easy / Normal / Hard grid sizes, move logic, scoring and rewards are unchanged.
- Immediate scene repeats are avoided where possible.

## Android update identity
- applicationId: `com.example.luckydex`
- versionCode / versionName: `253` / `0.25.3`
- Permanent keystore and certificate are unchanged from the recovered canonical signer.

## Build
Use the existing GitHub Actions workflow to build the Android APK. This source archive keeps `app/luckydex-dev.keystore` so v0.25.3 installs over the permanent-signer releases.

See `V0253_REPORT.md` and `TEST_REPORT_v0.25.3.md` for implementation and verification details.
