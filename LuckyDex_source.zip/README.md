# Lucky Dex v0.15 — Clefairy Moon Stage

Clefairy-only update on top of the accepted v0.14 pack opening. The pack modules
and original regression tests remain byte-for-byte unchanged.

## Clefairy

- One authoritative continuous-animation controller with overlapping local pose
  fades, character-only motion, a static scenic background and synchronized water
  reflection. No full-scene swapping or animated GIFs.
- STAR reaction/travelling trail, SONG bounce/staggered notes, MOON lift/bloom/
  water response, and an eased 1050 ms SPIN with gold rear/front trails and sparks.
- Cancellable sequences, selection highlights, reset/exit cleanup, background
  recovery and reduced motion. Existing reward formulas are preserved.
- Missing local poses fall back to idle, with a local SVG safety fallback if
  idle itself is unavailable. Spin uses clean idle art, never the baked-effects PNG.

## Accepted pack opening (v0.14)

- Deterministic newest-first set ordering with release-date enrichment and caching;
  unknown dates remain last in source order.
- IndexedDB/local artwork before network before placeholder. Cached packs open
  completely in airplane mode; corrupt images do not suppress usable fallback.
- Continuous XYZ perspective approach, slight overshoot/settle, then a shared-card
  Y flip. High-tier ribbons cross front/rear canvas planes, intensify during the
  flip, emit sparks, and fade. Skip and screen exit cancel owned animations.
- Existing pack balancing, economy, save schema and v0.13 cache keys retained.

## Tests and build

With Node and Chrome installed:

```sh
npm install
npm test
```

Browser tests use installed Chrome (`CHROME_PATH` can override its path), or
Playwright Chromium. If neither is installed, run `npx playwright install chromium`.
Tests mock external services and cover 360×800 and 412×915 viewports, IndexedDB
artwork, offline full-pack flow, chronology, duplicate commits, Clefairy reflection
sync, repeated actions, cancellation, background recovery and missing artwork.
Browser files run serially to avoid competing Chromium performance measurements.

Build with Java 17, Gradle 8.9 and Android SDK 35:

```sh
gradle --no-daemon :app:assembleDebug
```

APK: `app/build/outputs/apk/debug/app-debug.apk`. The existing GitHub Actions
workflow also builds it. The portable tools used locally are not in the source ZIP.

## Local visual replay

In the WebView/browser console:

```js
LuckyDexDebug.playPackTier('crown')
// Open Clefairy Match, then:
LuckyDexDebug.playClefairyAction('spin')
```

Pack replay also accepts `common`, `rare`, `one-star`, `two-star`, `three-star`,
or 0–5. Clefairy replay accepts `star`, `song`, `moon`, `spin`, `idle` and uses
the production animation without changing score/rewards/game state/save data.
Replay uses local artwork and does not consume currency.

See `docs/clefairy-verification.md` and the historical
`docs/pack-opening-verification.md` for evidence and device-testing limitations.
