# LuckyDex v0.25.7 — audited dig art + sprite-shaped recovery

LuckyDex v0.25.7 is a focused Fossil Dig / Oreburgh Museum correctness pass on top of v0.25.6.

## Changes

- Every active Fossil Dig / Museum reward now uses the audited v0.25.7 asset namespace.
- Great Ball, Ultra Ball, Nugget, Big Nugget, Pearl, Big Pearl, Stardust, Star Piece and Rare Bone were replaced with exact upstream Pokémon item sprites.
- 41 sourced sprites are pinned to their upstream Git blob SHA so a merely-present but wrong PNG no longer passes verification.
- The TCG-card placeholder is the only intentional local/non-upstream art because the actual card image is selected at runtime.
- Artifact recovery now follows the actual visible sprite silhouette rather than a coarse rectangular/percentage hitbox.
- Placement footprint and recovery hitbox are separate: the board still reserves enough space to prevent overlap, while recovery ignores transparent image-box corners.
- Every meaningful visible sprite cell must be uncovered before the item counts as recovered.
- All 45 active rewards have explicit recovery-mask coverage, including coin caches and the TCG card.
- Buried TCG card chance is now 6% per dig site (roughly 1 in 17 sites on average), up from 4%.
- Secret Rare remains reachable as the top 0.5% of buried-card rarity rolls.
- The v0.25.6 removal of the visible `UNBANKED` label remains in place; delayed banking/cave-in risk is unchanged mechanically.

## Android identity

- applicationId: `com.example.luckydex`
- versionCode / versionName: `257` / `0.25.7`
- permanent keystore SHA256: `90de91cea469f0eec5fbd69389cf03adc94ced396fa2ec85e2a51d2365a4f6d3`

Use the existing GitHub Actions workflow to build the APK. This source archive retains the permanent LuckyDex signer so it updates the existing installation.
