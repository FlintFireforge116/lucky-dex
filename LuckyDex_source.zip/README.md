# LuckyDex v0.25.2 — Fossil Dig risk + landscape Oreburgh Museum

LuckyDex v0.25.2 turns the v0.25.x Fossil Dig into a real risk/reward excavation loop and rebuilds the museum presentation around the genuine Oreburgh display furniture.

## Fossil Dig v0.25.2
- Fully excavated finds are now **UNBANKED** during the dig. Nothing is added to the Museum, Lucky Coins, Adventure inventory or Card Collection until the run ends.
- `END DIG → END & COLLECT` banks every fully excavated find safely.
- Clearing the full wall also banks the haul safely.
- A wall collapse now has consequences: each recovered/unbanked find has a **60% loss chance**. When at least two finds had been recovered, at least one is guaranteed to survive; a lone find can be lost.
- Collapse results explicitly separate banked rewards from items **Lost in the cave-in**. Only survivors are routed to their real destination.
- Classic fossil excavation art has been replaced by larger, recognisable mining-specific sprites instead of tiny generic bag icons.
- Buried footprints now reflect the visual object size: Helix 4×4, Dome 5×4, Old Amber 4×4, Root 5×5, Claw 4×5, Skull 4×4, Armor 5×4, Odd Keystone 4×4 and Star Piece 3×3.
- Evolution stones, Everstone, Hard Stone and Rare Bone also use larger mining-specific artwork/footprints.

## Oreburgh Museum v0.25.2
- Opening **Museum Collection** requests real Android landscape orientation; leaving it or returning to Fossil Dig restores portrait.
- Android handles the orientation/config-size change without recreating the WebView, preserving the live LuckyDex state.
- The active museum scene uses the authentic Oreburgh room with LuckyDex-added cases removed.
- Exhibit positions are now **case-relative** and use only the genuine three rear cabinets, three outer-right cases, two inner-right cases and central pedestal.
- All 30 museum exhibits fit those genuine surfaces; there is no invisible third inner case and no geology item is positioned on the floor/doorway.
- Odd Keystone retains the prominent central display.
- The museum header uses a valid local fossil asset and the room/plaques are arranged for the wider landscape composition.

## Existing v0.25.x behaviour retained
- 12×9 layered excavation wall with 3–6 non-overlapping multi-tile finds.
- Pickaxe: precise 3-depth hit for 3 wall stability.
- Hammer: 3×3 area hit for 8 wall stability.
- Intact/chipped rock at depths 4/3/2 remains fully opaque; buried finds only begin to appear at the final chipped layer.
- Fossils, Odd Keystone, Relics, stones, Balls, treasure, Lucky Coin caches and rare buried TCG cards remain in the find pool.
- First archaeological copies donate to the Museum; duplicate museum finds sell for Lucky Coins once banked.
- Adventure Balls route to inventory and buried TCG cards route to the Card Collection without incrementing pack-opening counts.

## Android update identity
- applicationId: `com.example.luckydex`
- versionCode / versionName: `252` / `0.25.2`
- Permanent keystore and certificate are unchanged from the recovered canonical signer.

## Build
Use the existing GitHub Actions workflow to build the Android APK. This archive intentionally keeps `app/luckydex-dev.keystore` so v0.25.2 installs over the permanent-signer releases.

See `V0252_REPORT.md` and `TEST_REPORT_v0.25.2.md` for implementation and verification details.
