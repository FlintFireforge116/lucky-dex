# User feedback driving this Codex pass

The user likes the visual target in `reference/TARGET_CLEFAIRY_AND_PACK_OPENING.png`, especially:
- the true sense of motion in the card reveal;
- card coming from distance toward the viewer;
- proper 3D rotation / flip;
- dramatic gold swirl around a very rare card;
- clean, game-like Moon Stage composition;
- Clefairy visibly performing different actions rather than one static sprite with PowerPoint-like effects.

What to avoid:
- static glow layers sold as animation;
- giant rarity labels covering the card;
- full-scene GIF/screenshot swapping;
- scene zooming/warping during idle;
- a reflection that moves differently from the character;
- append-only CSS override stacks;
- alphabetical set order when chronology is requested.
