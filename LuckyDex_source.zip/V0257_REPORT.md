# LuckyDex v0.25.7 implementation report

## Scope

Complete Fossil Dig / Oreburgh Museum asset provenance audit following reports that Rare Bone and Great Ball still looked like LuckyDex-drawn stand-ins.

## Root cause

The previous verifier proved only that a local PNG existed for several items. A subset of assets inherited from early LuckyDex builds were therefore accepted even though their bytes did not match the intended upstream Pokémon item sprite.

## Fix

- Added `arcade/fossil-museum-v0257/manifest.json` with exact upstream repository path and Git blob SHA for every sourced archaeology sprite.
- Added `tests/v0257-complete-dig-asset-audit.test.cjs` so an altered/missing/wrong sprite fails the release contract.
- Replaced Great Ball, Ultra Ball, Nugget, Big Nugget, Pearl, Big Pearl, Stardust, Star Piece and Rare Bone with exact `PokeAPI/sprites` item assets.
- Unified Poké Ball and every other active reward into the v0.25.7 item namespace.
- Kept the TCG placeholder as an explicit exception because actual card artwork is inserted at runtime.

## Visual audit

A full contact sheet of all 42 unique active sprite files was reviewed after replacement. No remaining active reward uses the old generic Ball/treasure drawings.
