# LuckyDex v0.23.1 Test Report

## Scope
Bounded polish release on top of v0.23.0 Adventure 2.0:

1. Normalize active Arcade rewards into a comparable successful-run band while preserving difficulty/skill variation and the 1000-coin Poké Ball Drop jackpot.
2. Expand Tile Puzzle content from three simple backgrounds to a large local scene pool.
3. Add persistent, visibly distinct Holo and Reverse-Holo rendering across physical pack reveal, Collection/binder, pack summary and full-screen card view.

Adventure 2.0 mechanics/ownership are unchanged.

## Release/update identity

- Android package: `com.example.luckydex`
- `versionName`: `0.23.1`
- `versionCode`: `231`
- save key/origin unchanged: `luckyDexSave` at `file:///android_asset/index.html`
- signing workflow/secret path unchanged from v0.23.0

## Arcade payout normalization

All active Arcade game payout paths now pass through `LuckyDexArcadePlatform.awardRun()` and the shared balance table before the existing partner-helper bonus is applied.

Representative raw → normalized successful-run examples:

| Game | Raw | Normalized |
|---|---:|---:|
| Berry Picker | 100 | 100 |
| Tile Puzzle | 90 | 144 |
| Voltorb Flip | 1000 | 140 |
| Poké Ball Drop, ordinary | 90 | 117 |
| Berry Blender | 400 | 140 |
| Clefairy Match | 330 | 149 |
| Fossil Excavation | 180 | 81 |
| Unown Decoder | 1000 | 140 |
| Who's That Pokémon? | 1400 | 140 |

The special Poké Ball Drop jackpot remains 1000+ coins and intentionally bypasses the normal clamp.

## Tile Puzzle content

- 8 packaged local backdrops
- 16 actor/prop scene layouts
- 8 packaged prop sets
- 1,024 backdrop/layout/prop combinations before caught-Pokémon selection/randomisation
- original three Pokémon-Amie scenes retained
- five Adventure 2.0 biome scenes added
- target thumbnail still uses the exact generated source picture

## Holo / Reverse-Holo

New owner: `card-foil-v0231.js` + `card-foil-v0231.css`.

- Holo: concentrated high-contrast prismatic sweep over the artwork region.
- Reverse Holo: distinct whole-card satin/rainbow sweep.
- Pack reveal: foil appears after reveal/payoff.
- Collection/binder: foil remains animated.
- Full-screen card: foil responds to pointer/touch position.
- Pack summary: foil class and variant label retained.
- New physical pulls persist `foilCounts` and preferred `foilKind` on the owned-card record.
- Existing printed Holo cards can be recognised safely from printed rarity and gain shimmer immediately.
- Pre-v0.23.1 historical Reverse-Holo ownership cannot be reconstructed reliably because older releases did not persist the transient reverse slot marker; no guessed migration is performed. New reverse pulls persist correctly.

## TDD / targeted regression

New tests:

- `tests/v0231-polish.test.cjs`
  - representative Arcade payout normalization
  - Ball Drop jackpot exception
  - Tile Puzzle content pool size/local scenes
  - foil identity, persistence and distinct classes
- `tests/v0231-foil-integration.test.cjs`
  - physical pack commit persistence
  - binder foil class
  - full-screen motion foil/badges
  - pack reveal foil class
  - pack summary foil class

RED→GREEN was observed for each feature group before implementation.

## Fresh verification in working source

Static/non-browser test programs: **13/13 pass**.

Included:
- Adventure battle model
- Adventure route/model generation (1,000 seeds per destination inside existing model suite)
- Arcade Ball Drop model
- Arcade Classics model
- Arcade platform/session
- v0.22 restore regressions
- v0.22 update compatibility
- v0.22.1 UI contract
- v0.22.2 device contract
- both v0.23.1 regressions

JavaScript syntax:
- top-level asset JS: **19/19 parse**
- Adventure module JS: **5/5 parse**

Asset verification:
- Arcade authentic scenes/sheets/crops: **44 pass**
- Arcade offline sprites: **2,098 pass**
- Arcade unretouched actors: **2,078 pass**
- venue assets: **8 pass**
- Adventure image audit: **829 images**, **1,025 species**, **386 back sprites**, **0 errors**

Foil isolated browser QA:
- Chromium set-content render succeeded
- Holo computed overlay opacity: `0.88`
- Reverse-Holo computed overlay opacity: `0.70`
- distinct gradients and animation positions active
- screenshot: `LuckyDex_v0.23.1_FOIL_QA.png` (delivered beside source package)

## Environment limitation

The source export intentionally does not contain `node_modules`. The local environment had Python Playwright/Chromium but not the Node `playwright` package required by the repository's `scripts/recovery-browser.cjs`, so browser-dependent Node test programs cannot be truthfully reported as executed here. Attempts fail at module load with `Cannot find module 'playwright'`, not an application assertion failure.

Full-app Chromium navigation is additionally blocked by this execution environment's administrator policy. CI/Codex should run the normal `npm ci` + Playwright browser suite before producing the APK.

No local APK compilation was claimed: the source export does not contain a Gradle wrapper/system Gradle. Existing GitHub Actions remains the authoritative Android build/signing path.
