/* Dedicated Pokémon TCG Pocket catalogue.
   TCGdex is excellent for the physical TCG but its Pocket catalogue/art can lag
   new releases. Pocket packs use the actively maintained community Pocket data
   and a deterministic full-art URL, while keeping the same Lucky Dex card IDs. */
(function(root){
  'use strict';
  const DATA_BASE='https://cdn.jsdelivr.net/gh/flibustier/pokemon-tcg-pocket-database@main/dist';
  const GOHUB_BASE='https://pocket.pokemongohub.net/tcg-pocket/cards';
  const EXCHANGE_RAW='https://raw.githubusercontent.com/flibustier/pokemon-tcg-exchange/main/public/images/cards-by-set';

  // Built in through the current B-series deluxe set so the newest set remains
  // visible even if the small remote set-index request is temporarily stale.
  const BUILTIN_SETS=[
    ['A1','Genetic Apex','2024-10-30',286],['A1a','Mythical Island','2024-12-17',86],
    ['A2','Space-Time Smackdown','2025-01-29',207],['A2a','Triumphant Light','2025-02-28',96],
    ['A2b','Shining Revelry','2025-03-27',111],['A3','Celestial Guardians','2025-04-30',239],
    ['A3a','Extradimensional Crisis','2025-05-29',103],['A3b','Eevee Grove','2025-06-26',107],
    ['A4','Wisdom of Sea and Sky','2025-07-30',241],['A4a','Secluded Springs','2025-08-28',105],
    ['A4b','Deluxe Pack: ex','2025-09-30',379],['B1','Mega Rising','2025-10-30',331],
    ['B1a','Crimson Blaze','2025-12-17',103],['B2','Fantastical Parade','2026-01-29',234],
    ['B2a','Paldean Wonders','2026-02-26',131],['B2b','Mega Shine','2026-03-26',117],
    ['B3','Pulsing Aura','2026-04-28',234],['B3a','Paradox Drive','2026-05-28',109],
    ['B3b','Everyday Wonders','2026-06-30',106],['B4','Ruler of the Skies','2026-07-30',233],
    ['B4a','Team Rocket’s Ambition','2026-08-27',110],['B4b','Deluxe Pack: Mega','2026-09-30',429]
  ].map(([id,name,releaseDate,total])=>({id,name,releaseDate,cardCount:{total,official:total},_pocketDataset:'flibustier-v2',_packSize:/^[AB]4b$/i.test(id)?4:5,_deluxe:/^[AB]4b$/i.test(id)}));

  const RARITY={C:'One Diamond',U:'Two Diamond',R:'Three Diamond',RR:'Four Diamond',AR:'One Star',SR:'Two Star',SAR:'Two Star',IM:'Three Star',UR:'Crown',S:'One Shiny',SSR:'Two Shiny'};
  const fetchCache=new Map();

  function numberId(value){return String(value??'').padStart(3,'0');}
  function artAsset(image=''){
    // Pocket filenames use multiple asset families. Pokémon are cPK_..., while
    // Trainers are cTR_.... The old resolver only accepted PK, so Trainer art
    // silently skipped the GO Hub source and fell through to LOCAL CARD PREVIEW
    // whenever the secondary mirror had not published the newest set yet.
    const m=String(image).match(/c?([A-Z]{2,4}_\d+_\d+_\d+)(?:_|\.)/i);
    return m?m[1]:'';
  }
  function artUrls(setCode,number,image){
    const code=String(setCode||'').trim(),n=String(number??'').trim(),asset=artAsset(image),urls=[];
    if(asset)urls.push(`${GOHUB_BASE}/${code.toLowerCase()}/webp/${asset}.webp`);
    if(code&&n){
      urls.push(`${EXCHANGE_RAW}/${encodeURIComponent(code)}/${encodeURIComponent(n)}.webp`);
      urls.push(`https://pokemon-tcg.exchange/images/cards-by-set/${encodeURIComponent(code)}/${encodeURIComponent(n)}.webp`);
    }
    return [...new Set(urls)];
  }
  function normalizeSet(row){
    const id=row.code||row.id,name=row.name?.en||row.name||id,total=Number(row.count||row.cardCount?.total||0);
    if(!id||/^PROMO/i.test(id)||!total)return null;
    return {id,name,releaseDate:row.releaseDate||'',cardCount:{total,official:total},packs:row.packs||[],_pocketDataset:'flibustier-v2',_packSize:/^[AB]4b$/i.test(id)?4:5,_deluxe:/^[AB]4b$/i.test(id)};
  }
  function mergeCatalog(remote=[]){
    const map=new Map(BUILTIN_SETS.map(s=>[s.id,{...s}]));
    remote.forEach(s=>{const n=normalizeSet(s);if(n)map.set(n.id,{...(map.get(n.id)||{}),...n});});
    return [...map.values()].sort((a,b)=>String(b.releaseDate).localeCompare(String(a.releaseDate)));
  }
  async function fetchJson(url,signal,timeout=4200){
    const key=url;if(!signal&&fetchCache.has(key))return fetchCache.get(key);
    const p=(async()=>{
      const controller=new AbortController(),forward=()=>controller.abort();
      if(signal?.aborted)controller.abort();else signal?.addEventListener('abort',forward,{once:true});
      const timer=setTimeout(()=>controller.abort(),timeout);
      try{
        const r=await fetch(url,{signal:controller.signal,cache:'no-cache'});
        if(!r.ok)throw new Error(`Pocket data ${r.status}`);
        return await r.json();
      }finally{clearTimeout(timer);signal?.removeEventListener('abort',forward);}
    })();
    if(!signal)fetchCache.set(key,p);
    try{return await p;}catch(e){if(!signal)fetchCache.delete(key);throw e;}
  }
  async function catalog(signal){
    try{
      const all=await fetchJson(`${DATA_BASE}/sets.json`,signal),rows=Object.values(all||{}).flat();
      return mergeCatalog(rows);
    }catch(_){return mergeCatalog([]);}
  }
  function cardFromRow(row,set){
    const urls=artUrls(set.id,row.number,row.image),localId=numberId(row.number);
    return {
      id:`${set.id}-${localId}`,localId,name:row.name||`Card ${row.number}`,
      rarity:RARITY[row.rarity]||row.rarity||'Unknown',source:'tcgp',image:urls[0]||'',
      set:{id:set.id,name:set.name},setId:set.id,setName:set.name,
      _pocketNative:true,_pocketDataset:'flibustier-v2',_pocketRarityCode:row.rarity||'',
      _pocketImageFile:row.image||'',_tcgpFallbacks:urls.slice(1),packs:row.packs||[]
    };
  }
  async function setDetail(id,signal){
    // v0.15.7: every current Pocket set is already known locally. Do not make
    // pack opening wait for the remote set catalogue before asking for cards.
    let set=BUILTIN_SETS.find(s=>s.id===id);
    if(!set){const catalogRows=await catalog(signal);set=catalogRows.find(s=>s.id===id);}
    if(!set)throw new Error('Pocket set not found');
    const urls=[
      `${DATA_BASE}/cards/${encodeURIComponent(id)}.json`,
      `https://raw.githubusercontent.com/flibustier/pokemon-tcg-pocket-database/main/dist/cards/${encodeURIComponent(id)}.json`
    ];
    // Race mirrors rather than waiting for one dead endpoint and then another.
    let settled=false,pending=urls.length,lastError=null;
    const rows=await new Promise((resolve,reject)=>{
      urls.forEach(url=>fetchJson(url,signal,4200).then(data=>{
        if(settled)return;
        if(Array.isArray(data)&&data.length){settled=true;resolve(data);return;}
        lastError=new Error('Pocket cards unavailable');if(--pending===0){settled=true;reject(lastError);}
      }).catch(err=>{lastError=err;if(!settled&&--pending===0){settled=true;reject(lastError);}}));
    });
    const cards=rows.map(row=>cardFromRow(row,set));
    return {...set,cardCount:{total:cards.length,official:cards.length},cards};
  }
  function packSize(setOrId){
    const id=typeof setOrId==='string'?setOrId:setOrId?.id;
    return Number((typeof setOrId==='object'&&setOrId?._packSize)||(/^[AB]4b$/i.test(String(id||''))?4:5));
  }
  root.LuckyDexPocket={DATA_BASE,BUILTIN_SETS,RARITY,catalog,setDetail,artUrls,cardFromRow,packSize,mergeCatalog};
})(typeof window==='object'?window:globalThis);
