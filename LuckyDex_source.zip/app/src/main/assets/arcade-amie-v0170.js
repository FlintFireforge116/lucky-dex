(function(root){
  'use strict';

  const platform=()=>root.LuckyDexArcadePlatform||globalThis.LuckyDexArcadePlatform;
  const BERRIES=[
    {id:'cheri',name:'Cheri',image:'https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/cheri-berry.png'},
    {id:'chesto',name:'Chesto',image:'https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/chesto-berry.png'},
    {id:'pecha',name:'Pecha',image:'https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/pecha-berry.png'},
    {id:'rawst',name:'Rawst',image:'https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/rawst-berry.png'},
    {id:'aspear',name:'Aspear',image:'https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/aspear-berry.png'},
    {id:'leppa',name:'Leppa',image:'https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/leppa-berry.png'},
    {id:'oran',name:'Oran',image:'https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/oran-berry.png'}
  ];
  const BERRY_CONFIGS={
    easy:{customers:2,berryCount:3,durationMs:45000,patienceMs:7500,dailyTarget:8,coinCap:70},
    normal:{customers:3,berryCount:5,durationMs:50000,patienceMs:6000,dailyTarget:14,coinCap:100},
    hard:{customers:4,berryCount:7,durationMs:55000,patienceMs:4500,dailyTarget:20,coinCap:140}
  };
  const HEAD_CONFIGS={
    easy:{lanes:2,durationMs:45000,fallStartMs:2500,fallFloorMs:1400,dailyTarget:1200,coinCap:70},
    normal:{lanes:3,durationMs:60000,fallStartMs:2200,fallFloorMs:1100,dailyTarget:2000,coinCap:100},
    hard:{lanes:4,durationMs:60000,fallStartMs:1900,fallFloorMs:800,dailyTarget:2800,coinCap:140},
    unlimited:{lanes:3,durationMs:null,fallStartMs:2100,fallFloorMs:700,dailyTarget:3200,dailyStreak:20,coinCap:150}
  };
  const TILE_CONFIGS={
    easy:{size:3,shuffleMoves:80,qualifySec:90,base:20,timeBonus:20,moveBonus:20,coinCap:60},
    normal:{size:4,shuffleMoves:160,qualifySec:180,base:35,timeBonus:30,moveBonus:25,coinCap:90},
    hard:{size:5,shuffleMoves:260,qualifySec:300,base:50,timeBonus:40,moveBonus:40,coinCap:130}
  };

  let currentGame=null;
  let berryMode='easy';
  let berryRun=null;
  let berryTimer=null;
  let selectedBerry=null;
  let dragBerry=null;
  let dragGhost=null;
  let headMode='easy';
  let headRun=null;
  let headRaf=null;
  let headSpawnTimer=null;
  let tileMode='easy';
  let tileRun=null;
  let tileTimer=null;

  function clamp(n,a,b){return Math.max(a,Math.min(b,n));}
  function berryDeliveryScore(combo,remainingPatienceFraction){
    return 100+Math.min(Math.max(0,Number(combo)||0),10)*10+Math.round(50*clamp(Number(remainingPatienceFraction)||0,0,1));
  }
  function berryPayout(score,mode){
    const cfg=BERRY_CONFIGS[mode]||BERRY_CONFIGS.easy;
    return clamp(Math.round((Number(score)||0)/20),20,cfg.coinCap);
  }
  function berryReward(mode){
    return {key:'berry',amount:mode==='hard'?4:mode==='normal'?3:2};
  }
  function safeParticipants(limit){
    const p=platform();
    return p&&typeof p.caughtParticipants==='function'?p.caughtParticipants(limit,[25,133,175,183]):[25,133,175,183].slice(0,limit).map(id=>({id,name:`Pokémon ${id}`,image:`https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/${id}.png`,shiny:false}));
  }
  function el(id){return typeof document!=='undefined'?document.getElementById(id):null;}
  function setText(id,value){const node=el(id);if(node)node.textContent=String(value);}
  function berryById(id){return BERRIES.find(x=>x.id===id)||BERRIES[0];}
  function randomBerry(pool){return pool[Math.floor(Math.random()*pool.length)];}

  function clearBerryTimers(){if(berryTimer){clearInterval(berryTimer);berryTimer=null;}}
  function clearDragGhost(){if(dragGhost){dragGhost.remove();dragGhost=null;}dragBerry=null;}
  function stopBerryRun(){clearBerryTimers();clearDragGhost();if(berryRun)berryRun.running=false;}

  function newCustomerRequest(index){
    if(!berryRun)return;
    const berry=randomBerry(berryRun.pool);
    berryRun.requests[index]={berryId:berry.id,startedAt:Date.now(),expiresAt:Date.now()+berryRun.config.patienceMs};
  }
  function renderBerryCustomers(){
    const host=el('berryPickerCustomers');if(!host||!berryRun)return;
    const now=Date.now();
    host.innerHTML=berryRun.participants.map((p,i)=>{
      const req=berryRun.requests[i]||{};const b=berryById(req.berryId);
      const remain=clamp((Number(req.expiresAt||now)-now)/berryRun.config.patienceMs,0,1);
      return `<button type="button" class="amie-customer" data-berry-customer="${i}"><span class="amie-request"><img src="${b.image}" alt="${b.name} Berry"/><b>${b.name}</b></span><img class="amie-pokemon" src="${p.image}" alt="${p.name}"/><span class="amie-name">${p.name}</span><i class="amie-patience"><em style="width:${Math.round(remain*100)}%"></em></i></button>`;
    }).join('');
    host.querySelectorAll('[data-berry-customer]').forEach(btn=>btn.addEventListener('click',()=>{
      if(selectedBerry)deliverBerry(Number(btn.dataset.berryCustomer),selectedBerry);
    }));
  }
  function renderBerryTray(){
    const host=el('berryPickerTray');if(!host||!berryRun)return;
    host.innerHTML=berryRun.pool.map(b=>`<button type="button" class="amie-berry" data-berry-id="${b.id}" aria-label="${b.name} Berry"><img src="${b.image}" alt=""/><span>${b.name}</span></button>`).join('');
    host.querySelectorAll('[data-berry-id]').forEach(btn=>{
      btn.addEventListener('click',()=>selectBerry(btn.dataset.berryId));
      btn.addEventListener('pointerdown',startBerryDrag);
    });
  }
  function selectBerry(id){
    if(!berryRun?.running)return;
    selectedBerry=id;
    const host=el('berryPickerTray');if(host)host.querySelectorAll('[data-berry-id]').forEach(x=>x.classList.toggle('selected',x.dataset.berryId===id));
    setText('berryPickerMessage',`Selected ${berryById(id).name} Berry — tap a Pokémon.`);
  }
  function startBerryDrag(ev){
    if(!berryRun?.running)return;
    ev.preventDefault();
    dragBerry=ev.currentTarget.dataset.berryId;
    selectedBerry=dragBerry;
    dragGhost=ev.currentTarget.cloneNode(true);
    dragGhost.classList.add('amie-berry-ghost');
    document.body.appendChild(dragGhost);
    moveBerryGhost(ev);
    window.addEventListener('pointermove',moveBerryGhost);
    window.addEventListener('pointerup',endBerryDrag,{once:true});
  }
  function moveBerryGhost(ev){if(dragGhost){dragGhost.style.left=`${ev.clientX}px`;dragGhost.style.top=`${ev.clientY}px`;}}
  function endBerryDrag(ev){
    window.removeEventListener('pointermove',moveBerryGhost);
    const target=document.elementFromPoint(ev.clientX,ev.clientY)?.closest?.('[data-berry-customer]');
    const id=dragBerry;clearDragGhost();
    if(target&&id)deliverBerry(Number(target.dataset.berryCustomer),id);
  }
  function deliverBerry(index,berryId){
    if(!berryRun?.running)return;
    const req=berryRun.requests[index];if(!req)return;
    if(req.berryId!==berryId){berryRun.combo=0;selectedBerry=null;setText('berryPickerMessage','Wrong Berry — combo reset.');renderBerryHud();return;}
    const now=Date.now();
    const frac=clamp((req.expiresAt-now)/berryRun.config.patienceMs,0,1);
    const gained=berryDeliveryScore(berryRun.combo,frac);
    berryRun.combo++;berryRun.correct++;berryRun.score+=gained;selectedBerry=null;
    if(typeof root.vibrate==='function')root.vibrate(18);
    setText('berryPickerMessage',`Perfect delivery! +${gained}`);
    newCustomerRequest(index);renderBerryHud();renderBerryCustomers();
  }
  function renderBerryHud(){
    if(!berryRun)return;
    setText('berryPickerScore',berryRun.score);
    setText('berryPickerCombo',berryRun.combo);
    setText('berryPickerCorrect',berryRun.correct);
  }
  function berryTick(){
    if(!berryRun?.running)return;
    const now=Date.now();
    const left=Math.max(0,berryRun.endsAt-now);
    setText('berryPickerTimer',Math.ceil(left/1000));
    berryRun.requests.forEach((req,i)=>{if(req&&now>=req.expiresAt){berryRun.combo=0;newCustomerRequest(i);}});
    renderBerryHud();renderBerryCustomers();
    if(left<=0)finishBerryPicker();
  }
  function startBerryPicker(){
    stopBerryRun();
    const config=BERRY_CONFIGS[berryMode]||BERRY_CONFIGS.easy;
    const participants=safeParticipants(config.customers);
    berryRun={running:true,config,participants,pool:BERRIES.slice(0,config.berryCount),requests:[],score:0,combo:0,correct:0,endsAt:Date.now()+config.durationMs};
    participants.forEach((_,i)=>newCustomerRequest(i));
    const start=el('berryPickerStartBtn');if(start)start.hidden=true;
    const restart=el('berryPickerRestartBtn');if(restart)restart.hidden=false;
    setText('berryPickerMessage','Serve the Berry each Pokémon is asking for!');
    renderBerryTray();renderBerryHud();renderBerryCustomers();berryTick();
    berryTimer=setInterval(berryTick,120);
  }
  function finishBerryPicker(){
    if(!berryRun?.running)return;
    berryRun.running=false;clearBerryTimers();
    const run=berryRun;const mode=berryMode;
    const coins=berryPayout(run.score,mode);
    const s=root.state||globalThis.state;
    if(s?.arcade?.bestBerryPicker)s.arcade.bestBerryPicker[mode]=Math.max(Number(s.arcade.bestBerryPicker[mode]||0),run.score);
    const p=platform();
    const result=p?.awardRun?.({gameId:'berryPicker',label:'Berry Picker',score:run.score,coins,dailyEligible:run.correct>=run.config.dailyTarget,dailyReward:berryReward(mode)})||{coinsAwarded:coins,itemAwarded:null};
    if(typeof root.save==='function')root.save();
    const bonus=result.itemAwarded?` · Daily +${result.itemAwarded.amount} Berry`:'';
    setText('berryPickerMessage',`Time! ${run.correct} served · ${result.coinsAwarded} coins${bonus}`);
    const start=el('berryPickerStartBtn');if(start){start.hidden=false;start.textContent='PLAY AGAIN';}
  }
  function setBerryMode(mode){
    if(!BERRY_CONFIGS[mode]||berryRun?.running)return;
    berryMode=mode;
    const host=el('berryPickerModes');if(host)host.querySelectorAll('[data-berry-mode]').forEach(x=>x.classList.toggle('active',x.dataset.berryMode===mode));
    const cfg=BERRY_CONFIGS[mode];setText('berryPickerTimer',Math.round(cfg.durationMs/1000));setText('berryPickerMessage',`${mode.toUpperCase()} · Serve ${cfg.dailyTarget} for today's Berry bonus.`);
  }

  function headTimingGrade(deltaMs){
    const d=Math.abs(Number(deltaMs)||0);return d<=90?'perfect':d<=220?'good':'miss';
  }
  function headScore(grade,combo,bonus=false){
    if(grade!=='perfect'&&grade!=='good')return 0;
    const base=bonus?300:(grade==='perfect'?100:60);
    return base+Math.min(Math.max(0,Number(combo)||0)*5,100);
  }
  function headUnlimitedEnded(misses){return Number(misses)>=3;}
  function headFallDuration(mode,hits){
    const cfg=HEAD_CONFIGS[mode]||HEAD_CONFIGS.easy;
    return Math.max(cfg.fallFloorMs,cfg.fallStartMs-Math.max(0,Number(hits)||0)*35);
  }
  function headReward(mode,score,streak){
    if(mode==='hard'&&Number(score)>=4200)return {key:'greatball',amount:1};
    if(mode==='unlimited'&&Number(streak)>=30)return {key:'greatball',amount:1};
    return {key:'potion',amount:1};
  }
  function headPayout(score,mode){const cfg=HEAD_CONFIGS[mode]||HEAD_CONFIGS.easy;return clamp(Math.round((Number(score)||0)/25),20,cfg.coinCap);}
  function clearHeadTimers(){
    if(headRaf){cancelAnimationFrame(headRaf);headRaf=null;}
    if(headSpawnTimer){clearTimeout(headSpawnTimer);headSpawnTimer=null;}
  }
  function stopHeadRun(){clearHeadTimers();if(headRun)headRun.running=false;const ball=el('headItBall');if(ball)ball.remove();}
  function setHeadMode(mode){
    if(!HEAD_CONFIGS[mode]||headRun?.running)return;
    headMode=mode;
    const host=el('headItModes');if(host)host.querySelectorAll('[data-head-mode]').forEach(x=>x.classList.toggle('active',x.dataset.headMode===mode));
    const cfg=HEAD_CONFIGS[mode];setText('headItTimer',cfg.durationMs===null?'∞':Math.round(cfg.durationMs/1000));
    setText('headItMessage',mode==='unlimited'?'Three misses ends the run.':'Time your tap as the yarn reaches your Pokémon.');
  }
  function renderHeadLanes(){
    const host=el('headItLanes');if(!host||!headRun)return;
    host.innerHTML=headRun.participants.map((p,i)=>`<button type="button" class="head-lane" data-head-lane="${i}"><span class="head-impact"></span><img src="${p.image}" alt="${p.name}"/><b>${p.name}</b></button>`).join('');
    host.querySelectorAll('[data-head-lane]').forEach(btn=>btn.addEventListener('click',()=>tapHeadLane(Number(btn.dataset.headLane))));
  }
  function renderHeadHud(){
    if(!headRun)return;
    setText('headItScore',headRun.score);setText('headItCombo',headRun.combo);setText('headItMisses',headRun.misses);
    if(headRun.config.durationMs!==null)setText('headItTimer',Math.max(0,Math.ceil((headRun.endsAt-Date.now())/1000)));
  }
  function scheduleHeadBall(delay=180){
    if(!headRun?.running)return;
    if(headSpawnTimer)clearTimeout(headSpawnTimer);
    headSpawnTimer=setTimeout(spawnHeadBall,delay);
  }
  function spawnHeadBall(){
    if(!headRun?.running||headRun.ball)return;
    const duration=headFallDuration(headMode,headRun.hits);
    const lane=Math.floor(Math.random()*headRun.config.lanes);
    const bonus=headRun.hits>0&&headRun.hits%10===0;
    const now=performance.now();
    headRun.ball={lane,spawnAt:now,impactAt:now+duration,duration,bonus};
    const play=el('headItPlayfield');if(play){const old=el('headItBall');old?.remove();const ball=document.createElement('div');ball.id='headItBall';ball.className=`head-yarn${bonus?' bonus':''}`;ball.textContent=bonus?'✦':'●';play.appendChild(ball);}
    headRaf=requestAnimationFrame(headLoop);
  }
  function headLoop(now){
    if(!headRun?.running)return;
    if(headRun.config.durationMs!==null&&Date.now()>=headRun.endsAt){finishHeadIt();return;}
    const ball=headRun.ball;
    if(ball){
      const node=el('headItBall');if(node){const frac=clamp((now-ball.spawnAt)/ball.duration,0,1.15);node.style.left=`${((ball.lane+.5)/headRun.config.lanes)*100}%`;node.style.top=`${-4+frac*82}%`;}
      if(now>ball.impactAt+220){resolveHeadBall('miss');return;}
    }
    renderHeadHud();headRaf=requestAnimationFrame(headLoop);
  }
  function tapHeadLane(lane){
    if(!headRun?.running||!headRun.ball)return;
    const ball=headRun.ball;
    if(Number(lane)!==ball.lane){resolveHeadBall('miss');return;}
    resolveHeadBall(headTimingGrade(performance.now()-ball.impactAt));
  }
  function resolveHeadBall(grade){
    if(!headRun?.ball)return;
    const ball=headRun.ball;headRun.ball=null;el('headItBall')?.remove();
    if(grade==='miss'){
      headRun.combo=0;headRun.misses++;setText('headItMessage','MISS!');
      if(headMode==='unlimited'&&headUnlimitedEnded(headRun.misses)){finishHeadIt();return;}
    }else{
      const gained=headScore(grade,headRun.combo,ball.bonus);headRun.score+=gained;headRun.combo++;headRun.hits++;headRun.bestStreak=Math.max(headRun.bestStreak,headRun.combo);
      if(typeof root.vibrate==='function')root.vibrate(grade==='perfect'?[12,18,20]:12);
      setText('headItMessage',`${grade==='perfect'?'PERFECT':'GOOD'}${ball.bonus?' · BONUS YARN':''} +${gained}`);
    }
    renderHeadHud();scheduleHeadBall(150);
  }
  function startHeadIt(){
    stopHeadRun();
    const config=HEAD_CONFIGS[headMode]||HEAD_CONFIGS.easy;
    headRun={running:true,config,participants:safeParticipants(config.lanes),score:0,combo:0,bestStreak:0,misses:0,hits:0,ball:null,endsAt:config.durationMs===null?null:Date.now()+config.durationMs};
    renderHeadLanes();renderHeadHud();setText('headItMessage','Get ready…');
    const start=el('headItStartBtn');if(start){start.textContent='RESTART';}
    scheduleHeadBall(450);
  }
  function finishHeadIt(){
    if(!headRun?.running)return;
    headRun.running=false;clearHeadTimers();el('headItBall')?.remove();
    const run=headRun;const mode=headMode;const s=root.state||globalThis.state;
    if(s?.arcade?.bestHeadIt){s.arcade.bestHeadIt[mode]=Math.max(Number(s.arcade.bestHeadIt[mode]||0),run.score);if(mode==='unlimited')s.arcade.bestHeadIt.unlimitedStreak=Math.max(Number(s.arcade.bestHeadIt.unlimitedStreak||0),run.bestStreak);}
    const eligible=mode==='unlimited'?(run.score>=run.config.dailyTarget||run.bestStreak>=run.config.dailyStreak):run.score>=run.config.dailyTarget;
    const coins=headPayout(run.score,mode);const p=platform();
    const result=p?.awardRun?.({gameId:'headIt',label:'Head It',score:run.score,coins,dailyEligible:eligible,dailyReward:headReward(mode,run.score,run.bestStreak)})||{coinsAwarded:coins,itemAwarded:null};
    if(typeof root.save==='function')root.save();
    const bonus=result.itemAwarded?` · Daily item +${result.itemAwarded.amount}`:'';
    setText('headItMessage',`Run complete · ${run.score} points · ${result.coinsAwarded} coins${bonus}`);
    const start=el('headItStartBtn');if(start)start.textContent='PLAY AGAIN';
  }

  function isSolvedPuzzle(tiles){return Array.isArray(tiles)&&tiles.every((v,i)=>Number(v)===i);}
  function puzzleNeighbors(empty,size){
    const r=Math.floor(empty/size),c=empty%size,out=[];
    if(r>0)out.push(empty-size);if(r<size-1)out.push(empty+size);if(c>0)out.push(empty-1);if(c<size-1)out.push(empty+1);return out;
  }
  function makeSolvablePuzzle(size,randomFn=Math.random,trace=null){
    const n=size*size,emptyValue=n-1,tiles=Array.from({length:n},(_,i)=>i);
    const moves=size===3?80:size===4?160:260;
    let empty=n-1,previousEmpty=-1;
    for(let i=0;i<moves;i++){
      let options=puzzleNeighbors(empty,size);
      if(options.length>1&&previousEmpty>=0)options=options.filter(x=>x!==previousEmpty);
      const chosen=options[Math.min(options.length-1,Math.floor(clamp(Number(randomFn())||0,0,.999999)*options.length))];
      if(trace)trace.push({emptyBefore:empty,tileIndex:chosen});
      previousEmpty=empty;[tiles[empty],tiles[chosen]]=[tiles[chosen],tiles[empty]];empty=chosen;
    }
    if(isSolvedPuzzle(tiles)){
      const chosen=puzzleNeighbors(empty,size)[0];if(trace)trace.push({emptyBefore:empty,tileIndex:chosen});[tiles[empty],tiles[chosen]]=[tiles[chosen],tiles[empty]];
    }
    return tiles;
  }
  function tilePayout(mode,elapsedSec,moves){
    const cfg=TILE_CONFIGS[mode]||TILE_CONFIGS.easy;
    const timeFrac=clamp(1-(Math.max(0,Number(elapsedSec)||0)/cfg.qualifySec),0,1);
    const moveFrac=clamp(1-(Math.max(0,Number(moves)||0)/(4*cfg.shuffleMoves)),0,1);
    return Math.min(cfg.coinCap,Math.round(cfg.base+cfg.timeBonus*timeFrac+cfg.moveBonus*moveFrac));
  }
  function tileReward(mode){return mode==='hard'?{key:'greatball',amount:1}:{key:'pokeball',amount:mode==='normal'?3:2};}
  function clearTileTimer(){if(tileTimer){clearInterval(tileTimer);tileTimer=null;}}
  function stopTileRun(){clearTileTimer();if(tileRun)tileRun.running=false;}
  function setTileMode(mode){
    if(!TILE_CONFIGS[mode]||tileRun?.running)return;tileMode=mode;
    const host=el('tilePuzzleModes');if(host)host.querySelectorAll('[data-tile-mode]').forEach(x=>x.classList.toggle('active',x.dataset.tileMode===mode));
    const cfg=TILE_CONFIGS[mode];setText('tilePuzzleTimer','0.0');setText('tilePuzzleMoves','0');setText('tilePuzzleMessage',`${cfg.size}×${cfg.size} · Daily item target ${cfg.qualifySec}s.`);
  }
  function renderTileTarget(){
    if(!tileRun)return;const img=el('tilePuzzleTarget');if(img)img.src=tileRun.participant.image;setText('tilePuzzleTargetName',tileRun.participant.name);
  }
  function renderTileGrid(){
    const host=el('tilePuzzleGrid');if(!host||!tileRun)return;
    const size=tileRun.config.size,empty=size*size-1;
    host.style.setProperty('--tile-size',size);
    host.innerHTML=tileRun.tiles.map((value,index)=>{
      if(value===empty)return `<button type="button" class="tile-piece empty" data-tile-index="${index}" aria-label="Empty tile"></button>`;
      const row=Math.floor(value/size),col=value%size;
      const bx=size===1?0:(col/(size-1))*100,by=size===1?0:(row/(size-1))*100;
      return `<button type="button" class="tile-piece" data-tile-index="${index}" aria-label="Puzzle tile ${value+1}" style="background-image:url('${tileRun.participant.image}');background-size:${size*100}% ${size*100}%;background-position:${bx}% ${by}%"></button>`;
    }).join('');
    host.querySelectorAll('[data-tile-index]').forEach(btn=>btn.addEventListener('click',()=>moveTile(Number(btn.dataset.tileIndex))));
  }
  function tileElapsed(){return tileRun?Math.max(0,(performance.now()-tileRun.startedAt)/1000):0;}
  function moveTile(index){
    if(!tileRun?.running)return;
    const emptyValue=tileRun.config.size*tileRun.config.size-1,empty=tileRun.tiles.indexOf(emptyValue);
    if(!puzzleNeighbors(empty,tileRun.config.size).includes(index))return;
    [tileRun.tiles[empty],tileRun.tiles[index]]=[tileRun.tiles[index],tileRun.tiles[empty]];tileRun.moves++;setText('tilePuzzleMoves',tileRun.moves);renderTileGrid();
    if(isSolvedPuzzle(tileRun.tiles))finishTilePuzzle();
  }
  function startTilePuzzle(){
    stopTileRun();const config=TILE_CONFIGS[tileMode]||TILE_CONFIGS.easy;const participant=safeParticipants(1)[0]||{id:25,name:'Pikachu',image:'https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/25.png'};
    tileRun={running:true,config,participant,tiles:makeSolvablePuzzle(config.size),moves:0,startedAt:performance.now()};
    renderTileTarget();renderTileGrid();setText('tilePuzzleMoves','0');setText('tilePuzzleTimer','0.0');setText('tilePuzzleMessage','Slide adjacent pieces until the Pokémon picture is complete.');
    const start=el('tilePuzzleStartBtn');if(start)start.hidden=true;const restart=el('tilePuzzleRestartBtn');if(restart)restart.hidden=false;
    tileTimer=setInterval(()=>{if(tileRun?.running)setText('tilePuzzleTimer',tileElapsed().toFixed(1));},100);
  }
  function finishTilePuzzle(){
    if(!tileRun?.running)return;tileRun.running=false;clearTileTimer();
    const run=tileRun,elapsed=tileElapsed(),mode=tileMode,coins=tilePayout(mode,elapsed,run.moves);const s=root.state||globalThis.state;
    if(s?.arcade?.bestTilePuzzle){const old=s.arcade.bestTilePuzzle[mode];if(old===null||old===undefined||elapsed<Number(old))s.arcade.bestTilePuzzle[mode]=Number(elapsed.toFixed(2));}
    const p=platform();const result=p?.awardRun?.({gameId:'tilePuzzle',label:'Tile Puzzle',score:Math.max(0,Math.round(10000-elapsed*10-run.moves)),coins,dailyEligible:elapsed<=run.config.qualifySec,dailyReward:tileReward(mode)})||{coinsAwarded:coins,itemAwarded:null};
    if(typeof root.save==='function')root.save();
    const bonus=result.itemAwarded?` · Daily item +${result.itemAwarded.amount}`:'';setText('tilePuzzleTimer',elapsed.toFixed(1));setText('tilePuzzleMessage',`Solved in ${elapsed.toFixed(1)}s · ${run.moves} moves · ${result.coinsAwarded} coins${bonus}`);
    const start=el('tilePuzzleStartBtn');if(start){start.hidden=false;start.textContent='NEW PUZZLE';}
  }

  function hideAllAmie(){['berryPickerGame','headItGame','tilePuzzleGame'].forEach(id=>{const n=el(id);if(n)n.hidden=true;});}
  function open(gameId){
    hideAllAmie();currentGame=gameId;
    const node=el(`${gameId}Game`);if(node)node.hidden=false;
    if(typeof document!=='undefined')document.body.classList.add('arcade-open');
    root.Android?.setImmersive?.(true);
    if(gameId==='berryPicker'){setBerryMode(berryMode);const start=el('berryPickerStartBtn');if(start)start.hidden=false;}
    if(gameId==='headIt')setHeadMode(headMode);
    if(gameId==='tilePuzzle')setTileMode(tileMode);
  }
  function close(force=false){
    stopBerryRun();stopHeadRun();stopTileRun();hideAllAmie();currentGame=null;
    if(typeof document!=='undefined')document.body.classList.remove('arcade-open');
    root.Android?.setImmersive?.(false);
    return true;
  }
  function activeGame(){return currentGame;}

  function wire(){
    const modes=el('berryPickerModes');if(modes)modes.querySelectorAll('[data-berry-mode]').forEach(btn=>btn.addEventListener('click',()=>setBerryMode(btn.dataset.berryMode)));
    el('berryPickerStartBtn')?.addEventListener('click',startBerryPicker);
    el('berryPickerRestartBtn')?.addEventListener('click',startBerryPicker);
    const headModes=el('headItModes');if(headModes)headModes.querySelectorAll('[data-head-mode]').forEach(btn=>btn.addEventListener('click',()=>setHeadMode(btn.dataset.headMode)));
    el('headItStartBtn')?.addEventListener('click',startHeadIt);
    const tileModes=el('tilePuzzleModes');if(tileModes)tileModes.querySelectorAll('[data-tile-mode]').forEach(btn=>btn.addEventListener('click',()=>setTileMode(btn.dataset.tileMode)));
    el('tilePuzzleStartBtn')?.addEventListener('click',startTilePuzzle);
    el('tilePuzzleRestartBtn')?.addEventListener('click',startTilePuzzle);
  }

  const api={BERRY_CONFIGS,BERRIES,HEAD_CONFIGS,TILE_CONFIGS,berryDeliveryScore,berryPayout,berryReward,safeParticipants,headTimingGrade,headScore,headUnlimitedEnded,headFallDuration,headReward,headPayout,makeSolvablePuzzle,isSolvedPuzzle,tilePayout,tileReward,open,close,activeGame,startBerryPicker,setBerryMode,startHeadIt,setHeadMode,startTilePuzzle,setTileMode};
  root.LuckyDexAmie=api;
  if(typeof module!=='undefined'&&module.exports)module.exports=api;
  if(typeof document!=='undefined')wire();
})(typeof window!=='undefined'?window:globalThis);
