(function(root,factory){
  const api=factory();
  if(typeof module!=='undefined'&&module.exports)module.exports=api;
  root.LuckyDexSushiGoRoundCore=api;
})(typeof window!=='undefined'?window:globalThis,function(){
  'use strict';

  const CONFIG=Object.freeze({
    durationMs:60000,
    plateCount:12,
    stepMs:520,
    comboCap:5,
    hotStunMs:1800,
    eatCooldownMs:220,
    respawnDelaySteps:2,
    stations:Object.freeze({player:0,cpu1:3,cpu2:6,cpu3:9}),
    bigBill:15000
  });
  const SUSHI=Object.freeze([
    Object.freeze({id:'uni',name:'Uni',value:1000,tier:'orange',hot:false,mark:'UNI'}),
    Object.freeze({id:'toro',name:'Toro',value:600,tier:'red',hot:false,mark:'TORO'}),
    Object.freeze({id:'ebi',name:'Ebi',value:350,tier:'yellow',hot:false,mark:'EBI'}),
    Object.freeze({id:'ikura',name:'Ikura',value:250,tier:'orange',hot:false,mark:'IKURA'}),
    Object.freeze({id:'tekka',name:'Tekka',value:200,tier:'red',hot:false,mark:'TEKKA'}),
    Object.freeze({id:'tamago',name:'Tamago',value:150,tier:'yellow',hot:false,mark:'EGG'}),
    Object.freeze({id:'kappa',name:'Kappa Maki',value:50,tier:'green',hot:false,mark:'KAPPA'}),
    Object.freeze({id:'agari',name:'Hot Tea',value:20,tier:'tea',hot:true,mark:'HOT'})
  ]);
  const SUSHI_BY_ID=Object.freeze(Object.fromEntries(SUSHI.map(x=>[x.id,x])));
  const DIFFICULTIES=Object.freeze({
    easy:Object.freeze({key:'easy',label:'Easy',takeChance:.44,valueWeight:.18,comboWeight:.12,hotAversion:.24}),
    normal:Object.freeze({key:'normal',label:'Normal',takeChance:.64,valueWeight:.34,comboWeight:.24,hotAversion:.52}),
    hard:Object.freeze({key:'hard',label:'Hard',takeChance:.82,valueWeight:.52,comboWeight:.38,hotAversion:.82})
  });
  const REWARDS=Object.freeze({easy:Object.freeze([100,65,40,25]),normal:Object.freeze([130,85,55,30]),hard:Object.freeze([160,105,70,40])});
  const LICKITUNG=Object.freeze({dex:108,name:'Lickitung'});
  const clamp=(n,a,b)=>Math.max(a,Math.min(b,n));
  const rand=rng=>clamp(Number((rng||Math.random)())||0,0,.999999);
  function difficultyProfile(key){return DIFFICULTIES[key]||DIFFICULTIES.normal;}
  function createRacer(id,index,kind){return {id,index,kind,label:id==='player'?'YOU':`COM ${index}`,species:{...LICKITUNG},bill:0,eaten:0,combo:0,bestCombo:0,lastType:null,lastEatAt:null,stunnedUntil:0,hotPenalties:0,lastGain:0};}
  function sushiFromRoll(rng){
    const x=rand(rng);
    // Weight cheaper pieces more heavily so premium sushi stays exciting.
    const thresholds=[.035,.10,.22,.36,.52,.69,.86,1];
    return SUSHI[thresholds.findIndex(t=>x<t)];
  }
  function makePlate(round,rng){
    const s=sushiFromRoll(rng),id=`plate-${++round.nextPlateId}`;
    return {id,type:s.id,name:s.name,value:s.value,hot:!!s.hot,tier:s.tier,mark:s.mark};
  }
  function createRound({difficulty='normal',rng=Math.random,nowMs=0}={}){
    const start=Number(nowMs)||0,profile=difficultyProfile(difficulty);
    const racers=[createRacer('player',0,'player'),createRacer('cpu1',1,'cpu'),createRacer('cpu2',2,'cpu'),createRacer('cpu3',3,'cpu')];
    const round={difficulty:profile.key,startedAt:start,endsAt:start+CONFIG.durationMs,nextStepAt:start+CONFIG.stepMs,stepIndex:0,racers,player:racers[0],plates:new Array(CONFIG.plateCount).fill(null),pendingRespawns:[],nextPlateId:0,finalized:false,finalizedAt:null,ranking:null};
    for(let i=0;i<CONFIG.plateCount;i++)round.plates[i]=makePlate(round,rng);
    return round;
  }
  function stationFor(id){return CONFIG.stations[id];}
  function plateAt(round,id='player'){const slot=stationFor(id);return slot==null?null:round?.plates?.[slot]||null;}
  function isStunned(racer,nowMs){return Number(racer?.stunnedUntil||0)>Number(nowMs||0);}
  function consumePlate(round,racer,slot,nowMs){
    const plate=round.plates[slot];if(!plate)return {accepted:false,reason:'empty'};
    const same=racer.lastType===plate.type;racer.combo=same?Math.min(CONFIG.comboCap,Number(racer.combo||0)+1):1;racer.bestCombo=Math.max(Number(racer.bestCombo||0),racer.combo);racer.lastType=plate.type;
    const gain=Number(plate.value||0)*racer.combo;racer.bill+=gain;racer.eaten++;racer.lastGain=gain;racer.lastEatAt=Number(nowMs)||0;
    if(plate.hot){racer.stunnedUntil=(Number(nowMs)||0)+CONFIG.hotStunMs;racer.hotPenalties++;}
    round.plates[slot]=null;round.pendingRespawns.push(round.stepIndex+CONFIG.respawnDelaySteps);
    return {accepted:true,plate,gain,multiplier:racer.combo,hot:!!plate.hot,bill:racer.bill};
  }
  function eatAtStation(round,id='player',nowMs=0){
    if(!round||round.finalized)return {accepted:false,reason:'finished'};
    const racer=round.racers.find(r=>r.id===id);if(!racer)return {accepted:false,reason:'racer'};
    const now=Number(nowMs)||0;if(now>=round.endsAt){finalizeRound(round,now);return {accepted:false,reason:'finished'};}
    if(isStunned(racer,now))return {accepted:false,reason:'stunned'};
    if(racer.lastEatAt!=null&&now-Number(racer.lastEatAt)<CONFIG.eatCooldownMs)return {accepted:false,reason:'cooldown'};
    const slot=stationFor(id);if(slot==null)return {accepted:false,reason:'station'};
    return consumePlate(round,racer,slot,now);
  }
  function cpuWantsPlate(racer,plate,profile,rng){
    if(!plate)return false;
    const valueScore=clamp(Number(plate.value||0)/1000,0,1)*profile.valueWeight;
    const comboScore=racer.lastType===plate.type?profile.comboWeight:0;
    const hotPenalty=plate.hot?profile.hotAversion:.0;
    const chance=clamp(profile.takeChance+valueScore+comboScore-hotPenalty,0.03,.985);
    return rand(rng)<chance;
  }
  function processCpuStations(round,at,rng){
    const profile=difficultyProfile(round.difficulty);
    for(let i=1;i<round.racers.length;i++){
      const racer=round.racers[i];if(isStunned(racer,at))continue;
      const slot=stationFor(racer.id),plate=round.plates[slot];
      if(plate&&cpuWantsPlate(racer,plate,profile,rng))consumePlate(round,racer,slot,at);
    }
  }
  function rotatePlates(round){
    const next=new Array(CONFIG.plateCount).fill(null);
    for(let i=0;i<CONFIG.plateCount;i++)next[(i+1)%CONFIG.plateCount]=round.plates[i];
    round.plates=next;
  }
  function respawnDue(round,rng){
    const due=round.pendingRespawns.filter(x=>x<=round.stepIndex).length;
    round.pendingRespawns=round.pendingRespawns.filter(x=>x>round.stepIndex);
    for(let n=0;n<due;n++){
      const empty=[];for(let i=0;i<round.plates.length;i++)if(!round.plates[i])empty.push(i);
      if(!empty.length)break;
      const slot=empty[Math.floor(rand(rng)*empty.length)]||empty[0];round.plates[slot]=makePlate(round,rng);
    }
  }
  function advanceStep(round,at,rng){round.stepIndex++;rotatePlates(round);respawnDue(round,rng);processCpuStations(round,at,rng);}
  function rankRound(round){return (round?.racers||[]).slice().sort((a,b)=>Number(b.bill||0)-Number(a.bill||0)||Number(b.eaten||0)-Number(a.eaten||0)||Number(b.bestCombo||0)-Number(a.bestCombo||0)||a.index-b.index);}
  function finalizeRound(round,nowMs){if(!round)return[];if(!round.finalized){round.finalized=true;round.finalizedAt=Math.max(round.endsAt,Number(nowMs)||round.endsAt);round.ranking=rankRound(round);}return round.ranking.slice();}
  function advanceRound(round,nowMs,rng=Math.random){
    if(!round||round.finalized)return round;const now=Number(nowMs)||0;
    let guard=0;while(round.nextStepAt<=Math.min(now,round.endsAt)&&guard++<512){advanceStep(round,round.nextStepAt,rng);round.nextStepAt+=CONFIG.stepMs;}
    if(now>=round.endsAt)finalizeRound(round,now);return round;
  }
  function placeFor(round,id='player'){const i=rankRound(round).findIndex(r=>r.id===id);return i<0?4:i+1;}
  function rewardFor(place,difficulty='normal'){const row=REWARDS[difficulty]||REWARDS.normal,idx=clamp(Math.trunc(Number(place)||1)-1,0,3);return row[idx];}
  function remainingMs(round,nowMs){return Math.max(0,Number(round?.endsAt||0)-Number(nowMs||0));}

  return {CONFIG,SUSHI,SUSHI_BY_ID,DIFFICULTIES,REWARDS,LICKITUNG,difficultyProfile,createRound,eatAtStation,advanceRound,rankRound,finalizeRound,placeFor,rewardFor,plateAt,isStunned,cpuWantsPlate,remainingMs};
});
