(function(root,factory){
  const api=factory();
  if(typeof module!=='undefined'&&module.exports)module.exports=api;
  root.LuckyDexSnoreWarCore=api;
})(typeof window!=='undefined'?window:globalThis,function(){
  'use strict';
  const TAU=Math.PI*2;
  const CONFIG={
    timingWindowMs:120,
    sleepCrossings:2,
    initialFullPeriodMs:2400,
    maxFullPeriodMs:720,
    rampToMaxMs:34000,
    maxCrossings:96
  };
  const DIFFICULTIES={
    easy:{label:'EASY',timingSpreadMs:165,errorChance:.24},
    normal:{label:'NORMAL',timingSpreadMs:110,errorChance:.13},
    hard:{label:'HARD',timingSpreadMs:68,errorChance:.065}
  };
  const REWARDS={easy:[85,58,36,20],normal:[110,75,48,26],hard:[140,95,62,35]};
  const OMEGA0=TAU/CONFIG.initialFullPeriodMs;
  const OMEGA_MAX=TAU/CONFIG.maxFullPeriodMs;
  const ACCEL=(OMEGA_MAX-OMEGA0)/CONFIG.rampToMaxMs;
  const CAP_PHASE=OMEGA0*CONFIG.rampToMaxMs+.5*ACCEL*CONFIG.rampToMaxMs*CONFIG.rampToMaxMs;
  const DROWZEE={dex:96,name:'Drowzee'};

  function clamp(n,a,b){return Math.max(a,Math.min(b,n));}
  function difficultyProfile(key){return DIFFICULTIES[key]||DIFFICULTIES.normal;}
  function phaseDeltaAtElapsed(ms){
    const t=Math.max(0,Number(ms)||0);
    if(t<=CONFIG.rampToMaxMs)return OMEGA0*t+.5*ACCEL*t*t;
    return CAP_PHASE+OMEGA_MAX*(t-CONFIG.rampToMaxMs);
  }
  function elapsedForPhaseDelta(delta){
    const d=Math.max(0,Number(delta)||0);
    if(d<=CAP_PHASE)return (-OMEGA0+Math.sqrt(OMEGA0*OMEGA0+2*ACCEL*d))/ACCEL;
    return CONFIG.rampToMaxMs+(d-CAP_PHASE)/OMEGA_MAX;
  }
  function centerTimeForIndex(race,index){
    const i=Math.max(0,Math.floor(Number(index)||0));
    return Number(race?.startedAt||0)+elapsedForPhaseDelta(Math.PI/2+i*Math.PI);
  }
  function pendulumPosition(race,nowMs){
    if(!race)return -1;
    const elapsed=Math.max(0,Number(nowMs)-Number(race.startedAt||0));
    return clamp(Math.sin(-Math.PI/2+phaseDeltaAtElapsed(elapsed)),-1,1);
  }
  function createRacer(id,label){return {id,label,species:{...DROWZEE},hits:0,misses:0,streak:0,bestStreak:0,attemptedCrossing:-1,sleepThroughCrossing:-1,lastSleepAt:null,lastHitAt:null,plannedCrossing:-1,plannedAt:null};}
  function isSleeping(racer,crossingIndex){return Number(racer?.sleepThroughCrossing??-1)>=Number(crossingIndex??0);}
  function planCpuAttempt(race,racer,index,rng){
    if(!racer||racer.id==='player'||isSleeping(racer,index)){racer.plannedCrossing=index;racer.plannedAt=null;return null;}
    const random=typeof rng==='function'?rng:Math.random,profile=difficultyProfile(race.difficulty),target=centerTimeForIndex(race,index);
    let offset;
    if(random()<profile.errorChance){const sign=random()<.5?-1:1;offset=sign*(CONFIG.timingWindowMs+45+random()*165);}
    else offset=(random()+random()-1)*profile.timingSpreadMs;
    racer.plannedCrossing=index;racer.plannedAt=target+offset;return racer.plannedAt;
  }
  function prepareCrossing(race,rng){
    race.targetAt=centerTimeForIndex(race,race.currentCrossing);
    for(const racer of race.racers.slice(1))planCpuAttempt(race,racer,race.currentCrossing,rng);
  }
  function createRace({difficulty='normal',rng=Math.random,nowMs=0}={}){
    const key=DIFFICULTIES[difficulty]?difficulty:'normal';
    const racers=[createRacer('player','YOU'),createRacer('cpu1','COM 1'),createRacer('cpu2','COM 2'),createRacer('cpu3','COM 3')];
    const race={difficulty:key,startedAt:Number(nowMs)||0,currentCrossing:0,targetAt:null,racers,player:racers[0],finalized:false,finalizedAt:null,winnerId:null};
    prepareCrossing(race,rng);return race;
  }
  function applyOutcome(race,racer,hit,nowMs,index=race.currentCrossing){
    if(!racer||race.finalized||racer.attemptedCrossing===index||isSleeping(racer,index))return false;
    racer.attemptedCrossing=index;
    if(hit){racer.hits++;racer.streak++;racer.bestStreak=Math.max(racer.bestStreak,racer.streak);racer.lastHitAt=Number(nowMs)||0;}
    else {racer.misses++;racer.streak=0;racer.sleepThroughCrossing=index+CONFIG.sleepCrossings-1;racer.lastSleepAt=Number(nowMs)||0;}
    return true;
  }
  function pressPlayer(race,nowMs){
    if(!race||race.finalized)return {accepted:false,hit:false,sleeping:false};
    const index=race.currentCrossing,player=race.player;
    if(isSleeping(player,index)||player.attemptedCrossing===index)return {accepted:false,hit:false,sleeping:isSleeping(player,index)};
    const hit=Math.abs((Number(nowMs)||0)-race.targetAt)<=CONFIG.timingWindowMs;
    applyOutcome(race,player,hit,nowMs,index);
    return {accepted:true,hit,sleeping:isSleeping(player,index),crossing:index};
  }
  function awakeRacers(race,index=race.currentCrossing){return (race?.racers||[]).filter(r=>!isSleeping(r,index));}
  function finalizeIfNeeded(race,nowMs){
    if(!race||race.finalized)return !!race?.finalized;
    const awake=awakeRacers(race,race.currentCrossing);
    if(awake.length>1)return false;
    race.finalized=true;race.finalizedAt=Number(nowMs)||0;
    if(awake.length===1)race.winnerId=awake[0].id;
    else race.winnerId=rankRace(race)[0]?.id||'player';
    return true;
  }
  function resolveExpiredCrossing(race,deadline,rng){
    const index=race.currentCrossing,target=race.targetAt;
    for(const racer of race.racers.slice(1)){
      if(racer.attemptedCrossing===index||isSleeping(racer,index))continue;
      if(racer.plannedCrossing!==index)planCpuAttempt(race,racer,index,rng);
      if(racer.plannedAt!=null&&racer.plannedAt<=deadline){applyOutcome(race,racer,Math.abs(racer.plannedAt-target)<=CONFIG.timingWindowMs,racer.plannedAt,index);}
    }
    for(const racer of race.racers){if(racer.attemptedCrossing!==index&&!isSleeping(racer,index))applyOutcome(race,racer,false,deadline,index);}
    if(finalizeIfNeeded(race,deadline))return;
    race.currentCrossing++;
    if(race.currentCrossing>=CONFIG.maxCrossings){race.finalized=true;race.finalizedAt=deadline;race.winnerId=rankRace(race)[0]?.id||'player';return;}
    prepareCrossing(race,rng);
  }
  function advanceRace(race,nowMs,rng=Math.random){
    if(!race||race.finalized)return race;
    const now=Number(nowMs)||0;
    let safety=0;
    while(!race.finalized&&safety++<CONFIG.maxCrossings){
      const index=race.currentCrossing,target=race.targetAt,deadline=target+CONFIG.timingWindowMs;
      for(const racer of race.racers.slice(1)){
        if(racer.attemptedCrossing===index||isSleeping(racer,index))continue;
        if(racer.plannedCrossing!==index)planCpuAttempt(race,racer,index,rng);
        if(racer.plannedAt!=null&&racer.plannedAt<=now&&racer.plannedAt<=deadline)applyOutcome(race,racer,Math.abs(racer.plannedAt-target)<=CONFIG.timingWindowMs,racer.plannedAt,index);
      }
      if(now<=deadline)break;
      resolveExpiredCrossing(race,deadline,rng);
    }
    return race;
  }
  function accuracyFor(racer){const total=Number(racer?.hits||0)+Number(racer?.misses||0);return total?Number(racer.hits||0)/total:0;}
  function rankRace(race){
    const index=Number(race?.currentCrossing||0),finalRanking=!!race?.winnerId;
    return [...(race?.racers||[])].sort((a,b)=>{
      if(race?.winnerId){if(a.id===race.winnerId)return -1;if(b.id===race.winnerId)return 1;}
      const aa=isSleeping(a,index)?0:1,ba=isSleeping(b,index)?0:1;if(ba!==aa)return ba-aa;
      if(finalRanking){const as=Number(a.lastSleepAt??-1),bs=Number(b.lastSleepAt??-1);if(bs!==as)return bs-as;}
      if(b.hits!==a.hits)return b.hits-a.hits;if(a.misses!==b.misses)return a.misses-b.misses;
      if(b.bestStreak!==a.bestStreak)return b.bestStreak-a.bestStreak;
      return race.racers.indexOf(a)-race.racers.indexOf(b);
    });
  }
  function placeFor(race,id){const i=rankRace(race).findIndex(r=>r.id===id);return i<0?4:i+1;}
  function rewardFor(place,difficulty){const rows=REWARDS[DIFFICULTIES[difficulty]?difficulty:'normal'];return rows[clamp(Math.round(Number(place)||4)-1,0,3)];}
  function shiftRaceTimestamps(race,deltaMs){
    if(!race)return race;const d=Math.max(0,Number(deltaMs)||0);race.startedAt+=d;race.targetAt+=d;if(race.finalizedAt!=null)race.finalizedAt+=d;
    for(const r of race.racers){if(r.plannedAt!=null)r.plannedAt+=d;if(r.lastSleepAt!=null)r.lastSleepAt+=d;if(r.lastHitAt!=null)r.lastHitAt+=d;}return race;
  }
  return {CONFIG,DIFFICULTIES,REWARDS,difficultyProfile,createRace,centerTimeForIndex,pendulumPosition,isSleeping,awakeRacers,pressPlayer,advanceRace,finalizeIfNeeded,rankRace,placeFor,accuracyFor,rewardFor,shiftRaceTimestamps};
});
