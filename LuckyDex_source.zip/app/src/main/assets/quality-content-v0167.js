/* LuckyDex v0.16.7 — quiz expansion, three new Arcade games, binder shortcuts */
(() => {
  'use strict';

  let ballDropGameV167=null,ballDropRafV167=null;
  let unownGameV167=null,unownTimerV167=null;
  let safariGameV167=null;

  const sleepV167=ms=>new Promise(r=>setTimeout(r,ms));
  const shuffleV167=arr=>{const a=[...arr];for(let i=a.length-1;i>0;i--){const j=Math.floor(Math.random()*(i+1));[a[i],a[j]]=[a[j],a[i]];}return a;};

  function ensureV167State(){
    state.arcade ||= {};
    const defaults={bestQuizEndless:0,bestQuizEndlessScore:0,bestBallDrop:0,bestUnown:0,bestSafari:0,safariCaught:0,unownPerfect:0,ballDropJackpots:0};
    let changed=false;for(const [k,v] of Object.entries(defaults)){if(state.arcade[k]==null){state.arcade[k]=v;changed=true;}}
    if(changed)save();
    if(!ACHIEVEMENTS.some(a=>a.id==='quiz_endless_20'))ACHIEVEMENTS.push(
      {id:'quiz_endless_20',icon:'♾️',name:'Silhouette Machine',desc:"Reach a streak of 20 in Who's That Pokémon? Endless.",reward:{coins:1500,tickets:1},progress:()=>[Number(state.arcade.bestQuizEndless||0),20]},
      {id:'ball_drop_jackpot',icon:'🔴',name:'Prize Machine Jackpot',desc:'Land a Pokéball in the centre jackpot slot.',reward:{coins:900},progress:()=>[Number(state.arcade.ballDropJackpots||0),1]},
      {id:'unown_perfect',icon:'🔤',name:'Ruins Scholar',desc:'Decode all 5 Unown messages in one run.',reward:{coins:1000,tickets:1},progress:()=>[Number(state.arcade.unownPerfect||0),1]},
      {id:'safari_ten',icon:'🦏',name:'Safari Regular',desc:'Catch 10 Pokémon across Safari Zone runs.',reward:{coins:1000},progress:()=>[Number(state.arcade.safariCaught||0),10]}
    );
  }

  /* Visible Card Binder shortcuts. The select remains for accessibility and set filtering. */
  function wireBinderQuickFiltersV167(){
    document.querySelectorAll('[data-binder-filter]').forEach(btn=>btn.onclick=()=>{
      const select=document.getElementById('collectionFilter');if(!select)return;
      select.value=btn.dataset.binderFilter;renderCollection();
    });
    const search=document.getElementById('collectionSearch');if(search)search.oninput=renderCollection;
    const filter=document.getElementById('collectionFilter');if(filter)filter.onchange=renderCollection;
    const group=document.getElementById('collectionGroupFilter');if(group)group.onchange=renderCollection;
  }

  /* ---------- Who's That Pokémon? — Super Hard + Endless ---------- */
  resetQuizGameV166 = function(){
    stopQuizV166();quizGameV166={round:0,score:0,streak:0,correct:0,active:false,token:1,current:null,mode:quizDifficultyV166};
    document.getElementById('quizRound').textContent='0';document.getElementById('quizScore').textContent='0';document.getElementById('quizStreak').textContent='0';
    document.getElementById('quizBest').textContent=fmt(state.arcade.bestQuiz||0);document.getElementById('quizEndlessBest').textContent=fmt(state.arcade.bestQuizEndless||0);
    document.getElementById('quizPrompt').textContent="WHO'S THAT POKÉMON?";document.getElementById('quizSprite').removeAttribute('src');
    const wrap=document.querySelector('.quiz-silhouette-wrap');wrap?.classList.remove('reveal','hard','super');if(wrap){wrap.style.removeProperty('--quiz-tilt');wrap.style.removeProperty('--quiz-x');wrap.style.removeProperty('--quiz-y');}
    document.getElementById('quizAnswers').innerHTML='';document.getElementById('quizTimerFill').style.width='0%';
    const b=document.getElementById('quizStartBtn');b.hidden=false;b.disabled=false;b.textContent=quizDifficultyV166==='endless'?'START ENDLESS':'START QUIZ';
    setQuizDifficultyV166(quizDifficultyV166||'normal');
  };

  setQuizDifficultyV166 = function(mode){
    if(quizGameV166?.active)return;quizDifficultyV166=['easy','normal','hard','super','endless'].includes(mode)?mode:'normal';
    document.querySelectorAll('[data-quiz-difficulty]').forEach(b=>b.classList.toggle('active',b.dataset.quizDifficulty===quizDifficultyV166));
    const copy={easy:'Kanto + Johto · 12 seconds',normal:'All regions · 9 seconds',hard:'All regions · mirrored silhouette · 6 seconds',super:'6 choices · cropped/rotated silhouette · 4.2 seconds',endless:'One miss ends the run · timer gets faster after every correct answer'};
    document.getElementById('quizHint').textContent=copy[quizDifficultyV166];
    document.getElementById('quizRoundLabel').textContent=quizDifficultyV166==='endless'?'Streak':'Question';document.getElementById('quizRoundMax').textContent=quizDifficultyV166==='endless'?'':'/10';
    const b=document.getElementById('quizStartBtn');if(b)b.textContent=quizDifficultyV166==='endless'?'START ENDLESS':'START QUIZ';
  };

  startQuizV166 = function(){
    stopQuizV166();quizGameV166={round:0,score:0,streak:0,correct:0,active:true,token:(quizGameV166?.token||0)+1,current:null,mode:quizDifficultyV166};
    document.getElementById('quizStartBtn').hidden=true;nextQuizQuestionV166();
  };

  nextQuizQuestionV166 = function(){
    const g=quizGameV166;if(!g||!g.active)return;const endless=g.mode==='endless';if(!endless&&g.round>=10){finishQuizV166();return;}
    const pool=quizPoolV166();if(pool.length<10){showToast('Pokédex data is still loading. Try again in a moment.');resetQuizGameV166();return;}
    g.round++;const correct=pool[Math.floor(Math.random()*pool.length)];
    const count=g.mode==='super'?6:g.mode==='hard'?5:endless?(g.round>20?6:g.round>10?5:4):4;
    const opts=quizOptionsV166(correct,pool,count);
    const duration=endless?Math.max(2500,9000-(g.round-1)*220):({easy:12000,normal:9000,hard:6000,super:4200}[g.mode]||9000);
    g.current={correct,answered:false,duration,started:performance.now()};const token=g.token;
    document.getElementById('quizRound').textContent=endless?g.streak:g.round;document.getElementById('quizPrompt').textContent="WHO'S THAT POKÉMON?";
    const gen=generationForIdV166(correct.id);
    document.getElementById('quizHint').textContent=g.mode==='super'?'No hints. Six choices.':g.mode==='hard'?'No hints · trust your Pokédex instincts':endless?(g.round<=5?`Generation ${gen.id} · ${gen.name}`:`${(duration/1000).toFixed(1)} seconds`):g.mode==='easy'?`${gen.name} Pokémon`:`Generation ${gen.id} · ${gen.name}`;
    const wrap=document.querySelector('.quiz-silhouette-wrap');wrap.classList.remove('reveal','hard','super');
    if(g.mode==='hard')wrap.classList.add('hard');if(g.mode==='super'){wrap.classList.add('super');wrap.style.setProperty('--quiz-tilt',`${Math.round(-15+Math.random()*30)}deg`);wrap.style.setProperty('--quiz-x',`${Math.round(-8+Math.random()*16)}%`);wrap.style.setProperty('--quiz-y',`${Math.round(-6+Math.random()*12)}%`);}else{wrap.style.removeProperty('--quiz-tilt');wrap.style.removeProperty('--quiz-x');wrap.style.removeProperty('--quiz-y');}
    const img=document.getElementById('quizSprite');img.src=API.sprite(correct.id);img.alt='Mystery Pokémon';
    const answers=document.getElementById('quizAnswers');answers.innerHTML=opts.map(x=>`<button data-quiz-answer="${x.id}">${escapeHtml(titlePokemonV166(x.name))}</button>`).join('');answers.querySelectorAll('[data-quiz-answer]').forEach(b=>b.onclick=()=>answerQuizV166(Number(b.dataset.quizAnswer)));
    if(quizTimerV166)clearInterval(quizTimerV166);const fill=document.getElementById('quizTimerFill');fill.style.width='100%';quizTimerV166=setInterval(()=>{if(!quizGameV166||token!==quizGameV166.token||!g.current||g.current.answered){clearInterval(quizTimerV166);quizTimerV166=null;return;}const remaining=Math.max(0,1-(performance.now()-g.current.started)/duration);fill.style.width=`${remaining*100}%`;if(remaining<=0)answerQuizV166(null);},80);
  };

  answerQuizV166 = function(id){
    const g=quizGameV166,q=g?.current;if(!g||!q||q.answered)return;q.answered=true;if(quizTimerV166){clearInterval(quizTimerV166);quizTimerV166=null;}
    const correct=id===q.correct.id,remaining=Math.max(0,1-(performance.now()-q.started)/q.duration),wrap=document.querySelector('.quiz-silhouette-wrap');wrap.classList.add('reveal');wrap.classList.remove('hard','super');
    document.getElementById('quizPrompt').textContent=correct?`${titlePokemonV166(q.correct.name)}!`:`It's ${titlePokemonV166(q.correct.name)}!`;document.getElementById('quizHint').textContent=correct?'Correct!':'That one caught you out.';
    document.querySelectorAll('[data-quiz-answer]').forEach(b=>{b.disabled=true;if(Number(b.dataset.quizAnswer)===q.correct.id)b.classList.add('correct');else if(id!=null&&Number(b.dataset.quizAnswer)===id)b.classList.add('wrong');});
    if(correct){g.correct++;g.streak++;const modeBoost=g.mode==='super'?1.5:g.mode==='hard'?1.2:g.mode==='endless'?1.25:1;g.score+=Math.round((100+remaining*120+Math.min(180,g.streak*14))*modeBoost);vibrate([10,14,20]);}else{if(g.mode!=='endless')g.streak=0;vibrate(22);}
    document.getElementById('quizScore').textContent=fmt(g.score);document.getElementById('quizStreak').textContent=g.streak;document.getElementById('quizRound').textContent=g.mode==='endless'?g.streak:g.round;document.getElementById('quizTimerFill').style.width='0%';
    if(g.mode==='endless'&&!correct)setTimeout(()=>{if(quizGameV166===g&&g.active)finishQuizV166();},950);else setTimeout(()=>{if(quizGameV166===g&&g.active)nextQuizQuestionV166();},850);
  };

  finishQuizV166 = function(){
    const g=quizGameV166;if(!g||!g.active)return;g.active=false;if(quizTimerV166){clearInterval(quizTimerV166);quizTimerV166=null;}
    if(g.mode==='endless'){
      state.arcade.bestQuizEndless=Math.max(Number(state.arcade.bestQuizEndless||0),g.correct);state.arcade.bestQuizEndlessScore=Math.max(Number(state.arcade.bestQuizEndlessScore||0),g.score);save();document.getElementById('quizEndlessBest').textContent=fmt(state.arcade.bestQuizEndless);
      const payout=Math.max(80,Math.round(g.score*.55+g.correct*22)),awarded=awardArcadeCoins(payout,"Who's That Pokémon? Endless",'quiz');window.LuckyDexArcadeSession?.showResult?.('quiz',{title:`ENDLESS STREAK ${g.correct}`,metricLabel:'SCORE',metricValue:`${fmt(g.score)} · ${Math.max(2.5,9-(Math.max(0,g.round-1)*.22)).toFixed(1)}s final timer`,coinsAwarded:awarded,itemAwarded:null,bestText:g.correct>=state.arcade.bestQuizEndless?'BEST STREAK':'',onReplay:resetQuizGameV166,onBack:()=>window.LuckyDexArcadeWorld?.backFromGame?.(true)});return;
    }
    const mult={easy:.42,normal:.52,hard:.64,super:.78}[g.mode]||.52,payout=Math.max(100,Math.round(g.score*mult+g.correct*20));state.arcade.bestQuiz=Math.max(Number(state.arcade.bestQuiz||0),g.score);if(g.correct===10)state.arcade.quizPerfect=1;save();document.getElementById('quizBest').textContent=fmt(state.arcade.bestQuiz);const awarded=awardArcadeCoins(payout,"Who's That Pokémon?",'quiz');window.LuckyDexArcadeSession?.showResult?.('quiz',{title:g.correct===10?'PERFECT 10/10!':`${g.correct}/10 CORRECT`,metricLabel:'SCORE',metricValue:`${fmt(g.score)} · ${g.mode.toUpperCase().replace('SUPER','SUPER HARD')}`,coinsAwarded:awarded,itemAwarded:null,bestText:g.correct===10?'PERFECT RUN':'',onReplay:resetQuizGameV166,onBack:()=>window.LuckyDexArcadeWorld?.backFromGame?.(true)});
  };

  /* ---------- Pokéball Drop ---------- */
  const BALL_SLOT_MULT_V167=[1,2,3,6,3,2,1];
  function stopBallDropV167(){if(ballDropRafV167){cancelAnimationFrame(ballDropRafV167);ballDropRafV167=null;}if(ballDropGameV167)ballDropGameV167.token=(ballDropGameV167.token||0)+1;}
  function resetBallDropV167(){stopBallDropV167();ballDropGameV167={round:0,score:0,dropping:false,ball:null,token:1};document.getElementById('ballDropRound').textContent='0';document.getElementById('ballDropScore').textContent='0';document.getElementById('ballDropAim').value='50';document.getElementById('ballDropBtn').disabled=false;drawBallDropV167();}
  function ballDropPegsV167(){const pegs=[];for(let row=0;row<7;row++){const count=row%2?7:6,margin=row%2?62:112,span=(720-margin*2)/(count-1);for(let i=0;i<count;i++)pegs.push({x:margin+i*span,y:145+row*74,r:10});}return pegs;}
  function drawPokeBallV167(ctx,x,y,r){ctx.save();ctx.translate(x,y);ctx.beginPath();ctx.arc(0,0,r,0,Math.PI*2);ctx.clip();ctx.fillStyle='#ef4e54';ctx.fillRect(-r,-r,r*2,r);ctx.fillStyle='#f5f3e9';ctx.fillRect(-r,0,r*2,r);ctx.fillStyle='#202832';ctx.fillRect(-r,-3,r*2,6);ctx.restore();ctx.strokeStyle='#202832';ctx.lineWidth=3;ctx.beginPath();ctx.arc(x,y,r,0,Math.PI*2);ctx.stroke();ctx.fillStyle='#f7f5e9';ctx.beginPath();ctx.arc(x,y,r*.27,0,Math.PI*2);ctx.fill();ctx.strokeStyle='#202832';ctx.lineWidth=2;ctx.stroke();}
  function drawBallDropV167(){const c=document.getElementById('ballDropCanvas');if(!c)return;const ctx=c.getContext('2d'),w=c.width,h=c.height;ctx.clearRect(0,0,w,h);const grd=ctx.createLinearGradient(0,0,0,h);grd.addColorStop(0,'#16315b');grd.addColorStop(1,'#081426');ctx.fillStyle=grd;ctx.fillRect(0,0,w,h);for(const p of ballDropPegsV167()){ctx.fillStyle='#d4bc68';ctx.beginPath();ctx.arc(p.x,p.y,p.r,0,Math.PI*2);ctx.fill();ctx.strokeStyle='#655122';ctx.lineWidth=3;ctx.stroke();}const sw=w/7;for(let i=0;i<=7;i++){ctx.strokeStyle='#536784';ctx.lineWidth=3;ctx.beginPath();ctx.moveTo(i*sw,650);ctx.lineTo(i*sw,h);ctx.stroke();}ctx.fillStyle='#f3d862';ctx.font='bold 24px sans-serif';ctx.textAlign='center';BALL_SLOT_MULT_V167.forEach((m,i)=>ctx.fillText(i===3?'★':`×${m}`,sw*(i+.5),720));if(ballDropGameV167?.ball)drawPokeBallV167(ctx,ballDropGameV167.ball.x,ballDropGameV167.ball.y,18);else{const aim=Number(document.getElementById('ballDropAim')?.value||50)/100*w;drawPokeBallV167(ctx,aim,55,18);} }
  function dropBallV167(){const g=ballDropGameV167;if(!g||g.dropping||g.round>=3)return;g.dropping=true;g.round++;document.getElementById('ballDropRound').textContent=g.round;document.getElementById('ballDropBtn').disabled=true;document.getElementById('ballDropAim').disabled=true;const c=document.getElementById('ballDropCanvas'),x=Number(document.getElementById('ballDropAim').value)/100*c.width;g.ball={x,y:55,vx:(Math.random()-.5)*1.4,vy:0,lastPeg:-1};let last=performance.now();const pegs=ballDropPegsV167(),sw=c.width/7;
    const step=now=>{const dt=Math.min(2,(now-last)/16.67);last=now;const b=g.ball;b.vy+=.42*dt;b.x+=b.vx*dt;b.y+=b.vy*dt;if(b.x<20){b.x=20;b.vx=Math.abs(b.vx)*.8;}if(b.x>c.width-20){b.x=c.width-20;b.vx=-Math.abs(b.vx)*.8;}pegs.forEach((p,idx)=>{const dx=b.x-p.x,dy=b.y-p.y,dist=Math.hypot(dx,dy),min=29;if(dist<min&&dist>0&&idx!==b.lastPeg){const nx=dx/dist,ny=dy/dist;b.x=p.x+nx*min;b.y=p.y+ny*min;const dot=b.vx*nx+b.vy*ny;b.vx=(b.vx-2*dot*nx)*.76+(Math.random()-.5)*.7;b.vy=Math.abs((b.vy-2*dot*ny)*.72);b.lastPeg=idx;setTimeout(()=>{if(g.ball)g.ball.lastPeg=-1;},70);}});drawBallDropV167();if(b.y<700){ballDropRafV167=requestAnimationFrame(step);return;}ballDropRafV167=null;const slot=Math.max(0,Math.min(6,Math.floor(b.x/sw))),mult=BALL_SLOT_MULT_V167[slot],gain=100*mult;g.score+=gain;if(slot===3)state.arcade.ballDropJackpots=Number(state.arcade.ballDropJackpots||0)+1;document.getElementById('ballDropScore').textContent=fmt(g.score);g.ball=null;g.dropping=false;document.getElementById('ballDropAim').disabled=false;vibrate(slot===3?[20,20,60]:12);drawBallDropV167();if(g.round>=3)finishBallDropV167();else document.getElementById('ballDropBtn').disabled=false;};ballDropRafV167=requestAnimationFrame(step);
  }
  function finishBallDropV167(){const g=ballDropGameV167;if(!g)return;const payout=Math.round(g.score*.62);state.arcade.bestBallDrop=Math.max(Number(state.arcade.bestBallDrop||0),g.score);save();awardArcadeCoins(payout,'Pokéball Drop','ballDrop');resultV166('POKÉBALL DROP','🔴','PRIZE MACHINE COMPLETE',`Three balls scored ${fmt(g.score)} points · ${fmt(payout)} Lucky Coins.`,'DROP AGAIN',resetBallDropV167);}

  /* ---------- Unown Decoder ---------- */
  const UNOWN_WORDS_V167=[
    ['PIKACHU','Electric mascot'],['EEVEE','Evolution Pokémon'],['MEWTWO','Legendary experiment'],['GENGAR','Shadow Pokémon'],['SNORLAX','Sleeping giant'],['LUCARIO','Aura Pokémon'],['CELEBI','Time-traveling mythical'],['LUGIA','Guardian of the seas'],['HOOH','Rainbow legendary'],['KANTO','Region'],['JOHTO','Region'],['HOENN','Region'],['SINNOH','Region'],['UNOVA','Region'],['KALOS','Region'],['ALOLA','Region'],['GALAR','Region'],['PALDEA','Region'],['BERRY','Adventure item'],['POTION','Healing item'],['POKEDEX','Professor research tool'],['MASTERBALL','Ultimate Pokéball'],['CHARIZARD','Fire/Flying favourite'],['DRAGONITE','Original pseudo-legendary']
  ].map(([word,clue])=>({word,clue}));
  function stopUnownV167(){if(unownTimerV167){clearInterval(unownTimerV167);unownTimerV167=null;}if(unownGameV167)unownGameV167.token=(unownGameV167.token||0)+1;}
  function resetUnownV167(){stopUnownV167();unownGameV167={round:0,score:0,correct:0,active:false,used:new Set(),token:1,current:null};document.getElementById('unownRound').textContent='0';document.getElementById('unownScore').textContent='0';document.getElementById('unownGlyphs').innerHTML='';document.getElementById('unownClue').textContent='Press START DECODER.';document.getElementById('unownAnswers').innerHTML='';document.getElementById('unownTimerFill').style.width='0%';const b=document.getElementById('unownStartBtn');b.hidden=false;b.disabled=false;}
  function startUnownV167(){resetUnownV167();unownGameV167.active=true;document.getElementById('unownStartBtn').hidden=true;nextUnownV167();}
  function unownImgV167(ch){return `https://img.pokemondb.net/sprites/home/normal/unown-${ch.toLowerCase()}.png`;}
  function nextUnownV167(){const g=unownGameV167;if(!g?.active)return;if(g.round>=5){finishUnownV167();return;}const pool=UNOWN_WORDS_V167.filter(x=>!g.used.has(x.word)),entry=pool[Math.floor(Math.random()*pool.length)];g.used.add(entry.word);g.round++;g.current={entry,answered:false,started:performance.now(),duration:13000};document.getElementById('unownRound').textContent=g.round;document.getElementById('unownClue').textContent=`CLUE · ${entry.clue}`;document.getElementById('unownGlyphs').innerHTML=[...entry.word].map((ch,i)=>`<div class="unown-glyph" style="--unown-rot:${(i%3-1)*3}deg"><img src="${unownImgV167(ch)}" alt="Unown glyph" onerror="this.parentElement.classList.add('fallback');this.remove()"><span>${ch}</span></div>`).join('');const distract=shuffleV167(UNOWN_WORDS_V167.filter(x=>x.word!==entry.word)).slice(0,3),opts=shuffleV167([entry,...distract]);const box=document.getElementById('unownAnswers');box.innerHTML=opts.map(x=>`<button data-unown-answer="${escapeHtml(x.word)}">${escapeHtml(x.word.replace('HOOH','HO-OH').replace('MASTERBALL','MASTER BALL'))}</button>`).join('');box.querySelectorAll('[data-unown-answer]').forEach(b=>b.onclick=()=>answerUnownV167(b.dataset.unownAnswer));const token=g.token,fill=document.getElementById('unownTimerFill');fill.style.width='100%';unownTimerV167=setInterval(()=>{if(!unownGameV167||token!==unownGameV167.token||g.current?.answered){clearInterval(unownTimerV167);unownTimerV167=null;return;}const rem=Math.max(0,1-(performance.now()-g.current.started)/g.current.duration);fill.style.width=`${rem*100}%`;if(rem<=0)answerUnownV167('');},90);}
  function answerUnownV167(word){const g=unownGameV167,q=g?.current;if(!g||!q||q.answered)return;q.answered=true;if(unownTimerV167){clearInterval(unownTimerV167);unownTimerV167=null;}const ok=word===q.entry.word,rem=Math.max(0,1-(performance.now()-q.started)/q.duration);document.querySelectorAll('[data-unown-answer]').forEach(b=>{b.disabled=true;if(b.dataset.unownAnswer===q.entry.word)b.classList.add('correct');else if(b.dataset.unownAnswer===word)b.classList.add('wrong');});if(ok){g.correct++;g.score+=Math.round(180+q.entry.word.length*18+rem*180);vibrate([9,12,18]);document.getElementById('unownClue').textContent=`DECODED · ${q.entry.word.replace('HOOH','HO-OH')}`;}else{vibrate(20);document.getElementById('unownClue').textContent=`The message was ${q.entry.word.replace('HOOH','HO-OH')}.`;}document.getElementById('unownScore').textContent=fmt(g.score);document.getElementById('unownTimerFill').style.width='0%';setTimeout(()=>{if(unownGameV167===g&&g.active)nextUnownV167();},850);}
  function finishUnownV167(){const g=unownGameV167;if(!g?.active)return;g.active=false;const payout=Math.max(100,Math.round(g.score*.58+g.correct*40));state.arcade.bestUnown=Math.max(Number(state.arcade.bestUnown||0),g.score);if(g.correct===5)state.arcade.unownPerfect=1;save();awardArcadeCoins(payout,'Unown Decoder','unown');resultV166('UNOWN DECODER',g.correct===5?'🏛️':'🔤',g.correct===5?'RUINS MASTERED!':`${g.correct}/5 DECODED`,`Score ${fmt(g.score)} · ${fmt(payout)} Lucky Coins.`,'DECODE AGAIN',resetUnownV167);}

  /* ---------- Safari Zone ---------- */
  const SAFARI_POOL_V167=[
    {id:29,name:'Nidoran♀',tier:'Common',catch:.62,flee:.08,pts:120},{id:32,name:'Nidoran♂',tier:'Common',catch:.62,flee:.08,pts:120},{id:46,name:'Paras',tier:'Common',catch:.64,flee:.07,pts:110},{id:102,name:'Exeggcute',tier:'Common',catch:.58,flee:.09,pts:140},{id:111,name:'Rhyhorn',tier:'Uncommon',catch:.48,flee:.12,pts:190},{id:115,name:'Kangaskhan',tier:'Rare',catch:.30,flee:.18,pts:340},{id:123,name:'Scyther',tier:'Rare',catch:.28,flee:.20,pts:360},{id:127,name:'Pinsir',tier:'Rare',catch:.30,flee:.19,pts:350},{id:128,name:'Tauros',tier:'Rare',catch:.27,flee:.21,pts:390},{id:113,name:'Chansey',tier:'Very rare',catch:.19,flee:.24,pts:520},{id:147,name:'Dratini',tier:'Very rare',catch:.22,flee:.20,pts:500}
  ];
  function stopSafariV167(){if(safariGameV167)safariGameV167.token=(safariGameV167.token||0)+1;}
  function resetSafariV167(){stopSafariV167();safariGameV167={round:0,caught:0,score:0,balls:10,active:false,current:null,token:1};document.getElementById('safariRound').textContent='0';document.getElementById('safariCaught').textContent='0';document.getElementById('safariBalls').textContent='10';document.getElementById('safariBest').textContent=fmt(state.arcade.bestSafari||0);document.getElementById('safariName').textContent='???';document.getElementById('safariRarity').textContent='A wild Pokémon appeared!';document.getElementById('safariMessage').textContent='Press START SAFARI.';document.getElementById('safariSprite').removeAttribute('src');document.getElementById('safariScene').classList.remove('caught','fled');document.querySelectorAll('[data-safari-action]').forEach(b=>b.disabled=true);const start=document.getElementById('safariStartBtn');start.hidden=false;start.disabled=false;}
  function startSafariV167(){resetSafariV167();safariGameV167.active=true;document.getElementById('safariStartBtn').hidden=true;document.querySelectorAll('[data-safari-action]').forEach(b=>b.disabled=false);nextSafariV167();}
  function weightedSafariV167(){const r=Math.random();let pool=r<.12?SAFARI_POOL_V167.filter(x=>x.tier==='Very rare'):r<.38?SAFARI_POOL_V167.filter(x=>x.tier==='Rare'):r<.62?SAFARI_POOL_V167.filter(x=>x.tier==='Uncommon'):SAFARI_POOL_V167.filter(x=>x.tier==='Common');if(!pool.length)pool=SAFARI_POOL_V167;return pool[Math.floor(Math.random()*pool.length)];}
  function nextSafariV167(){const g=safariGameV167;if(!g?.active)return;if(g.round>=6||g.balls<=0){finishSafariV167();return;}g.round++;const p=weightedSafariV167();g.current={p,catchMod:1,fleeMod:1,observed:false,turns:0,done:false};document.getElementById('safariRound').textContent=g.round;document.getElementById('safariName').textContent=p.name;document.getElementById('safariRarity').textContent=`${p.tier.toUpperCase()} ENCOUNTER`;document.getElementById('safariMessage').textContent=`${p.name} is watching carefully…`;const scene=document.getElementById('safariScene');scene.classList.remove('caught','fled');const img=document.getElementById('safariSprite');img.src=API.sprite(p.id);img.alt=p.name;document.querySelectorAll('[data-safari-action]').forEach(b=>b.disabled=false);}
  async function safariActionV167(action){const g=safariGameV167,q=g?.current;if(!g?.active||!q||q.done)return;q.turns++;document.querySelectorAll('[data-safari-action]').forEach(b=>b.disabled=true);const msg=document.getElementById('safariMessage');if(action==='ball'){if(g.balls<=0){finishSafariV167();return;}g.balls--;document.getElementById('safariBalls').textContent=g.balls;const chance=Math.min(.92,q.p.catch*q.catchMod*(q.observed?1.12:1));msg.textContent=`Safari Ball thrown… ${Math.round(chance*100)}% catch chance`;await sleepV167(550);if(Math.random()<chance){q.done=true;g.caught++;g.score+=q.p.pts+Math.max(0,5-q.turns)*20;state.arcade.safariCaught=Number(state.arcade.safariCaught||0)+1;save();document.getElementById('safariCaught').textContent=g.caught;document.getElementById('safariScene').classList.add('caught');msg.textContent=`Gotcha! ${q.p.name} was caught!`;vibrate([10,12,28]);await sleepV167(800);nextSafariV167();return;}msg.textContent=`Oh no! ${q.p.name} broke free.`;
      }else if(action==='bait'){q.catchMod*=.72;q.fleeMod*=.48;msg.textContent=`${q.p.name} is eating. It looks calmer, but harder to catch.`;}else if(action==='rock'){q.catchMod*=1.55;q.fleeMod*=1.65;msg.textContent=`${q.p.name} is angry! Catch chance rose, but so did the flee risk.`;}else{q.observed=true;q.catchMod*=1.08;q.fleeMod*=.82;msg.textContent=`You stay still and study ${q.p.name}'s movement.`;}
    await sleepV167(420);const fleeChance=Math.min(.8,q.p.flee*q.fleeMod*(1+Math.max(0,q.turns-3)*.12));if(Math.random()<fleeChance){q.done=true;document.getElementById('safariScene').classList.add('fled');msg.textContent=`${q.p.name} fled!`;vibrate(18);await sleepV167(750);nextSafariV167();return;}if(q.turns>=6){q.done=true;msg.textContent=`${q.p.name} slipped back into the grass.`;await sleepV167(650);nextSafariV167();return;}document.querySelectorAll('[data-safari-action]').forEach(b=>b.disabled=false);
  }
  function finishSafariV167(){const g=safariGameV167;if(!g?.active)return;g.active=false;document.querySelectorAll('[data-safari-action]').forEach(b=>b.disabled=true);const payout=Math.max(80,Math.round(g.score*.72+g.caught*70));state.arcade.bestSafari=Math.max(Number(state.arcade.bestSafari||0),g.score);save();document.getElementById('safariBest').textContent=fmt(state.arcade.bestSafari);awardArcadeCoins(payout,'Safari Zone','safari');resultV166('SAFARI ZONE','🦏',`${g.caught} CAUGHT`,`Safari score ${fmt(g.score)} · ${fmt(payout)} Lucky Coins earned.`,'NEW SAFARI',resetSafariV167);}

  /* Extend the v0.16.6 arcade shell to the three new games. */
  openArcadeGame = function(name){
    if(name!=='clefairy')stopClefairyGame();stopFossilV166();stopDittoV166();stopQuizV166();stopBallDropV167();stopUnownV167();stopSafariV167();
    ['voltorb','clefairy','berry','fossil','ditto','quiz','ballDrop','unown','safari'].forEach(g=>{const el=document.getElementById(`${g}Game`);if(el)el.hidden=g!==name;});
    document.body.classList.add('arcade-open');window.Android?.setImmersive?.(true);if(name==='voltorb')newVoltorbBoard();if(name==='clefairy')resetMemoryGame();if(name==='berry')resetBerryGame();if(name==='fossil')resetFossilGameV166();if(name==='ditto')resetDittoGameV166();if(name==='quiz')resetQuizGameV166();if(name==='ballDrop')resetBallDropV167();if(name==='unown')resetUnownV167();if(name==='safari')resetSafariV167();renderArcadeHelper();
  };
  closeArcadeGame = function(force=false){
    const atRisk=(voltorb&&!voltorb.busted&&voltorb.revealed>0&&voltorb.bank>1)||(memoryGame&&memoryGame.bank>0)||(dittoGameV166&&dittoGameV166.bank>0&&!dittoGameV166.failed);
    if(atRisk&&!force&&!confirm('Leave the minigame? Any unbanked reward will be lost.'))return;stopClefairyGame();if(berryRaf)cancelAnimationFrame(berryRaf);if(berryGame)berryGame.running=false;stopFossilV166();stopDittoV166();stopQuizV166();stopBallDropV167();stopUnownV167();stopSafariV167();['voltorb','clefairy','berry','fossil','ditto','quiz','ballDrop','unown','safari'].forEach(g=>{const el=document.getElementById(`${g}Game`);if(el)el.hidden=true;});document.body.classList.remove('arcade-open');window.Android?.setImmersive?.(false);voltorb=null;memoryGame=null;fossilGameV166=null;dittoGameV166=null;quizGameV166=null;ballDropGameV167=null;unownGameV167=null;safariGameV167=null;renderArcadeHelper();
  };

  function wireV167(){
    ensureV167State();wireBinderQuickFiltersV167();
    document.querySelectorAll('[data-game]').forEach(b=>b.onclick=()=>openArcadeGame(b.dataset.game));document.querySelectorAll('[data-exit-game]').forEach(b=>b.onclick=()=>closeArcadeGame());
    document.querySelectorAll('[data-quiz-difficulty]').forEach(b=>b.onclick=()=>setQuizDifficultyV166(b.dataset.quizDifficulty));document.getElementById('quizStartBtn').onclick=startQuizV166;
    document.getElementById('ballDropBtn').onclick=dropBallV167;if(document.getElementById('ballDropNewBtn'))document.getElementById('ballDropNewBtn').onclick=resetBallDropV167;document.getElementById('ballDropAim').oninput=()=>{if(!ballDropGameV167?.dropping)drawBallDropV167();};
    document.getElementById('unownStartBtn').onclick=startUnownV167;document.getElementById('safariStartBtn').onclick=startSafariV167;document.querySelectorAll('[data-safari-action]').forEach(b=>b.onclick=()=>safariActionV167(b.dataset.safariAction));
    setQuizDifficultyV166('normal');
  }
  wireV167();
})();
