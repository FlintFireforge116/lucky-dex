(function(root,factory){
  const api=factory();
  if(typeof module==='object'&&module.exports){module.exports=api;return;}
  root.LuckyDexCosmeticsCatalogV0413=api;
})(typeof globalThis!=='undefined'?globalThis:this,function(){
  'use strict';
  const rows=[
    ['luckydex-default','LuckyDex Default','luckydex','common','Always available',false],
    ['luckydex-midnight','LuckyDex Midnight','luckydex','common','Always available',false],
    ['luckydex-cream','LuckyDex Cream','luckydex','common','Always available',false],
    ['luckydex-pixel','LuckyDex Pixel','luckydex','common','Always available',false],
    ['kanto-red','Kanto Red','pokemon','rare','Clear Kanto Regional Adventure',false,'regional_kanto'],
    ['johto-gold','Johto Gold','pokemon','rare','Clear Johto Regional Adventure',false,'regional_johto'],
    ['hoenn-emerald','Hoenn Emerald','pokemon','rare','Clear Hoenn Regional Adventure',false,'regional_hoenn'],
    ['shiny-charm','Shiny Charm','pokemon','rare','Catch 25 shiny Pokémon',false,'shiny_25'],
    ['kanto-dex','Kanto Dex','pokemon','rare','Complete the Kanto Pokédex',false,'dex_gen_1'],
    ['type-wheel','Type Wheel','pokemon','rare','Own Pokémon representing all 18 types',false,'v0413_types_all_18'],
    ['eras','Across the Eras','pokemon','rare','Own a Pokémon from every generation',false,'v0413_gens_all_9'],
    ['shiny-tour','Shiny Tour','pokemon','rare','Own shiny Pokémon from 3 generations',false,'v0413_shiny_gens_3'],
    ['tcg-master','TCG Master','tcg','rare','Complete 10 physical TCG sets',false,'sets_tcg_10'],
    ['dual-binder','Dual Binder','tcg','rare','Complete a TCG and TCG Pocket set',false,'v0413_dual_set_complete'],
    ['sealed-vault','Sealed Vault','tcg','rare','Own 5 sealed boosters at once',false,'v0413_sealed_5'],
    ['first-ball','First Ball','tcg','rare','Make a first-throw catch',false,'v0413_first_throw'],
    ['pocket-master','Pocket Master','tcgp','rare','Complete 5 TCG Pocket sets',false,'sets_tcgp_5'],
    ['god-pack','God Pack','tcgp','epic','Open a God Pack',false,'god_pack_1'],
    ['dash-champion','Dash Champion','events','rare','Earn Gold with every Dash type',false,'dash_all_types_gold'],
    ['museum-fossil','Museum Fossil','events','rare','Complete 20 museum exhibits',false,'museum_exhibits_20'],
    ['rock-solid','Rock Solid','events','rare','Clear every Rock Harden difficulty',false,'rock_harden_all_difficulties'],
    ['unown-code','Unown Code','events','rare','Perfect five Unown rounds',false,'unown_perfect_5'],
    ['link-cable','Link Cable','events','rare','Complete 10 trades',false,'v0413_trade_10'],
    ['arcade-pass','Arcade Pass','events','rare','Record results in 8 Arcade games',false,'v0413_arcade_sampler_8'],
    ['oak-trio','???','secrets','secret','',true,'v0413_secret_kanto_starters'],
    ['eevee-spectrum','???','secrets','secret','',true,'v0413_secret_eevee_family'],
    ['splash-school','???','secrets','secret','',true,'v0413_secret_magikarp_6'],
    ['voltorb-lost','???','secrets','secret','',true,'v0413_secret_voltorb_gift_lost'],
    ['golden-recipe','???','secrets','secret','',true,'v0413_secret_golden_berry_perfect'],
    ['already-got-em','???','secrets','secret','',true,'v0413_secret_god_pack_no_new']
  ];
  const trueSecretNames={
    'oak-trio':'Oak Trio','eevee-spectrum':'Eevee Spectrum','splash-school':'Splash School',
    'voltorb-lost':'Voltorb Lost','golden-recipe':'Golden Recipe','already-got-em':'Already Got ’Em'
  };
  const CATALOGUE=rows.map(([id,name,category,tier,unlockText,hidden,sourceAchievementId])=>({
    id,name,realName:trueSecretNames[id]||name,category,tier,unlockText,hidden:!!hidden,sourceAchievementId:sourceAchievementId||null,
    artPath:`cosmetics/sleeves/${id}.webp`
  }));
  const BY_ID=Object.fromEntries(CATALOGUE.map(x=>[x.id,x]));
  return {CATALOGUE,BY_ID};
});
