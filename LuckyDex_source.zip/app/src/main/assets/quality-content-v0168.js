/* LuckyDex v0.16.8 — marketplace polish, Pokéball physics, Unown difficulty */
(() => {
  'use strict';

  let ballGameV168 = null;
  let ballRafV168 = null;
  let unownGameV168 = null;
  let unownTimerV168 = null;
  let unownDifficultyV168 = 'easy';

  const BALL_SLOT_SCORE_V168 = [150,250,400,1000,400,250,150];
  const BALL_PIN_BONUS_V168 = 12;
  const sleepV168 = ms => new Promise(resolve => setTimeout(resolve, ms));
  const shuffleV168 = arr => {
    const out=[...arr];
    for(let i=out.length-1;i>0;i--){const j=Math.floor(Math.random()*(i+1));[out[i],out[j]]=[out[j],out[i]];}
    return out;
  };

  /* Safari is being held back for the future roguelite/catching mode rather than Arcade. */
  function retireSafariArcadeV168(){
    document.querySelector('[data-game="safari"]')?.remove();
    const idx = ACHIEVEMENTS.findIndex(a=>a.id==='safari_ten');
    if(idx>=0) ACHIEVEMENTS.splice(idx,1);
  }

  /* ---------------- Pokéball Drop: real circular dynamics ---------------- */
  function ballCanvasV168(){ return document.getElementById('ballDropCanvas'); }
  function ballPegsV168(){
    const pegs=[];
    for(let row=0;row<7;row++){
      const count=row%2?7:6, margin=row%2?62:112, span=(720-margin*2)/(count-1);
      for(let i=0;i<count;i++) pegs.push({id:`${row}:${i}`,x:margin+i*span,y:145+row*74,r:10});
    }
    return pegs;
  }
  function drawPokeballV168(ctx,b){
    const r=b.r;
    ctx.save();ctx.translate(b.x,b.y);ctx.rotate(b.angle||0);
    ctx.beginPath();ctx.arc(0,0,r,0,Math.PI*2);ctx.clip();
    ctx.fillStyle='#ef4b54';ctx.fillRect(-r,-r,r*2,r);
    ctx.fillStyle='#f5f3e9';ctx.fillRect(-r,0,r*2,r);
    ctx.fillStyle='#20262f';ctx.fillRect(-r,-3.2,r*2,6.4);
    ctx.restore();
    ctx.save();ctx.translate(b.x,b.y);ctx.rotate(b.angle||0);
    ctx.strokeStyle='#20262f';ctx.lineWidth=3.2;ctx.beginPath();ctx.arc(0,0,r,0,Math.PI*2);ctx.stroke();
    ctx.fillStyle='#f7f5e9';ctx.beginPath();ctx.arc(0,0,r*.28,0,Math.PI*2);ctx.fill();ctx.strokeStyle='#20262f';ctx.lineWidth=2.2;ctx.stroke();
    ctx.restore();
  }
  function drawBallBoardV168(){
    const c=ballCanvasV168(); if(!c) return;
    const ctx=c.getContext('2d'),w=c.width,h=c.height,sw=w/7,slotTop=610,floorY=686;
    ctx.clearRect(0,0,w,h);
    const bg=ctx.createLinearGradient(0,0,0,h);bg.addColorStop(0,'#17325d');bg.addColorStop(.7,'#09162b');bg.addColorStop(1,'#060d1a');ctx.fillStyle=bg;ctx.fillRect(0,0,w,h);
    // subtle prize-machine rails
    ctx.strokeStyle='rgba(217,185,90,.24)';ctx.lineWidth=3;ctx.strokeRect(10,10,w-20,h-20);
    for(const p of ballPegsV168()){
      const g=ctx.createRadialGradient(p.x-3,p.y-4,1,p.x,p.y,p.r+2);g.addColorStop(0,'#fff1a5');g.addColorStop(.42,'#d6b756');g.addColorStop(1,'#655020');ctx.fillStyle=g;ctx.beginPath();ctx.arc(p.x,p.y,p.r,0,Math.PI*2);ctx.fill();ctx.strokeStyle='#3f3219';ctx.lineWidth=2;ctx.stroke();
    }
    ctx.strokeStyle='#536784';ctx.lineWidth=4;
    for(let i=0;i<=7;i++){ctx.beginPath();ctx.moveTo(i*sw,slotTop);ctx.lineTo(i*sw,floorY);ctx.stroke();}
    ctx.strokeStyle='#6f83a3';ctx.lineWidth=4;ctx.beginPath();ctx.moveTo(0,floorY);ctx.lineTo(w,floorY);ctx.stroke();
    const g=ballGameV168;
    if(Number.isInteger(g?.settledSlot)){
      const x=g.settledSlot*sw;ctx.fillStyle=g.settledSlot===3?'rgba(255,221,86,.22)':'rgba(104,163,255,.15)';ctx.fillRect(x,slotTop,sw,floorY-slotTop);
    }
    ctx.textAlign='center';ctx.font='900 21px sans-serif';BALL_SLOT_SCORE_V168.forEach((pts,i)=>{ctx.fillStyle=i===3?'#ffe46b':'#c6d3e8';ctx.fillText(i===3?'★ 1000 ★':String(pts),sw*(i+.5),730);});
    if(g?.ball) drawPokeballV168(ctx,g.ball);
    else {
      const aim=Number(document.getElementById('ballDropAim')?.value||50)/100*w;
      drawPokeballV168(ctx,{x:aim,y:55,r:20,angle:0});
    }
  }
  function stopBallV168(){
    if(ballRafV168){cancelAnimationFrame(ballRafV168);ballRafV168=null;}
    if(ballGameV168) ballGameV168.token=(ballGameV168.token||0)+1;
  }
  function resetBallV168(){
    stopBallV168();
    ballGameV168={round:0,score:0,dropping:false,ball:null,settledSlot:null,token:1};
    document.getElementById('ballDropRound').textContent='0';
    document.getElementById('ballDropScore').textContent='0';
    document.getElementById('ballDropAim').value='50';
    document.getElementById('ballDropAim').disabled=false;
    document.getElementById('ballDropBtn').disabled=false;
    document.getElementById('ballDropLanding').hidden=true;
    drawBallBoardV168();
  }
  function resolvePinCollisionV168(b,p,now){
    const dx=b.x-p.x,dy=b.y-p.y,min=b.r+p.r,dist=Math.hypot(dx,dy);
    if(dist<=0||dist>=min) return false;
    const nx=dx/dist,ny=dy/dist,tx=-ny,ty=nx,overlap=min-dist;
    b.x+=nx*overlap;b.y+=ny*overlap;
    const vn=b.vx*nx+b.vy*ny;
    if(vn<0){
      // Fixed-pin collision for a solid circular ball. Resolve normal bounce,
      // then a Coulomb-limited tangential impulse that exchanges slide speed
      // for angular velocity. The rotation you see is therefore contact-driven.
      const restitution=.76,jn=-(1+restitution)*vn;
      b.vx+=jn*nx;b.vy+=jn*ny;
      const inertia=.5*b.r*b.r;
      const relativeTangent=b.vx*tx+b.vy*ty-b.omega*b.r;
      const tangentDenom=1+(b.r*b.r/inertia);
      let jt=-relativeTangent/tangentDenom;
      const maxFriction=Math.abs(jn)*.28;jt=Math.max(-maxFriction,Math.min(maxFriction,jt));
      b.vx+=jt*tx;b.vy+=jt*ty;b.omega-=jt*b.r/inertia;
      // Real prize machines are never perfectly symmetric; a tiny imperfection
      // avoids dead-straight repeat paths without overriding the physics.
      b.vx+=(Math.random()-.5)*7;
      if(-vn>75){
        b.pinCooldown ||= {};
        const last=Number(b.pinCooldown[p.id]||0);
        if(now-last>65){b.pinCooldown[p.id]=now;b.pinHits=Number(b.pinHits||0)+1;}
      }
    }
    return true;
  }
  function resolveSlotWallsV168(b,w){
    const sw=w/7,slotTop=610,floorY=686;
    if(b.y+b.r>slotTop){
      for(let i=1;i<7;i++){
        const wall=i*sw,dx=b.x-wall;
        if(Math.abs(dx)<b.r && b.y-b.r<floorY){
          const side=dx>=0?1:-1;b.x=wall+side*b.r;
          if(b.vx*side<0){b.vx=-b.vx*.55;b.omega+=-b.vx/b.r*.32;}
        }
      }
    }
    if(b.x-b.r<0){b.x=b.r;b.vx=Math.abs(b.vx)*.62;b.omega-=b.vy/b.r*.05;}
    if(b.x+b.r>w){b.x=w-b.r;b.vx=-Math.abs(b.vx)*.62;b.omega+=b.vy/b.r*.05;}
  }
  async function settleBallV168(slot){
    const g=ballGameV168;if(!g?.ball)return;
    const c=ballCanvasV168(),sw=c.width/7,b=g.ball;
    b.x=sw*(slot+.5);b.y=686-b.r;b.vx=0;b.vy=0;b.omega*=.18;g.settledSlot=slot;
    const slotPoints=BALL_SLOT_SCORE_V168[slot],pinBonus=Math.min(300,Number(b.pinHits||0)*BALL_PIN_BONUS_V168),gain=slotPoints+pinBonus;
    drawBallBoardV168();
    g.score+=gain;document.getElementById('ballDropScore').textContent=fmt(g.score);
    if(slot===3){state.arcade.ballDropJackpots=Number(state.arcade.ballDropJackpots||0)+1;save();}
    const land=document.getElementById('ballDropLanding');
    document.getElementById('ballDropLandingTitle').textContent=slot===3?'★ JACKPOT ★':`${fmt(slotPoints)} POINT SLOT`;
    document.getElementById('ballDropLandingScore').textContent=`+${fmt(gain)} POINTS`;
    const detail=document.getElementById('ballDropLandingDetail');if(detail)detail.textContent=`${fmt(slotPoints)} landing + ${fmt(pinBonus)} pin bonus · ${Number(b.pinHits||0)} hits`;
    land.classList.toggle('jackpot',slot===3);land.hidden=false;
    vibrate(slot===3?[18,20,30,20,70]:[10,16,20]);
    // The ball physically comes to rest and remains visible long enough for the
    // player to see where it scored before the machine resets for the next one.
    await sleepV168(slot===3?1550:1250);
    if(ballGameV168!==g)return;
    land.hidden=true;land.classList.remove('jackpot');g.ball=null;g.settledSlot=null;g.dropping=false;drawBallBoardV168();
    document.getElementById('ballDropAim').disabled=false;
    if(g.round>=3){
      const payout=Math.round(g.score*.62);state.arcade.bestBallDrop=Math.max(Number(state.arcade.bestBallDrop||0),g.score);save();awardArcadeCoins(payout,'Pokéball Drop','ballDrop');
      resultV166('POKÉBALL DROP','🔴','PRIZE MACHINE COMPLETE',`Three Pokéballs scored ${fmt(g.score)} points · ${fmt(payout)} Lucky Coins.`,'DROP AGAIN',resetBallV168);
    }else document.getElementById('ballDropBtn').disabled=false;
  }
  function dropBallV168(){
    const g=ballGameV168,c=ballCanvasV168();if(!g||!c||g.dropping||g.round>=3)return;
    g.dropping=true;g.round++;document.getElementById('ballDropRound').textContent=g.round;document.getElementById('ballDropBtn').disabled=true;document.getElementById('ballDropAim').disabled=true;document.getElementById('ballDropLanding').hidden=true;
    const x=Number(document.getElementById('ballDropAim').value)/100*c.width;
    g.ball={x,y:54,r:20,vx:(Math.random()-.5)*34,vy:0,angle:0,omega:(Math.random()-.5)*1.2,pinHits:0,pinCooldown:{}};
    const token=++g.token,pins=ballPegsV168();let last=performance.now();
    const frame=now=>{
      if(!ballGameV168||ballGameV168!==g||token!==g.token)return;
      let dt=Math.min(.032,(now-last)/1000);last=now;
      const steps=Math.max(2,Math.ceil(dt/.008));dt/=steps;
      for(let k=0;k<steps;k++){
        const b=g.ball;b.vy+=1300*dt;b.vx*=.999;b.omega*=.9985;b.x+=b.vx*dt;b.y+=b.vy*dt;b.angle+=b.omega*dt;
        resolveSlotWallsV168(b,c.width);
        for(const p of pins)resolvePinCollisionV168(b,p,now);
        if(b.y+b.r>=686){
          const slot=Math.max(0,Math.min(6,Math.floor(b.x/(c.width/7))));
          ballRafV168=null;settleBallV168(slot);return;
        }
      }
      drawBallBoardV168();ballRafV168=requestAnimationFrame(frame);
    };
    ballRafV168=requestAnimationFrame(frame);
  }

  /* ---------------- Unown Decoder: Easy + Hard ---------------- */
  const UNOWN_WORDS_V168 = [
    {answer:'PIKACHU',letters:'PIKACHU',clue:'Electric mascot'},{answer:'EEVEE',letters:'EEVEE',clue:'Evolution Pokémon'},
    {answer:'MEWTWO',letters:'MEWTWO',clue:'Legendary experiment'},{answer:'GENGAR',letters:'GENGAR',clue:'Shadow Pokémon'},
    {answer:'SNORLAX',letters:'SNORLAX',clue:'Sleeping giant'},{answer:'LUCARIO',letters:'LUCARIO',clue:'Aura Pokémon'},
    {answer:'CELEBI',letters:'CELEBI',clue:'Time-travelling mythical'},{answer:'LUGIA',letters:'LUGIA',clue:'Guardian of the seas'},
    {answer:'HO-OH',letters:'HOOH',clue:'Rainbow legendary'},{answer:'KANTO',letters:'KANTO',clue:'Region'},
    {answer:'JOHTO',letters:'JOHTO',clue:'Region'},{answer:'HOENN',letters:'HOENN',clue:'Region'},{answer:'SINNOH',letters:'SINNOH',clue:'Region'},
    {answer:'UNOVA',letters:'UNOVA',clue:'Region'},{answer:'KALOS',letters:'KALOS',clue:'Region'},{answer:'ALOLA',letters:'ALOLA',clue:'Region'},
    {answer:'GALAR',letters:'GALAR',clue:'Region'},{answer:'PALDEA',letters:'PALDEA',clue:'Region'},{answer:'BERRY',letters:'BERRY',clue:'Adventure item'},
    {answer:'POTION',letters:'POTION',clue:'Healing item'},{answer:'POKÉDEX',letters:'POKEDEX',clue:'Professor research tool'},
    {answer:'MASTER BALL',letters:'MASTER BALL',clue:'Ultimate Pokéball'},{answer:'CHARIZARD',letters:'CHARIZARD',clue:'Fire/Flying favourite'},
    {answer:'DRAGONITE',letters:'DRAGONITE',clue:'Original pseudo-legendary'}
  ];
  function stopUnownV168(){if(unownTimerV168){clearInterval(unownTimerV168);unownTimerV168=null;}if(unownGameV168)unownGameV168.token=(unownGameV168.token||0)+1;}
  function unownImgV168(ch){return `https://img.pokemondb.net/sprites/home/normal/unown-${ch.toLowerCase()}.png`;}
  function renderUnownGlyphsV168(entry){
    const host=document.getElementById('unownGlyphs');host.innerHTML='';
    const words=entry.letters.split(' ');
    for(const word of words){
      const line=document.createElement('div');line.className='unown-word';line.style.setProperty('--unown-count',String(word.length));
      line.innerHTML=[...word].map((ch,i)=>`<div class="unown-glyph" style="--unown-rot:${(i%3-1)*2}deg"><img src="${unownImgV168(ch)}" alt="Unown glyph" onerror="this.parentElement.classList.add('fallback');this.remove()"><span>${ch}</span></div>`).join('');
      host.appendChild(line);
    }
  }
  function setUnownDifficultyV168(mode){
    if(unownGameV168?.active)return;unownDifficultyV168=mode==='hard'?'hard':'easy';
    document.querySelectorAll('[data-unown-difficulty]').forEach(b=>b.classList.toggle('active',b.dataset.unownDifficulty===unownDifficultyV168));
    const clue=document.getElementById('unownClue');if(clue)clue.textContent=unownDifficultyV168==='easy'?'Hints on · 14 seconds · 4 choices':'Hints off · 8 seconds · 6 choices';
  }
  function resetUnownV168(){
    stopUnownV168();unownGameV168={round:0,score:0,correct:0,active:false,used:new Set(),token:1,current:null,mode:unownDifficultyV168};
    document.getElementById('unownRound').textContent='0';document.getElementById('unownScore').textContent='0';document.getElementById('unownGlyphs').innerHTML='';document.getElementById('unownAnswers').innerHTML='';document.getElementById('unownTimerFill').style.width='0%';
    document.getElementById('unownStartBtn').hidden=false;setUnownDifficultyV168(unownDifficultyV168);
  }
  function startUnownV168(){resetUnownV168();unownGameV168.active=true;unownGameV168.mode=unownDifficultyV168;document.getElementById('unownStartBtn').hidden=true;nextUnownV168();}
  function nextUnownV168(){
    const g=unownGameV168;if(!g?.active)return;if(g.round>=5){finishUnownV168();return;}
    const pool=UNOWN_WORDS_V168.filter(x=>!g.used.has(x.answer)),entry=pool[Math.floor(Math.random()*pool.length)];g.used.add(entry.answer);g.round++;
    const hard=g.mode==='hard',duration=hard?8000:14000,optionCount=hard?6:4;g.current={entry,answered:false,started:performance.now(),duration};
    document.getElementById('unownRound').textContent=g.round;document.getElementById('unownClue').textContent=hard?'HINTS OFF · decode the glyphs':`CLUE · ${entry.clue}`;renderUnownGlyphsV168(entry);
    const distract=shuffleV168(UNOWN_WORDS_V168.filter(x=>x.answer!==entry.answer)).slice(0,optionCount-1),opts=shuffleV168([entry,...distract]),box=document.getElementById('unownAnswers');
    box.innerHTML=opts.map(x=>`<button data-unown-v168="${escapeHtml(x.answer)}">${escapeHtml(x.answer)}</button>`).join('');box.querySelectorAll('[data-unown-v168]').forEach(b=>b.onclick=()=>answerUnownV168(b.dataset.unownV168));
    const token=g.token,fill=document.getElementById('unownTimerFill');fill.style.width='100%';if(unownTimerV168)clearInterval(unownTimerV168);unownTimerV168=setInterval(()=>{if(!unownGameV168||token!==unownGameV168.token||g.current?.answered){clearInterval(unownTimerV168);unownTimerV168=null;return;}const rem=Math.max(0,1-(performance.now()-g.current.started)/duration);fill.style.width=`${rem*100}%`;if(rem<=0)answerUnownV168('');},80);
  }
  function answerUnownV168(answer){
    const g=unownGameV168,q=g?.current;if(!g||!q||q.answered)return;q.answered=true;if(unownTimerV168){clearInterval(unownTimerV168);unownTimerV168=null;}
    const ok=answer===q.entry.answer,rem=Math.max(0,1-(performance.now()-q.started)/q.duration);document.querySelectorAll('[data-unown-v168]').forEach(b=>{b.disabled=true;if(b.dataset.unownV168===q.entry.answer)b.classList.add('correct');else if(b.dataset.unownV168===answer)b.classList.add('wrong');});
    if(ok){g.correct++;const mult=g.mode==='hard'?1.55:1;g.score+=Math.round((180+q.entry.letters.replace(/\s/g,'').length*18+rem*180)*mult);vibrate([9,12,18]);document.getElementById('unownClue').textContent=`DECODED · ${q.entry.answer}`;}else{vibrate(20);document.getElementById('unownClue').textContent=`The message was ${q.entry.answer}.`;}
    document.getElementById('unownScore').textContent=fmt(g.score);document.getElementById('unownTimerFill').style.width='0%';setTimeout(()=>{if(unownGameV168===g&&g.active)nextUnownV168();},850);
  }
  function finishUnownV168(){
    const g=unownGameV168;if(!g?.active)return;g.active=false;const payout=Math.max(100,Math.round(g.score*(g.mode==='hard'?.66:.58)+g.correct*40));state.arcade.bestUnown=Math.max(Number(state.arcade.bestUnown||0),g.score);if(g.correct===5)state.arcade.unownPerfect=1;save();awardArcadeCoins(payout,'Unown Decoder','unown');resultV166('UNOWN DECODER',g.correct===5?'🏛️':'🔤',g.correct===5?'RUINS MASTERED!':`${g.correct}/5 DECODED`,`Score ${fmt(g.score)} · ${fmt(payout)} Lucky Coins · ${g.mode.toUpperCase()}.`,'DECODE AGAIN',resetUnownV168);
  }

  function wireV168(){
    retireSafariArcadeV168();
    // Rewire the two revised games after v0.16.7 has installed its handlers.
    const ballCard=document.querySelector('[data-game="ballDrop"]');if(ballCard)ballCard.onclick=()=>{openArcadeGame('ballDrop');setTimeout(resetBallV168,0);};
    const unownCard=document.querySelector('[data-game="unown"]');if(unownCard)unownCard.onclick=()=>{openArcadeGame('unown');setTimeout(resetUnownV168,0);};
    document.getElementById('ballDropBtn').onclick=dropBallV168;document.getElementById('ballDropNewBtn').onclick=resetBallV168;document.getElementById('ballDropAim').oninput=()=>{if(!ballGameV168?.dropping)drawBallBoardV168();};
    document.getElementById('unownStartBtn').onclick=startUnownV168;document.querySelectorAll('[data-unown-difficulty]').forEach(b=>b.onclick=()=>setUnownDifficultyV168(b.dataset.unownDifficulty));
    document.querySelectorAll('[data-exit-game]').forEach(b=>b.addEventListener('click',()=>{stopBallV168();stopUnownV168();}));
    setUnownDifficultyV168('easy');
  }
  wireV168();
})();
