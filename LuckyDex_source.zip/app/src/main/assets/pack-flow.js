/* The single pack orchestration path. Existing v0.13 caches and the existing
   commitPreparedPack economy function remain the persistence authorities. */
let packRun=null;
let packEpoch=0;
const catalogJobs=new Map();
const validatedPackArt=new Map();

function packStageLoading(copy='Preparing artwork…') {
  const stage=document.getElementById('packStage');stage.hidden=false;document.body.classList.add('pack-opening');
  stage.innerHTML=`<button class="pack-exit" id="packExitBtn">‹ SHOP</button><div class="loading pack-loading"><div class="spinner"></div><b>${escapeHtml(copy)}</b></div>`;
  document.getElementById('packExitBtn').onclick=()=>closePackOpening();return stage;
}
function cancelPackRun() {
  packEpoch++;
  if(!packRun)return;
  packRun.reveal?.destroy();packRun.abort.abort();
  packRun.urls.forEach(url=>URL.revokeObjectURL(url));packRun.urls.clear();packRun=null;
}
function newPackRun() {
  cancelPackRun();
  return packRun={epoch:packEpoch,abort:new AbortController(),urls:new Set(),art:new Map(),reveal:null};
}
function validPackRun(run) {return run===packRun&&!run.abort.signal.aborted;}
function packDelay(ms,signal) {
  return new Promise(resolve=>{
    let timer=null;
    const finish=value=>{clearTimeout(timer);signal.removeEventListener('abort',abort);resolve(value);};
    const abort=()=>finish(false);
    if(signal.aborted){resolve(false);return;}
    signal.addEventListener('abort',abort,{once:true});timer=setTimeout(()=>finish(true),ms);
  });
}
async function packFetch(url,signal,timeout=4500) {
  if(!isOnlineV13())throw new Error('offline');
  const controller=new AbortController(),abort=()=>controller.abort();
  if(signal?.aborted)controller.abort();signal?.addEventListener('abort',abort,{once:true});
  const timer=setTimeout(abort,timeout);
  try{const response=await fetch(url,{signal:controller.signal});if(!response.ok)throw new Error(String(response.status));return await response.json();}
  finally{clearTimeout(timer);signal?.removeEventListener('abort',abort);}
}
function renderSetOptionsV13(source,sets) {
  const select=document.getElementById('setSelect');if(!select)return;
  const old=select.value, ordered=LuckyDexPack.orderSets((sets||[]).filter(s=>s.cardCount?.total>0));
  setCache[source]=ordered;
  if(document.getElementById('cardSource').value!==source)return;
  select.innerHTML=ordered.map(s=>`<option value="${escapeHtml(s.id)}">${escapeHtml((LuckyDexPack.dateValue(s.releaseDate)!==null?s.releaseDate+' · ':'')+s.name)} (${s.cardCount.total})</option>`).join('');
  if(ordered.some(s=>s.id===old))select.value=old;
  updatePackButton();updateOfflineHintV13();
}
async function loadSets(source) {
  const select=document.getElementById('setSelect');if(!select)return;
  const stored=readCatalogCacheV13()[source]?.sets||[];
  const cached=await LuckyDexPack.enrichSets(stored,{online:false,cached:id=>cachedSetV13(id,source)});
  if(cached.length)saveCatalogCacheV13(source,cached);
  if(cached.length)renderSetOptionsV13(source,cached);
  if(!isOnlineV13()){
    if(!cached.length && document.getElementById('cardSource').value===source)select.innerHTML='<option value="">Connect once to sync set list</option>';
    updatePackButton();return;
  }
  if(catalogJobs.has(source))return catalogJobs.get(source);
  const job=(async()=>{
    if(!cached.length&&document.getElementById('cardSource').value===source)select.innerHTML='<option value="">Syncing release dates…</option>';
    try{
      let sets;
      if(source==='tcgp')sets=(await packFetch(API.tcgSeries('tcgp'))).sets||[];
      else{
        const all=await packFetch(`${API.tcgSets}?sort:field=releaseDate&sort:order=DESC`);
        let pocket=setCache.tcgp;
        try{pocket=(await packFetch(API.tcgSeries('tcgp'))).sets||[];}catch(_){}
        const ids=new Set(pocket.map(s=>s.id));sets=(all||[]).filter(s=>!ids.has(s.id));
      }
      sets=sets.filter(s=>s.cardCount?.total>0);
      // Date metadata is small; cache it separately from full set/card payloads.
      const previous=new Map(cached.map(s=>[s.id,s]));
      const enriched=await LuckyDexPack.enrichSets(sets,{
        online:isOnlineV13(),cached:id=>{
          const full=cachedSetV13(id,source);return LuckyDexPack.dateValue(full?.releaseDate)!==null?full:previous.get(id);
        },
        detail:id=>packFetch(API.tcgSet(id)),
        persist:s=>{previous.set(s.id,s);saveCatalogCacheV13(source,LuckyDexPack.orderSets(sets.map(row=>previous.get(row.id)||row)));}
      });
      saveCatalogCacheV13(source,enriched);renderSetOptionsV13(source,enriched);
    }catch(_){if(!cached.length&&document.getElementById('cardSource').value===source)select.innerHTML='<option value="">Could not sync sets</option>';}
    finally{catalogJobs.delete(source);updatePackButton();}
  })();
  catalogJobs.set(source,job);return job;
}
async function packCachedBlob(id) {
  try{
    const db=await packDbV131();
    return await new Promise((resolve,reject)=>{const tx=db.transaction('images','readonly'),request=tx.objectStore('images').get(id);request.onsuccess=()=>resolve(request.result||null);request.onerror=()=>reject(request.error);});
  }catch(_){return null;}
}
async function packArtworkIsUsable(card,blob) {
  if(!blob?.size)return /^data:/i.test(card.image||'')?LuckyDexPack.decodeImage(card.image):false;
  let fingerprint=null;
  if(window.crypto?.subtle){
    const digest=await crypto.subtle.digest('SHA-256',await blob.arrayBuffer());
    fingerprint=Array.from(new Uint8Array(digest)).map(n=>n.toString(16).padStart(2,'0')).join('');
    const cached=validatedPackArt.get(card.id);if(cached?.fingerprint===fingerprint)return cached.usable;
  }
  const usable=(async()=>{const url=URL.createObjectURL(blob);try{return await LuckyDexPack.decodeImage(url);}finally{URL.revokeObjectURL(url);}})();
  if(fingerprint)validatedPackArt.set(card.id,{fingerprint,usable});return usable;
}
async function packNetworkBlob(card,run) {
  // Avoid the generic image onerror ladder: one bounded request chain, and none
  // at all when airplane mode is already known.
  let base=card.image||deriveCardBase(card,preparedPack?.set);
  if(!base&&isOnlineV13())base=await resolveCardArtwork(card,preparedPack?.set,preparedPack?.source,run.abort.signal);
  if(!base)return null;
  for(const url of [cardImage(base,'high','webp'),cardImage(base,'low','png')]){
    if(!validPackRun(run)||!isOnlineV13())return null;
    const controller=new AbortController(),abort=()=>controller.abort();run.abort.signal.addEventListener('abort',abort,{once:true});
    const timer=setTimeout(abort,2200);
    try{
      const response=await fetch(url,{signal:controller.signal});if(!response.ok)continue;
      const blob=await response.blob();if(blob.size){
        const probe=URL.createObjectURL(blob);
        const usable=await LuckyDexPack.decodeImage(probe,run.abort.signal);URL.revokeObjectURL(probe);
        if(!usable||!validPackRun(run))continue;
        await putOfflineImageV131(card.id,blob);updateOfflineHintV13();return blob;
      }
    }catch(_){}finally{clearTimeout(timer);run.abort.signal.removeEventListener('abort',abort);}
  }
  return null;
}
function preloadPackCard(card,run=packRun) {
  if(!run||!card)return Promise.resolve(null);
  if(run.art.has(card.id))return run.art.get(card.id);
  const promise=LuckyDexPack.resolveArtwork(card,{
    online:isOnlineV13(),signal:run.abort.signal,cached:packCachedBlob,
    network:c=>packNetworkBlob(c,run),
    decode:url=>LuckyDexPack.decodeImage(url,run.abort.signal),
    objectUrl:blob=>{const url=URL.createObjectURL(blob);run.urls.add(url);return url;},
    revoke:url=>{URL.revokeObjectURL(url);run.urls.delete(url);},placeholder:LuckyDexPack.placeholder(card.name)
  }).then(result=>{
    if(!validPackRun(run)){if(result.owned)URL.revokeObjectURL(result.url);return result;}
    card._packArtwork=result.url;return result;
  });
  run.art.set(card.id,promise);return promise;
}
async function preparePack() {
  if(packRun?.building)return;
  const setId=document.getElementById('setSelect').value,source=document.getElementById('cardSource').value;if(!setId)return;
  const entitlement=packEntitlement();if(entitlement.mode==='coins'&&state.profile.coins<entitlement.cost){showToast('Not enough Lucky Coins.');return;}
  const run=newPackRun();run.building=true;preparedPack=null;
  const stage=packStageLoading('Building your pack…'),btn=document.getElementById('openPackBtn');btn.disabled=true;
  try{
    let set=cachedSetV13(setId,source),cards,luckyPack=Math.random()<1/2000;
    if(!isOnlineV13()){
      if(!set)throw new Error('offline-set-missing');cards=await buildOfflinePackV13(set,source,luckyPack);
    }else{
      if(!set?.cards?.length)set=await packFetch(API.tcgSet(setId),run.abort.signal);
      if(!validPackRun(run))return;
      cacheSetV13(set,source);cards=await buildBalancedPack(set,source,luckyPack,run.abort.signal);
      if(!validPackRun(run))return;
      cacheCardsV13(cards,set,source);
    }
    if(!validPackRun(run))return;
    preparedPack={set,source,cards,luckyPack,revealed:new Set(),committed:false,entitlement,currentIndex:0};
    await Promise.all(cards.slice(0,2).map(c=>preloadPackCard(c,run)));
    if(!validPackRun(run))return;
    // Cache remaining art without delaying the sealed pack. The reveal always
    // awaits its own and the next image, or the immediately available placeholder.
    cards.slice(2).forEach(c=>preloadPackCard(c,run));
    renderSealedPack();
  }catch(error){
    if(!validPackRun(run))return;
    stage.innerHTML=`<button class="pack-exit" id="packExitBtn">‹ SHOP</button><div class="empty"><b>${isOnlineV13()?'PACK ERROR':'OFFLINE CACHE NEEDED'}</b><br>${isOnlineV13()?'Could not prepare this set. Please try again.':'Open this set online once to cache its cards and artwork.'}</div>`;
    document.getElementById('packExitBtn').onclick=()=>closePackOpening();
  }finally{if(validPackRun(run)){run.building=false;updatePackButton();updateOfflineHintV13();}}
}
async function tearPack() {
  const run=packRun,pack=preparedPack;if(!run||!pack||pack.tearing||pack.committed)return;
  pack.tearing=true;const sealed=document.getElementById('sealedPack');if(sealed){sealed.disabled=true;sealed.classList.add('tearing');}
  vibrate([14,18,24]);
  if(!await packDelay(620,run.abort.signal)||!validPackRun(run)||preparedPack!==pack)return;
  commitPreparedPack();pack.currentIndex=0;await renderPackCard();
}
async function renderPackCard() {
  const run=packRun,pack=preparedPack;if(!run||!pack)return;
  run.reveal?.destroy();run.reveal=null;
  const index=pack.currentIndex,card=pack.cards[index];
  const stage=packStageLoading();
  const [art]=await Promise.all([preloadPackCard(card,run),preloadPackCard(pack.cards[index+1],run)]);
  if(!validPackRun(run)||preparedPack!==pack||pack.currentIndex!==index)return;
  run.reveal=LuckyDexPack.mountReveal(stage,{
    card,artwork:art.url,index,count:pack.cards.length,setName:pack.set.name,haptic:packHaptic,
    onExit:()=>closePackOpening(),onNext:advancePackCard,onPrevious:previousPackCard,
    onFullScreen:()=>openCardModal({...card,image:art.url,_packArtwork:art.url}),
    onSettle:()=>pack.revealed.add(index)
  });
}
function advancePackCard() {
  if(!packRun?.reveal?.session.ready||!preparedPack)return;
  if(preparedPack.currentIndex>=preparedPack.cards.length-1)renderPackSummary();
  else{preparedPack.currentIndex++;renderPackCard();}
}
function previousPackCard() {
  if(!packRun?.reveal?.session.ready||!preparedPack||preparedPack.currentIndex<=0)return;
  preparedPack.currentIndex--;renderPackCard();
}
function renderPackSummary() {
  const pack=preparedPack;if(!pack)return;
  packRun?.reveal?.destroy();if(packRun)packRun.reveal=null;
  const stage=document.getElementById('packStage');stage.dataset.packPhase='summary';
  stage.innerHTML=`<button class="pack-exit" id="packExitBtn">‹ SHOP</button><div class="v13-summary"><div class="screen-title"><div><div class="eyebrow">PACK COMPLETE</div><h2>${escapeHtml(pack.set.name)}</h2></div><span class="pill">${pack.cards.length} cards</span></div><div class="v13-summary-grid">${pack.cards.map(c=>`<button class="v13-summary-card level-${LuckyDexPack.profileFor(c).level}" data-summary-card="${escapeHtml(c.id)}"><div class="card-art-wrap"><img src="${escapeHtml(c._packArtwork||LuckyDexPack.placeholder(c.name))}" alt="${escapeHtml(c.name)}"></div><b>${c._wasNew?'NEW · ':''}${escapeHtml(c.name)}</b><span>${escapeHtml(c.rarity||c._foil)}</span></button>`).join('')}</div><button class="primary full v13-back-shop" id="shopAnotherPackBtn">BACK TO PACK SHOP</button></div>`;
  document.getElementById('packExitBtn').onclick=document.getElementById('shopAnotherPackBtn').onclick=()=>closePackOpening();
  stage.querySelectorAll('[data-summary-card]').forEach(button=>button.onclick=()=>{const c=pack.cards.find(c=>c.id===button.dataset.summaryCard);openCardModal({...c,image:c._packArtwork});});
}
function closePackOpening(force=false) {
  const stage=document.getElementById('packStage');if(!stage)return;
  if(!force&&preparedPack&&!preparedPack.committed&&!preparedPack.debug&&document.getElementById('sealedPack')&&!confirm('Leave this unopened pack? Nothing has been spent yet.'))return;
  const dialog=document.getElementById('cardDialog');if(dialog?.open)dialog.close();
  cancelPackRun();preparedPack=null;stage.hidden=true;stage.innerHTML='';delete stage.dataset.packPhase;document.body.classList.remove('pack-opening');updatePackButton();
}
function packHaptic(pattern) {
  if(!state.settings.vibration)return;
  if(window.Android?.packHaptic)window.Android.packHaptic(JSON.stringify(pattern));
  else vibrate(pattern);
}
window.LuckyDexDebug=Object.assign(window.LuckyDexDebug||{}, {
  async playPackTier(tier='crown') {
    if(preparedPack&&!preparedPack.debug)throw new Error('Close the active pack before replaying a preview.');
    const rarities=['Common','Rare','Double Rare','One Star','Two Star','Crown'];
    const aliases={common:0,rare:1,holo:1,illustration:3,'one-star':3,'two-star':4,'three-star':4,high:4,crown:5,top:5};
    const value=typeof tier==='number'?rarities[Math.max(0,Math.min(5,Math.floor(tier)))]:rarities[aliases[String(tier).toLowerCase()]]||String(tier);
    const run=newPackRun(),card={id:'local-debug-card',name:'Lucky Dex Preview',rarity:value,image:LuckyDexPack.placeholder('Lucky Dex Preview')};
    preparedPack={set:{id:'local-preview',name:'Local preview'},source:'tcgp',cards:[card],currentIndex:0,debug:true,committed:true,revealed:new Set()};
    await preloadPackCard(card,run);await renderPackCard();
  }
});
