(function(root){
  'use strict';
  const core=root.LuckyDexFossilMuseumCore;
  let dig=null,selectedTool='pickaxe',haul=[],pendingCoins=0,finishing=false,bannerTimer=0,markupReady=false;
  const $=id=>typeof document!=='undefined'?document.getElementById(id):null;
  const bridge=()=>root.LuckyDexFossilMuseumBridge||null;
  const session=()=>root.LuckyDexArcadeSession||null;
  const MUSEUM_SLOTS={
    // Three original wall cabinets: Kanto fossils.
    'helix-fossil':{x:50,y:14,w:4.2},'dome-fossil':{x:61,y:14,w:4.2},'old-amber':{x:71,y:14,w:4.2},
    // Right-hand glass cases: Hoenn/Sinnoh, Unova/Kalos, then Galar.
    'root-fossil':{x:88,y:34,w:3.8},'claw-fossil':{x:92,y:34,w:3.8},'skull-fossil':{x:88,y:39,w:3.8},'armor-fossil':{x:92,y:39,w:3.8},
    'cover-fossil':{x:88,y:50,w:3.8},'plume-fossil':{x:92,y:50,w:3.8},'jaw-fossil':{x:88,y:55,w:3.8},'sail-fossil':{x:92,y:55,w:3.8},
    'fossilized-bird':{x:88,y:66,w:3.7},'fossilized-dino':{x:92,y:66,w:3.7},'fossilized-drake':{x:88,y:71,w:3.7},'fossilized-fish':{x:92,y:71,w:3.7},
    // Central coal display becomes the signature Odd Keystone pedestal.
    'odd-keystone':{x:39,y:48,w:6.5,prominent:true},
    // Two authentic cases added to the empty left floor for the Relic collection.
    'relic-copper':{x:12,y:37,w:3.8},'relic-silver':{x:17,y:37,w:3.8},'relic-gold':{x:12,y:43,w:3.8},'relic-vase':{x:17,y:43,w:3.8},
    'relic-band':{x:12,y:56,w:3.8},'relic-statue':{x:17,y:56,w:4.0},'relic-crown':{x:21,y:61,w:4.0},
    // Existing and added small cases hold the geology collection.
    'hard-stone':{x:66,y:50,w:3.6},'everstone':{x:70,y:53,w:3.6},
    'fire-stone':{x:66,y:66,w:3.6},'water-stone':{x:70,y:69,w:3.6},
    'thunder-stone':{x:46,y:31,w:3.5},'leaf-stone':{x:50,y:31,w:3.5},'moon-stone':{x:48,y:35,w:3.5}
  };
  function escText(v){return String(v??'');}
  function ensureDigMarkup(){
    if(typeof document==='undefined')return null;
    const host=$('fossilGame');if(!host)return null;
    if(!markupReady||!$('fossilGrid')){
      host.className='panel arcade-game fossil-game fossil-dig-v0250';
      host.innerHTML=`
        <div class="arcade-full-head"><button class="game-exit" data-exit-game>‹ OREBURGH MINING MUSEUM</button><div class="arcade-mascot"><img src="arcade/fossil-museum-v0250/items/odd-keystone.png" alt="" /><span>UNDERGROUND EXCAVATION</span></div></div>
        <div class="fossil-head-v0250">
          <div><div class="eyebrow">FOSSIL DIG</div><h2>Oreburgh dig wall</h2></div>
          <div class="fossil-stats-v0250"><span><small>WALL STABILITY</small><b id="fossilStability">100%</b></span><span><small>ITEMS FOUND</small><b id="fossilItemsFound">0/0</b></span></div>
        </div>
        <div class="fossil-wall-shell-v0250" id="fossilWallShell">
          <div class="fossil-wall-stage-v0250">
            <div class="fossil-find-layer-v0250" id="fossilFindLayer" aria-hidden="true"></div>
            <div class="fossil-grid-v0250" id="fossilGrid" aria-label="12 by 9 excavation wall"></div>
            <div class="fossil-find-banner-v0250" id="fossilFindBanner" hidden></div>
          </div>
        </div>
        <div class="fossil-tools-v0250" role="group" aria-label="Excavation tool">
          <button type="button" id="fossilToolPickaxe" data-fossil-tool="pickaxe" class="active"><span class="fossil-tool-icon-v0250">⛏</span><b>PICKAXE</b><small>Precise · −3 stability</small></button>
          <button type="button" id="fossilToolHammer" data-fossil-tool="hammer"><span class="fossil-tool-icon-v0250">🔨</span><b>HAMMER</b><small>3×3 strike · −8 stability</small></button>
        </div>
        <div class="fossil-dig-actions-v0251"><button type="button" id="fossilEndDig">END DIG</button></div>
        <div class="fossil-end-confirm-v0251" id="fossilEndConfirm" hidden role="dialog" aria-modal="false" aria-labelledby="fossilEndConfirmTitle">
          <b id="fossilEndConfirmTitle">Finish this excavation?</b>
          <span>Only fully uncovered finds will be collected.</span>
          <div><button type="button" id="fossilKeepDigging">KEEP DIGGING</button><button type="button" id="fossilEndCollect">END & COLLECT</button></div>
        </div>`;
      host.querySelectorAll('[data-fossil-tool]').forEach(btn=>btn.addEventListener('click',()=>selectTool(btn.dataset.fossilTool)));
      $('fossilGrid')?.addEventListener('click',e=>{const cell=e.target.closest('[data-fossil-cell]');if(cell)strikeCell(Number(cell.dataset.fossilCell));});
      $('fossilEndDig')?.addEventListener('click',()=>showEndConfirm(true));
      $('fossilKeepDigging')?.addEventListener('click',()=>showEndConfirm(false));
      $('fossilEndCollect')?.addEventListener('click',()=>{showEndConfirm(false);finishDig('manual');});
      markupReady=true;
    }
    session()?.mount?.('fossil',host);
    session()?.ensureStrip?.('fossil',host);
    return host;
  }
  function spriteFor(find,item){return find?.card?.image||item?.sprite||'';}
  function renderFinds(){
    const layer=$('fossilFindLayer');if(!layer||!dig)return;
    layer.replaceChildren();
    for(const find of dig.finds){
      const item=core.byId(find.itemId);if(!item)continue;
      const rows=find.cells.map(i=>Math.floor(i/dig.cols)),cols=find.cells.map(i=>i%dig.cols);
      const minR=Math.min(...rows),maxR=Math.max(...rows),minC=Math.min(...cols),maxC=Math.max(...cols);
      const img=document.createElement('img');img.className='fossil-find-v0250';img.alt='';img.draggable=false;
      img.src=spriteFor(find,item);img.style.left=`${minC/dig.cols*100}%`;img.style.top=`${minR/dig.rows*100}%`;img.style.width=`${(maxC-minC+1)/dig.cols*100}%`;img.style.height=`${(maxR-minR+1)/dig.rows*100}%`;
      layer.appendChild(img);
    }
  }
  function renderGrid(){
    const grid=$('fossilGrid');if(!grid||!dig)return;
    const frag=document.createDocumentFragment();
    for(let i=0;i<dig.depths.length;i++){
      const btn=document.createElement('button');btn.type='button';btn.className='fossil-cell-v0250';btn.dataset.fossilCell=String(i);btn.dataset.depth=String(dig.depths[i]);btn.setAttribute('aria-label',`Rock ${i+1}, depth ${dig.depths[i]}`);btn.disabled=!!dig.finished;frag.appendChild(btn);
    }
    grid.replaceChildren(frag);
  }
  function renderStatus(){
    if(!dig)return;
    if($('fossilStability'))$('fossilStability').textContent=`${Math.max(0,dig.stability)}%`;
    if($('fossilItemsFound'))$('fossilItemsFound').textContent=`${dig.awardedFindIds.length}/${dig.finds.length}`;
    $('fossilToolPickaxe')?.classList.toggle('active',selectedTool==='pickaxe');
    $('fossilToolHammer')?.classList.toggle('active',selectedTool==='hammer');
    session()?.update?.('fossil',{runText:`Wall stability ${dig.stability}%`,rewardText:`${dig.awardedFindIds.length}/${dig.finds.length} recovered`,liveLabel:'TOOL',liveValue:selectedTool.toUpperCase()});
  }
  function renderDig(){renderFinds();renderGrid();renderStatus();}
  function showFindBanner(title,subtitle=''){
    const banner=$('fossilFindBanner');if(!banner)return;
    clearTimeout(bannerTimer);banner.replaceChildren();const b=document.createElement('b');b.textContent=title;banner.appendChild(b);if(subtitle){const s=document.createElement('span');s.textContent=subtitle;banner.appendChild(s);}banner.hidden=false;banner.classList.remove('show');void banner.offsetWidth;banner.classList.add('show');bannerTimer=setTimeout(()=>{banner.hidden=true;banner.classList.remove('show');},1500);
  }
  async function hydrateCardFinds(site){
    const b=bridge();if(!site||!b)return;
    for(const find of site.finds.filter(f=>f.itemId==='tcg-card')){
      let resolved=null;try{resolved=await b.resolveBuriedCard?.();}catch(_){resolved=null;}
      if(resolved?.card){find.card=resolved.card;find.set=resolved.set||{};continue;}
      const fallback=core.byId(Math.random()<.5?'star-piece':'nugget');find.itemId=fallback.id;
    }
  }
  async function startDig(){
    ensureDigMarkup();session()?.hideResult?.();showEndConfirm(false);finishing=false;haul=[];pendingCoins=0;selectedTool='pickaxe';
    dig=core.generateDigSite();await hydrateCardFinds(dig);renderDig();return dig;
  }
  function showEndConfirm(show){const box=$('fossilEndConfirm');if(!box)return false;box.hidden=!show;if(show)bridge()?.vibrate?.(6);return true;}
  function selectTool(toolId){if(!core.TOOL_RULES[toolId])return false;selectedTool=toolId;renderStatus();bridge()?.vibrate?.(toolId==='hammer'?12:5);return true;}
  function addHaul(title,subtitle,kind){haul.push({title:escText(title),subtitle:escText(subtitle),kind:escText(kind||'find')});}
  function routeRecoveredFind(find){
    const item=core.byId(find.itemId),b=bridge();if(!item||!b)return;
    if(item.rewardDestination==='museum'){
      const arcade=b.getState?.()?.arcade||{};const museum=core.ensureMuseumState(arcade);const rec=core.recordMuseumFind(museum,item,Date.now());
      if(rec.isNew){addHaul(item.name,'New museum exhibit','museum');showFindBanner(item.name,'NEW MUSEUM EXHIBIT');}
      else{pendingCoins+=rec.duplicateCoins;addHaul(item.name,`Duplicate sold · +${rec.duplicateCoins} coins`,'coins');showFindBanner(item.name,`DUPLICATE · +${rec.duplicateCoins}`);}
      b.save?.();return;
    }
    if(item.rewardDestination==='coins'){
      pendingCoins+=Math.max(0,Number(item.duplicateCoins)||0);addHaul(item.name,`Sold · +${item.duplicateCoins} coins`,'coins');showFindBanner(item.name,`+${item.duplicateCoins} COINS`);return;
    }
    if(item.rewardDestination==='inventory'){
      const granted=b.grantInventory?.(item.inventoryKey,item.amount||1)||0;addHaul(item.name,granted?'Added to Adventure inventory':'Inventory unchanged','inventory');showFindBanner(item.name,granted?'ADDED TO INVENTORY':'FOUND');return;
    }
    if(item.rewardDestination==='card'&&find.card){
      const row=b.grantCard?.(find.card,find.set||{});const name=row?.name||find.card.name||'Buried TCG Card';addHaul(name,'Added to Card Collection','card');showFindBanner(name,'BURIED CARD FOUND');
    }
  }
  function strikeCell(index){
    if(!dig||dig.finished||finishing)return false;
    const result=core.strike(dig,index,selectedTool);if(!result.changedIndices.length&&!result.recoveredIds.length)return false;
    bridge()?.vibrate?.(selectedTool==='hammer'?[18,10,18]:8);
    for(const id of result.recoveredIds){const find=dig.finds.find(f=>f.id===id);if(find)routeRecoveredFind(find);}
    renderDig();
    if(result.collapsed)finishDig('collapse');else if(result.allRecovered)finishDig('complete');
    return true;
  }
  function finishDig(reason='complete'){
    if(!dig||finishing||dig.resultShown)return false;finishing=true;dig.resultShown=true;dig.finished=true;
    let awarded=0;if(pendingCoins>0)awarded=bridge()?.grantCoins?.(pendingCoins,'Fossil Dig')||pendingCoins;
    const collapsed=reason==='collapse'||dig.collapsed,manual=reason==='manual';showEndConfirm(false);
    session()?.showResult?.('fossil',{title:collapsed?'WALL COLLAPSED':manual?'DIG ENDED':'DIG COMPLETE',metricLabel:'FINDS',metricValue:`${haul.length}/${dig.finds.length}`,coinsAwarded:awarded,details:haul,bestText:collapsed||manual?'Only fully excavated finds were recovered.':'SITE CLEARED',replayLabel:'DIG AGAIN',onReplay:()=>startDig(),onBack:()=>root.LuckyDexArcadeWorld?.backFromGame?.()});
    renderStatus();return true;
  }
  function openPlaque(item,record){
    const plaque=$('museumPlaque');if(!plaque)return false;
    $('museumPlaqueName').textContent=item.name.toUpperCase();$('museumPlaqueFlavour').textContent=item.flavour||'A recovered piece of Pokémon-world history.';$('museumPlaqueCount').textContent=`Excavated: ${Math.max(1,Number(record?.foundCount)||1)}`;plaque.hidden=false;return true;
  }
  function renderMuseum(){
    if(typeof document==='undefined')return false;const layer=$('museumExhibitLayer');if(!layer)return false;layer.replaceChildren();
    const state=bridge()?.getState?.(),museum=core.ensureMuseumState(state?.arcade||{});let count=0;
    for(const [id,slot] of Object.entries(MUSEUM_SLOTS)){
      const record=museum.exhibits?.[id];if(!record?.discovered)continue;const item=core.byId(id);if(!item?.museumEligible)continue;count++;
      const btn=document.createElement('button');btn.type='button';btn.className='museum-exhibit-v0250';if(slot.prominent)btn.classList.add('prominent');btn.dataset.museumId=id;btn.style.left=`${slot.x}%`;btn.style.top=`${slot.y}%`;btn.style.width=`${slot.w}%`;btn.setAttribute('aria-label',`${item.name}, excavated ${record.foundCount||1}`);
      const img=document.createElement('img');img.src=item.sprite;img.alt='';img.draggable=false;btn.appendChild(img);btn.addEventListener('click',()=>openPlaque(item,record));layer.appendChild(btn);
    }
    if($('museumExhibitCount'))$('museumExhibitCount').textContent=`${count} EXHIBIT${count===1?'':'S'}`;return count;
  }
  function wireMuseum(){
    const close=$('museumPlaqueClose');if(close&&!close.dataset.wired){close.dataset.wired='1';close.addEventListener('click',()=>{$('museumPlaque').hidden=true;});}
  }
  function open(activityId){
    if(activityId==='museum'){const host=$('museumGame');if(!host)return false;ensureDigMarkup();$('fossilGame').hidden=true;host.hidden=false;wireMuseum();if($('museumPlaque'))$('museumPlaque').hidden=true;renderMuseum();return true;}
    if(activityId!=='fossil')return false;const host=ensureDigMarkup();if(!host)return false;if($('museumGame'))$('museumGame').hidden=true;host.hidden=false;startDig();return true;
  }
  function close(activityId){
    clearTimeout(bannerTimer);if(!activityId||activityId==='fossil'){const host=$('fossilGame');if(host)host.hidden=true;dig=null;finishing=false;}
    if(!activityId||activityId==='museum'){const museum=$('museumGame');if(museum)museum.hidden=true;if($('museumPlaque'))$('museumPlaque').hidden=true;}
    return true;
  }
  const api={MUSEUM_SLOTS,open,close,startDig,selectTool,strikeCell,finishDig,showEndConfirm,renderMuseum,currentDig:()=>dig};
  root.LuckyDexFossilMuseum=api;
  if(typeof module!=='undefined'&&module.exports)module.exports=api;
  if(typeof document!=='undefined')ensureDigMarkup();
})(typeof window!=='undefined'?window:globalThis);
