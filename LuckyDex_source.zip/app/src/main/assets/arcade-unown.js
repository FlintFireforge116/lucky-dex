/* Authoritative Unown Decoder owner. */
(()=>{'use strict';
let unownGameV168=null,unownTimerV168=null,unownDifficultyV168='easy';
const timeouts=new Set();
const setTimeout=(fn,ms)=>{const id=window.setTimeout(()=>{timeouts.delete(id);fn();},ms);timeouts.add(id);return id;};
const shuffleV168=arr=>[...arr].sort(()=>Math.random()-.5);
  const UNOWN_WORDS_V168 = [
    {answer:'PIKACHU',letters:'PIKACHU',clue:'Electric mascot'},{answer:'EEVEE',letters:'EEVEE',clue:'Evolution Pokémon'},
    {answer:'MEWTWO',letters:'MEWTWO',clue:'Legendary experiment'},{answer:'GENGAR',letters:'GENGAR',clue:'Shadow Pokémon'},
    {answer:'SNORLAX',letters:'SNORLAX',clue:'Sleeping giant'},{answer:'LUCARIO',letters:'LUCARIO',clue:'Aura Pokémon'},
    {answer:'CELEBI',letters:'CELEBI',clue:'Time-travelling mythical'},{answer:'LUGIA',letters:'LUGIA',clue:'Guardian of the seas'},
    {answer:'HO-OH',letters:'HOOH',clue:'Rainbow legendary'},{answer:'KANTO',letters:'KANTO',clue:'Region'},
    {answer:'JOHTO',letters:'JOHTO',clue:'Region'},{answer:'HOENN',letters:'HOENN',clue:'Region'},{answer:'SINNOH',letters:'SINNOH',clue:'Region'},
    {answer:'UNOVA',letters:'UNOVA',clue:'Region'},{answer:'KALOS',letters:'KALOS',clue:'Region'},{answer:'ALOLA',letters:'ALOLA',clue:'Region'},
    {answer:'GALAR',letters:'GALAR',clue:'Region'},{answer:'PALDEA',letters:'PALDEA',clue:'Region'},{answer:'BERRY',letters:'BERRY',clue:'Adventure item'},
    {answer:'POTION',letters:'POTION',clue:'Healing item'},{answer:'POKÉDEX',letters:'POKEDEX',clue:'Professor research tool'},
    {answer:'MASTER BALL',letters:'MASTER BALL',clue:'Ultimate Pokéball'},{answer:'CHARIZARD',letters:'CHARIZARD',clue:'Fire/Flying favourite'},
    {answer:'DRAGONITE',letters:'DRAGONITE',clue:'Original pseudo-legendary'}
  ];
  function stopUnownV168(){if(unownTimerV168){clearInterval(unownTimerV168);unownTimerV168=null;}if(unownGameV168){unownGameV168.active=false;unownGameV168.token++;}for(const id of timeouts)window.clearTimeout(id);timeouts.clear();}
  function unownImgV168(ch){return `arcade/sprites/actors/unown/${ch.toLowerCase()}.png`;}
  function renderUnownGlyphsV168(entry){
    const host=document.getElementById('unownGlyphs');host.innerHTML='';
    const words=entry.letters.split(' ');
    for(const word of words){
      const line=document.createElement('div');line.className='unown-word';line.style.setProperty('--unown-count',String(word.length));
      line.innerHTML=[...word].map((ch,i)=>`<div class="unown-glyph" style="--unown-rot:${(i%3-1)*2}deg"><img src="${unownImgV168(ch)}" alt="Unown glyph"><span>${ch}</span></div>`).join('');
      host.appendChild(line);
    }
  }
  function setUnownDifficultyV168(mode){
    if(unownGameV168?.active)return;unownDifficultyV168=mode==='hard'?'hard':'easy';
    document.querySelectorAll('[data-unown-difficulty]').forEach(b=>b.classList.toggle('active',b.dataset.unownDifficulty===unownDifficultyV168));
    const clue=document.getElementById('unownClue');if(clue)clue.textContent=unownDifficultyV168==='easy'?'Hints on · 14 seconds · 4 choices':'Hints off · 8 seconds · 6 choices';
  }
  function resetUnownV168(){
    stopUnownV168();unownGameV168={round:0,score:0,correct:0,active:false,used:new Set(),token:1,current:null,mode:unownDifficultyV168};
    document.getElementById('unownRound').textContent='0';document.getElementById('unownScore').textContent='0';document.getElementById('unownGlyphs').innerHTML='';document.getElementById('unownAnswers').innerHTML='';document.getElementById('unownTimerFill').style.width='0%';
    document.getElementById('unownStartBtn').hidden=false;setUnownDifficultyV168(unownDifficultyV168);renderUnownGlyphsV168({letters:'UNOWN'});
  }
  function startUnownV168(){resetUnownV168();unownGameV168.active=true;unownGameV168.mode=unownDifficultyV168;document.getElementById('unownStartBtn').hidden=true;nextUnownV168();}
  function nextUnownV168(){
    const g=unownGameV168;if(!g?.active)return;if(g.round>=5){finishUnownV168();return;}
    const pool=UNOWN_WORDS_V168.filter(x=>!g.used.has(x.answer)),entry=pool[Math.floor(Math.random()*pool.length)];g.used.add(entry.answer);g.round++;
    const hard=g.mode==='hard',duration=hard?8000:14000,optionCount=hard?6:4;g.current={entry,answered:false,started:performance.now(),duration};
    document.getElementById('unownRound').textContent=g.round;document.getElementById('unownClue').textContent=hard?'HINTS OFF · decode the glyphs':`CLUE · ${entry.clue}`;renderUnownGlyphsV168(entry);
    const distract=shuffleV168(UNOWN_WORDS_V168.filter(x=>x.answer!==entry.answer)).slice(0,optionCount-1),opts=shuffleV168([entry,...distract]),box=document.getElementById('unownAnswers');
    box.innerHTML=opts.map(x=>`<button data-unown-v168="${escapeHtml(x.answer)}">${escapeHtml(x.answer)}</button>`).join('');box.querySelectorAll('[data-unown-v168]').forEach(b=>b.onclick=()=>answerUnownV168(b.dataset.unownV168));
    const token=g.token,fill=document.getElementById('unownTimerFill');fill.style.width='100%';if(unownTimerV168)clearInterval(unownTimerV168);unownTimerV168=setInterval(()=>{if(!unownGameV168||token!==unownGameV168.token||g.current?.answered){clearInterval(unownTimerV168);unownTimerV168=null;return;}const rem=Math.max(0,1-(performance.now()-g.current.started)/duration);fill.style.width=`${rem*100}%`;if(rem<=0)answerUnownV168('');},80);
  }
  function answerUnownV168(answer){
    const g=unownGameV168,q=g?.current;if(!g||!q||q.answered)return;q.answered=true;if(unownTimerV168){clearInterval(unownTimerV168);unownTimerV168=null;}
    const ok=answer===q.entry.answer,rem=Math.max(0,1-(performance.now()-q.started)/q.duration);document.querySelectorAll('[data-unown-v168]').forEach(b=>{b.disabled=true;if(b.dataset.unownV168===q.entry.answer)b.classList.add('correct');else if(b.dataset.unownV168===answer)b.classList.add('wrong');});
    if(ok){g.correct++;const mult=g.mode==='hard'?1.55:1;g.score+=Math.round((180+q.entry.letters.replace(/\s/g,'').length*18+rem*180)*mult);vibrate([9,12,18]);document.getElementById('unownClue').textContent=`DECODED · ${q.entry.answer}`;}else{vibrate(20);document.getElementById('unownClue').textContent=`The message was ${q.entry.answer}.`;}
    document.getElementById('unownScore').textContent=fmt(g.score);document.getElementById('unownTimerFill').style.width='0%';setTimeout(()=>{if(unownGameV168===g&&g.active)nextUnownV168();},850);
  }
  function finishUnownV168(){
    const g=unownGameV168;if(!g?.active)return;g.active=false;const payout=Math.max(100,Math.round(g.score*(g.mode==='hard'?.66:.58)+g.correct*40));state.arcade.bestUnown=Math.max(Number(state.arcade.bestUnown||0),g.score);if(g.correct===5)state.arcade.unownPerfect=1;save();const awarded=window.LuckyDexArcadePlatform?.awardRun?.({gameId:'unown',label:'Unown Decoder',score:g.score,coins:payout,dailyEligible:false,dailyReward:null})?.coinsAwarded??payout;window.LuckyDexArcadeSession?.showResult?.('unown',{title:g.correct===5?'RUINS MASTERED!':`${g.correct}/5 DECODED`,metricLabel:'SCORE',metricValue:`${fmt(g.score)} · ${g.mode.toUpperCase()}`,coinsAwarded:awarded,itemAwarded:null,bestText:g.correct===5?'PERFECT DECODE':'',onReplay:resetUnownV168,onBack:()=>window.LuckyDexArcadeWorld?.backFromGame?.(true)});
  }


document.getElementById('unownStartBtn').onclick=startUnownV168;document.querySelectorAll('[data-unown-difficulty]').forEach(b=>b.onclick=()=>setUnownDifficultyV168(b.dataset.unownDifficulty));window.LuckyDexUnown={open:resetUnownV168,close:stopUnownV168,start:startUnownV168};
})();
