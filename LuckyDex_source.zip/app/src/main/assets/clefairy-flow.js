/* Authoritative memory-game orchestration. Reward formulas are unchanged;
   every asynchronous cue belongs to one cancellable game/playback run. */
const clefairyScene=LuckyDexClefairy.mount(document.getElementById('clefairyStage'));
const CLEFAIRY_ACTIONS=['star','song','moon','spin'];
let clefairyGameRun=null,clefairyPlayback=null,clefairyResetTimer=0,clefairyResumeSequence=null;
function stopClefairyGame(){
  clefairyGameRun?.abort();clefairyPlayback?.abort();clefairyGameRun=clefairyPlayback=null;
  clefairyResumeSequence=null;
  clearTimeout(clefairyResetTimer);clefairyResetTimer=0;clefairyScene.suspend();
}
function resetMemoryGame(){
  stopClefairyGame();clefairyGameRun=new AbortController();
  memoryGame={sequence:[],round:0,bank:0,input:0,accepting:false,perkUsed:false};
  document.getElementById('clefairyRound').textContent='0';document.getElementById('clefairyBank').textContent='0';
  document.getElementById('memoryDisplay').textContent='Tap START and watch the sequence.';
  document.getElementById('memoryStartBtn').textContent='START';document.getElementById('memoryStartBtn').disabled=false;
  document.getElementById('memoryCashBtn').disabled=true;document.getElementById('memorySequenceTrack').innerHTML='';
  if(!document.getElementById('clefairyGame').hidden)clefairyScene.resume();
  renderArcadePerkButtons();
}
function clefairyDelay(ms,signal){return new Promise(resolve=>{
  if(signal.aborted){resolve(false);return;}
  const done=ok=>{clearTimeout(timer);signal.removeEventListener('abort',cancel);resolve(ok);},cancel=()=>done(false);
  const timer=setTimeout(()=>done(true),ms);signal.addEventListener('abort',cancel,{once:true});
});}
function playClefairyAction(n){return clefairyScene.play(CLEFAIRY_ACTIONS[n]||'idle');}
async function flashMemorySequence(){
  if(!memoryGame||clefairyPlayback)return false;
  const game=memoryGame,run=clefairyGameRun;if(!run||run.signal.aborted)return false;
  const playback=new AbortController();clefairyPlayback=playback;
  const abort=()=>{playback.abort();clefairyScene.reset();};run.signal.addEventListener('abort',abort,{once:true});
  const track=document.getElementById('memorySequenceTrack');track.innerHTML='';
  try{
    for(const n of [...game.sequence]){
      if(run.signal.aborted||playback.signal.aborted||memoryGame!==game)return false;
      track.insertAdjacentHTML('beforeend',`<i data-action="${CLEFAIRY_ACTIONS[n]}">${MEMORY_SYMBOLS_V5[n]}</i>`);
      vibrate(8);if(!await playClefairyAction(n))return false;
      if(!await clefairyDelay(220,playback.signal))return false;
    }return memoryGame===game&&!run.signal.aborted;
  }finally{
    run.signal.removeEventListener('abort',abort);if(clefairyPlayback===playback)clefairyPlayback=null;
  }
}
async function nextMemoryRound(){
  if(!memoryGame||clefairyPlayback||document.getElementById('memoryStartBtn').disabled)return;
  const game=memoryGame,run=clefairyGameRun;
  game.round++;game.sequence.push(Math.floor(Math.random()*4));game.input=0;game.accepting=false;
  document.getElementById('clefairyRound').textContent=game.round;
  document.getElementById('memoryStartBtn').disabled=true;document.getElementById('memoryCashBtn').disabled=true;
  document.getElementById('memoryDisplay').textContent='Watch Clefairy…';
  if(!await flashMemorySequence()||run?.signal.aborted||memoryGame!==game)return;
  game.accepting=true;document.getElementById('memoryDisplay').textContent='Your turn — copy the symbols.';
  document.getElementById('memorySequenceTrack').innerHTML='';
}
async function replayMemory(){
  if(!memoryGame?.accepting||memoryGame.perkUsed||!memoryGame.sequence.length||clefairyPlayback)return;
  const game=memoryGame,run=clefairyGameRun;game.perkUsed=true;game.accepting=false;
  if(!await flashMemorySequence()||run?.signal.aborted||memoryGame!==game)return;
  game.input=0;game.accepting=true;document.getElementById('memoryDisplay').textContent='Second Sight replayed the sequence.';renderArcadePerkButtons();
}
function memoryTap(n){
  if(!memoryGame?.accepting||!Number.isInteger(n)||n<0||n>3)return;
  const game=memoryGame;playClefairyAction(n);
  const track=document.getElementById('memorySequenceTrack');
  if(n!==game.sequence[game.input]){
    game.accepting=false;track.insertAdjacentHTML('beforeend',`<i data-action="${CLEFAIRY_ACTIONS[n]}" class="current">❌</i>`);
    const consolation=Math.round(game.bank*.2);
    document.getElementById('memoryDisplay').textContent=`Miss! ${consolation?`Consolation ${consolation} coins.`:'Bank lost.'}`;
    const awarded=consolation?awardArcadeCoins(consolation,'Clefairy consolation','clefairy'):0;
    state.arcade.bestMemory=Math.max(state.arcade.bestMemory,game.round-1);save();
    clefairyResetTimer=setTimeout(()=>{if(memoryGame!==game||clefairyGameRun?.signal.aborted)return;window.LuckyDexArcadeSession?.showResult?.('clefairy',{title:'SEQUENCE BROKEN',metricLabel:'ROUND',metricValue:String(Math.max(0,game.round-1)),coinsAwarded:awarded,itemAwarded:null,bestText:'',onReplay:resetMemoryGame,onBack:()=>window.LuckyDexArcadeWorld?.backFromGame?.(true)});},LuckyDexClefairy.durationFor(CLEFAIRY_ACTIONS[n])+150);return;
  }
  game.input++;track.querySelectorAll('.current').forEach(i=>i.classList.remove('current'));
  track.insertAdjacentHTML('beforeend',`<i class="copied current" data-action="${CLEFAIRY_ACTIONS[n]}">${MEMORY_SYMBOLS_V5[n]}</i>`);
  if(game.input===game.sequence.length){
    game.accepting=false;game.bank+=50+game.round*30;
    document.getElementById('clefairyBank').textContent=fmt(game.bank);
    document.getElementById('memoryDisplay').textContent='Matched! Cash out or push another round.';
    document.getElementById('memoryCashBtn').disabled=false;document.getElementById('memoryStartBtn').disabled=false;
    document.getElementById('memoryStartBtn').textContent='NEXT ROUND';
  }
}
window.LuckyDexDebug=Object.assign(window.LuckyDexDebug||{},{playClefairyAction(action='idle'){
  if(!['idle',...CLEFAIRY_ACTIONS].includes(action)||clefairyPlayback)return Promise.resolve(false);
  return clefairyScene.play(action);
}});
document.addEventListener('visibilitychange',async()=>{
  if(document.hidden){
    if(clefairyPlayback){clefairyResumeSequence=memoryGame;clefairyPlayback.abort();clefairyPlayback=null;}
    clefairyScene.suspend();
  }else if(!document.getElementById('clefairyGame').hidden){
    clefairyScene.resume();const game=clefairyResumeSequence;clefairyResumeSequence=null;
    if(game&&memoryGame===game&&await flashMemorySequence()&&memoryGame===game&&!document.hidden){
      game.input=0;game.accepting=true;document.getElementById('memorySequenceTrack').innerHTML='';
      document.getElementById('memoryDisplay').textContent='Your turn — copy the symbols.';
    }
  }
});
