(function(root){
  'use strict';

  const platform=()=>root.LuckyDexArcadePlatform||globalThis.LuckyDexArcadePlatform;
  const session=()=>root.LuckyDexArcadeSession||globalThis.LuckyDexArcadeSession;
  const legacy=()=>root.LuckyDexAmie||globalThis.LuckyDexAmie;
  const BERRIES=[
    {id:'cheri',name:'Cheri',image:'https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/cheri-berry.png'},
    {id:'chesto',name:'Chesto',image:'https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/chesto-berry.png'},
    {id:'pecha',name:'Pecha',image:'https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/pecha-berry.png'},
    {id:'rawst',name:'Rawst',image:'https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/rawst-berry.png'},
    {id:'aspear',name:'Aspear',image:'https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/aspear-berry.png'},
    {id:'leppa',name:'Leppa',image:'https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/leppa-berry.png'},
    {id:'oran',name:'Oran',image:'https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/oran-berry.png'}
  ];
  const BERRY_CONFIGS={
    easy:{customers:2,berryCount:3,durationMs:45000,patienceMs:7500,dailyTarget:8,coinCap:70},
    normal:{customers:3,berryCount:5,durationMs:50000,patienceMs:6000,dailyTarget:14,coinCap:100},
    hard:{customers:4,berryCount:7,durationMs:55000,patienceMs:4500,dailyTarget:20,coinCap:140}
  };
  const HEAD_RUN_CONFIGS={
    easy:{lanes:2,balls:12,fallStartMs:1500,fallFloorMs:900,fallStepMs:50,coinCap:70,dailyTarget:1200},
    normal:{lanes:3,balls:18,fallStartMs:1250,fallFloorMs:650,fallStepMs:35,coinCap:100,dailyTarget:2000},
    hard:{lanes:4,balls:24,fallStartMs:1000,fallFloorMs:480,fallStepMs:25,coinCap:140,dailyTarget:2800},
    unlimited:{lanes:3,balls:null,fallStartMs:1150,fallFloorMs:420,fallStepMs:20,missLimit:3,coinCap:150,dailyTarget:3200,dailyStreak:20}
  };
  const TILE_CONFIGS={
    easy:{size:3,shuffleMoves:80,qualifySec:90,base:20,timeBonus:20,moveBonus:20,coinCap:60},
    normal:{size:4,shuffleMoves:160,qualifySec:180,base:35,timeBonus:30,moveBonus:25,coinCap:90},
    hard:{size:5,shuffleMoves:260,qualifySec:300,base:50,timeBonus:40,moveBonus:40,coinCap:130}
  };
  let currentGame=null,berryMode='easy',berryRun=null,berryTimer=null,selectedBerry=null,dragBerry=null,dragGhost=null;
  let headMode='easy',headRun=null,headRaf=null,headSpawnTimer=null,headBallSeq=0;
  let tileMode='easy',tileRun=null,tileTimer=null,tilePointer=null,tileSuppressClick=false;

  function clamp(n,a,b){return Math.max(a,Math.min(b,n));}
  function el(id){return typeof document!=='undefined'?document.getElementById(id):null;}
  function setText(id,v){const n=el(id);if(n)n.textContent=String(v);}
  function safeParticipants(limit){const p=platform();return p?.caughtParticipants?.(limit,[25,133,175,183])||[25,133,175,183].slice(0,limit).map(id=>({id,name:`Pokémon ${id}`,image:`https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/${id}.png`,shiny:false}));}
  function berryDeliveryScore(combo,remainingPatienceFraction){return 100+Math.min(Math.max(0,Number(combo)||0),10)*10+Math.round(50*clamp(Number(remainingPatienceFraction)||0,0,1));}
  function berryPayout(score,mode){const cfg=BERRY_CONFIGS[mode]||BERRY_CONFIGS.easy;return clamp(Math.round((Number(score)||0)/20),20,cfg.coinCap);}
  function berryReward(mode){return {key:'berry',amount:mode==='hard'?4:mode==='normal'?3:2};}
  function berryById(id){return BERRIES.find(x=>x.id===id)||BERRIES[0];}
  function randomBerry(pool){return pool[Math.floor(Math.random()*pool.length)];}
  function berrySceneModel(mode='easy'){
    const config=BERRY_CONFIGS[mode]||BERRY_CONFIGS.easy,pool=BERRIES.slice(0,config.berryCount),participants=safeParticipants(config.customers);
    return {mode,config,pool,customers:participants.map((participant,index)=>({index,participant,reaction:'idle',request:{berryId:randomBerry(pool).id,patienceMs:config.patienceMs}}))};
  }
  function clearBerryTimers(){if(berryTimer){clearInterval(berryTimer);berryTimer=null;}}
  function clearDragGhost(){if(dragGhost){dragGhost.remove();dragGhost=null;}dragBerry=null;}
  function stopBerryRun(){clearBerryTimers();clearDragGhost();if(berryRun)berryRun.running=false;}
  function newCustomerRequest(index){if(!berryRun)return;const b=randomBerry(berryRun.pool),now=Date.now();berryRun.requests[index]={berryId:b.id,startedAt:now,expiresAt:now+berryRun.config.patienceMs};berryRun.reactions[index]='idle';}
  function renderBerryCustomers(){
    const host=el('berryPickerCustomers');if(!host||!berryRun)return;const now=Date.now();
    host.innerHTML=berryRun.participants.map((p,i)=>{const req=berryRun.requests[i],b=berryById(req?.berryId),remain=clamp((Number(req?.expiresAt||now)-now)/berryRun.config.patienceMs,0,1),reaction=berryRun.reactions[i]||'idle';return `<button type="button" class="amie-customer ${reaction}" data-berry-customer="${i}"><span class="thought-bubble"><img src="${b.image}" alt="${b.name} Berry"><b>${b.name}</b><i class="thought-patience"><em style="--patience:${Math.round(remain*100)}%"></em></i></span><span class="pokemon-reaction" aria-hidden="true"></span><img class="amie-pokemon" src="${p.image}" alt="${p.name}"><span class="amie-name">${p.name}</span></button>`;}).join('');
    host.querySelectorAll('[data-berry-customer]').forEach(btn=>btn.addEventListener('click',()=>{if(selectedBerry)deliverBerry(Number(btn.dataset.berryCustomer),selectedBerry);}));
  }
  function renderBerryTrees(){
    const host=el('berryPickerTray');if(!host||!berryRun)return;
    const groups=[berryRun.pool.filter((_,i)=>i%3===0),berryRun.pool.filter((_,i)=>i%3===1),berryRun.pool.filter((_,i)=>i%3===2)].filter(x=>x.length);
    host.innerHTML=groups.map((group,gi)=>`<div class="berry-tree tree-${gi+1}"><span class="tree-canopy" aria-hidden="true"></span><span class="tree-trunk" aria-hidden="true"></span><div class="tree-berries">${group.map(b=>`<button type="button" class="amie-berry" data-berry-id="${b.id}" aria-label="Pick ${b.name} Berry"><img src="${b.image}" alt=""><span>${b.name}</span></button>`).join('')}</div></div>`).join('');
    host.querySelectorAll('[data-berry-id]').forEach(btn=>{btn.addEventListener('click',()=>selectBerry(btn.dataset.berryId));btn.addEventListener('pointerdown',startBerryDrag);});
  }
  function selectBerry(id){if(!berryRun?.running)return;selectedBerry=id;el('berryPickerTray')?.querySelectorAll('[data-berry-id]').forEach(x=>x.classList.toggle('selected',x.dataset.berryId===id));setText('berryPickerMessage',`${berryById(id).name} Berry selected — tap a Pokémon.`);}
  function startBerryDrag(ev){if(!berryRun?.running)return;ev.preventDefault();dragBerry=ev.currentTarget.dataset.berryId;selectedBerry=dragBerry;dragGhost=ev.currentTarget.cloneNode(true);dragGhost.classList.add('amie-berry-ghost');document.body.appendChild(dragGhost);moveBerryGhost(ev);window.addEventListener('pointermove',moveBerryGhost);window.addEventListener('pointerup',endBerryDrag,{once:true});}
  function moveBerryGhost(ev){if(dragGhost){dragGhost.style.left=`${ev.clientX}px`;dragGhost.style.top=`${ev.clientY}px`;}}
  function endBerryDrag(ev){window.removeEventListener('pointermove',moveBerryGhost);const target=document.elementFromPoint(ev.clientX,ev.clientY)?.closest?.('[data-berry-customer]'),id=dragBerry;clearDragGhost();if(target&&id)deliverBerry(Number(target.dataset.berryCustomer),id);}
  function pulseReaction(index,reaction,nextRequest=false){if(!berryRun)return;berryRun.reactions[index]=reaction;renderBerryCustomers();setTimeout(()=>{if(!berryRun?.running)return;if(nextRequest)newCustomerRequest(index);else berryRun.reactions[index]='idle';renderBerryCustomers();},360);}
  function deliverBerry(index,berryId){
    if(!berryRun?.running)return;const req=berryRun.requests[index];if(!req)return;
    if(req.berryId!==berryId){berryRun.combo=0;selectedBerry=null;pulseReaction(index,'wrong',false);setText('berryPickerMessage','Wrong Berry — combo reset.');renderBerryHud();return;}
    const frac=clamp((req.expiresAt-Date.now())/berryRun.config.patienceMs,0,1),gained=berryDeliveryScore(berryRun.combo,frac);berryRun.combo++;berryRun.correct++;berryRun.score+=gained;selectedBerry=null;root.vibrate?.(18);pulseReaction(index,'happy',true);setText('berryPickerMessage',`Great delivery! +${gained}`);renderBerryHud();
  }
  function renderBerryHud(){if(!berryRun)return;setText('berryPickerScore',berryRun.score);setText('berryPickerCombo',berryRun.combo);setText('berryPickerCorrect',berryRun.correct);session()?.update?.('berryPicker',{runText:`${berryRun.correct} served · ${Math.max(0,Math.ceil((berryRun.endsAt-Date.now())/1000))}s left`,liveLabel:'SCORE',liveValue:berryRun.score});}
  function berryTick(){
    if(!berryRun?.running)return;const now=Date.now(),left=Math.max(0,berryRun.endsAt-now);setText('berryPickerTimer',Math.ceil(left/1000));
    berryRun.requests.forEach((req,i)=>{if(req&&now>=req.expiresAt&&berryRun.reactions[i]!=='timeout'){berryRun.combo=0;berryRun.reactions[i]='timeout';renderBerryCustomers();setTimeout(()=>{if(berryRun?.running){newCustomerRequest(i);renderBerryCustomers();}},320);}});
    renderBerryHud();renderBerryCustomers();if(left<=0)finishBerryPicker();
  }
  function completeBerryRun(run,mode){
    if(!run||run.finished)return false;run.finished=true;run.running=false;
    const coins=berryPayout(run.score,mode),s=root.state||globalThis.state,bestBefore=Number(s?.arcade?.bestBerryPicker?.[mode]||0);
    if(s?.arcade?.bestBerryPicker)s.arcade.bestBerryPicker[mode]=Math.max(bestBefore,Number(run.score)||0);
    const result=platform()?.awardRun?.({gameId:'berryPicker',label:'Berry Picker',score:run.score,coins,dailyEligible:Number(run.correct)>=Number(run.config?.dailyTarget||0),dailyReward:berryReward(mode)})||{coinsAwarded:coins,itemAwarded:null};root.save?.();
    session()?.showResult?.('berryPicker',{title:'GARDEN COMPLETE',metricLabel:'SERVED',metricValue:`${run.correct} · ${run.score} pts`,coinsAwarded:result.coinsAwarded,itemAwarded:result.itemAwarded,bestText:Number(run.score)>bestBefore?'NEW BEST':'',onReplay:startBerryPicker,onBack:()=>root.LuckyDexArcadeWorld?.backFromGame?.(true)});
    return true;
  }
  function finishBerryPicker(){if(!berryRun?.running)return;clearBerryTimers();const run=berryRun;completeBerryRun(run,berryMode);setText('berryPickerMessage',`Garden closed · ${run.correct} served`);const start=el('berryPickerStartBtn');if(start){start.hidden=false;start.textContent='PLAY AGAIN';}}
  function startBerryPicker(){
    stopBerryRun();session()?.hideResult?.();const config=BERRY_CONFIGS[berryMode]||BERRY_CONFIGS.easy,participants=safeParticipants(config.customers);berryRun={running:true,finished:false,config,participants,pool:BERRIES.slice(0,config.berryCount),requests:[],reactions:Array(config.customers).fill('idle'),score:0,combo:0,correct:0,endsAt:Date.now()+config.durationMs};participants.forEach((_,i)=>newCustomerRequest(i));
    const start=el('berryPickerStartBtn');if(start)start.hidden=true;const restart=el('berryPickerRestartBtn');if(restart)restart.hidden=false;setText('berryPickerMessage','Serve each thought bubble from the berry trees.');renderBerryTrees();renderBerryHud();renderBerryCustomers();berryTick();berryTimer=setInterval(berryTick,120);
  }
  function setBerryMode(mode){if(!BERRY_CONFIGS[mode]||berryRun?.running)return;berryMode=mode;el('berryPickerModes')?.querySelectorAll('[data-berry-mode]').forEach(x=>x.classList.toggle('active',x.dataset.berryMode===mode));const cfg=BERRY_CONFIGS[mode];setText('berryPickerTimer',Math.round(cfg.durationMs/1000));setText('berryPickerMessage',`${mode.toUpperCase()} · ${cfg.customers} customers · serve ${cfg.dailyTarget} for the daily bonus.`);}

  function headTimingGrade(deltaMs){const d=Math.abs(Number(deltaMs)||0);return d<=90?'perfect':d<=220?'good':'miss';}
  function headScore(grade,combo,bonus=false){if(grade!=='perfect'&&grade!=='good')return 0;const base=bonus?300:(grade==='perfect'?100:60);return base+Math.min(Math.max(0,Number(combo)||0)*5,100);}
  function headFallDuration(mode,index){const cfg=HEAD_RUN_CONFIGS[mode]||HEAD_RUN_CONFIGS.easy;return Math.max(cfg.fallFloorMs,cfg.fallStartMs-Math.max(0,Number(index)||0)*cfg.fallStepMs);}
  function headReward(mode,score,streak){if(mode==='hard'&&Number(score)>=4200)return {key:'greatball',amount:1};if(mode==='unlimited'&&Number(streak)>=30)return {key:'greatball',amount:1};return {key:'potion',amount:1};}
  function headPayout(score,mode){const cfg=HEAD_RUN_CONFIGS[mode]||HEAD_RUN_CONFIGS.easy;return clamp(Math.round((Number(score)||0)/25),20,cfg.coinCap);}
  function headRunModel(mode='easy'){
    const config=HEAD_RUN_CONFIGS[mode]||HEAD_RUN_CONFIGS.easy;
    return {mode,config,participants:safeParticipants(config.lanes),score:0,combo:0,bestStreak:0,misses:0,hits:0,ballsResolved:0,activeBall:null,finished:false,awarded:false,lastOutcome:null,running:false};
  }
  function resolveHeadAttempt(run,{tapLane=null,offsetMs=9999}={}){
    const ball=run?.activeBall;if(!run||!ball||ball.resolved||run.finished)return false;ball.resolved=true;
    const grade=Number(tapLane)===Number(ball.lane)?headTimingGrade(offsetMs):'miss';run.ballsResolved++;
    if(grade==='miss'){run.combo=0;run.misses++;run.lastOutcome={grade:'miss',points:0,lane:ball.lane,bonus:!!ball.bonus};}
    else{const points=headScore(grade,run.combo,!!ball.bonus);run.score+=points;run.combo++;run.hits++;run.bestStreak=Math.max(run.bestStreak,run.combo);run.lastOutcome={grade,points,lane:ball.lane,bonus:!!ball.bonus};}
    if(run.config.balls!==null&&run.ballsResolved>=run.config.balls)run.finished=true;
    if(run.config.balls===null&&run.misses>=Number(run.config.missLimit||3))run.finished=true;
    return true;
  }
  function clearHeadTimers(){if(headRaf){cancelAnimationFrame(headRaf);headRaf=null;}if(headSpawnTimer){clearTimeout(headSpawnTimer);headSpawnTimer=null;}}
  function stopHeadRun(){clearHeadTimers();if(headRun)headRun.running=false;el('headItBall')?.remove();}
  function renderHeadLanes(){
    const host=el('headItLanes');if(!host||!headRun)return;
    host.style.setProperty('--head-lanes',headRun.config.lanes);
    host.innerHTML=headRun.participants.map((p,i)=>`<button type="button" class="head-lane" data-head-lane="${i}" aria-label="Head yarn with ${p.name}"><span class="head-impact"></span><img class="head-pokemon" src="${p.image}" alt="${p.name}"><b>${p.name}</b></button>`).join('');
    host.querySelectorAll('[data-head-lane]').forEach(btn=>btn.addEventListener('click',()=>tapHeadLane(Number(btn.dataset.headLane))));
  }
  function renderHeadHud(){
    if(!headRun)return;setText('headItScore',headRun.score);setText('headItCombo',headRun.combo);setText('headItMisses',headRun.misses);
    const runText=headRun.config.balls===null?`${Math.max(0,headRun.config.missLimit-headRun.misses)} misses left`:`Ball ${Math.min(headRun.ballsResolved+1,headRun.config.balls)} / ${headRun.config.balls}`;
    setText('headItTimer',runText);session()?.update?.('headIt',{runText,liveLabel:'SCORE',liveValue:headRun.score});
  }
  function headFeedback(outcome){
    const lane=el('headItLanes')?.querySelector?.(`[data-head-lane="${outcome.lane}"]`);if(!lane)return;
    lane.querySelector('.head-feedback')?.remove();const f=document.createElement('span');f.className=`head-feedback ${outcome.grade}`;f.textContent=outcome.grade==='miss'?'MISS':`${outcome.grade.toUpperCase()} +${outcome.points}`;lane.appendChild(f);setTimeout(()=>f.remove(),420);
  }
  function scheduleHeadBall(delay=110){if(!headRun?.running||headRun.finished)return;if(headSpawnTimer)clearTimeout(headSpawnTimer);headSpawnTimer=setTimeout(spawnHeadBall,delay);}
  function spawnHeadBall(){
    if(!headRun?.running||headRun.finished||headRun.activeBall)return;const index=headRun.ballsResolved,duration=headFallDuration(headMode,index),lane=Math.floor(Math.random()*headRun.config.lanes),bonus=index>0&&(index+1)%10===0,now=performance.now();
    headRun.activeBall={id:++headBallSeq,lane,bonus,resolved:false,spawnAt:now,impactAt:now+duration,duration};
    const play=el('headItPlayfield');if(play){el('headItBall')?.remove();const ball=document.createElement('div');ball.id='headItBall';ball.className=`head-yarn${bonus?' bonus':''}`;ball.setAttribute('aria-label',bonus?'Bonus yarn':'Yarn');ball.innerHTML='<i></i>';play.appendChild(ball);}renderHeadHud();headRaf=requestAnimationFrame(headLoop);
  }
  function headLoop(now){
    if(!headRun?.running||headRun.finished)return;const ball=headRun.activeBall;if(ball&&!ball.resolved){const node=el('headItBall'),frac=clamp((now-ball.spawnAt)/ball.duration,0,1.2);if(node){node.style.left=`${((ball.lane+.5)/headRun.config.lanes)*100}%`;node.style.top=`${-10+Math.min(frac,1)*78+Math.max(0,frac-1)*55}%`;node.style.transform=`translate(-50%,-50%) rotate(${(now-ball.spawnAt)*.28}deg)`;}if(now>ball.impactAt+220){resolveHeadVisual(null,now);return;}}
    headRaf=requestAnimationFrame(headLoop);
  }
  function tapHeadLane(lane){if(!headRun?.running||!headRun.activeBall)return;const btn=el('headItLanes')?.querySelector?.(`[data-head-lane="${lane}"]`);btn?.classList.add('bump');setTimeout(()=>btn?.classList.remove('bump'),170);resolveHeadVisual(lane,performance.now());}
  function resolveHeadVisual(tapLane,now){
    const run=headRun,ball=run?.activeBall;if(!run||!ball||ball.resolved)return;const offset=now-ball.impactAt;if(!resolveHeadAttempt(run,{tapLane,offsetMs:offset}))return;const outcome=run.lastOutcome;headFeedback(outcome);renderHeadHud();
    if(outcome.grade!=='miss'){root.vibrate?.(outcome.grade==='perfect'?[10,14,22]:10);const node=el('headItBall');node?.classList.add('deflect');}else root.vibrate?.(18);
    setText('headItMessage',outcome.grade==='miss'?'Miss — next yarn!':`${outcome.grade.toUpperCase()}${outcome.bonus?' · BONUS':''}`);
    setTimeout(()=>{if(headRun!==run)return;el('headItBall')?.remove();run.activeBall=null;if(run.finished){completeHeadRun(run,headMode);return;}scheduleHeadBall(110);},outcome.grade==='miss'?130:210);
  }
  function completeHeadRun(run,mode){
    if(!run||run.awarded)return false;run.awarded=true;run.finished=true;run.running=false;clearHeadTimers();el('headItBall')?.remove();
    const s=root.state||globalThis.state,bestBefore=Number(s?.arcade?.bestHeadIt?.[mode]||0);if(s?.arcade?.bestHeadIt){s.arcade.bestHeadIt[mode]=Math.max(bestBefore,Number(run.score)||0);if(mode==='unlimited')s.arcade.bestHeadIt.unlimitedStreak=Math.max(Number(s.arcade.bestHeadIt.unlimitedStreak||0),Number(run.bestStreak)||0);}
    const eligible=mode==='unlimited'?(run.score>=run.config.dailyTarget||run.bestStreak>=run.config.dailyStreak):run.score>=run.config.dailyTarget,coins=headPayout(run.score,mode),result=platform()?.awardRun?.({gameId:'headIt',label:'Head It',score:run.score,coins,dailyEligible:eligible,dailyReward:headReward(mode,run.score,run.bestStreak)})||{coinsAwarded:coins,itemAwarded:null};root.save?.();
    session()?.showResult?.('headIt',{title:'YARN RALLY COMPLETE',metricLabel:'SCORE',metricValue:`${run.score} · ${run.misses} misses`,coinsAwarded:result.coinsAwarded,itemAwarded:result.itemAwarded,bestText:run.score>bestBefore?'NEW BEST':'',onReplay:startHeadIt,onBack:()=>root.LuckyDexArcadeWorld?.backFromGame?.(true)});setText('headItMessage',`Run complete · ${run.score} points`);const start=el('headItStartBtn');if(start)start.textContent='PLAY AGAIN';return true;
  }
  function startHeadIt(){stopHeadRun();session()?.hideResult?.();headRun=headRunModel(headMode);headRun.running=true;renderHeadLanes();renderHeadHud();setText('headItMessage','Ready — watch the falling yarn.');const start=el('headItStartBtn');if(start)start.textContent='RESTART';scheduleHeadBall(260);}
  function setHeadMode(mode){if(!HEAD_RUN_CONFIGS[mode]||headRun?.running)return;headMode=mode;el('headItModes')?.querySelectorAll('[data-head-mode]').forEach(x=>x.classList.toggle('active',x.dataset.headMode===mode));const cfg=HEAD_RUN_CONFIGS[mode];setText('headItTimer',cfg.balls===null?`${cfg.missLimit} misses left`:`Ball 1 / ${cfg.balls}`);setText('headItMessage',mode==='unlimited'?'Endless — the third miss ends the run.':`${cfg.balls} balls · speed increases every ball.`);}


  function puzzleNeighbors(empty,size){const r=Math.floor(empty/size),c=empty%size,out=[];if(r>0)out.push(empty-size);if(r<size-1)out.push(empty+size);if(c>0)out.push(empty-1);if(c<size-1)out.push(empty+1);return out;}
  function isSolvedPuzzle(tiles){return Array.isArray(tiles)&&tiles.every((v,i)=>v===i);}
  function makeSolvablePuzzle(size,randomFn=Math.random,trace=null){
    const n=size*size,tiles=Array.from({length:n},(_,i)=>i),steps=size===3?80:size===4?160:260;let previous=-1;
    for(let i=0;i<steps;i++){const empty=tiles.indexOf(n-1),choices=puzzleNeighbors(empty,size).filter(x=>x!==previous),pick=choices[Math.floor(randomFn()*choices.length)]??puzzleNeighbors(empty,size)[0];if(trace)trace.push({emptyBefore:empty,tileIndex:pick});[tiles[empty],tiles[pick]]=[tiles[pick],tiles[empty]];previous=empty;}
    if(isSolvedPuzzle(tiles)){const empty=tiles.indexOf(n-1),pick=puzzleNeighbors(empty,size)[0];if(trace)trace.push({emptyBefore:empty,tileIndex:pick});[tiles[empty],tiles[pick]]=[tiles[pick],tiles[empty]];}
    return tiles;
  }
  function tilePayout(mode,elapsedSec,moves){const cfg=TILE_CONFIGS[mode]||TILE_CONFIGS.easy,time=Math.max(0,Number(elapsedSec)||0),moveCount=Math.max(0,Number(moves)||0),ideal=cfg.shuffleMoves/4;const timePart=Math.max(0,Math.round(cfg.timeBonus*(1-time/cfg.qualifySec))),movePart=Math.max(0,Math.round(cfg.moveBonus*(1-Math.max(0,moveCount-ideal)/(cfg.shuffleMoves/2))));return clamp(cfg.base+timePart+movePart,cfg.base,cfg.coinCap);}
  function tileReward(mode){return mode==='hard'?{key:'greatball',amount:1}:{key:'pokeball',amount:mode==='normal'?3:2};}
  function officialArtworkUrl(participant){const id=Number(participant?.id);return Number.isFinite(id)&&id>0?`https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/other/official-artwork/${id}.png`:(participant?.image||'');}
  function canSlideTile(board,size,tileIndex){if(!Array.isArray(board)||tileIndex<0||tileIndex>=board.length)return false;const empty=board.indexOf(size*size-1);return empty>=0&&puzzleNeighbors(empty,size).includes(tileIndex);}
  function swipeTargetsEmpty(board,size,tileIndex,dx,dy,threshold=18){
    if(!canSlideTile(board,size,tileIndex))return false;const empty=board.indexOf(size*size-1),tr=Math.floor(tileIndex/size),tc=tileIndex%size,er=Math.floor(empty/size),ec=empty%size,ax=Math.abs(dx),ay=Math.abs(dy);
    if(er===tr&&ec===tc-1)return ax>=threshold&&ax>ay&&dx<0;if(er===tr&&ec===tc+1)return ax>=threshold&&ax>ay&&dx>0;if(ec===tc&&er===tr-1)return ay>=threshold&&ay>ax&&dy<0;if(ec===tc&&er===tr+1)return ay>=threshold&&ay>ax&&dy>0;return false;
  }
  function tileCrop(tileValue,size){return {leftPct:(tileValue%size)*100/size,topPct:Math.floor(tileValue/size)*100/size,widthPct:100/size,heightPct:100/size};}
  function clearTileTimer(){if(tileTimer){clearInterval(tileTimer);tileTimer=null;}}
  function stopTileRun(){clearTileTimer();tilePointer=null;if(tileRun)tileRun.running=false;}
  function tileElapsed(run=tileRun){if(!run)return 0;if(Number.isFinite(run.elapsedSec))return run.elapsedSec;return Math.max(0,(performance.now()-Number(run.startedAt||performance.now()))/1000);}
  function renderTileTarget(){if(!tileRun)return;const img=el('tilePuzzleTarget'),src=officialArtworkUrl(tileRun.participant);if(img){img.src=src;img.onerror=()=>{img.onerror=null;if(tileRun?.participant?.image)img.src=tileRun.participant.image;};}setText('tilePuzzleTargetName',tileRun.participant.name||'Pokémon');}
  function tileMarkup(value,index){
    const size=tileRun.config.size,empty=size*size-1;if(value===empty)return `<button type="button" class="tile-piece-v018 empty" data-tile-index="${index}" aria-label="Empty puzzle space" disabled></button>`;
    const crop=tileCrop(value,size),src=officialArtworkUrl(tileRun.participant),fallback=tileRun.participant.image||src;return `<button type="button" class="tile-piece-v018" data-tile-index="${index}" aria-label="Puzzle tile ${value+1}"><span class="tile-crop"><img src="${src}" data-fallback="${fallback}" alt="" style="width:${size*100}%;height:${size*100}%;left:-${crop.leftPct*size}%;top:-${crop.topPct*size}%"></span></button>`;
  }
  function renderTileBoard(){
    const host=el('tilePuzzleBoard');if(!host||!tileRun)return;host.style.setProperty('--tile-size',tileRun.config.size);host.style.gridTemplateColumns=`repeat(${tileRun.config.size},minmax(0,1fr))`;host.innerHTML=tileRun.tiles.map(tileMarkup).join('');
    host.querySelectorAll('.tile-piece-v018:not(.empty)').forEach(btn=>{const index=Number(btn.dataset.tileIndex);btn.addEventListener('pointerdown',ev=>{if(!tileRun?.running)return;tilePointer={index,x:ev.clientX,y:ev.clientY,pointerId:ev.pointerId};btn.setPointerCapture?.(ev.pointerId);});btn.addEventListener('pointerup',ev=>{if(!tilePointer||tilePointer.pointerId!==ev.pointerId)return;const pointer=tilePointer;tilePointer=null;const dx=ev.clientX-pointer.x,dy=ev.clientY-pointer.y;if(swipeTargetsEmpty(tileRun.tiles,tileRun.config.size,pointer.index,dx,dy)){tileSuppressClick=true;moveTileAt(pointer.index);setTimeout(()=>{tileSuppressClick=false;},0);}});btn.addEventListener('click',()=>{if(tileSuppressClick)return;moveTileAt(index);});});
    host.querySelectorAll('img[data-fallback]').forEach(img=>img.addEventListener('error',()=>{const fb=img.dataset.fallback;if(fb&&img.src!==fb){img.src=fb;}else img.removeAttribute('src');},{once:true}));
  }
  function renderTileHud(){if(!tileRun)return;const elapsed=tileElapsed(tileRun);setText('tilePuzzleTimer',elapsed.toFixed(1));setText('tilePuzzleMoves',tileRun.moves);session()?.update?.('tilePuzzle',{runText:`${tileRun.config.size}×${tileRun.config.size} · ${tileRun.moves} moves`,liveLabel:'TIME',liveValue:`${elapsed.toFixed(1)}s`});}
  function moveTileAt(index){if(!tileRun?.running||!canSlideTile(tileRun.tiles,tileRun.config.size,index))return false;const empty=tileRun.tiles.indexOf(tileRun.config.size*tileRun.config.size-1);[tileRun.tiles[empty],tileRun.tiles[index]]=[tileRun.tiles[index],tileRun.tiles[empty]];tileRun.moves++;renderTileBoard();renderTileHud();if(isSolvedPuzzle(tileRun.tiles))finishTilePuzzle();return true;}
  function completeTileRun(run,mode){
    if(!run||run.awarded)return false;run.awarded=true;run.finished=true;run.running=false;const elapsed=tileElapsed(run),s=root.state||globalThis.state,bestBefore=Number(s?.arcade?.bestTilePuzzle?.[mode]??Infinity);if(s?.arcade?.bestTilePuzzle){const previous=s.arcade.bestTilePuzzle[mode];s.arcade.bestTilePuzzle[mode]=previous==null?elapsed:Math.min(Number(previous),elapsed);}
    const coins=tilePayout(mode,elapsed,run.moves),score=Math.max(0,Math.round(10000-elapsed*10-run.moves)),result=platform()?.awardRun?.({gameId:'tilePuzzle',label:'Tile Puzzle',score,coins,dailyEligible:elapsed<=run.config.qualifySec,dailyReward:tileReward(mode)})||{coinsAwarded:coins,itemAwarded:null};root.save?.();
    session()?.showResult?.('tilePuzzle',{title:'PICTURE COMPLETE',metricLabel:'TIME',metricValue:`${elapsed.toFixed(1)}s · ${run.moves} moves`,coinsAwarded:result.coinsAwarded,itemAwarded:result.itemAwarded,bestText:elapsed<bestBefore?'NEW BEST':'',onReplay:startTilePuzzle,onBack:()=>root.LuckyDexArcadeWorld?.backFromGame?.(true)});return true;
  }
  function finishTilePuzzle(){if(!tileRun?.running)return false;const run=tileRun;run.running=false;run.elapsedSec=tileElapsed(run);clearTileTimer();const board=el('tilePuzzleBoard'),src=officialArtworkUrl(run.participant),fallback=run.participant.image||src;if(board){board.innerHTML=`<img class="tile-complete-image" src="${src}" data-fallback="${fallback}" alt="Completed ${run.participant.name||'Pokémon'} picture">`;const img=board.querySelector('img');img?.addEventListener('error',()=>{if(fallback&&img.src!==fallback)img.src=fallback;},{once:true});}setText('tilePuzzleMessage',`Complete! ${run.elapsedSec.toFixed(1)}s · ${run.moves} moves`);setTimeout(()=>{if(tileRun===run)completeTileRun(run,tileMode);},650);return true;}
  function startTilePuzzle(){stopTileRun();session()?.hideResult?.();const config=TILE_CONFIGS[tileMode]||TILE_CONFIGS.easy,participant=safeParticipants(1)[0]||{id:25,name:'Pikachu',image:'https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/25.png'};tileRun={mode:tileMode,config,participant,tiles:makeSolvablePuzzle(config.size),moves:0,startedAt:performance.now(),elapsedSec:null,running:true,finished:false,awarded:false};renderTileTarget();renderTileBoard();renderTileHud();setText('tilePuzzleMessage','Slide a neighbouring tile into the empty space — tap or swipe.');const start=el('tilePuzzleStartBtn');if(start){start.hidden=true;start.textContent='NEW PUZZLE';}const restart=el('tilePuzzleRestartBtn');if(restart)restart.hidden=false;tileTimer=setInterval(renderTileHud,100);}
  function setTileMode(mode){if(!TILE_CONFIGS[mode]||tileRun?.running)return;tileMode=mode;el('tilePuzzleModes')?.querySelectorAll('[data-tile-mode]').forEach(x=>x.classList.toggle('active',x.dataset.tileMode===mode));const cfg=TILE_CONFIGS[mode];setText('tilePuzzleTimer','0.0');setText('tilePuzzleMoves','0');setText('tilePuzzleMessage',`${cfg.size}×${cfg.size} puzzle · daily item target ${cfg.qualifySec}s.`);}

  function hideAll(){['berryPickerGame','headItGame','tilePuzzleGame'].forEach(id=>{const n=el(id);if(n)n.hidden=true;});}
  function open(gameId){
    if(!['berryPicker','headIt','tilePuzzle'].includes(gameId)){currentGame=null;return legacy()?.open?.(gameId)!==false;}
    legacy()?.close?.(true);hideAll();currentGame=gameId;const node=el(`${gameId}Game`);if(node)node.hidden=false;if(typeof document!=='undefined')document.body.classList.add('arcade-open');root.Android?.setImmersive?.(true);session()?.mount?.(gameId);if(gameId==='berryPicker')setBerryMode(berryMode);else if(gameId==='headIt')setHeadMode(headMode);else setTileMode(tileMode);return true;
  }
  function close(force=false){if(['berryPicker','headIt','tilePuzzle'].includes(currentGame)){stopBerryRun();stopHeadRun();stopTileRun();hideAll();currentGame=null;if(typeof document!=='undefined')document.body.classList.remove('arcade-open');root.Android?.setImmersive?.(false);return true;}return legacy()?.close?.(force)!==false;}
  function activeGame(){return currentGame||legacy()?.activeGame?.()||null;}
  function interceptClick(node,fn){node?.addEventListener('click',ev=>{ev.preventDefault();ev.stopImmediatePropagation();fn(ev);},true);}
  function wire(){
    const modes=el('berryPickerModes');modes?.querySelectorAll('[data-berry-mode]').forEach(btn=>interceptClick(btn,()=>setBerryMode(btn.dataset.berryMode)));interceptClick(el('berryPickerStartBtn'),startBerryPicker);interceptClick(el('berryPickerRestartBtn'),startBerryPicker);
    el('headItModes')?.querySelectorAll('[data-head-mode]').forEach(btn=>interceptClick(btn,()=>setHeadMode(btn.dataset.headMode)));interceptClick(el('headItStartBtn'),startHeadIt);
    el('tilePuzzleModes')?.querySelectorAll('[data-tile-mode]').forEach(btn=>interceptClick(btn,()=>setTileMode(btn.dataset.tileMode)));interceptClick(el('tilePuzzleStartBtn'),startTilePuzzle);interceptClick(el('tilePuzzleRestartBtn'),startTilePuzzle);
  }

  const api={BERRIES,BERRY_CONFIGS,HEAD_RUN_CONFIGS,TILE_CONFIGS,berryDeliveryScore,berryPayout,berryReward,safeParticipants,berrySceneModel,completeBerryRun,startBerryPicker,setBerryMode,headTimingGrade,headScore,headFallDuration,headReward,headPayout,headRunModel,resolveHeadAttempt,completeHeadRun,startHeadIt,setHeadMode,puzzleNeighbors,makeSolvablePuzzle,isSolvedPuzzle,tilePayout,tileReward,officialArtworkUrl,canSlideTile,swipeTargetsEmpty,tileCrop,completeTileRun,startTilePuzzle,setTileMode,open,close,activeGame};
  root.LuckyDexAmieV0180=api;
  if(typeof module!=='undefined'&&module.exports)module.exports=api;
  if(typeof document!=='undefined')wire();
})(typeof window!=='undefined'?window:globalThis);
