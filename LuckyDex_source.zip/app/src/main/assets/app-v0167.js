const API = {
  pokeSpecies: 'https://pokeapi.co/api/v2/pokemon-species?limit=2000',
  pokemon: id => `https://pokeapi.co/api/v2/pokemon/${id}`,
  pokeType: type => `https://pokeapi.co/api/v2/type/${type}`,
  tcgSets: 'https://api.tcgdex.net/v2/en/sets',
  tcgSeries: id => `https://api.tcgdex.net/v2/en/series/${id}`,
  tcgSet: id => `https://api.tcgdex.net/v2/en/sets/${id}`,
  card: id => `https://api.tcgdex.net/v2/en/cards/${id}`,
  sprite: (id, shiny=false) => `arcade/sprites/pokemon/${shiny ? 'shiny/' : ''}${id}.png`
};

const MAX_DEX_ID = 1025;
const LEGENDARY_RATE = 1 / 400;
const RARE_WILD_RATE = 1 / 20;
const PACK_COST = {tcg:600, tcgp:450};
const BALLS = {
  pokeball:{name:'Poké Ball',mod:1,emoji:'🔴'},
  greatball:{name:'Great Ball',mod:1.5,emoji:'🔵'},
  ultraball:{name:'Ultra Ball',mod:2,emoji:'🟡'}
};
const LEGENDARIES = new Set([144,145,146,150,151,243,244,245,249,250,251,377,378,379,380,381,382,383,384,385,386,480,481,482,483,484,485,486,487,488,489,490,491,492,493,494,638,639,640,641,642,643,644,645,646,647,648,649,716,717,718,719,720,721,772,773,785,786,787,788,789,790,791,792,800,801,802,807,808,809,888,889,890,891,892,893,894,895,896,897,898,905,1001,1002,1003,1004,1007,1008,1009,1010,1024,1025]);
const MYTHICAL = new Set([151,251,385,386,489,490,491,492,493,494,647,648,649,719,720,721,801,802,807,808,809,893]);
const RARE_WILD = new Set([
  1,2,3,4,5,6,7,8,9,138,139,140,141,142,147,148,149,152,153,154,155,156,157,158,159,160,246,247,248,
  252,253,254,255,256,257,258,259,260,345,346,347,348,371,372,373,374,375,376,387,388,389,390,391,392,393,394,395,
  408,409,410,411,443,444,445,495,496,497,498,499,500,501,502,503,564,565,566,567,633,634,635,650,651,652,653,654,655,
  656,657,658,696,697,698,699,704,705,706,722,723,724,725,726,727,728,729,730,782,783,784,810,811,812,813,814,815,816,
  817,818,880,881,882,883,885,886,887,906,907,908,909,910,911,912,913,914,996,997,998
]);
const GENERATIONS = [
  {id:1,name:'Kanto',min:1,max:151},{id:2,name:'Johto',min:152,max:251},{id:3,name:'Hoenn',min:252,max:386},
  {id:4,name:'Sinnoh',min:387,max:493},{id:5,name:'Unova',min:494,max:649},{id:6,name:'Kalos',min:650,max:721},
  {id:7,name:'Alola',min:722,max:809},{id:8,name:'Galar/Hisui',min:810,max:905},{id:9,name:'Paldea',min:906,max:1025}
];
const ZONES = {
  meadow:{name:'Meadow',emoji:'🌿',types:['grass','normal','bug','fairy'],rank:1,levels:[2,8],flavor:'Open grassland and woodland edges'},
  cave:{name:'Cave',emoji:'🪨',types:['rock','ground','dark','poison','steel'],rank:3,levels:[6,14],flavor:'Deep tunnels and mineral chambers'},
  haunted:{name:'Haunted House',emoji:'🏚️',types:['ghost','psychic','dark','poison'],rank:5,levels:[10,20],flavor:'An abandoned manor outside Lavender Town'},
  coast:{name:'Coast',emoji:'🌊',types:['water','ice','flying'],rank:6,levels:[10,20],flavor:'Rock pools, beaches and rough surf'},
  volcano:{name:'Volcano',emoji:'🌋',types:['fire','rock','ground','dragon'],rank:10,levels:[16,28],flavor:'Hot caverns beneath an active crater'}
};
// v0.15.7: Adventure must remain playable when Android reports a connection
// but PokeAPI is slow/unreachable. These are immediate local encounter seeds;
// a successful background refresh replaces them with the full live type pool.
const LOCAL_ZONE_POOLS={
  meadow:[[10,'caterpie'],[13,'weedle'],[16,'pidgey'],[19,'rattata'],[21,'spearow'],[25,'pikachu'],[29,'nidoran-f'],[32,'nidoran-m'],[35,'clefairy'],[39,'jigglypuff'],[43,'oddish'],[46,'paras'],[48,'venonat'],[52,'meowth'],[69,'bellsprout'],[102,'exeggcute'],[113,'chansey'],[123,'scyther'],[127,'pinsir'],[133,'eevee']],
  cave:[[41,'zubat'],[50,'diglett'],[51,'dugtrio'],[66,'machop'],[67,'machoke'],[74,'geodude'],[75,'graveler'],[95,'onix'],[111,'rhyhorn'],[127,'pinsir'],[142,'aerodactyl'],[246,'larvitar'],[304,'aron'],[443,'gible'],[524,'roggenrola'],[529,'drilbur'],[703,'carbink'],[744,'rockruff']],
  haunted:[[41,'zubat'],[42,'golbat'],[63,'abra'],[64,'kadabra'],[92,'gastly'],[93,'haunter'],[94,'gengar'],[96,'drowzee'],[97,'hypno'],[200,'misdreavus'],[302,'sableye'],[353,'shuppet'],[355,'duskull'],[425,'drifloon'],[442,'spiritomb'],[607,'litwick'],[708,'phantump'],[778,'mimikyu']],
  coast:[[54,'psyduck'],[60,'poliwag'],[72,'tentacool'],[79,'slowpoke'],[86,'seel'],[90,'shellder'],[98,'krabby'],[116,'horsea'],[118,'goldeen'],[120,'staryu'],[129,'magikarp'],[131,'lapras'],[170,'chinchou'],[194,'wooper'],[223,'remoraid'],[278,'wingull'],[320,'wailmer'],[363,'spheal']],
  volcano:[[4,'charmander'],[5,'charmeleon'],[37,'vulpix'],[58,'growlithe'],[74,'geodude'],[77,'ponyta'],[95,'onix'],[111,'rhyhorn'],[126,'magmar'],[218,'slugma'],[228,'houndour'],[240,'magby'],[322,'numel'],[324,'torkoal'],[390,'chimchar'],[485,'heatran'],[636,'larvesta'],[757,'salandit']]
};
const STARTER_META={
  1:{id:1,name:'bulbasaur',types:['grass','poison'],baseStats:{hp:45,attack:49,defense:49,speed:45}},
  4:{id:4,name:'charmander',types:['fire'],baseStats:{hp:39,attack:52,defense:43,speed:65}},
  7:{id:7,name:'squirtle',types:['water'],baseStats:{hp:44,attack:48,defense:65,speed:43}},
  25:{id:25,name:'pikachu',types:['electric'],baseStats:{hp:35,attack:55,defense:40,speed:90}}
};
const zonePoolRefreshJobs={};
const TYPE_MOVE = {
  normal:'Body Slam',fire:'Flame Burst',water:'Water Pulse',electric:'Spark',grass:'Razor Leaf',ice:'Icy Wind',fighting:'Brick Break',
  poison:'Poison Jab',ground:'Mud Shot',flying:'Air Slash',psychic:'Psybeam',bug:'Bug Bite',rock:'Rock Throw',ghost:'Shadow Sneak',
  dragon:'Dragon Breath',dark:'Bite',steel:'Metal Claw',fairy:'Draining Kiss'
};
const SUPER = {
  fire:['grass','ice','bug','steel'],water:['fire','ground','rock'],electric:['water','flying'],grass:['water','ground','rock'],ice:['grass','ground','flying','dragon'],
  fighting:['normal','ice','rock','dark','steel'],poison:['grass','fairy'],ground:['fire','electric','poison','rock','steel'],flying:['grass','fighting','bug'],
  psychic:['fighting','poison'],bug:['grass','psychic','dark'],rock:['fire','ice','flying','bug'],ghost:['psychic','ghost'],dragon:['dragon'],dark:['psychic','ghost'],
  steel:['ice','rock','fairy'],fairy:['fighting','dragon','dark']
};
const WEAK = {
  fire:['fire','water','rock','dragon'],water:['water','grass','dragon'],electric:['electric','grass','dragon'],grass:['fire','grass','poison','flying','bug','dragon','steel'],
  ice:['fire','water','ice','steel'],fighting:['poison','flying','psychic','bug','fairy'],poison:['poison','ground','rock','ghost'],ground:['grass','bug'],
  flying:['electric','rock','steel'],psychic:['psychic','steel'],bug:['fire','fighting','poison','flying','ghost','steel','fairy'],rock:['fighting','ground','steel'],
  ghost:['dark'],dragon:['steel'],dark:['fighting','dark','fairy'],steel:['fire','water','electric','steel'],fairy:['fire','poison','steel']
};
const IMMUNE = {normal:['ghost'],electric:['ground'],fighting:['ghost'],poison:['steel'],ground:['flying'],psychic:['dark'],ghost:['normal'],dragon:['fairy']};


const DAILY_POOL = [
  {id:'catch3',name:'Catch 3 Pokémon',icon:'🔴',target:3,key:'caught'},
  {id:'arcade500',name:'Earn 500 Arcade Coins',icon:'🎮',target:500,key:'arcadeCoins'},
  {id:'expedition1',name:'Clear 1 Expedition',icon:'🗺️',target:1,key:'adventureClears'},
  {id:'battles4',name:'Win 4 battles',icon:'⚔️',target:4,key:'battlesWon'},
  {id:'pack1',name:'Open 1 pack',icon:'🃏',target:1,key:'packs'},
  {id:'ghost1',name:'Catch a Ghost type',icon:'👻',target:1,key:'ghostCaught',rank:3},
  {id:'great1',name:'Make a Great/Ultra Ball catch',icon:'🔵',target:1,key:'greatCatches',rank:3},
  {id:'perfect2',name:'Hit 2 perfect Berry Blend rounds',icon:'🍓',target:2,key:'perfectBerry'}
];
const ACHIEVEMENTS = [
  {id:'first_shiny',icon:'✨',name:'A Different Colour',desc:'Catch your first shiny Pokémon.',reward:{coins:500,fragment:1},progress:()=>[state.stats.shinies,1]},
  {id:'ghost10',icon:'👻',name:'Ghost Hunter',desc:'Own 10 different Ghost-type Pokémon.',reward:{coins:750},progress:()=>[ownedTypeCount('ghost'),10]},
  {id:'kanto_all',icon:'🔴',name:'Professor Oak Would Be Proud',desc:'Own every species in the Kanto Pokédex.',reward:{coins:2500,tickets:2,fragment:1},progress:()=>[ownedRangeCount(1,151),151]},
  {id:'celestial_storm',icon:'🌌',name:'Celestial Storm Master',desc:'Complete the Celestial Storm card set.',reward:{coins:2000,tickets:2},progress:()=>setCompletionProgress(/celestial storm/i)},
  {id:'gold_card',icon:'👑',name:'Golden Ticket',desc:'Pull a Gold/Crown rarity card from TCG Pocket.',reward:{coins:1000,tickets:1},progress:()=>[Math.max(Number(state.stats.goldCards||0),Object.values(state.cards).filter(c=>c.source==='tcgp'&&/(crown|gold)/i.test(String(c.rarity||''))).length),1]},
  {id:'haunted_visit',icon:'🏚️',name:'Things That Go Bump',desc:'Visit the Lavender Haunted House expedition.',reward:{coins:400},progress:()=>[state.stats.visitedLocations?.haunted?1:0,1]},
  {id:'haunted_clear',icon:'🕯️',name:'Exorcist',desc:'Clear the Lavender Haunted House.',reward:{coins:1000,tickets:1},progress:()=>[state.profile.firstClears?.haunted?1:0,1]},
  {id:'packs25',icon:'🃏',name:'Card Shop Regular',desc:'Open 25 packs.',reward:{coins:750,tickets:1},progress:()=>[state.stats.packs,25]},
  {id:'packs100',icon:'📦',name:'I Can Quit Whenever I Want',desc:'Open 100 packs.',reward:{coins:2500,tickets:3},progress:()=>[state.stats.packs,100]},
  {id:'arcade10k',icon:'🕹️',name:'Game Corner Ace',desc:'Earn 10,000 Lucky Coins from Arcade games.',reward:{coins:1000,tickets:1},progress:()=>[state.stats.arcadeCoins,10000]},
  {id:'five_shiny',icon:'🌟',name:'Shiny Squad',desc:'Catch 5 shiny Pokémon.',reward:{coins:1500,fragment:1},progress:()=>[state.stats.shinies,5]},
  {id:'zubat3',icon:'🦇',name:'Not Again…',desc:'Encounter Zubat three times in a row.',hidden:true,reward:{coins:300},progress:()=>[state.stats.maxZubatStreak,3]},
  {id:'fails3',icon:'💢',name:'Surely This Time',desc:'Fail three catches in one play history.',hidden:true,reward:{coins:250},progress:()=>[state.stats.failedCatches,3]},
  {id:'loaded_pack',icon:'💥',name:'Loaded Pack',desc:'Pull three or more high-rarity cards from one pack.',hidden:true,reward:{coins:750,tickets:1},progress:()=>[state.stats.maxBigHitsInPack,3]}
];

const defaultState = {
  saveVersion:6,
  settings:{shinyOdds:2048,vibration:true,zone:'meadow',ball:'pokeball'},
  stats:{encounters:0,catches:0,shinies:0,packs:0,cardsPulled:0,zonesExplored:{},visitedLocations:{},battlesWon:0,ballsThrown:0,arcadeGames:0,arcadeCoins:0,adventureClears:0,expeditionRetreats:0,failedCatches:0,maxZubatStreak:0,zubatStreak:0,perfectBerryRounds:0,goldCards:0,maxBigHitsInPack:0},
  profile:{xp:0,coins:750,tickets:1,dust:0,lastDailyPack:'',firstClears:{},rankRewards:[],achievementClaims:[],shinyCharmFragments:0},
  inventory:{pokeball:20,greatball:5,ultraball:1,berry:8,potion:5},
  pokemon:{},cards:{},team:[],recentPokemon:[],rareHits:[],
  claimedMilestones:{dex:[],cards:[]},
  arcade:{voltorbLevel:1,bestMemory:0,bestFossil:0,fossilsFound:0,bestDitto:0,bestQuiz:0,quizPerfect:0,bestQuizEndless:0,bestQuizEndlessScore:0,bestBallDrop:0,bestUnown:0,bestSafari:0,safariCaught:0,dailyRewards:{},bestBerryPicker:{easy:0,normal:0,hard:0},bestHeadIt:{easy:0,normal:0,hard:0,unlimited:0,unlimitedStreak:0},bestTilePuzzle:{easy:null,normal:null,hard:null},lastArcadeZone:'amie',lastArcadeVenue:'amieGarden'},
  daily:{date:'',tasks:[],progress:{},claimed:false},
  adventureV2:{schema:1,destinations:{},activeRoam:null,activeExpedition:null,lastDestination:'meadow'},
  ui:{packBrowser:{sortKey:'releaseDate',sortDir:'desc'},packMetrics:{}}
};

let state = loadState();
Object.defineProperty(window,'state',{get:()=>state,configurable:true});
window.API=API;
let species = [];
let zonePools = {};
let setCache = {tcg:[],tcgp:[]};
let cardDetailCache = new Map();
let pokemonMetaCache = new Map();
let collectionMode = 'pokemon';
let preparedPack = null;
let toastTimer = null;
let pokemonModalKey = null;




let challengeTab = 'active';
let starterChoiceInFlight=false;

function cloneDefault(){ return JSON.parse(JSON.stringify(defaultState)); }
function todayKey(){ return new Date().toLocaleDateString('en-CA'); }
function loadState(){
  try{
    const raw=JSON.parse(localStorage.getItem('luckyDexSave')||'{}');
    const base=cloneDefault();
    const migrated={
      ...base,...raw,
      settings:{...base.settings,...(raw.settings||{})},
      stats:{...base.stats,...(raw.stats||{}),zonesExplored:{...(raw.stats?.zonesExplored||{})},visitedLocations:{...(raw.stats?.visitedLocations||{})}},
      profile:{...base.profile,...(raw.profile||{}),firstClears:{...(raw.profile?.firstClears||{})},rankRewards:[...(raw.profile?.rankRewards||[])]},
      inventory:{...base.inventory,...(raw.inventory||{})},
      pokemon:{...(raw.pokemon||{})},cards:{...(raw.cards||{})},team:[...(raw.team||[])],recentPokemon:[...(raw.recentPokemon||[])],rareHits:[...(raw.rareHits||[])],
      claimedMilestones:{dex:[...(raw.claimedMilestones?.dex||[])],cards:[...(raw.claimedMilestones?.cards||[])]},
      arcade:{...base.arcade,...(raw.arcade||{}),dailyRewards:{...base.arcade.dailyRewards,...(raw.arcade?.dailyRewards||{})},bestBerryPicker:{...base.arcade.bestBerryPicker,...(raw.arcade?.bestBerryPicker||{})},bestHeadIt:{...base.arcade.bestHeadIt,...(raw.arcade?.bestHeadIt||{})},bestTilePuzzle:{...base.arcade.bestTilePuzzle,...(raw.arcade?.bestTilePuzzle||{})}},daily:{...base.daily,...(raw.daily||{})},
      ui:{...base.ui,...(raw.ui||{}),packBrowser:{...base.ui.packBrowser,...(raw.ui?.packBrowser||{})},packMetrics:{...(raw.ui?.packMetrics||{})}}
    };
    if(!raw.arcade?.lastArcadeVenue){const venueMap={amie:'amieGarden',gameCorner:'goldenrod',discovery:'oreburghMuseum',performance:'lilycoveContest'};migrated.arcade.lastArcadeVenue=venueMap[raw.arcade?.lastArcadeZone]||'amieGarden';}
    if(!raw.saveVersion){
      if(Number(migrated.settings.shinyOdds)===512) migrated.settings.shinyOdds=2048;
      migrated.stats.catches ||= Object.values(migrated.pokemon).reduce((n,p)=>n+Number(p.count||0),0);
      Object.values(migrated.cards).forEach(c=>{ if(!c.setName&&c.set)c.setName=c.set; if(!c.setId&&c.id?.includes('-'))c.setId=c.id.split('-').slice(0,-1).join('-'); });
    }
    if(Number(raw.saveVersion||0)<3){
      const uniquePokemon=new Set(Object.values(migrated.pokemon).map(p=>p.id)).size;
      const uniqueCards=Object.keys(migrated.cards).length;
      if(!raw.profile){
        migrated.profile.xp=uniquePokemon*60+uniqueCards*8+Number(migrated.stats.shinies||0)*250+Number(migrated.stats.packs||0)*25;
        migrated.profile.coins=1000+uniquePokemon*20+Number(migrated.stats.packs||0)*60;
        migrated.profile.tickets=Math.max(1,Math.floor(Number(migrated.stats.packs||0)/10));
      }
      Object.entries(migrated.pokemon).forEach(([key,p])=>{
        p.level=Number(p.level||Math.min(30,5+Math.max(0,Number(p.count||1)-1)*2));
        p.xp=Number(p.xp||0); p.types=Array.isArray(p.types)?p.types:[]; p.baseStats=p.baseStats||null;
        p.generation=p.generation||generationForId(p.id).id;
      });
      if(!migrated.team.length) migrated.team=bestAutoTeam(migrated.pokemon);
    }
    if(Number(raw.saveVersion||0)<4){
      migrated.inventory.potion=Number(migrated.inventory.potion||5);
      migrated.stats.visitedLocations={...(migrated.stats.visitedLocations||{})};
      migrated.profile.achievementClaims=[...(migrated.profile.achievementClaims||[])];
      migrated.profile.shinyCharmFragments=Number(migrated.profile.shinyCharmFragments||0);
      migrated.daily={...cloneDefault().daily,...(migrated.daily||{}),progress:{...(migrated.daily?.progress||{})}};
    }
    migrated.saveVersion=6;
    resetDaily(migrated);
    window.LuckyDexAdventureModel?.ensureState(migrated);
    return migrated;
  }catch(e){ const s=cloneDefault(); resetDaily(s); window.LuckyDexAdventureModel?.ensureState(s); return s; }
}
function dailyTaskIdsFor(date,rank=1){let seed=[...date].reduce((n,ch)=>(n*31+ch.charCodeAt(0))>>>0,2166136261);const pool=DAILY_POOL.filter(x=>(x.rank||1)<=rank);for(let i=pool.length-1;i>0;i--){seed=(seed*1664525+1013904223)>>>0;const j=seed%(i+1);[pool[i],pool[j]]=[pool[j],pool[i]];}return pool.slice(0,3).map(x=>x.id);}
function resetDaily(s=state){const t=todayKey();if(s.daily.date!==t){s.daily={date:t,tasks:dailyTaskIdsFor(t,rankForXp(Number(s.profile?.xp||0))),progress:{},claimed:false};}else if(!Array.isArray(s.daily.tasks)||!s.daily.tasks.length){s.daily.tasks=dailyTaskIdsFor(t,rankForXp(Number(s.profile?.xp||0)));s.daily.progress={caught:Number(s.daily.caught||0),arcadeCoins:Number(s.daily.arcadeCoins||0),adventureClears:Number(s.daily.adventureClears||0),...(s.daily.progress||{})};s.daily.claimed=!!s.daily.claimed;}}
function bumpDaily(key,amount=1){resetDaily();state.daily.progress[key]=Number(state.daily.progress[key]||0)+amount;}
function save(){
  state.saveVersion=6;resetDaily();localStorage.setItem('luckyDexSave',JSON.stringify(state));
  // Persistence must never fail just because a secondary HUD renderer has a bug.
  // v0.15.5-v0.15.7 could save the starter and then throw while updating the pack
  // HUD, leaving the visible screen frozen even though progress had changed.
  try{renderGlobalHud();}catch(e){console.error('[LuckyDex] HUD render failed',e);}
}
function fmt(n){ return Number(n||0).toLocaleString(); }
function titleCase(s=''){ return String(s).replaceAll('-',' ').replace(/\b\w/g,c=>c.toUpperCase()); }
function delay(ms){ return new Promise(r=>setTimeout(r,ms)); }
function clamp(n,a,b){ return Math.max(a,Math.min(b,n)); }
function vibrate(ms=30){ if(state.settings.vibration&&navigator.vibrate)navigator.vibrate(ms); }
function escapeHtml(s=''){ return String(s).replace(/[&<>'"]/g,ch=>({'&':'&amp;','<':'&lt;','>':'&gt;',"'":'&#39;','"':'&quot;'}[ch])); }

function humanCardText(value,fallback='Card'){
  const raw=String(value??'').trim();if(!raw)return fallback;
  if(/(?:https?:\/\/|[\\/]|\.(?:webp|png|jpe?g|gif|json|zip)\b|^file\b|\b(?:source[_ -]?url|provider|asset|filepath|filename)\b)/i.test(raw))return fallback;
  if(raw==='[object Object]')return fallback;
  return raw.length>60?raw.slice(0,57)+'…':raw;
}
function cardDisplayMeta(card){
  const rarity=humanCardText(card?.rarity||'','');
  const setName=humanCardText(cardSetName(card),'Card');
  const number=humanCardText(card?.localId||card?.number||'','');
  return [number?`#${number}`:'',rarity&&!/^(?:unknown|none)$/i.test(rarity)?rarity:setName].filter(Boolean).join(' · ');
}
async function fetchJson(url,timeoutMs=3200){
  const controller=new AbortController(),timer=setTimeout(()=>controller.abort(),Math.max(500,Number(timeoutMs)||3200));
  try{const r=await fetch(url,{signal:controller.signal,cache:'no-cache'});if(!r.ok)throw new Error(`${r.status}`);return await r.json();}
  finally{clearTimeout(timer);}
}
function showToast(text,duration=1900){ const el=document.getElementById('toast');el.textContent=text;el.classList.add('show');clearTimeout(toastTimer);toastTimer=setTimeout(()=>el.classList.remove('show'),duration); }
function generationForId(id){ return GENERATIONS.find(g=>id>=g.min&&id<=g.max)||GENERATIONS[GENERATIONS.length-1]; }
function numericLocalId(v){ const m=String(v||'').match(/\d+/);return m?Number(m[0]):99999; }
function rankForXp(xp=state.profile.xp){ return Math.min(50,1+Math.floor(Number(xp||0)/400)); }
function rankProgress(){ const rank=rankForXp(),within=Number(state.profile.xp||0)%400; return {rank,within,next:400,pct:(within/400)*100}; }
function bestAutoTeam(map=state.pokemon){ return Object.entries(map).sort((a,b)=>Number(b[1].shiny)-Number(a[1].shiny)||Number(b[1].level||0)-Number(a[1].level||0)||Number(b[1].count||0)-Number(a[1].count||0)).slice(0,3).map(([k])=>k); }
function hasSpecies(id){ return Object.values(state.pokemon).some(p=>Number(p.id)===Number(id)); }
function currentRank(){ return rankForXp(); }
function effectiveShinyOdds(){const completedCharms=Math.floor(Number(state.profile.shinyCharmFragments||0)/3);return Math.max(64,Math.round(Number(state.settings.shinyOdds||2048)/(1+completedCharms*.34)));}
function cardImage(base,q='high'){ return base?`${base}/${q}.webp`:''; }
function assetImage(base){ return base?`${base}.webp`:''; }
function cardArtHtml(base,name){ return `<div class="card-art-wrap ${base?'':'broken'}"><img ${base?`src="${cardImage(base)}"`:''} data-card-base="${escapeHtml(base||'')}" data-fallback-step="0" alt="${escapeHtml(name||'Card')}" onerror="cardImageFallback(this)"><div class="card-art-fallback">Artwork unavailable<br><small>${escapeHtml(name||'Card')}</small></div></div>`; }
function cardImageFallback(img){ const base=img.dataset.cardBase||'';const step=Number(img.dataset.fallbackStep||0);if(base&&step===0){img.dataset.fallbackStep='1';img.src=cardImage(base,'low');return;}img.parentElement?.classList.add('broken'); }
window.cardImageFallback=cardImageFallback;

function rarityTier(rarity=''){
  if(window.LuckyDexPack?.profileFor)return LuckyDexPack.profileFor({rarity}).level;
  const x=String(rarity||'').toLowerCase();
  if(/crown|gold rare|hyper rare|legend/.test(x))return 6;
  if(/rainbow|special illustration|secret rare/.test(x))return 5;
  if(/illustration|ultra rare/.test(x))return 4;
  if(/double rare/.test(x))return 3;
  if(/rare|holo/.test(x))return 2;
  if(/uncommon/.test(x))return 1;
  return /common/.test(x)?0:1;
}
function looksRare(r=''){ return rarityTier(r)>=3; }
function tierLabel(t){ return ['Common','Uncommon','Rare','Double rare','Illustration/ultra','Special rare','Jackpot'][clamp(t,0,6)]; }
function dustForTier(t){ return [1,2,3,6,12,24,50][clamp(t,0,6)]; }
function rollWeighted(entries){ const r=Math.random();let acc=0;for(const [value,p] of entries){acc+=p;if(r<acc)return value;}return entries.at(-1)[0]; }
function hitTierForSource(source){ return rollWeighted(source==='tcgp'?[[2,.60],[3,.28],[4,.09],[5,.025],[6,.005]]:[[2,.62],[3,.25],[4,.09],[5,.035],[6,.005]]); }

function grantCoins(amount,source='Reward'){ amount=Math.max(0,Math.round(amount));state.profile.coins+=amount;save();if(amount)showToast(`${source}: +${fmt(amount)} Lucky Coins`); }
function addTrainerXp(amount){
  amount=Math.max(0,Math.round(amount));const oldRank=currentRank();state.profile.xp+=amount;const newRank=currentRank();
  if(newRank>oldRank){for(let r=oldRank+1;r<=newRank;r++){if(!state.profile.rankRewards.includes(r)){state.profile.rankRewards.push(r);state.profile.coins+=150;if(r%5===0)state.profile.tickets++;}}vibrate([30,30,80]);showToast(`Trainer Rank ${newRank}! +150 coins${newRank%5===0?' + Pack Ticket':''}`,2600);}
}
function grantTrainerXp(amount){addTrainerXp(amount);save();}
function trackDaily(kind,amount=1){bumpDaily(kind,amount);save();}

document.querySelectorAll('[data-nav]').forEach(b=>b.addEventListener('click',()=>navigate(b.dataset.nav)));

async function initSpecies(){
  // Seed synchronously so title/starter/adventure never wait on PokeAPI.
  try{const cached=JSON.parse(localStorage.getItem('luckyDexSpecies')||'null');if(Array.isArray(cached)&&cached.length)species=cached.filter(x=>Number(x.id)<=MAX_DEX_ID);}catch(e){}
  if(!species.length)species=Array.from({length:151},(_,i)=>({id:i+1,name:STARTER_META[i+1]?.name||`pokemon-${i+1}`}));
  try{
    const data=await fetchJson(API.pokeSpecies,3200);
    const fresh=(data.results||[]).map(x=>({name:x.name,id:Number(x.url.split('/').filter(Boolean).pop())})).filter(x=>Number.isFinite(x.id)&&x.id<=MAX_DEX_ID);
    if(fresh.length){species=fresh;localStorage.setItem('luckyDexSpecies',JSON.stringify(species));}
  }catch(e){}
  return species;
}
async function loadPokemonMeta(id){
  id=Number(id);if(pokemonMetaCache.has(id))return pokemonMetaCache.get(id);
  try{
    const d=await fetchJson(API.pokemon(id),2800),base={};(d.stats||[]).forEach(s=>base[s.stat.name]=s.base_stat);
    const meta={id,name:d.name,types:(d.types||[]).sort((a,b)=>a.slot-b.slot).map(t=>t.type.name),baseStats:{hp:base.hp||60,attack:base.attack||60,defense:base.defense||60,speed:base.speed||60}};pokemonMetaCache.set(id,meta);return meta;
  }catch(e){
    const seed=STARTER_META[id],meta=seed?{...seed,types:[...seed.types],baseStats:{...seed.baseStats}}:{id,name:species.find(p=>Number(p.id)===id)?.name||`pokemon-${id}`,types:['normal'],baseStats:{hp:60,attack:60,defense:60,speed:60}};
    // Cache the fallback for this session so repeated offline actions stay fast.
    pokemonMetaCache.set(id,meta);return meta;
  }
}
async function ensurePokemonBuild(entry){
  if(entry.types?.length&&entry.baseStats)return entry;
  const seed=STARTER_META[Number(entry.id)]||{name:entry.name||`pokemon-${entry.id}`,types:['normal'],baseStats:{hp:60,attack:60,defense:60,speed:60}};
  entry.name=entry.name||seed.name;entry.types=[...(seed.types||['normal'])];entry.baseStats={...(seed.baseStats||{hp:60,attack:60,defense:60,speed:60})};
  // Persist an immediately usable build, then improve it in the background.
  try{localStorage.setItem('luckyDexSave',JSON.stringify(state));}catch(e){}
  loadPokemonMeta(entry.id).then(m=>{if(!Object.values(state.pokemon).includes(entry))return;entry.name=m.name||entry.name;entry.types=m.types||entry.types;entry.baseStats=m.baseStats||entry.baseStats;try{localStorage.setItem('luckyDexSave',JSON.stringify(state));}catch(e){}}).catch(()=>{});
  return entry;
}
function combatStats(entryOrMeta,level){ const b=entryOrMeta.baseStats||{hp:60,attack:60,defense:60,speed:60};return {maxHp:Math.round(b.hp*.55+level*4+18),attack:Math.round(b.attack*.28+level*2.1+8),defense:Math.round(b.defense*.28+level*2+8),speed:Math.round(b.speed*.22+level*1.6+6)}; }
function xpNeeded(level){return 80+level*30;}
function grantPokemonXp(key,amount){const p=state.pokemon[key];if(!p)return; p.xp=Number(p.xp||0)+amount;let leveled=0;while(p.level<50&&p.xp>=xpNeeded(p.level)){p.xp-=xpNeeded(p.level);p.level++;leveled++;}if(leveled)showToast(`${titleCase(p.name)} reached Lv. ${p.level}!`);save();}
function typeEffectiveness(att,defs=[]){let mult=1;for(const d of defs){if((IMMUNE[att]||[]).includes(d))mult*=0;else if((SUPER[att]||[]).includes(d))mult*=2;else if((WEAK[att]||[]).includes(d))mult*=.5;}return mult;}
function damageRoll(attacker,defender,power,type){const eff=typeEffectiveness(type,defender.types);const variance=.86+Math.random()*.22;const dmg=Math.max(1,Math.round(power*(attacker.attack/Math.max(1,defender.defense))*.44*variance*eff));return {dmg,eff};}

async function loadZonePool(zoneKey){
  if(zonePools[zoneKey]?.length)return zonePools[zoneKey];
  const cacheKey=`luckyDexZonePool:${zoneKey}:v2`;
  try{const cached=JSON.parse(localStorage.getItem(cacheKey)||'null');if(Array.isArray(cached)&&cached.length>20){zonePools[zoneKey]=cached;return cached;}}catch(e){}
  const seed=(LOCAL_ZONE_POOLS[zoneKey]||[]).map(([id,name])=>({id,name}));
  zonePools[zoneKey]=seed.length?seed:(species.length?species.slice(0,151):[{id:25,name:'pikachu'}]);
  // Never block a search on the network. Refresh the richer type pool behind
  // the scenes and use it on the next encounter/session.
  if(navigator.onLine!==false&&!zonePoolRefreshJobs[zoneKey]){
    const zone=ZONES[zoneKey];
    zonePoolRefreshJobs[zoneKey]=(async()=>{
      try{
        const lists=await Promise.all(zone.types.map(t=>fetchJson(API.pokeType(t),2800))),map=new Map();
        lists.forEach(data=>(data.pokemon||[]).forEach(row=>{const p=row.pokemon||{},id=Number((p.url||'').split('/').filter(Boolean).pop());if(id>0&&id<=MAX_DEX_ID)map.set(id,{id,name:p.name});}));
        const pool=[...map.values()];if(pool.length>=20){zonePools[zoneKey]=pool;try{localStorage.setItem(cacheKey,JSON.stringify(pool));}catch(e){}}
      }catch(e){}finally{delete zonePoolRefreshJobs[zoneKey];}
    })();
  }
  return zonePools[zoneKey];
}
async function chooseStarter(id){
  id=Number(id);if(starterChoiceInFlight||Object.keys(state.pokemon).length)return;
  starterChoiceInFlight=true;document.querySelectorAll('[data-starter]').forEach(b=>b.disabled=true);
  const seed=STARTER_META[id]||{id,name:`pokemon-${id}`,types:['normal'],baseStats:{hp:60,attack:60,defense:60,speed:60}},name=seed.name,key=`${id}:n`;
  // Commit the choice before touching the network. This prevents the old bug
  // where several taps queued several async starter grants while the screen
  // appeared frozen.
  state.pokemon[key]={id,name,shiny:false,count:1,firstSeen:Date.now(),generation:generationForId(id).id,level:5,xp:0,types:[...seed.types],baseStats:{...seed.baseStats},lastZone:'meadow'};
  state.team=[key];state.profile.coins+=250;state.inventory.pokeball+=10;state.recentPokemon.unshift({id,name,shiny:false,zone:'meadow',ts:Date.now()});
  save();document.getElementById('starterPanel').hidden=true;renderTeamPanel();renderTitlePartners();renderAdventurePartyMini();showAdventureHub();showToast(`${titleCase(name)} joined you! +10 Poké Balls`);
  try{const meta=await loadPokemonMeta(id),entry=state.pokemon[key];if(entry){entry.name=meta.name||entry.name;entry.types=meta.types||entry.types;entry.baseStats=meta.baseStats||entry.baseStats;save();renderTeamPanel();renderTitlePartners();renderAdventurePartyMini();}}catch(e){}
  finally{starterChoiceInFlight=false;}
}
function helperAbility(entry){const types=entry?.types||[];if(types.includes('electric'))return {game:'voltorb',name:'Static Scan',desc:'Once per Voltorb board, inspect one hidden tile for danger.'};if(types.includes('psychic'))return {game:'clefairy',name:'Second Sight',desc:'Replay the current Clefairy sequence once per game.'};if(types.includes('grass'))return {game:'berry',name:'Gentle Hands',desc:'Widens the perfect timing zone in Berry Blend.'};if(types.includes('water'))return {game:'berry',name:'Cool Blend',desc:'Berry Blend coin payout +10%.'};if([52,53].includes(Number(entry?.id)))return {game:'all',name:'Pickup',desc:'All Arcade coin payouts +10%.'};return {game:'all',name:'Lucky Cheer',desc:'Your partner cheers you on. No mechanical bonus yet.'};}
function arcadePayoutBonus(amount,game){const e=state.pokemon[state.team[0]],a=helperAbility(e);if(a.name==='Pickup')amount*=1.1;if(a.name==='Cool Blend'&&game==='berry')amount*=1.1;return Math.round(amount);}
function awardArcadeCoins(amount,label,game='all'){amount=arcadePayoutBonus(amount,game);state.profile.coins+=amount;state.stats.arcadeCoins+=amount;state.stats.arcadeGames++;bumpDaily('arcadeCoins',amount);addTrainerXp(Math.min(120,Math.round(amount/10)));save();showToast(`${label}: +${fmt(amount)} Lucky Coins`);renderProfile();return amount;}
async function getCardDetail(brief){if(cardDetailCache.has(brief.id))return cardDetailCache.get(brief.id);let card;try{card=await fetchJson(API.card(brief.id));}catch(e){card={...brief,rarity:'Unknown'};}cardDetailCache.set(brief.id,card);return card;}
async function pickCardForTier(briefs,targetTier,used){const pool=briefs.filter(c=>!used.has(c.id));if(!pool.length)return getCardDetail(briefs[Math.floor(Math.random()*briefs.length)]);const maxAttempts=targetTier>=5?20:targetTier>=4?14:9;const tried=new Set();let best=null,bestDistance=999;for(let i=0;i<maxAttempts&&tried.size<pool.length;i++){let brief;do{brief=pool[Math.floor(Math.random()*pool.length)];}while(tried.has(brief.id)&&tried.size<pool.length);tried.add(brief.id);const card=await getCardDetail(brief),tier=rarityTier(card.rarity),distance=Math.abs(tier-targetTier);if(distance<bestDistance||(distance===bestDistance&&tier<=(best?rarityTier(best.rarity):99))){best=card;bestDistance=distance;}if(tier===targetTier)return card;}return best||getCardDetail(pool[0]);}
async function buildBalancedPack(set,source,luckyPack=false){const briefs=set.cards||[];if(!briefs.length)throw new Error('No cards');const hitTier=hitTierForSource(source);const plan=luckyPack?[4,4,4,5,6]:(source==='tcgp'?[0,0,1,rollWeighted([[1,.72],[2,.25],[3,.03]]),hitTier]:[0,1,1,rollWeighted([[1,.55],[2,.38],[3,.07]]),hitTier]);const cards=[],used=new Set();for(const target of plan){const card=await pickCardForTier(briefs,target,used);cards.push(card);used.add(card.id);}return cards;}
function packEntitlement(){const source=document.getElementById('cardSource')?.value||'tcg';if(state.profile.lastDailyPack!==todayKey())return {mode:'daily',label:'FREE DAILY PACK',cost:0};if(state.profile.tickets>0)return {mode:'ticket',label:'USE PACK TICKET',cost:0};const cost=PACK_COST[source];return {mode:'coins',label:`OPEN · ${fmt(cost)} COINS`,cost};}
function updatePackButton(){const btn=document.getElementById('openPackBtn');if(!btn)return;const e=packEntitlement();btn.textContent=e.label;btn.disabled=e.mode==='coins'&&state.profile.coins<e.cost;document.getElementById('dailyPackPill').textContent=state.profile.lastDailyPack!==todayKey()?'Daily ready':'Daily claimed';document.getElementById('packPriceCopy').textContent=e.mode==='daily'?'Your first pack today is free.':e.mode==='ticket'?'A Pack Ticket will be used.':`${fmt(e.cost)} Lucky Coins · earn more in Arcade/Adventure`;document.getElementById('dustExchangeBtn').disabled=state.profile.dust<100;}



function consumePackEntitlement(){const e=preparedPack.entitlement;if(e.mode==='daily')state.profile.lastDailyPack=todayKey();else if(e.mode==='ticket')state.profile.tickets=Math.max(0,state.profile.tickets-1);else state.profile.coins=Math.max(0,state.profile.coins-e.cost);}
function existingPhysicalCardForLibraryPullV165(card,set){
  if(!card?._libraryNative||card?._librarySetKey==='MFB')return null;
  const wantedSet=normalizeSetNameV5(card?.set?.name||set?.name||''),wantedName=normalizeSetNameV5(card?.name||'');
  const wantedNumbers=new Set(physicalCollectorNumbersV163(card));
  if(!wantedSet||!wantedName||!wantedNumbers.size)return null;
  let hit=null;
  for(const [id,owned] of Object.entries(state.cards||{})){
    if((owned?.source||'tcg')==='tcgp')continue;
    if(owned?._libraryCanonicalId){if(owned._libraryCanonicalId===card._libraryCanonicalId)return {id,card:owned};continue;}
    if(normalizeSetNameV5(owned?.setName||owned?.set?.name||'')!==wantedSet)continue;
    if(normalizeSetNameV5(owned?.name||'')!==wantedName)continue;
    const numbers=physicalCollectorNumbersV163(owned);if(!numbers.some(n=>wantedNumbers.has(n)))continue;
    if(hit)return null; // ambiguous legacy identity: never merge by guess
    hit={id,card:owned};
  }
  return hit;
}
function commitPreparedPack(){
  if(!preparedPack||preparedPack.committed)return;
  consumePackEntitlement();
  const {cards,set,source}=preparedPack;
  state.stats.packs++;bumpDaily('packs',1);state.stats.cardsPulled+=cards.length;
  const bigHits=cards.filter(c=>rarityTier(c.rarity)>=4).length;
  state.stats.maxBigHitsInPack=Math.max(Number(state.stats.maxBigHitsInPack||0),bigHits);
  state.stats.goldCards+=cards.filter(c=>source==='tcgp'&&/(crown|gold)/i.test(String(c.rarity||''))).length;
  if(preparedPack.luckyPack)state.rareHits.unshift({type:'pack',name:'✦ Lucky Pack',rarity:'~1/2,000 event',ts:Date.now()});
  cards.forEach(c=>{
    let storageId=c.id,existing=state.cards[storageId];
    if(!existing&&source==='tcg'&&c?._libraryNative){const legacy=existingPhysicalCardForLibraryPullV165(c,set);if(legacy){storageId=legacy.id;existing=legacy.card;}}
    c._wasNew=!existing;
    const old=existing||{id:storageId,name:c.name,image:c.image,localId:c.localId,setId:c.set?.id||set.id,setName:c.set?.name||set.name,setTotal:c.set?.cardCount?.total||set.cardCount?.total||0,source,rarity:c.rarity||'Unknown',count:0,firstPulled:Date.now()};
    if(existing)state.profile.dust+=dustForTier(rarityTier(c.rarity||old.rarity));
    old.count++;old.image=c.image||old.image;old.localId=c.localId||old.localId;old.rarity=c.rarity||old.rarity;
    old.setId=c.set?.id||old.setId||set.id;old.setName=c.set?.name||old.setName||set.name;old.setTotal=c.set?.cardCount?.total||old.setTotal||set.cardCount?.total||0;old.source=source||old.source;
    if(c._tcgpFallbacks?.length)old._tcgpFallbacks=[...c._tcgpFallbacks];if(c._limitlessSetCode)old._limitlessSetCode=c._limitlessSetCode;if(c._pocketImageFile)old._pocketImageFile=c._pocketImageFile;if(c._pocketNative)old._pocketNative=true;
    if(c._libraryNative)old._libraryNative=true;if(c._librarySetKey)old._librarySetKey=c._librarySetKey;if(c._libraryCanonicalId)old._libraryCanonicalId=c._libraryCanonicalId;if(c._artSource)old._artSource=c._artSource;if(c._artIdentityVerified)old._artIdentityVerified=true;
    state.cards[storageId]=old;
    addTrainerXp(existing?3:12);
    if(looksRare(c.rarity||'')){addTrainerXp(25);state.rareHits.unshift({type:'card',name:c.name,rarity:c.rarity,set:old.setName,tier:rarityTier(c.rarity),ts:Date.now()});}
  });
  state.rareHits=state.rareHits.slice(0,50);preparedPack.committed=true;checkCardMilestones(set.id);save();updatePackButton();
}


function exchangeDust(){if(state.profile.dust<100){showToast('You need 100 Card Dust.');return;}state.profile.dust-=100;state.profile.tickets++;save();showToast('100 Card Dust → 1 Pack Ticket');}

function cardSetKey(c){return c.setId||c.setName||c.set||'Unknown set';}function cardSetName(c){return c.setName||c.set||c.setId||'Unknown set';}
function ownedRangeCount(min,max){return new Set(Object.values(state.pokemon).filter(p=>Number(p.id)>=min&&Number(p.id)<=max).map(p=>Number(p.id))).size;}
function ownedTypeCount(type){return new Set(Object.values(state.pokemon).filter(p=>(p.types||[]).includes(type)).map(p=>Number(p.id))).size;}
function setCompletionProgress(pattern){const rows=Object.values(state.cards).filter(c=>pattern.test(String(cardSetName(c))));if(!rows.length)return [0,1];const total=Math.max(...rows.map(c=>Number(c.setTotal||0)),0);const owned=new Set(rows.map(c=>c.id)).size;return [owned,total||Math.max(1,owned+1)];}
function achievementProgress(a){try{const [value,target]=a.progress();return {value:Number(value||0),target:Math.max(1,Number(target||1)),complete:Number(value||0)>=Number(target||1),claimed:state.profile.achievementClaims.includes(a.id)};}catch(e){return {value:0,target:1,complete:false,claimed:false};}}
function rewardText(r={}){const bits=[];if(r.coins)bits.push(`◉ ${fmt(r.coins)}`);if(r.tickets)bits.push(`🎟 ×${r.tickets}`);if(r.fragment)bits.push(`✨ Charm Fragment ×${r.fragment}`);return bits.join(' · ');}
function claimAchievement(id){const a=ACHIEVEMENTS.find(x=>x.id===id);if(!a)return;const p=achievementProgress(a);if(!p.complete||p.claimed)return;state.profile.achievementClaims.push(id);state.profile.coins+=Number(a.reward?.coins||0);state.profile.tickets+=Number(a.reward?.tickets||0);state.profile.shinyCharmFragments+=Number(a.reward?.fragment||0);addTrainerXp(100+Number(a.reward?.fragment||0)*100);save();vibrate([20,25,60]);showToast(`${a.name} complete · ${rewardText(a.reward)}`,2800);renderAchievements();renderProfile();}
function renderAchievements(){const list=document.getElementById('achievementList');if(!list)return;const rows=ACHIEVEMENTS.map(a=>({a,p:achievementProgress(a)}));const earned=rows.filter(x=>x.p.complete).length;document.getElementById('achievementCountPill').textContent=`${earned}/${ACHIEVEMENTS.length} earned`;let shown=rows.filter(({a,p})=>challengeTab==='complete'?p.complete&&!a.hidden:challengeTab==='hidden'?a.hidden:( !a.hidden&&!p.claimed));if(challengeTab==='active')shown.sort((x,y)=>Number(y.p.complete)-Number(x.p.complete)||y.p.value/y.p.target-x.p.value/x.p.target);list.innerHTML=shown.length?shown.map(({a,p})=>{const secret=a.hidden&&!p.complete;const pct=clamp(p.value/p.target*100,0,100);return `<div class="achievement-row ${p.complete?'complete':''} ${p.claimed?'claimed':''} ${secret?'secret-card':''}"><div class="achievement-icon">${secret?'?':a.icon}</div><div><b>${secret?'Secret achievement':escapeHtml(a.name)}</b><span>${secret?'Keep exploring Lucky Dex to uncover this.':escapeHtml(a.desc)}</span>${!secret?`<div class="progress-track"><i style="width:${pct}%"></i></div><small>${Math.min(p.value,p.target)} / ${p.target}</small>`:''}</div><div>${!secret?`<span class="achievement-reward">${rewardText(a.reward)}</span>`:''}${p.complete&&!p.claimed?`<button class="primary" data-claim-achievement="${a.id}">CLAIM</button>`:p.claimed?'<span class="achievement-reward">✓ CLAIMED</span>':''}</div></div>`;}).join(''):'<div class="empty compact-empty">Nothing in this tab yet.</div>';list.querySelectorAll('[data-claim-achievement]').forEach(b=>b.onclick=()=>claimAchievement(b.dataset.claimAchievement));}
function checkDexMilestones(id){const g=generationForId(id),owned=new Set(Object.values(state.pokemon).filter(p=>p.id>=g.min&&p.id<=g.max).map(p=>p.id)).size,total=g.max-g.min+1;for(const [pct,coins,ticket] of [[.25,250,0],[.5,600,0],[1,1500,1]]){if(owned/total>=pct){const k=`g${g.id}:${pct}`;if(!state.claimedMilestones.dex.includes(k)){state.claimedMilestones.dex.push(k);state.profile.coins+=coins;state.profile.tickets+=ticket;showToast(`Gen ${g.id} ${Math.round(pct*100)}% milestone · +${coins} coins${ticket?' + ticket':''}`,2600);}}}}
function checkCardMilestones(setId){const cards=Object.values(state.cards).filter(c=>cardSetKey(c)===setId),total=Number(cards[0]?.setTotal||0);if(!total)return;const owned=new Set(cards.map(c=>c.id)).size;for(const [pct,coins,ticket] of [[.25,250,0],[.5,500,0],[1,1000,1]]){if(owned/total>=pct){const k=`${setId}:${pct}`;if(!state.claimedMilestones.cards.includes(k)){state.claimedMilestones.cards.push(k);state.profile.coins+=coins;state.profile.tickets+=ticket;showToast(`${cardSetName(cards[0])} ${Math.round(pct*100)}% · +${coins} coins${ticket?' + ticket':''}`,2600);}}}}
function rebuildCollectionControls(){const filter=document.getElementById('collectionFilter'),group=document.getElementById('collectionGroupFilter'),oldFilter=filter.value,oldGroup=group.value;if(collectionMode==='pokemon'){filter.innerHTML='<option value="all">All caught</option><option value="shiny">Shiny only</option><option value="team">Adventure team</option><option value="duplicates">Duplicates</option>';const ids=new Set(Object.values(state.pokemon).map(x=>x.id)),ownedGens=GENERATIONS.filter(g=>[...ids].some(id=>id>=g.min&&id<=g.max));group.innerHTML='<option value="all">All generations</option>'+ownedGens.map(g=>{const n=[...ids].filter(id=>id>=g.min&&id<=g.max).length;return `<option value="gen:${g.id}">Gen ${g.id} · ${escapeHtml(g.name)} · ${n}/${g.max-g.min+1}</option>`;}).join('');}else{filter.innerHTML='<option value="all">All cards</option><option value="rare">Rare hits</option><option value="duplicates">Duplicates</option>';const map=new Map();Object.values(state.cards).forEach(c=>{const k=cardSetKey(c),row=map.get(k)||{key:k,name:cardSetName(c),ids:new Set(),total:Number(c.setTotal||0)};row.ids.add(c.id);row.total=Math.max(row.total,Number(c.setTotal||0));map.set(k,row);});group.innerHTML='<option value="all">All owned sets</option>'+[...map.values()].sort((a,b)=>a.name.localeCompare(b.name)).map(s=>`<option value="set:${escapeHtml(s.key)}">${escapeHtml(s.name)} · ${s.ids.size}${s.total?`/${s.total}`:''}</option>`).join('');}if([...filter.options].some(o=>o.value===oldFilter))filter.value=oldFilter;if([...group.options].some(o=>o.value===oldGroup))group.value=oldGroup;document.getElementById('teamPanel').hidden=collectionMode!=='pokemon';}
function renderCollectionProgress(items,allItems){const el=document.getElementById('collectionProgress'),group=document.getElementById('collectionGroupFilter').value;let title=collectionMode==='pokemon'?'Pokédex':'Card binder',owned=0,total=0,sub='';if(collectionMode==='pokemon'){const unique=new Set(items.map(x=>x.id));owned=unique.size;if(group.startsWith('gen:')){const g=GENERATIONS.find(x=>x.id===Number(group.split(':')[1]));total=g.max-g.min+1;title=`Gen ${g.id} · ${g.name}`;sub=`${owned} of ${total} species caught`; }else{owned=new Set(allItems.map(x=>x.id)).size;total=MAX_DEX_ID;sub=`${owned} species caught across all generations`;}}else{owned=new Set(items.map(x=>x.id)).size;if(group.startsWith('set:')){const first=items[0];total=Number(first?.setTotal||0);title=first?cardSetName(first):'Set';sub=total?`${owned} of ${total} cards collected`:`${owned} unique cards collected`;}else{owned=new Set(allItems.map(x=>x.id)).size;sub=`${owned} unique cards across ${new Set(allItems.map(cardSetKey)).size} sets`;}}const pct=total?clamp(owned/total*100,0,100):0;el.innerHTML=`<div><b>${escapeHtml(title)}</b><span>${escapeHtml(sub)}</span></div>${total?`<div class="progress-track"><i style="width:${pct}%"></i></div>`:''}`;}
function renderCollection(){
  const q=document.getElementById('collectionSearch').value.toLowerCase(),filter=document.getElementById('collectionFilter').value,group=document.getElementById('collectionGroupFilter').value,grid=document.getElementById('collectionGrid'),allItems=Object.values(collectionMode==='pokemon'?state.pokemon:state.cards);
  let items=allItems.filter(x=>(x.name||'').toLowerCase().includes(q));
  const quick=document.getElementById('binderQuickFilters'),dupCount=document.getElementById('binderDuplicateCount');
  if(quick)quick.hidden=collectionMode!=='cards';if(dupCount)dupCount.textContent=Object.values(state.cards||{}).filter(x=>Number(x.count||0)>1).length;
  document.querySelectorAll('[data-binder-filter]').forEach(b=>b.classList.toggle('active',collectionMode==='cards'&&b.dataset.binderFilter===filter));
  if(collectionMode==='pokemon'){
    if(group.startsWith('gen:')){const g=GENERATIONS.find(x=>x.id===Number(group.split(':')[1]));items=items.filter(x=>x.id>=g.min&&x.id<=g.max);}if(filter==='shiny')items=items.filter(x=>x.shiny);if(filter==='team')items=items.filter(x=>state.team.includes(`${x.id}:${x.shiny?'s':'n'}`));if(filter==='duplicates')items=items.filter(x=>x.count>1);items.sort((a,b)=>group==='all'?(b.firstSeen||0)-(a.firstSeen||0):a.id-b.id||Number(b.shiny)-Number(a.shiny));
  }else{
    if(group.startsWith('set:')){const key=group.slice(4);items=items.filter(x=>cardSetKey(x)===key);}if(filter==='rare')items=items.filter(x=>looksRare(x.rarity));if(filter==='duplicates')items=items.filter(x=>Number(x.count||0)>1);items.sort((a,b)=>group==='all'?(b.firstPulled||0)-(a.firstPulled||0):numericLocalId(a.localId)-numericLocalId(b.localId)||a.name.localeCompare(b.name));
  }
  renderCollectionProgress(items,allItems);if(!items.length){grid.innerHTML=`<div class="empty">${collectionMode==='cards'&&filter==='duplicates'?'No spare card copies yet.':'Nothing here yet.'}</div>`;return;}
  grid.innerHTML=items.map(x=>collectionMode==='pokemon'?(()=>{const key=`${x.id}:${x.shiny?'s':'n'}`;return `<button class="collection-item ${x.shiny?'shiny-glow':''}" data-pokemon-key="${key}">${state.team.includes(key)?'<span class="team-badge">TEAM</span>':''}<span class="count-badge">×${x.count}</span><img src="${API.sprite(x.id,x.shiny)}"><b>${x.shiny?'★ ':''}${escapeHtml(titleCase(x.name))}</b><span>#${x.id} · Lv.${x.level||1} · Gen ${generationForId(x.id).id}</span></button>`;})():`<button class="collection-item card ${looksRare(x.rarity||'')?'rare-card':''}" data-card-id="${escapeHtml(x.id)}"><span class="count-badge">×${x.count}</span>${cardArtHtml(x.image,x.name,x)}<div class="card-tile-copy"><b>${escapeHtml(humanCardText(x.name,'Unknown card'))}</b><span>${escapeHtml(cardDisplayMeta(x))}</span></div></button>`).join('');
  grid.querySelectorAll('[data-card-id]').forEach(b=>b.onclick=()=>openCardModal(state.cards[b.dataset.cardId]));grid.querySelectorAll('[data-pokemon-key]').forEach(b=>b.onclick=()=>openPokemonModal(b.dataset.pokemonKey));
}
function renderTeamPanel(){const slots=document.getElementById('teamSlots');slots.innerHTML=[0,1,2].map(i=>{const key=state.team[i],p=state.pokemon[key];return p?`<button class="team-slot" data-team-key="${key}"><img src="${API.sprite(p.id,p.shiny)}"><b>${p.shiny?'★ ':''}${escapeHtml(titleCase(p.name))}</b><span>Lv.${p.level||1}</span></button>`:`<div class="team-slot"><b>Empty slot</b><span>Tap a Pokémon below</span></div>`;}).join('');slots.querySelectorAll('[data-team-key]').forEach(b=>b.onclick=()=>openPokemonModal(b.dataset.teamKey));}
async function openPokemonModal(key){const p=state.pokemon[key];if(!p)return;pokemonModalKey=key;await ensurePokemonBuild(p);const s=combatStats(p,p.level),a=helperAbility(p);document.getElementById('pokemonDialogSprite').src=API.sprite(p.id,p.shiny);document.getElementById('pokemonDialogDex').textContent=`#${p.id} · Gen ${generationForId(p.id).id}`;document.getElementById('pokemonDialogName').textContent=`${p.shiny?'★ ':''}${titleCase(p.name)} · Lv.${p.level}`;document.getElementById('pokemonDialogTypes').innerHTML=p.types.map(t=>`<span>${titleCase(t)}</span>`).join('');document.getElementById('pokemonDialogStats').innerHTML=[['HP',s.maxHp],['ATK',s.attack],['DEF',s.defense],['SPD',s.speed]].map(([k,v])=>`<div><b>${v}</b><span>${k}</span></div>`).join('');document.getElementById('pokemonDialogHelper').innerHTML=`<b>Arcade helper · ${escapeHtml(a.name)}</b>${escapeHtml(a.desc)}<br><span class="muted">XP ${fmt(p.xp||0)} / ${fmt(xpNeeded(p.level))}</span>`;const inTeam=state.team.includes(key),btn=document.getElementById('teamToggleBtn');btn.textContent=inTeam?'REMOVE FROM TEAM':'ADD TO TEAM';btn.className=inTeam?'secondary full':'primary full';document.getElementById('pokemonDialog').showModal();}
function toggleTeam(){const key=pokemonModalKey;if(!key)return;const i=state.team.indexOf(key);if(i>=0)state.team.splice(i,1);else if(state.team.length<3)state.team.push(key);else{showToast('Team is full. Remove a partner first.');return;}save();renderTeamPanel();renderCollection();document.getElementById('pokemonDialog').close();}
function openCardModal(card){if(!card)return;const stored=state.cards[card.id]||card,img=document.getElementById('cardDialogImage'),base=card.image||stored.image||'';img.parentElement.classList.toggle('broken',!base);img.dataset.cardBase=base;img.dataset.fallbackStep='0';img.src=cardImage(base);img.onerror=()=>cardImageFallback(img);document.getElementById('cardDialogName').textContent=card.name||stored.name;document.getElementById('cardDialogMeta').textContent=[humanCardText(card.rarity||stored.rarity||'',''),humanCardText(card.set?.name||stored.setName||stored.set||'','Unknown set')].filter(Boolean).join(' · ');const badges=[];if(stored.count)badges.push(`Owned ×${stored.count}`);if(card.localId||stored.localId)badges.push(`#${card.localId||stored.localId}`);const t=rarityTier(card.rarity||stored.rarity);if(t>=3)badges.push(tierLabel(t));document.getElementById('cardDialogBadges').innerHTML=badges.map(x=>`<span>${escapeHtml(x)}</span>`).join('');document.getElementById('cardDialog').showModal();}

function renderDaily(){const el=document.getElementById('dailyChallenges');if(!el)return;resetDaily();const tasks=state.daily.tasks.map(id=>DAILY_POOL.find(x=>x.id===id)).filter(Boolean);el.innerHTML=tasks.map(t=>{const v=Number(state.daily.progress[t.key]||0),done=v>=t.target;return `<div class="daily-row ${done?'done':''}"><div class="daily-check">${t.icon}</div><div><b>${escapeHtml(t.name)}</b><span>${Math.min(v,t.target)} / ${t.target}</span><div class="progress-track"><i style="width:${clamp(v/t.target*100,0,100)}%"></i></div></div><div class="daily-check">${done?'✓':'○'}</div></div>`;}).join('');const complete=tasks.length===3&&tasks.every(t=>Number(state.daily.progress[t.key]||0)>=t.target),btn=document.getElementById('dailyClaimBtn');btn.disabled=!complete||state.daily.claimed;btn.textContent=state.daily.claimed?'DAILY REWARD CLAIMED':'COMPLETE ALL 3 · CLAIM 🎟 + 300 COINS';document.getElementById('dailyStatusPill').textContent=state.daily.claimed?'Claimed':`${tasks.filter(t=>Number(state.daily.progress[t.key]||0)>=t.target).length}/3`;}
function claimDaily(){resetDaily();const tasks=state.daily.tasks.map(id=>DAILY_POOL.find(x=>x.id===id)).filter(Boolean);if(state.daily.claimed||tasks.length!==3||!tasks.every(t=>Number(state.daily.progress[t.key]||0)>=t.target))return;state.daily.claimed=true;state.profile.tickets++;state.profile.coins+=300;addTrainerXp(125);save();vibrate([20,30,60]);showToast('Daily board complete · +1 Pack Ticket +300 Coins');renderProfile();}
function renderProfile(){const rp=rankProgress();document.getElementById('trainerRank').textContent=rp.rank;document.getElementById('trainerXpText').textContent=`${fmt(state.profile.xp)} XP`;document.getElementById('trainerXpBar').style.width=`${rp.pct}%`;const next=Object.values(ZONES).find(z=>z.rank>rp.rank);document.getElementById('trainerNextUnlock').textContent=next?`Next zone: ${next.name} at Rank ${next.rank}`:'All current zones unlocked';renderDaily();renderAchievements();const uniquePokemon=new Set(Object.values(state.pokemon).map(x=>x.id)).size,uniqueCards=Object.keys(state.cards).length,setsStarted=new Set(Object.values(state.cards).map(cardSetKey)).size;document.getElementById('statsGrid').innerHTML=[['Battles won',state.stats.battlesWon],['Expeditions',state.stats.adventureClears],['Arcade coins',state.stats.arcadeCoins],['Caught',state.stats.catches],['Shinies',state.stats.shinies],['Species',uniquePokemon],['Packs',state.stats.packs],['Unique cards',uniqueCards],['Sets started',setsStarted],['Balls thrown',state.stats.ballsThrown],['Retreats',state.stats.expeditionRetreats||0],['Charm fragments',state.profile.shinyCharmFragments||0]].map(([k,v])=>`<div class="stat-card"><strong>${fmt(v)}</strong><span>${k}</span></div>`).join('');document.getElementById('unlockList').innerHTML=Object.values(ZONES).map(z=>`<div class="unlock-row ${rp.rank>=z.rank?'unlocked':'locked'}"><span>${z.emoji} ${z.name} hunting + expedition</span><b>${rp.rank>=z.rank?'UNLOCKED':`RANK ${z.rank}`}</b></div>`).join('')+`<div class="unlock-row ${rp.rank>=3?'unlocked':'locked'}"><span>🔵 Great Balls in Poké Mart</span><b>${rp.rank>=3?'UNLOCKED':'RANK 3'}</b></div><div class="unlock-row ${rp.rank>=7?'unlocked':'locked'}"><span>🟡 Ultra Balls in Poké Mart</span><b>${rp.rank>=7?'UNLOCKED':'RANK 7'}</b></div><div class="unlock-row ${state.profile.shinyCharmFragments>=3?'unlocked':'locked'}"><span>✨ Shiny Charm · every 3 fragments improves shiny odds</span><b>${state.profile.shinyCharmFragments>=3?`ACTIVE · 1/${effectiveShinyOdds()}`:`${state.profile.shinyCharmFragments||0}/3`}</b></div>`;const rare=state.rareHits.slice(0,16);document.getElementById('rarestList').innerHTML=rare.length?rare.map(x=>`<div class="rare-row"><b>${escapeHtml(x.name)}</b><span>${x.type==='pokemon'&&x.odds?`~1/${fmt(Math.round(x.odds))}`:escapeHtml(x.rarity||x.set||'Rare')}</span></div>`).join(''):'<div class="empty">Your shiny, legendary and high-rarity pulls will appear here.</div>';renderGlobalHud();}
function renderSupplyShop(){const rank=currentRank(),items=[['pokeball','5 Poké Balls',5,100,1],['greatball','3 Great Balls',3,180,3],['ultraball','2 Ultra Balls',2,240,7],['berry','5 Berries',5,120,1],['potion','3 Potions',3,180,1]];document.getElementById('supplyShopList').innerHTML=items.map(([key,name,qty,cost,req])=>`<div class="shop-row"><div><b>${name}</b><span>${key==='berry'?'Boosts the next catch attempt':key==='potion'?'Restores 38% HP during an expedition battle':'Better balls improve catch odds'}</span></div><button class="${rank>=req?'primary':'secondary'}" data-buy="${key}" data-qty="${qty}" data-cost="${cost}" data-rank="${req}" ${rank<req?'disabled':''}>${rank<req?`RANK ${req}`:`◉ ${cost}`}</button></div>`).join('');document.querySelectorAll('[data-buy]').forEach(b=>b.onclick=()=>buySupply(b.dataset.buy,Number(b.dataset.qty),Number(b.dataset.cost)));}
function buySupply(key,qty,cost){if(state.profile.coins<cost){showToast('Not enough Lucky Coins.');return;}state.profile.coins-=cost;state.inventory[key]+=qty;save();renderSupplyShop();showToast(`Purchased ${qty} ${key==='berry'?'Berries':key==='potion'?'Potions':BALLS[key].name+'s'}.`);}
function exportSave(){const data=JSON.stringify(state,null,2);if(window.Android?.shareText){window.Android.shareText(data);return;}const blob=new Blob([data],{type:'application/json'}),a=document.createElement('a');a.href=URL.createObjectURL(blob);a.download='lucky-dex-save.json';a.click();URL.revokeObjectURL(a.href);}
let pendingImportedSave=null;
function parseImportedSave(text){
  const parsed=JSON.parse(String(text||''));
  if(!parsed||typeof parsed!=='object'||Array.isArray(parsed))throw new Error('Save must be a JSON object.');
  if(!parsed.profile&&!parsed.pokemon&&!parsed.cards&&!parsed.arcade)throw new Error('This does not look like a LuckyDex save.');
  return parsed;
}
function importedSaveSummary(raw){
  const pokemon=Object.keys(raw?.pokemon||{}).length,cards=Object.keys(raw?.cards||{}).length,coins=Math.max(0,Number(raw?.profile?.coins||0)||0);
  return `${pokemon} Pokémon · ${cards} cards · ${fmt(coins)} coins`;
}
function closeImportSave(){pendingImportedSave=null;const panel=document.getElementById('importSavePanel'),text=document.getElementById('importSaveText'),summary=document.getElementById('importSaveSummary'),confirmBtn=document.getElementById('confirmImportBtn');if(panel)panel.hidden=true;if(text)text.value='';if(summary)summary.textContent='Paste an exported save to validate it.';if(confirmBtn)confirmBtn.disabled=true;}
function validateImportSave(){const text=document.getElementById('importSaveText'),summary=document.getElementById('importSaveSummary'),confirmBtn=document.getElementById('confirmImportBtn');try{pendingImportedSave=parseImportedSave(text?.value);if(summary)summary.textContent=`Ready to import · ${importedSaveSummary(pendingImportedSave)}`;if(confirmBtn)confirmBtn.disabled=false;return true;}catch(err){pendingImportedSave=null;if(summary)summary.textContent=text?.value?.trim()?`Invalid save: ${err.message}`:'Paste an exported save to validate it.';if(confirmBtn)confirmBtn.disabled=true;return false;}}
function openImportSave(){const panel=document.getElementById('importSavePanel');if(panel)panel.hidden=false;document.getElementById('importSaveText')?.focus();validateImportSave();}
function confirmImportSave(){if(!pendingImportedSave&&!validateImportSave())return false;const incoming=pendingImportedSave;if(!incoming)return false;try{localStorage.setItem('luckyDexSave',JSON.stringify(incoming));pendingImportedSave=null;location.reload();return true;}catch(err){showToast(`Import failed: ${err.message}`,3000);return false;}}

// Shared events (Adventure owns its scene listeners).
document.getElementById('closeSupplyShop').onclick=()=>document.getElementById('supplyDialog').close();
document.getElementById('cardSource').onchange=e=>{preparedPack=null;document.getElementById('packStage').innerHTML='<div class="empty compact-empty">Choose a set and spend your earned coins.</div>';loadSets(e.target.value);updatePackButton();};document.getElementById('openPackBtn').onclick=preparePack;document.getElementById('dustExchangeBtn').onclick=exchangeDust;
document.querySelectorAll('[data-collection]').forEach(b=>b.onclick=()=>{collectionMode=b.dataset.collection;document.querySelectorAll('[data-collection]').forEach(x=>x.classList.toggle('active',x===b));rebuildCollectionControls();renderTeamPanel();renderCollection();});document.getElementById('collectionSearch').oninput=renderCollection;document.getElementById('collectionFilter').onchange=renderCollection;document.getElementById('collectionGroupFilter').onchange=renderCollection;
document.querySelectorAll('[data-challenge-tab]').forEach(b=>b.onclick=()=>{challengeTab=b.dataset.challengeTab;document.querySelectorAll('[data-challenge-tab]').forEach(x=>x.classList.toggle('active',x===b));renderAchievements();});
document.getElementById('settingsBtn').onclick=()=>document.getElementById('settingsDialog').showModal();document.getElementById('closeSettings').onclick=()=>document.getElementById('settingsDialog').close();document.getElementById('closeCardDialog').onclick=()=>document.getElementById('cardDialog').close();document.getElementById('closePokemonDialog').onclick=()=>document.getElementById('pokemonDialog').close();document.getElementById('teamToggleBtn').onclick=toggleTeam;document.getElementById('cardDialog').addEventListener('click',e=>{if(e.target===e.currentTarget)e.currentTarget.close();});document.getElementById('pokemonDialog').addEventListener('click',e=>{if(e.target===e.currentTarget)e.currentTarget.close();});
document.getElementById('shinyOddsSelect').value=String(state.settings.shinyOdds);document.getElementById('vibrationToggle').checked=state.settings.vibration;document.getElementById('shinyOddsSelect').onchange=e=>{state.settings.shinyOdds=Number(e.target.value);save();updateSearchCard();};document.getElementById('vibrationToggle').onchange=e=>{state.settings.vibration=e.target.checked;save();};document.getElementById('dailyClaimBtn').onclick=claimDaily;document.getElementById('exportBtn').onclick=exportSave;document.getElementById('settingsExportBtn').onclick=exportSave;document.getElementById('importBtn').onclick=openImportSave;document.getElementById('cancelImportBtn').onclick=closeImportSave;document.getElementById('confirmImportBtn').onclick=confirmImportSave;document.getElementById('importSaveText').oninput=validateImportSave;document.getElementById('resetBtn').onclick=()=>{if(confirm('Delete the entire Lucky Dex collection and game progress?')){window.LuckyDexAdventure?.leave?.();state=cloneDefault();resetDaily();window.LuckyDexAdventureModel?.ensureState(state);save();renderStarter();renderZones();renderProfile();rebuildCollectionControls();renderCollection();}};


async function bootLuckyDexV0158(){
  resetDaily();const speciesJob=initSpecies();renderGlobalHud();renderStarter();renderZones();rebuildCollectionControls();renderTeamPanel();renderProfile();
  // Fire background hydration, but never hold Adventure or the title screen on it.
  loadZonePool(state.settings.zone in ZONES?state.settings.zone:'meadow');loadSets('tcg');speciesJob.then(()=>{renderStarter();}).catch(()=>{});
}


/* =========================================================
   v0.5 — app-flow / pack / arcade overrides
   ========================================================= */

const MEMORY_SYMBOLS_V5=['⭐','🎵','🌙','💫'];


function assetFlexible(base){
  if(!base)return '';
  return /\.(?:webp|png|jpe?g)(?:\?.*)?$/i.test(base)?base:`${base}.webp`;
}
function normalizeCardBase(base=''){
  let out=String(base||'');
  if(/images\.pokemontcg\.io/i.test(out))return out.replace(/_hires\.png(?:\?.*)?$/i,'').replace(/\.png(?:\?.*)?$/i,'');
  return out.replace(/\/(?:high|low)\.(?:webp|png|jpe?g)(?:\?.*)?$/i,'');
}
function cardImage(base,q='high',ext='webp'){
  base=normalizeCardBase(base);if(!base)return '';
  if(/^(?:blob:|data:)/i.test(base))return base;
  // pokemon-tcg-data switched newer sets to Scrydex's direct image routes.
  // These are already complete image URLs (large/small), not TCGdex-style bases.
  if(/images\.scrydex\.com/i.test(base)){
    if(/\/(?:large|small)(?:\?.*)?$/i.test(base))return base.replace(/\/(?:large|small)(?=\?|$)/i,q==='high'?'/large':'/small');
    return `${base.replace(/\/$/,'')}/${q==='high'?'large':'small'}`;
  }
  if(/images\.pokemontcg\.io/i.test(base))return `${base}${q==='high'?'_hires':''}.png`;
  // Preserve any other already-complete image URL instead of corrupting it by
  // appending /high.webp. TCGdex bases intentionally have no extension.
  if(/\.(?:png|webp|jpe?g|avif)(?:\?.*)?$/i.test(base))return base;
  return `${base}/${q}.${ext}`;
}
function deriveCardBase(card,set){
  if(card?.image)return normalizeCardBase(card.image);
  const local=card?.localId;
  const setId=card?.set?.id||set?.id;
  const serieId=card?.set?.serie?.id||set?.serie?.id;
  if(local!=null&&setId&&serieId)return `https://assets.tcgdex.net/en/${serieId}/${setId}/${local}`;
  return '';
}

// Physical-card identity helpers. v0.16.4 deliberately does not infer artwork
// from a collector number alone: subset/reprint catalogues can number the same
// physical cards differently, so only verified cross-catalogue matches may feed art.
function normalizePhysicalSetCodeV163(value=''){
  const code=String(value||'').trim().toUpperCase().replace(/[^A-Z0-9]/g,'');
  return code.length>=2&&code.length<=10?code:'';
}
function physicalCollectorNumbersV163(card){
  const raw=String(card?.localId??card?.number??'').trim();if(!raw)return [];
  const values=[];const add=v=>{v=String(v||'').trim().toUpperCase();if(v&&!values.includes(v))values.push(v);};
  if(/^0*\d+$/.test(raw)){const n=String(Number(raw));add(n.padStart(3,'0'));add(n);}
  else {add(raw);add(raw.replace(/[^A-Z0-9]/gi,''));}
  return values;
}
function physicalSetCodesV163(card,set=null){
  const values=[];const add=v=>{const code=normalizePhysicalSetCodeV163(v);if(code&&!values.includes(code))values.push(code);};
  add(card?._limitlessSetCode);add(card?._ptcgoCode);
  add(card?.set?.tcgOnline);add(card?.set?.ptcgoCode);add(card?.set?.abbreviation?.official);add(card?.set?.abbreviation);add(card?.set?.abbreviations?.official);
  add(set?.tcgOnline);add(set?.ptcgoCode);add(set?.abbreviation?.official);add(set?.abbreviation);add(set?.abbreviations?.official);
  // TCGdex uses the official short code as the set id for some current promo
  // sets (e.g. mep), so keep IDs as the final candidate rather than assuming
  // every API uses the same naming scheme.
  add(card?.set?.id);add(card?.setId);add(set?.id);
  return values;
}
function physicalCardArtworkCandidatesV163(card,set=null){
  // v0.16.4: NEVER guess physical artwork from a set code + collector number.
  // That is not identity-safe for reprint/subset sets (for example 30th-c #015
  // collides with 30C #015, which is Fuecoco ex). Only surface URLs that were
  // attached after a metadata-backed identity match.
  if(!card||(card.source||'tcg')==='tcgp')return [];
  const urls=[],seen=new Set(),add=url=>{url=String(url||'');if(url&&!seen.has(url)){seen.add(url);urls.push(url);}};
  add(card._scrydexImageLarge);add(card._scrydexImageSmall);
  add(card._ptcgImageLarge);add(card._ptcgImageSmall);
  return urls;
}
window.physicalCardArtworkCandidatesV163=physicalCardArtworkCandidatesV163;

let ptcgSetListV5=null;
const ptcgCardSetCacheV151=new Map();
const ptcgCardRecordCacheV151=new Map();

// v0.15.2: bundled bridge for the 2026 anniversary sets. TCGdex currently
// exposes some of these cards before its image CDN has matching artwork, and
// Android WebView can also fail the GitHub metadata request on a slow/strict
// connection. Keep a compact, deterministic map for the affected Classic
// Collection so a card such as TCGdex 30th-c-003 Metagross can resolve to the
// maintained Scrydex image me55c-11 without another metadata round-trip.
const PTCG_30TH_CLASSIC_V152=[
  ['me55c-58','Pikachu','58','Common','40','Mitsuhiro Arita'],
  ['me55c-4','Charizard','4','Rare Holo','120','Mitsuhiro Arita'],
  ['me55c-18','Misty','18','Rare Holo','','Ken Sugimori'],
  ['me55c-69',"Erika's Jigglypuff",'69','Common','50','Ken Sugimori'],
  ['me55c-25','Sneasel','25','Rare','60','Ken Sugimori'],
  ['me55c-106','Shining Celebi','106','Rare Secret','50','Hironobu Yoshida'],
  ['me55c-149','Lugia','149','Rare Secret','80','Naoyo Kimura'],
  ['me55c-5','Delcatty','5','Rare Holo','70','Atsuko Nishida'],
  ['me55c-19','Dark Tyranitar','19','Rare','120','Nakaoka'],
  ['me55c-108','Scizor ex','108','Rare Holo ex','120','Mitsuhiro Arita'],
  ['me55c-11','Metagross','11','Rare Holo','100','Masakazu Fukuda'],
  ['me55c-106p','Palkia LV.X','106','Rare Holo LV.X','120','Ryo Ueda'],
  ['me55c-43','Uxie','43','Rare','70','Ken Sugimori'],
  ['me55c-47','Crobat G','47','Uncommon','80','Makoto Imai'],
  ['me55c-94','Gengar','94','Rare Prime','130','Takashi Yamaguchi'],
  ['me55c-99','Darkrai & Cresselia LEGEND','99','LEGEND','150','Noriko Takaya, Shinji Higuchi'],
  ['me55c-100','Darkrai & Cresselia LEGEND','100','LEGEND','150','Noriko Takaya, Shinji Higuchi'],
  ['me55c-101','N','101','Rare Ultra','','Ken Sugimori'],
  ['me55c-85','Rayquaza-EX','85','Rare Holo EX','170','Eske Yoshinob'],
  ['me55c-11g','Genesect-EX','11','Rare Holo EX','170','Eske Yoshinob'],
  ['me55c-106m','M Gardevoir-EX','106','Rare Holo EX','210','5ban Graphics'],
  ['me55c-41','Greninja BREAK','41','Rare BREAK','170','5ban Graphics'],
  ['me55c-89','Solgaleo-GX','89','Rare Holo GX','250','PLANETA'],
  ['me55c-57','Buzzwole-GX','57','Rare Holo GX','190','5ban Graphics'],
  ['me55c-33','Pikachu & Zekrom-GX','33','Rare Holo GX','240','Mitsuhiro Arita'],
  ['me55c-138','Zacian V','138','Holo Rare V','220','5ban Graphics'],
  ['me55c-50','Raikou','50','Amazing Rare','110','Hideki Ishikawa'],
  ['me55c-114','Mew VMAX','114','Holo Rare VMAX','310','5ban Graphics'],
  ['me55c-123','Arceus VSTAR','123','Holo Rare VSTAR','280','5ban Graphics'],
  ['me55c-203','Magikarp','203','Illustration Rare','30','Shinji Kanda']
].map(([id,name,number,rarity,hp,artist])=>({id,name,number,rarity,hp,artist,images:{large:`https://images.scrydex.com/pokemon/${id}/large`,small:`https://images.scrydex.com/pokemon/${id}/small`}}));

function bundledPtcgArtworkRecordV152(card,set=null){
  const setName=normalizeSetNameV5(card?.set?.name||card?.setName||set?.name||'');
  const setId=String(card?.set?.id||card?.setId||set?.id||'').toLowerCase();
  const classic=setId==='30th-c'||setName==='30th classic collection'||setName==='30th celebration classic collection';
  if(classic){
    const wanted=normalizeSetNameV5(card?.name||''),wantedBase=normalizeLegacyCardNameV153(card?.name||'');
    let candidates=PTCG_30TH_CLASSIC_V152.filter(c=>normalizeSetNameV5(c.name)===wanted);
    // Several Classic Collection entries use the base Pokémon name in TCGdex
    // while the maintained art dataset keeps the original mechanic suffix.
    // Example: Palkia -> Palkia LV.X. Fall back to mechanic-insensitive names.
    if(!candidates.length)candidates=PTCG_30TH_CLASSIC_V152.filter(c=>normalizeLegacyCardNameV153(c.name)===wantedBase);
    if(!candidates.length)return null;
    const scored=candidates.map((c,index)=>({c,index,score:ptcgCandidateScoreV153(card,c)})).sort((a,b)=>b.score-a.score||a.index-b.index);
    if(scored.length===1||scored[0].score>scored[1].score)return scored[0].c;
    const sameBriefs=(set?.cards||[]).filter(c=>normalizeLegacyCardNameV153(c?.name||'')===wantedBase);
    const occurrence=Math.max(0,sameBriefs.findIndex(c=>c?.id===card?.id));
    return candidates[Math.min(occurrence,candidates.length-1)]||candidates[0];
  }
  // The main 30th Celebration set uses the same printed number in
  // pokemon-tcg-data/Scrydex, so no large name map is necessary.
  const celebration=setId==='30th'||setName==='30th celebration';
  if(celebration){
    const raw=String(card?.localId??'').trim();if(!raw)return null;
    const number=/^0*\d+$/.test(raw)?String(Number(raw)):raw.toUpperCase();
    const id=`me55-${number}`;
    return {id,name:card?.name||'',number,rarity:card?.rarity||'',hp:card?.hp||'',artist:card?.illustrator||card?.artist||'',images:{large:`https://images.scrydex.com/pokemon/${id}/large`,small:`https://images.scrydex.com/pokemon/${id}/small`}};
  }
  return null;
}
function normalizeSetNameV5(name=''){return String(name).toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g,'').replace(/pok[eé]mon/g,'pokemon').replace(/[^a-z0-9]+/g,' ').trim();}
function normalizedDateV151(value=''){return String(value||'').trim().replace(/\//g,'-').slice(0,10);}
function setCardCountV151(set){return Number(set?.cardCount?.total??set?.cardCount?.official??set?.total??set?.printedTotal??0)||0;}
function tokenSetV151(value=''){return new Set(normalizeSetNameV5(value).split(/\s+/).filter(Boolean));}
function tokenSimilarityV151(a,b){
  const A=tokenSetV151(a),B=tokenSetV151(b);if(!A.size||!B.size)return 0;
  let shared=0;for(const t of A)if(B.has(t))shared++;
  return shared/Math.max(A.size,B.size);
}
async function loadPtcgSetListV5(signal=null){
  if(ptcgSetListV5)return ptcgSetListV5;
  let cached=[];try{const hit=JSON.parse(localStorage.getItem('luckyDexPtcgSets')||'null');if(Array.isArray(hit))cached=hit;}catch(e){}
  // Do not let a months-old set list live forever. This was the reason newly
  // released sets such as 30th Celebration could never reach their real art.
  if(typeof isOnlineV13==='function'&&!isOnlineV13()){ptcgSetListV5=cached;return cached;}
  try{
    const url='https://raw.githubusercontent.com/PokemonTCG/pokemon-tcg-data/master/sets/en.json';
    const list=signal?await packFetch(url,signal,12000):await fetchJson(url);
    if(signal?.aborted)throw new DOMException('Cancelled','AbortError');
    ptcgSetListV5=Array.isArray(list)?list:cached;
    if(ptcgSetListV5.length)try{localStorage.setItem('luckyDexPtcgSets',JSON.stringify(ptcgSetListV5));localStorage.setItem('luckyDexPtcgSetsAt',String(Date.now()));}catch(e){}
    return ptcgSetListV5;
  }catch(e){if(signal?.aborted)throw e;ptcgSetListV5=cached;return cached;}
}
function choosePtcgSetV151(setName,set,list){
  const wanted=normalizeSetNameV5(setName),release=normalizedDateV151(set?.releaseDate),count=setCardCountV151(set);
  const wantedId=String(set?.id||'').trim().toLowerCase();
  const wantedCodes=new Set(physicalSetCodesV163(null,set));
  let best=null,bestScore=-1;
  for(const row of list||[]){
    const n=normalizeSetNameV5(row?.name||''),rowId=String(row?.id||'').trim().toLowerCase(),rowCode=normalizePhysicalSetCodeV163(row?.ptcgoCode||row?.tcgOnline||'');
    const sameId=!!(wantedId&&rowId===wantedId),sameCode=!!(rowCode&&wantedCodes.has(rowCode)),sameName=!!(wanted&&n===wanted);
    // v0.16.4: artwork may only cross catalogues after an identity-strength
    // set match. Fuzzy token similarity is useful for search, but it is not
    // safe enough to attach an image to a named card.
    if(!sameId&&!sameCode&&!sameName)continue;
    let score=(sameId?100:0)+(sameCode?80:0)+(sameName?20:0);
    if(release&&normalizedDateV151(row?.releaseDate)===release)score+=3;
    const rc=setCardCountV151(row);if(count&&rc&&count===rc)score+=2;
    if(score>bestScore){bestScore=score;best=row;}
  }
  return best;
}

async function loadPtcgCardsForSetV151(setId,signal=null){
  if(!setId)return [];
  if(ptcgCardSetCacheV151.has(setId))return ptcgCardSetCacheV151.get(setId);
  const key=`luckyDexPtcgCardsV151:${setId}`;
  let cached=[];try{const hit=JSON.parse(localStorage.getItem(key)||'null');if(Array.isArray(hit)&&hit.length)cached=hit;}catch(e){}
  if(typeof isOnlineV13==='function'&&!isOnlineV13()){ptcgCardSetCacheV151.set(setId,cached);return cached;}
  try{
    const url=`https://raw.githubusercontent.com/PokemonTCG/pokemon-tcg-data/master/cards/en/${encodeURIComponent(setId)}.json`;
    const list=signal?await packFetch(url,signal,12000):await fetchJson(url);
    if(signal?.aborted)throw new DOMException('Cancelled','AbortError');
    const cards=Array.isArray(list)?list:cached;ptcgCardSetCacheV151.set(setId,cards);
    // Persist only compact art/identity metadata. Full card JSON for large sets
    // can exceed WebView localStorage limits.
    if(cards.length){
      const compact=cards.map(c=>({id:c.id,name:c.name,number:c.number,rarity:c.rarity,artist:c.artist,hp:c.hp,images:c.images}));
      try{localStorage.setItem(key,JSON.stringify(compact));}catch(e){}
      return compact;
    }
    return cards;
  }catch(e){if(signal?.aborted)throw e;ptcgCardSetCacheV151.set(setId,cached);return cached;}
}
function normalizeArtistV151(value=''){return normalizeSetNameV5(String(value||'').replace(/\s+/g,' '));}
function normalizeLegacyCardNameV153(value=''){
  // Reprint databases disagree on whether the era mechanic is part of the
  // display name (Palkia vs Palkia LV.X, Rayquaza vs Rayquaza-EX, etc.).
  // Strip only trailing mechanic tokens for matching; preserve the real name.
  let x=normalizeSetNameV5(value);
  x=x.replace(/\b(?:lv x|vmax|vstar|break|prime|ex|gx|v|g)\b/g,' ').replace(/\s+/g,' ').trim();
  return x;
}
function ptcgCandidateScoreV153(card,candidate){
  const wanted=normalizeSetNameV5(card?.name||''),got=normalizeSetNameV5(candidate?.name||'');
  const wantedBase=normalizeLegacyCardNameV153(card?.name||''),gotBase=normalizeLegacyCardNameV153(candidate?.name||'');
  let score=0;
  if(wanted&&got===wanted)score+=30;
  else if(wantedBase&&gotBase===wantedBase)score+=16;
  const artist=normalizeArtistV151(card?.illustrator||card?.artist),hp=String(card?.hp??'');
  if(artist&&normalizeArtistV151(candidate?.artist)===artist)score+=8;
  if(hp&&String(candidate?.hp??'')===hp)score+=4;
  return score;
}
function stripCardNumberV151(value=''){return String(value??'').trim().replace(/^0+(?=\d)/,'').toLowerCase();}
function choosePtcgCardV151(card,set,cards){
  const wanted=normalizeSetNameV5(card?.name||''),wantedBase=normalizeLegacyCardNameV153(card?.name||'');
  let candidates=(cards||[]).filter(c=>normalizeSetNameV5(c?.name||'')===wanted);
  if(!candidates.length)candidates=(cards||[]).filter(c=>normalizeLegacyCardNameV153(c?.name||'')===wantedBase);
  if(!candidates.length)return null;if(candidates.length===1)return candidates[0];
  const local=stripCardNumberV151(card?.localId),exact=candidates.find(c=>stripCardNumberV151(c?.number)===local);if(exact)return exact;
  let scored=candidates.map((c,index)=>({c,index,score:ptcgCandidateScoreV153(card,c)}));
  scored.sort((a,b)=>b.score-a.score||a.index-b.index);
  if(scored[0]?.score>scored[1]?.score)return scored[0].c;
  // Reprint subsets can contain two cards with the same name/artist/stats (for
  // example the two LEGEND halves). Preserve occurrence order instead of
  // collapsing them onto the same image.
  const sameBriefs=(set?.cards||[]).filter(c=>normalizeLegacyCardNameV153(c?.name||'')===wantedBase);
  const occurrence=Math.max(0,sameBriefs.findIndex(c=>c?.id===card?.id));
  return candidates[Math.min(occurrence,candidates.length-1)]||candidates[0];
}

const scrydexExpansionCacheV164=new Map();
const scrydexCardCacheV164=new Map();
const MCD23_BY_NUMBER_V164={
  '1':'Sprigatito','2':'Fuecoco','3':'Quaxly','4':'Cetoddle','5':'Cetitan',
  '6':'Pikachu','7':'Pawmi','8':'Kilowattrel','9':'Flittle','10':'Sandaconda',
  '11':'Klawf','12':'Blissey','13':'Tandemaus','14':'Cyclizar','15':'Kirlia'
};
function scrydexRowsV164(payload){return Array.isArray(payload)?payload:(Array.isArray(payload?.data)?payload.data:[]);}
function scrydexEscapeV164(value=''){return String(value||'').replace(/\\/g,'\\\\').replace(/"/g,'\\"');}
async function scrydexFetchV164(url,signal=null,timeout=6500){
  if(typeof isOnlineV13==='function'&&!isOnlineV13())throw new Error('offline');
  const controller=new AbortController(),abort=()=>controller.abort();if(signal?.aborted)controller.abort();signal?.addEventListener('abort',abort,{once:true});
  const timer=setTimeout(abort,timeout);
  try{const r=await fetch(url,{signal:controller.signal,cache:'force-cache'});if(!r.ok)throw new Error(`Scrydex ${r.status}`);return await r.json();}
  finally{clearTimeout(timer);signal?.removeEventListener('abort',abort);}
}
function scrydexSetAliasV164(setName='',setId=''){
  const name=normalizeSetNameV5(setName),id=String(setId||'').toLowerCase();
  if(name==='mcdonald s collection 2023'||id==='2023sv'||id==='mcd23')return 'mcd23';
  if(name==='30th classic collection'||name==='30th celebration classic collection'||id==='30th-c')return 'me55c';
  return '';
}
function scrydexImageUrlsV164(hit){
  const out=[];const add=v=>{v=String(v||'');if(v&&!out.includes(v))out.push(v);};
  if(Array.isArray(hit?.images)){
    const fronts=[...hit.images].sort((a,b)=>(a?.type==='front'?-1:0)-(b?.type==='front'?-1:0));
    for(const row of fronts){add(row?.large);add(row?.medium);add(row?.small);}
  }else if(hit?.images){add(hit.images.large);add(hit.images.medium);add(hit.images.small);}
  if(hit?.id){add(`https://images.scrydex.com/pokemon/${hit.id}/large`);add(`https://images.scrydex.com/pokemon/${hit.id}/small`);}
  return out;
}
async function scrydexExpansionForSetV164(card,set=null,signal=null){
  const setName=card?.set?.name||card?.setName||set?.name||'',setId=card?.set?.id||card?.setId||set?.id||'';
  const alias=scrydexSetAliasV164(setName,setId);if(alias)return {id:alias,name:setName,_trustedAlias:true};
  const key=`${normalizeSetNameV5(setName)}|${normalizedDateV151(set?.releaseDate||card?.set?.releaseDate||'')}`;if(scrydexExpansionCacheV164.has(key))return scrydexExpansionCacheV164.get(key);
  const wanted=normalizeSetNameV5(setName);if(!wanted)return null;
  try{
    const q=encodeURIComponent(`!name:"${scrydexEscapeV164(setName)}"`),url=`https://api.scrydex.com/pokemon/v1/en/expansions?q=${q}&page_size=20&select=id,name,code,total,printed_total,release_date`;
    const rows=scrydexRowsV164(await scrydexFetchV164(url,signal));
    const exact=rows.filter(r=>normalizeSetNameV5(r?.name||'')===wanted);
    const release=normalizedDateV151(set?.releaseDate||card?.set?.releaseDate||''),count=setCardCountV151(set||card?.set);
    let best=null,bestScore=-1;for(const row of exact){let score=20;if(release&&normalizedDateV151(row?.release_date)===release)score+=4;const rc=Number(row?.total||row?.printed_total||0);if(count&&rc&&count===rc)score+=2;if(score>bestScore){best=row;bestScore=score;}}
    scrydexExpansionCacheV164.set(key,best||null);return best||null;
  }catch(e){if(signal?.aborted)throw e;scrydexExpansionCacheV164.set(key,null);return null;}
}
async function scrydexCardRecordV164(card,set=null,signal=null){
  if(!card)return null;
  const cacheKey=card?.id||`${set?.id||''}:${card?.localId||''}:${card?.name||''}`;if(scrydexCardCacheV164.has(cacheKey))return scrydexCardCacheV164.get(cacheKey);
  const setName=card?.set?.name||card?.setName||set?.name||'',setId=card?.set?.id||card?.setId||set?.id||'',alias=scrydexSetAliasV164(setName,setId);
  // These two aliases are deterministic and do not require an API request.
  if(alias==='mcd23'){
    const raw=String(card?.localId??card?.number??'').trim();
    if(/^0*\d+$/.test(raw)){
      const number=String(Number(raw)),expected=MCD23_BY_NUMBER_V164[number]||'';
      // This bridge is only used when BOTH the local collector number and card
      // name agree with McDonald's Collection 2023. It therefore cannot turn a
      // valid name into unrelated artwork if another catalogue reuses a number.
      if(expected&&normalizeSetNameV5(expected)===normalizeSetNameV5(card?.name||'')){
        const hit={id:`mcd23-${number}`,name:expected,number,rarity:'Promo',artist:card?.illustrator||card?.artist||'',hp:card?.hp||'',images:{large:`https://images.scrydex.com/pokemon/mcd23-${number}/large`,small:`https://images.scrydex.com/pokemon/mcd23-${number}/small`}};
        scrydexCardCacheV164.set(cacheKey,hit);return hit;
      }
    }
  }
  if(alias==='me55c'){
    const hit=bundledPtcgArtworkRecordV152(card,set);if(hit){scrydexCardCacheV164.set(cacheKey,hit);return hit;}
  }
  const expansion=await scrydexExpansionForSetV164(card,set,signal);if(!expansion?.id)return null;
  try{
    const wanted=normalizeSetNameV5(card?.name||'');if(!wanted)return null;
    const q=encodeURIComponent(`!name:"${scrydexEscapeV164(card.name)}"`),url=`https://api.scrydex.com/pokemon/v1/en/expansions/${encodeURIComponent(expansion.id)}/cards?q=${q}&page_size=100&select=id,name,number,artist,hp,rarity,images,expansion_sort_order`;
    const rows=scrydexRowsV164(await scrydexFetchV164(url,signal)).filter(r=>normalizeSetNameV5(r?.name||'')===wanted);if(!rows.length)return null;
    if(rows.length===1){scrydexCardCacheV164.set(cacheKey,rows[0]);return rows[0];}
    const local=stripCardNumberV151(card?.localId??card?.number),artist=normalizeArtistV151(card?.illustrator||card?.artist),hp=String(card?.hp??'');
    const scored=rows.map((r,index)=>{let score=0;if(local&&stripCardNumberV151(r?.number)===local)score+=12;if(artist&&normalizeArtistV151(r?.artist)===artist)score+=8;if(hp&&String(r?.hp??'')===hp)score+=4;return {r,index,score};}).sort((a,b)=>b.score-a.score||Number(a.r?.expansion_sort_order??a.index)-Number(b.r?.expansion_sort_order??b.index));
    let hit=scored[0]?.r||null;if(scored.length>1&&scored[0].score===scored[1].score){const same=(set?.cards||[]).filter(c=>normalizeSetNameV5(c?.name||'')===wanted),occ=Math.max(0,same.findIndex(c=>c?.id===card?.id));const ordered=[...rows].sort((a,b)=>Number(a?.expansion_sort_order??0)-Number(b?.expansion_sort_order??0));hit=ordered[Math.min(occ,ordered.length-1)]||hit;}
    if(hit)scrydexCardCacheV164.set(cacheKey,hit);return hit;
  }catch(e){if(signal?.aborted)throw e;return null;}
}
async function scrydexArtworkBaseV164(card,set=null,signal=null){
  const hit=await scrydexCardRecordV164(card,set,signal);if(!hit)return '';
  const urls=scrydexImageUrlsV164(hit),art=urls[0]||'';if(!art)return '';
  card._scrydexId=hit.id||'';card._scrydexImageLarge=urls.find(x=>/\/large(?:\?|$)/i.test(x))||art;card._scrydexImageSmall=urls.find(x=>/\/small(?:\?|$)/i.test(x))||'';card._artSource='scrydex-identity';card._artIdentityVerified=true;
  if((!card.rarity||/^(?:none|unknown)$/i.test(String(card.rarity)))&&hit.rarity)card.rarity=hit.rarity;
  card.image=art;return art;
}
window.scrydexArtworkBaseV164=scrydexArtworkBaseV164;

async function pokemonTcgArtworkRecordV151(card,set=null,signal=null){
  const cacheKey=card?.id||`${set?.id||''}:${card?.localId||''}:${card?.name||''}`;
  if(ptcgCardRecordCacheV151.has(cacheKey))return ptcgCardRecordCacheV151.get(cacheKey);
  const bundled=bundledPtcgArtworkRecordV152(card,set);
  if(bundled){ptcgCardRecordCacheV151.set(cacheKey,bundled);return bundled;}
  const list=await loadPtcgSetListV5(signal),setName=card?.set?.name||card?.setName||set?.name||'';
  const match=choosePtcgSetV151(setName,set,list);if(!match)return null;
  const matchCode=normalizePhysicalSetCodeV163(match?.ptcgoCode||match?.tcgOnline||'');if(matchCode)card._limitlessSetCode=matchCode;
  const cards=await loadPtcgCardsForSetV151(match.id,signal),hit=choosePtcgCardV151(card,set,cards);
  if(hit)ptcgCardRecordCacheV151.set(cacheKey,hit);return hit||null;
}
async function pokemonTcgArtworkBaseV5(card,set=null,signal=null){
  const hit=await pokemonTcgArtworkRecordV151(card,set,signal);
  if(hit?.images){
    const art=hit.images.large||hit.images.small||'';
    if(art){
      if(card.image&&!/images\.scrydex\.com/i.test(String(card.image)))card._tcgdexImage=card._tcgdexImage||card.image;card._artSource='pokemon-tcg-data';card._artIdentityVerified=true;card._ptcgId=hit.id;card._ptcgNumber=hit.number||'';card._ptcgImageLarge=hit.images.large||'';card._ptcgImageSmall=hit.images.small||'';
      // TCGdex deliberately reports some new reprint subsets as rarity "None".
      // The alternate catalogue has the actual printed rarity, which also lets
      // Lucky Dex choose sensible pack slots and reveal tiers.
      if((!card.rarity||/^(?:none|unknown)$/i.test(String(card.rarity)))&&hit.rarity)card.rarity=hit.rarity;
      card.image=art;return art;
    }
  }
  return '';
}
async function enrichPhysicalCardV151(card,set=null,signal=null){
  if(!card)return card;
  try{const art=await pokemonTcgArtworkBaseV5(card,set,signal);if(!art)await scrydexArtworkBaseV164(card,set,signal);}catch(e){if(signal?.aborted)throw e;}
  return card;
}
function cardArtHtml(base,name,card=null){
  const clean=normalizeCardBase(base),cardId=card?.id||'';
  let direct='';try{if(!clean&&card&&(typeof isOnlineV13!=='function'||isOnlineV13()))direct=physicalCardArtworkCandidatesV163(card,null)[0]||'';}catch(_){ }
  const first=clean||direct,physicalIndex=direct?1:0;
  return `<div class="card-art-wrap ${first?'loading-art':'broken loading-art'}"><img ${first?`src="${cardImage(first,'high','webp')}"`:''} data-card-base="${escapeHtml(first)}" data-card-id="${escapeHtml(cardId)}" data-fallback-step="0" data-alt-tried="0" data-physical-fallback="${physicalIndex}" alt="${escapeHtml(name||'Card')}" onerror="cardImageFallback(this)"><div class="card-art-fallback">Artwork unavailable<br><small>${escapeHtml(name||'Card')}</small></div></div>`;
}
async function cardImageFallback(img){
  const base=normalizeCardBase(img.dataset.cardBase||'');
  let step=Number(img.dataset.fallbackStep||0);
  const ptcg=/images\.pokemontcg\.io/i.test(base),completeDirect=/\.(?:png|webp|jpe?g|avif)(?:\?.*)?$/i.test(base)&&!ptcg;
  const attempts=completeDirect?[]:ptcg?[()=>cardImage(base,'low','png')]:[
    ()=>cardImage(base,'high','png'),
    ()=>cardImage(base,'low','webp'),
    ()=>cardImage(base,'low','png')
  ];
  if(base&&step<attempts.length){img.dataset.fallbackStep=String(step+1);img.src=attempts[step]();return;}
  const cardId=img.dataset.cardId||'';
  const live=img._luckyCard||(cardId?(state.cards[cardId]||preparedPack?.cards?.find(c=>c.id===cardId)):null);
  if(live&&(live.source||preparedPack?.source)==='tcgp'){
    const fallbacks=live._tcgpFallbacks||[],idx=Number(img.dataset.pocketFallback||0);
    if(idx<fallbacks.length){img.dataset.pocketFallback=String(idx+1);img.dataset.cardBase=fallbacks[idx];img.dataset.fallbackStep='0';img.parentElement?.classList.remove('broken');img.parentElement?.classList.add('loading-art');img.src=fallbacks[idx];return;}
  }
  // Try any already identity-verified alternate artwork before another lookup.
  if(live&&(live.source||preparedPack?.source||'tcg')!=='tcgp'){
    const direct=physicalCardArtworkCandidatesV163(live,preparedPack?.set||live?.set||null),idx=Number(img.dataset.physicalFallback||0);
    if(idx<direct.length){img.dataset.physicalFallback=String(idx+1);img.dataset.cardBase=direct[idx];img.dataset.fallbackStep='0';img.parentElement?.classList.remove('broken');img.parentElement?.classList.add('loading-art');img.src=direct[idx];return;}
  }
  if(!ptcg&&cardId&&img.dataset.altTried!=='1'){
    img.dataset.altTried='1';
    if(live&&(live.source||preparedPack?.source||'tcg')!=='tcgp'){
      let alt=await pokemonTcgArtworkBaseV5(live,preparedPack?.set||live?.set||null);
      if(!alt)alt=await scrydexArtworkBaseV164(live,preparedPack?.set||live?.set||null);
      if(alt&&normalizeCardBase(alt)!==base){
        live.image=alt;if(state.cards[cardId]){state.cards[cardId].image=alt;try{localStorage.setItem('luckyDexSave',JSON.stringify(state));}catch(e){}}
        img.dataset.cardBase=alt;img.dataset.fallbackStep='0';img.parentElement?.classList.remove('broken');img.parentElement?.classList.add('loading-art');img.src=cardImage(alt,'high','png');return;
      }
    }
  }
  img.parentElement?.classList.remove('loading-art');img.parentElement?.classList.add('broken');
}
window.cardImageFallback=cardImageFallback;

async function getCardDetail(brief,signal=null){
  if(signal?.aborted)throw new DOMException('Cancelled','AbortError');
  if(cardDetailCache.has(brief.id))return cardDetailCache.get(brief.id);
  if(brief?._libraryNative||brief?._pocketNative){const card={...brief};cardDetailCache.set(brief.id,card);return card;}
  let card;
  try{
    const detail=signal?(packCacheV13.cards[brief.id]||await packFetch(API.card(brief.id),signal)):await fetchJson(API.card(brief.id));
    card={...brief,...detail,image:detail.image||brief.image||''};
  }catch(e){if(signal?.aborted)throw e;card={...brief,rarity:brief.rarity||'Unknown'};}
  if(signal?.aborted)throw new DOMException('Cancelled','AbortError');
  cardDetailCache.set(brief.id,card);
  return card;
}

async function resolveCardArtwork(card,set=null,source=card?.source||'tcg',signal=null){
  if(signal?.aborted)throw new DOMException('Cancelled','AbortError');
  if(!card)return '';
  if(source!=='tcgp'&&window.LuckyDexCardArt){
    try{
      const local=await LuckyDexCardArt.resolveLocal(card,set);
      if(local){card.image=local;card._artIdentityVerified=true;card._artSource='luckydex-library-v1';return local;}
    }catch(e){if(signal?.aborted)throw e;}
  }
  if(source!=='tcgp'){
    const bundled=bundledPtcgArtworkRecordV152(card,set);
    if(bundled?.images){const art=bundled.images.large||bundled.images.small||'';if(art){card.image=art;card._artIdentityVerified=true;card._artSource='bundled-identity';if((!card.rarity||/^(?:none|unknown)$/i.test(String(card.rarity)))&&bundled.rarity)card.rarity=bundled.rarity;return art;}}
  }
  if(card.image&&!/limitlesstcg\.nyc3\.cdn\.digitaloceanspaces\.com/i.test(String(card.image)))return normalizeCardBase(card.image);
  try{
    const detail=await getCardDetail(card,signal);
    if(detail.image){card.image=normalizeCardBase(detail.image);card._artIdentityVerified=true;card._artSource='tcgdex';return card.image;}
  }catch(e){if(signal?.aborted)throw e;}
  if(source!=='tcgp'){
    const ptcg=await pokemonTcgArtworkBaseV5(card,set,signal);if(ptcg){card.image=ptcg;card._artSource='PokemonTCG';return ptcg;}
    const scrydex=await scrydexArtworkBaseV164(card,set,signal);if(scrydex){card.image=scrydex;return scrydex;}
  }
  let setDetail=set;
  const setId=card.set?.id||card.setId||set?.id;
  if(!setDetail?.serie?.id&&setId){try{setDetail=signal?await packFetch(API.tcgSet(setId),signal):await fetchJson(API.tcgSet(setId));}catch(e){if(signal?.aborted)throw e;}}
  const derived=deriveCardBase(card,setDetail);if(derived)card.image=derived;return derived;
}
async function repairOwnedCardImages(limit=40){
  const missing=Object.values(state.cards).filter(c=>!c.image).slice(0,limit);
  if(!missing.length)return;
  for(let i=0;i<missing.length;i+=4){
    const chunk=missing.slice(i,i+4);
    await Promise.allSettled(chunk.map(async c=>{const base=await resolveCardArtwork(c);if(base)c.image=base;}));
  }
  save();if(collectionMode==='cards')renderCollection();
}

/* startup / title */
function renderTitlePartners(){
  const row=document.getElementById('titlePartners');if(!row)return;
  const team=state.team.map(k=>state.pokemon[k]).filter(Boolean).slice(0,3);
  const use=team.length?team:[{id:1},{id:25},{id:4}];
  row.innerHTML=use.map(p=>`<img src="${API.sprite(p.id,!!p.shiny)}" alt="">`).join('');
  const rank=document.getElementById('titleRankText');if(rank)rank.textContent=`TRAINER RANK ${currentRank()}`;
}
// Shared callers refresh the single Adventure owner.
function renderAdventurePartyMini(){window.LuckyDexAdventure?.refresh?.();}
function renderZones(){window.LuckyDexAdventure?.refresh?.();}
function updateSearchCard(){window.LuckyDexAdventure?.refresh?.();}
function renderStarter(){
  const panel=document.getElementById('starterPanel');if(!panel)return;
  if(Object.keys(state.pokemon).length||!window.luckyTitleDismissed){panel.hidden=true;return;}
  panel.hidden=false;
  const starters=[{id:1,name:'Bulbasaur'},{id:4,name:'Charmander'},{id:7,name:'Squirtle'},{id:25,name:'Pikachu'}];
  document.getElementById('starterChoices').innerHTML=starters.map(s=>`<button class="starter-choice" data-starter="${s.id}"><img src="${API.sprite(s.id)}"><b>${s.name}</b></button>`).join('');
  document.querySelectorAll('[data-starter]').forEach(b=>b.onclick=()=>chooseStarter(Number(b.dataset.starter)));
}
function renderGlobalHud(){
  const rank=currentRank();
  ['trainerRankMini','trainerRank'].forEach(id=>{const el=document.getElementById(id);if(el)el.textContent=rank;});
  const binds={coinMini:state.profile.coins,ticketMini:state.profile.tickets,arcadeCoinCount:state.profile.coins,packCoinCount:state.profile.coins,packTicketCount:state.profile.tickets,packDustCount:state.profile.dust,
    pokeballCount:state.inventory.pokeball,greatballCount:state.inventory.greatball,ultraballCount:state.inventory.ultraball,berryCount:state.inventory.berry,battleBerryCount:`×${state.inventory.berry}`};
  Object.entries(binds).forEach(([id,v])=>{const el=document.getElementById(id);if(el)el.textContent=fmt(v);});
  renderTitlePartners();renderAdventurePartyMini();updatePackButton();renderDaily();
}
function showAdventureHub(){window.LuckyDexAdventure?.enter?.();}
function navigate(page){
  if(page!=='adventure'&&document.querySelector('.page.active')?.dataset.page==='adventure')window.LuckyDexAdventure?.leave?.();
  if(page!=='packs'&&document.body.classList.contains('pack-opening'))closePackOpening(true);
  if(page!=='arcade')window.LuckyDexArcadeWorld?.leave();
  if(page!=='trade')window.LuckyDexTrade?.leave();
  document.querySelectorAll('.page').forEach(x=>x.classList.toggle('active',x.dataset.page===page));
  document.querySelectorAll('[data-nav]').forEach(x=>x.classList.toggle('active',x.dataset.nav===page));
  if(page==='adventure')showAdventureHub();
  if(page==='collection'){rebuildCollectionControls();renderTeamPanel();renderCollection();}
  if(page==='arcade')window.LuckyDexArcadeWorld?.openWorld();
  if(page==='trade')window.LuckyDexTrade?.enter();
  if(page==='packs'){closePackOpening(true);loadSets(document.getElementById('cardSource').value);updatePackButton();updatePackFormatV5();}
  if(page==='profile')renderProfile();
}
/* Arcade result overlay */
/* physical packs: 10 cards / 4 common / 3 uncommon / 3 foil slots */
async function pickCardForSlotV5(briefs,targetTier,used,variant=null,signal=null,set=null,source='tcg'){
  if(signal?.aborted)throw new DOMException('Cancelled','AbortError');
  const pool=briefs.filter(c=>!used.has(c.id));if(!pool.length)return getCardDetail(briefs[Math.floor(Math.random()*briefs.length)],signal);
  const attempts=Math.min(pool.length,targetTier>=4?30:20);let best=null,bestScore=1e9;const tried=new Set();
  for(let i=0;i<attempts;i++){
    let brief;do{brief=pool[Math.floor(Math.random()*pool.length)];}while(tried.has(brief.id)&&tried.size<pool.length);tried.add(brief.id);
    let card=await getCardDetail(brief,signal);if(source==='tcg'&&!card?._libraryNative)card=await enrichPhysicalCardV151(card,set,signal);const tier=rarityTier(card.rarity);let score=Math.abs(tier-targetTier)*10;
    if(variant==='reverse'&&card.variants&&!card.variants.reverse)score+=6;
    if(variant==='holo'&&card.variants&&!(card.variants.holo||tier>=2))score+=4;
    if(score<bestScore){best=card;bestScore=score;}if(score===0)break;
  }
  if(best)return best;let fallback=await getCardDetail(pool[0],signal);if(source==='tcg'&&!fallback?._libraryNative)fallback=await enrichPhysicalCardV151(fallback,set,signal);return fallback;
}
function physicalPackSizeV250(set){return window.LuckyDexPack?.physicalPackSizeFor?.(set)||10;}
function physicalPackSlotsV250(set,luckyPack=false){
  const size=physicalPackSizeV250(set),hit=Math.max(2,hitTierForSource('tcg'));
  const normalTargets=size===4?[0,1]:size===6?[0,0,1,1]:size===8?[0,0,0,1,1]:[0,0,0,0,1,1,1];
  const reverseCount=size>=8?2:1,slots=normalTargets.map(target=>[target,'normal']);
  for(let i=0;i<reverseCount;i++)slots.push([i===0?rollWeighted([[0,.45],[1,.45],[2,.10]]):rollWeighted([[1,.55],[2,.38],[3,.07]]),'reverse']);
  slots.push([hit,'holo']);
  if(luckyPack){
    const holoIndex=slots.length-1,reverseStart=holoIndex-reverseCount;
    slots[holoIndex]=[6,'holo'];
    if(reverseCount===2){slots[reverseStart]=[4,'reverse'];slots[reverseStart+1]=[5,'reverse'];}
    else {slots[reverseStart]=[5,'reverse'];const bonus=Math.max(0,reverseStart-1);slots[bonus]=[4,slots[bonus][1]];}
  }
  return slots;
}
async function buildBalancedPack(set,source,luckyPack=false,signal=null){
  const briefs=set.cards||[];if(!briefs.length)throw new Error('No cards');const cards=[],used=new Set();
  if(source==='tcgp'){
    const pocketSize=window.LuckyDexPocket?.packSize(set)||5;
    const plan=pocketSize===4&&set?._deluxe?
      (luckyPack?[4,4,5,6]:[0,1,2,Math.max(3,hitTierForSource(source))]):
      (luckyPack?[4,4,4,5,6]:[0,0,1,rollWeighted([[1,.72],[2,.25],[3,.03]]),hitTierForSource(source)]);
    for(const target of plan){const c=await pickCardForSlotV5(briefs,target,used,null,signal,set,source);c.image=deriveCardBase(c,set)||c.image;c._foil='';cards.push(c);used.add(c.id);}return cards;
  }
  const slots=physicalPackSlotsV250(set,luckyPack);
  for(const [target,variant] of slots){const c=await pickCardForSlotV5(briefs,target,used,variant,signal,set,source);if(c.image)c.image=normalizeCardBase(c.image);c._foil=variant==='reverse'?'Reverse Holo':variant==='holo'?'Foil':'';cards.push(c);used.add(c.id);}
  return cards;
}
function updatePackFormatV5(){
  const source=document.getElementById('cardSource')?.value||'tcg',physical=source==='tcg',setId=document.getElementById('setSelect')?.value||'',set=setCache[source]?.find(s=>s.id===setId)||cachedSetV13(setId,source),pocketSize=window.LuckyDexPocket?.packSize(set||setId)||5;
  const t=document.getElementById('packFormatTitle'),c=document.getElementById('packFormatCopy'),b=document.getElementById('packCountBadge');
  const physicalSize=physical?physicalPackSizeV250(set):0;
  if(t)t.textContent=physical?`${physicalSize}-card booster`:pocketSize===4?'4-card Deluxe Pocket pack':'5-card Pocket pack';
  if(c)c.textContent=physical?`${physicalSize} cards · scaled to this set size`:pocketSize===4?'Deluxe format · Four Diamond+ guaranteed':'Pocket-style 5-card rarity spread';
  if(b)b.textContent=physical?String(physicalSize):String(pocketSize);
}
function updatePackButton(){
  const btn=document.getElementById('openPackBtn');if(!btn)return;const e=packEntitlement();btn.textContent=e.label;btn.disabled=e.mode==='coins'&&state.profile.coins<e.cost;
  const daily=document.getElementById('dailyPackPill');if(daily)daily.textContent=state.profile.lastDailyPack!==todayKey()?'Daily ready':'Daily claimed';
  const copy=document.getElementById('packPriceCopy');if(copy)copy.textContent=e.mode==='daily'?'Your first pack today is free.':e.mode==='ticket'?'A Pack Ticket will be used.':`${fmt(e.cost)} Lucky Coins`;
  const dust=document.getElementById('dustExchangeBtn');if(dust)dust.disabled=state.profile.dust<100;updatePackFormatV5();
}

function renderSealedPack(){
  const {set,source,cards}=preparedPack,boosters=(set.boosters||[]).filter(b=>b.artwork_front),booster=boosters.length?boosters[Math.floor(Math.random()*boosters.length)]:null;
  const realArt=isOnlineV13()&&booster?.artwork_front?assetFlexible(booster.artwork_front):'';
  const logo=isOnlineV13()&&set.logo?`<img class="pack-logo" src="${assetFlexible(set.logo)}" alt="">`:'';
  const packHtml=realArt?
    `<button class="sealed-pack real-pack" id="sealedPack" aria-label="Open ${escapeHtml(set.name)} booster"><img class="booster-art" src="${realArt}" alt="${escapeHtml(booster?.name||set.name)} booster"></button>`:
    `<button class="sealed-pack" id="sealedPack" aria-label="Open ${escapeHtml(set.name)} pack"><div class="pack-foil"></div><div class="pack-notch"></div>${logo}<div class="pack-title"><small>${source==='tcgp'?'TCG POCKET':'POKÉMON TCG'}</small><b>${escapeHtml(set.name)}</b><span>${cards.length} cards</span></div><div class="tear-line"></div></button>`;
  document.getElementById('packStage').innerHTML=`<button class="pack-exit" id="packExitBtn">‹ SHOP</button><div class="pack-instruction">Tap the pack to tear it open · ${cards.length} cards</div>${packHtml}`;
  document.getElementById('packExitBtn').onclick=()=>closePackOpening();document.getElementById('sealedPack').onclick=tearPack;
}





async function openCardModal(card){
  if(!card)return;const stored=state.cards[card.id]||card;let base=card.image||stored.image||'';
  if(!base){base=await resolveCardArtwork(stored);if(base&&state.cards[card.id]){state.cards[card.id].image=base;save();}}
  const img=document.getElementById('cardDialogImage');img.parentElement.classList.toggle('broken',!base);img.dataset.cardBase=normalizeCardBase(base);img.dataset.cardId=card.id||stored.id||'';img.dataset.fallbackStep='0';img.dataset.altTried='0';img.dataset.pocketFallback='0';img.dataset.physicalFallback='0';img._luckyCard={...stored,...card};img.src=base?cardImage(base,'high','webp'):'';img.onerror=()=>cardImageFallback(img);
  document.getElementById('cardDialogName').textContent=card.name||stored.name;document.getElementById('cardDialogMeta').textContent=`${card.rarity||stored.rarity||'Unknown rarity'} · ${card.set?.name||stored.setName||stored.set||'Unknown set'}`;
  const badges=[];if(stored.count)badges.push(`Owned ×${stored.count}`);if(card.localId||stored.localId)badges.push(`#${card.localId||stored.localId}`);if(card._foil)badges.push(card._foil);const t=rarityTier(card.rarity||stored.rarity);if(t>=3)badges.push(tierLabel(t));document.getElementById('cardDialogBadges').innerHTML=badges.map(x=>`<span>${escapeHtml(x)}</span>`).join('');document.getElementById('cardDialog').showModal();
}

/* Back handling + startup wiring */
window.handleLuckyBack=function(){
  const openDialog=document.querySelector('dialog[open]');if(openDialog){openDialog.close();return true;}
  if(document.body.classList.contains('pack-opening')){closePackOpening();return true;}
  if(document.body.classList.contains('arcade-open')){window.LuckyDexArcadeWorld?.backFromGame(true);return true;}
  const starter=document.getElementById('starterPanel');if(starter&&!starter.hidden){starter.hidden=true;document.getElementById('titleScreen').classList.remove('hidden-title');window.luckyTitleDismissed=false;return true;}
  if(document.querySelector('.page.active')?.dataset.page==='adventure'&&window.LuckyDexAdventure?.handleBack?.())return true;
  return false;
};

function wireV5(){
  const title=document.getElementById('titleScreen');renderTitlePartners();
  document.getElementById('titleContinueBtn').onclick=()=>{window.luckyTitleDismissed=true;title.classList.add('hidden-title');renderStarter();showAdventureHub();};
  document.getElementById('starterBackBtn').onclick=()=>{document.getElementById('starterPanel').hidden=true;window.luckyTitleDismissed=false;title.classList.remove('hidden-title');};
  document.getElementById('cardSource').onchange=e=>{closePackOpening(true);loadSets(e.target.value);updatePackButton();updatePackFormatV5();};
  updatePackFormatV5();showAdventureHub();renderTitlePartners();setTimeout(()=>repairOwnedCardImages(60),1800);
}


/* === v0.6.2 patch: chronology + rare-card drama === */
const __origCommitPreparedPackV62 = commitPreparedPack;
commitPreparedPack = function(){
  if(!preparedPack||preparedPack.committed||preparedPack.debug)return;
  const openedSetMeta={source:preparedPack.source,setId:preparedPack.set?.id,setName:preparedPack.set?.name};
  __origCommitPreparedPackV62();
  try{window.LuckyDexPackBrowser?.recordOpen?.(preparedPack.set,preparedPack.source,Date.now());}catch(_){}
  try{Promise.resolve(window.LuckyDexTrade?.noteOpenedSet?.(openedSetMeta)).catch(()=>{});}catch(_){}
  try{
    if(preparedPack?.cards?.length){
      const rel = preparedPack.set?.releaseDate || '';
      preparedPack.cards.forEach(c=>{ if(state.cards[c.id]) state.cards[c.id].setRelease = rel; });
      save();
    }
  }catch(e){}
};



rebuildCollectionControls = function(){
  const filter=document.getElementById('collectionFilter'),group=document.getElementById('collectionGroupFilter'),oldFilter=filter.value,oldGroup=group.value;
  if(collectionMode==='pokemon'){
    filter.innerHTML='<option value="all">All caught</option><option value="shiny">Shiny only</option><option value="team">Adventure team</option><option value="duplicates">Duplicates</option>';
    const ids=new Set(Object.values(state.pokemon).map(x=>x.id)),ownedGens=GENERATIONS.filter(g=>[...ids].some(id=>id>=g.min&&id<=g.max));
    group.innerHTML='<option value="all">All generations</option>'+ownedGens.map(g=>{const n=[...ids].filter(id=>id>=g.min&&id<=g.max).length;return `<option value="gen:${g.id}">Gen ${g.id} · ${escapeHtml(g.name)} · ${n}/${g.max-g.min+1}</option>`;}).join('');
  } else {
    filter.innerHTML='<option value="all">All cards</option><option value="rare">Rare hits</option><option value="duplicates">Duplicates</option>';
    const map=new Map();
    Object.values(state.cards).forEach(c=>{
      const k=cardSetKey(c), row=map.get(k)||{key:k,name:cardSetName(c),ids:new Set(),total:Number(c.setTotal||0),release:c.setRelease||''};
      row.ids.add(c.id); row.total=Math.max(row.total,Number(c.setTotal||0)); row.release = row.release || c.setRelease || '';
      map.set(k,row);
    });
    const rows=[...map.values()].sort((a,b)=>String(a.release||'9999-99-99').localeCompare(String(b.release||'9999-99-99'))||a.name.localeCompare(b.name));
    group.innerHTML='<option value="all">All owned sets</option>'+rows.map(s=>`<option value="set:${escapeHtml(s.key)}">${escapeHtml(s.release?`${s.release} · ${s.name}`:s.name)} · ${s.ids.size}${s.total?`/${s.total}`:''}</option>`).join('');
  }
  if([...filter.options].some(o=>o.value===oldFilter))filter.value=oldFilter;
  if([...group.options].some(o=>o.value===oldGroup))group.value=oldGroup;
  document.getElementById('teamPanel').hidden=collectionMode!=='pokemon';
  const quick=document.getElementById('binderQuickFilters');if(quick)quick.hidden=collectionMode!=='cards';const dc=document.getElementById('binderDuplicateCount');if(dc)dc.textContent=Object.values(state.cards||{}).filter(c=>Number(c.count||0)>1).length;
};





/* === v0.7 patch: stronger scene + pack suspense === */




/* === v0.8 pack spectacle + Clefairy action reliability === */







/* === v0.9 polish patch: proper game-scene Clefairy + cinematic pack hits === */







/* === v0.10: visible card reveal scene + cache-busted build === */


/* v0.10.1 reveal completion hardening */










































/* === v0.13: chronological sets, offline-ready packs, cinematic reveal === */
const PACK_CACHE_KEY_V13='luckyDexPackCacheV13';
const SET_CATALOG_KEY_V13='luckyDexSetCatalogV13';
let packCacheV13={sets:{},cards:{}};
try{packCacheV13=JSON.parse(localStorage.getItem(PACK_CACHE_KEY_V13)||'null')||{sets:{},cards:{}};}catch(e){packCacheV13={sets:{},cards:{}};}
if(!packCacheV13.sets)packCacheV13.sets={};if(!packCacheV13.cards)packCacheV13.cards={};
function savePackCacheV13(){
  try{localStorage.setItem(PACK_CACHE_KEY_V13,JSON.stringify(packCacheV13));}catch(e){
    // Keep the newest 220 card details if WebView storage is tight.
    const entries=Object.entries(packCacheV13.cards||{}).sort((a,b)=>(b[1]._cachedAt||0)-(a[1]._cachedAt||0)).slice(0,220);
    packCacheV13.cards=Object.fromEntries(entries);try{localStorage.setItem(PACK_CACHE_KEY_V13,JSON.stringify(packCacheV13));}catch(_e){}
  }
}
function cacheSetV13(set,source){
  if(!set?.id)return;packCacheV13.sets[`${source}:${set.id}`]={...set,_cachedAt:Date.now(),_source:source};savePackCacheV13();
}
function cacheCardsV13(cards,set,source){
  for(const c of cards||[]){if(!c?.id)continue;packCacheV13.cards[c.id]={...c,setId:set?.id||c.set?.id||c.setId||'',setName:set?.name||c.set?.name||'',setRelease:set?.releaseDate||'',source,_cachedAt:Date.now()};}
  savePackCacheV13();
}
function cachedSetV13(id,source){return packCacheV13.sets[`${source}:${id}`]||null;}
function cachedCardsForSetV13(id){return Object.values(packCacheV13.cards||{}).filter(c=>(c.setId||c.set?.id)===id);}
function isOnlineV13(){return navigator.onLine!==false;}

const __fetchJsonV13=fetchJson;
fetchJson=async function(url){
  // Transparent persistent cache for full set/card detail requests.
  const cardMatch=String(url).match(/\/cards\/([^/?#]+)$/);
  const setMatch=String(url).match(/\/sets\/([^/?#]+)$/);
  if(!isOnlineV13()){
    if(cardMatch&&packCacheV13.cards[decodeURIComponent(cardMatch[1])])return packCacheV13.cards[decodeURIComponent(cardMatch[1])];
    if(setMatch){const id=decodeURIComponent(setMatch[1]);const hit=Object.values(packCacheV13.sets).find(s=>s.id===id);if(hit)return hit;}
  }
  try{
    const data=await __fetchJsonV13(url);
    if(cardMatch&&data?.id){packCacheV13.cards[data.id]={...data,_cachedAt:Date.now()};savePackCacheV13();}
    return data;
  }catch(e){
    if(cardMatch){const id=decodeURIComponent(cardMatch[1]);if(packCacheV13.cards[id])return packCacheV13.cards[id];}
    if(setMatch){const id=decodeURIComponent(setMatch[1]);const hit=Object.values(packCacheV13.sets).find(s=>s.id===id);if(hit)return hit;}
    throw e;
  }
};

function readCatalogCacheV13(){try{return JSON.parse(localStorage.getItem(SET_CATALOG_KEY_V13)||'null')||{};}catch(e){return {};}}
function saveCatalogCacheV13(source,sets){const all=readCatalogCacheV13();all[source]={sets,at:Date.now()};try{localStorage.setItem(SET_CATALOG_KEY_V13,JSON.stringify(all));}catch(e){}}



async function buildOfflinePackV13(set,source,luckyPack=false){
  const pool=cachedCardsForSetV13(set.id);
  const need=source==='tcgp'?(window.LuckyDexPocket?.packSize(set)||5):physicalPackSizeV250(set);
  if(pool.length<need)throw new Error('offline-cache-empty');
  const shuffled=[...pool].sort(()=>Math.random()-.5),cards=[];
  const byTier=t=>shuffled.filter(c=>rarityTier(c.rarity)===t&&!cards.some(x=>x.id===c.id));
  const take=(target,foil='')=>{
    let opts=byTier(target);if(!opts.length)opts=shuffled.filter(c=>!cards.some(x=>x.id===c.id));
    if(!opts.length)opts=pool;
    const c={...opts[Math.floor(Math.random()*opts.length)]};c._foil=foil;cards.push(c);
  };
  if(source==='tcgp'){
    const plan=need===4&&set?._deluxe?(luckyPack?[4,4,5,6]:[0,1,2,Math.max(3,hitTierForSource(source))]):(luckyPack?[4,4,4,5,6]:[0,0,1,1,Math.max(2,hitTierForSource(source))]);
    plan.forEach(t=>take(t,''));
  }else{
    physicalPackSlotsV250(set,luckyPack).forEach(([target,variant])=>take(target,variant==='reverse'?'Reverse Holo':variant==='holo'?'Foil':''));
  }
  return cards.slice(0,need);
}

















// Give the player a clear offline-readiness hint on set changes.
let offlineHintEpoch=0;
async function updateOfflineHintV13(){
  const select=document.getElementById('setSelect'),source=document.getElementById('cardSource')?.value||'tcg';if(!select)return;
  const epoch=++offlineHintEpoch,setId=select.value,pool=cachedCardsForSetV13(setId),selectedSet=setCache[source]?.find(s=>s.id===setId)||cachedSetV13(setId,source),libraryInstalled=!!(source==='tcg'&&selectedSet?._libraryKey&&window.LuckyDexCardArt?.isInstalled?.(selectedSet._libraryKey)),need=source==='tcgp'?(window.LuckyDexPocket?.packSize(selectedSet||setId)||5):physicalPackSizeV250(selectedSet),metadata=libraryInstalled||!!cachedSetV13(setId,source)&&pool.length>=need;
  const blobs=!libraryInstalled&&metadata?await Promise.all(pool.map(c=>packCachedBlob(c.id))):[];
  if(epoch!==offlineHintEpoch||select.value!==setId||document.getElementById('cardSource').value!==source)return;
  let ready=metadata;
  for(let i=0;ready&&!libraryInstalled&&i<pool.length;i+=4){
    if(epoch!==offlineHintEpoch)return;
    const usable=await Promise.all(pool.slice(i,i+4).map((c,j)=>packArtworkIsUsable(c,blobs[i+j])));ready=usable.every(Boolean);
  }
  if(epoch!==offlineHintEpoch)return;
  let hint=document.getElementById('offlinePackHint');if(!hint){hint=document.createElement('div');hint.id='offlinePackHint';hint.className='v13-offline-hint';select.parentElement?.appendChild(hint);}
  hint.textContent=libraryInstalled?'✓ Exact artwork pack installed · offline-ready':ready?'✓ Offline-ready · cards and artwork cached':selectedSet?._libraryKey?(isOnlineV13()?'Exact artwork downloads when you open this set':'Exact artwork pack not installed'):isOnlineV13()?'Open this set online to cache cards and artwork':'Cards or artwork are not fully cached for this set';
  hint.classList.toggle('ready',ready);
}
setTimeout(()=>{
  document.getElementById('setSelect')?.addEventListener('change',()=>{updateOfflineHintV13();updatePackFormatV5();});
  document.getElementById('cardSource')?.addEventListener('change',()=>setTimeout(updateOfflineHintV13,250));
  window.addEventListener('online',updateOfflineHintV13);window.addEventListener('offline',updateOfflineHintV13);updateOfflineHintV13();
},120);

/* === v0.13.1: persistent offline artwork cache === */
const __cardImageV131=cardImage;
cardImage=function(base,q='high',ext='webp'){
  const s=String(base||'');if(/^blob:|^data:/i.test(s))return s;return __cardImageV131(base,q,ext);
};
let packDbPromiseV131=null;
function packDbV131(){
  if(packDbPromiseV131)return packDbPromiseV131;
  packDbPromiseV131=new Promise((resolve,reject)=>{
    try{
      const req=indexedDB.open('LuckyDexOfflinePackV164',1);
      req.onupgradeneeded=()=>{const db=req.result;if(!db.objectStoreNames.contains('images'))db.createObjectStore('images');};
      req.onsuccess=()=>resolve(req.result);req.onerror=()=>reject(req.error);
    }catch(e){reject(e);}
  });return packDbPromiseV131;
}
async function putOfflineImageV131(cardId,blob){
  if(!cardId||!blob)return;try{const db=await packDbV131();await new Promise((res,rej)=>{const tx=db.transaction('images','readwrite');tx.objectStore('images').put(blob,cardId);tx.oncomplete=res;tx.onerror=()=>rej(tx.error);});}catch(e){}
}


/* === v0.16.5 deterministic artwork identity migration ===
   v0.16.3 could cache a visually valid but WRONG Limitless image when a subset
   reused a parent set code/number. Purge those unverified URLs and use a fresh
   IndexedDB namespace so a bad blob cannot survive the fix. */
function migrateArtworkIdentityV165(){
  let oldSchema='';try{oldSchema=localStorage.getItem('luckyDexArtworkSchema')||'';}catch(_){ }
  if(oldSchema==='165')return;
  let changed=false;
  const externalAlternate=url=>/(?:limitlesstcg\.nyc3\.cdn\.digitaloceanspaces\.com|images\.pokemontcg\.io|images\.scrydex\.com)/i.test(String(url||''));
  const resetCard=card=>{
    if(!card||(card.source||'tcg')==='tcgp')return;
    // v0.16.3 could persist a decodable but identity-wrong alternate image.
    // Keep TCGdex card-ID artwork, but force all cross-catalogue art through the
    // stricter v0.16.4 resolver once before trusting it again.
    if(externalAlternate(card.image)){card.image='';changed=true;}
    for(const key of ['_resolvedArtworkUrl','_artIdentityVerified','_artSource','_ptcgId','_ptcgNumber','_ptcgImageLarge','_ptcgImageSmall','_scrydexId','_scrydexImageLarge','_scrydexImageSmall','_limitlessSetCode','_limitlessNumber']){
      if(Object.prototype.hasOwnProperty.call(card,key)){delete card[key];changed=true;}
    }
  };
  for(const card of Object.values(state.cards||{}))resetCard(card);
  for(const card of Object.values(packCacheV13.cards||{}))resetCard(card);
  try{localStorage.setItem('luckyDexArtworkSchema','165');}catch(_){ }
  if(changed){try{save();}catch(_){ }try{savePackCacheV13();}catch(_){ }}
}


/* === v0.15.9 runtime-order hardening ===
   IMPORTANT: all startup work runs only after the whole script has evaluated.
   Earlier builds booted midway through this file, before packCacheV13 and
   offlineHintEpoch had left their lexical TDZ. renderGlobalHud() ->
   updatePackButton() -> updatePackFormatV5() -> cachedSetV13() therefore threw
   before the app could finish wiring. That single runtime exception explained
   the frozen starter, Wild Search/Expedition stalls and permanent Loading sets.
*/
window.__LUCKYDEX_BUILD='0.24.5-promos-small-packs-pull-impact';
window.addEventListener('error',event=>{
  try{localStorage.setItem('luckyDexLastRuntimeError',JSON.stringify({build:window.__LUCKYDEX_BUILD,message:String(event?.message||'Unknown error'),source:String(event?.filename||''),line:Number(event?.lineno||0),at:Date.now()}));}catch(_){ }
});
window.addEventListener('unhandledrejection',event=>{
  try{localStorage.setItem('luckyDexLastRuntimeError',JSON.stringify({build:window.__LUCKYDEX_BUILD,message:String(event?.reason?.stack||event?.reason||'Unhandled rejection'),at:Date.now()}));}catch(_){ }
});
// Adventure's one controller uses explicit shared services and owns its saves.
window.LuckyDexAdventureBridge={
  getState:()=>state,save,currentRank,effectiveShinyOdds,addTrainerXp,bumpDaily,checkDexMilestones,showToast,navigate,
  generationFor:generationForId,generationForId,combatStats,grantPokemonXp,ensurePokemonBuild,
  ZONES,LOCAL_ZONE_POOLS,BALLS,TYPE_MOVE,LEGENDARIES,MYTHICAL,RARE_WILD,API,
  vibrate,renderTeamPanel,renderCollection,renderProfile,
  openSupplies:()=>{renderSupplyShop();document.getElementById('supplyDialog').showModal();}
};

(function startLuckyDexV0158(){
  // At this point PACK_CACHE_KEY_V13, packCacheV13, offlineHintEpoch and the
  // IndexedDB helpers are all initialized. No startup renderer can touch a TDZ.
  try{migrateArtworkIdentityV165();}catch(e){console.error('[LuckyDex] artwork migration failed',e);}
  Promise.resolve(bootLuckyDexV0158()).catch(e=>console.error('[LuckyDex] boot failed',e));
  try{wireV5();}catch(e){console.error('[LuckyDex] wiring failed',e);}
})();

