(function(root,factory){
  const core=root.LuckyDexPowerTrialCore||(typeof require==='function'?require('./arcade-power-trial-core.js'):null);
  const api=factory(root,core);root.LuckyDexPowerTrial=api;if(typeof module!=='undefined'&&module.exports)module.exports=api;
})(typeof window!=='undefined'?window:globalThis,function(root,core){
  'use strict';
  if(!core)throw new Error('LuckyDexPowerTrialCore required');
  const $=id=>typeof document!=='undefined'?document.getElementById(id):null;
  const now=()=>typeof performance!=='undefined'&&performance.now?performance.now():Date.now();
  const raf=fn=>(root.requestAnimationFrame||globalThis.requestAnimationFrame||((f)=>setTimeout(()=>f(now()),16)))(fn);
  const caf=id=>(root.cancelAnimationFrame||globalThis.cancelAnimationFrame||clearTimeout)(id);
  const platform=()=>root.LuckyDexArcadePlatform||globalThis.LuckyDexArcadePlatform;
  const session=()=>root.LuckyDexArcadeSession||globalThis.LuckyDexArcadeSession;
  let opened=false,difficulty='normal',participants=[],selectedKey=null,run=null,phase='setup',rafId=0,chargePressedAt=null,lockedCharge=0,impactStartedAt=0,resultUntil=0,lastStrike=null,completionHandled=false,hostClick=null,keyDown=null,keyUp=null,chargePointer=null;

  function stopLoop(){if(rafId){caf(rafId);rafId=0;}}
  function schedule(){if(opened&&!rafId&&['charge','impact','result'].includes(phase))rafId=raf(frame);}
  function saveState(){try{root.save?.();}catch(_){}}
  function powerState(){const s=root.state||globalThis.state;if(!s)return null;s.arcade=platform()?.ensureArcadeState?.(s.arcade)||s.arcade||{};return s.arcade.powerTrial;}
  function rareRate(){return Math.max(0,Math.min(1,Number(root.state?.settings?.rareOdds?.powerTrialGolden??.02)||0));}
  function currentParticipant(){return participants.find(row=>row.key===selectedKey)||null;}
  function profile(){return core.difficultyProfile(difficulty);}
  function esc(v){return String(v??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));}

  function shell(){
    const host=$('powerTrialGame');if(!host)return null;
    host.innerHTML=`<div class="arcade-full-head"><button class="game-exit" data-exit-game>‹ ARCADE</button><div class="arcade-mascot"><img src="arcade/sprites/actors/pokemon/68.png" alt="Machamp"><span>POKÉMON CHALLENGE COURSE</span></div></div>
      <div class="powertrial-shell">
        <section id="powerTrialSetup" class="powertrial-setup">
          <div class="powertrial-title"><div><div class="eyebrow">ATTACK EVENT</div><h2>Power Trial</h2><p>Charge your Pokémon's strike, then nail the impact timing. Attack raises the ceiling — your timing delivers the power.</p></div><div class="powertrial-record"><small>BEST</small><b id="powerTrialBest">0</b></div></div>
          <div class="powertrial-difficulties" aria-label="Power Trial difficulty"><button data-power-difficulty="easy">EASY<small>Wide timing</small></button><button data-power-difficulty="normal">NORMAL<small>Balanced</small></button><button data-power-difficulty="hard">HARD<small>Heavy targets</small></button></div>
          <div class="powertrial-picker-head"><b>CHOOSE YOUR POKÉMON</b><span>Base Attack influences about one third of each hit.</span></div>
          <div id="powerTrialPicker" class="powertrial-picker"></div>
          <div id="powerTrialEmpty" class="powertrial-empty" hidden>Catch a Pokémon first, then return to the Challenge Course.</div>
          <button id="powerTrialStart" class="primary powertrial-start" type="button">START POWER TRIAL</button>
        </section>
        <section id="powerTrialPlay" class="powertrial-play" hidden>
          <div class="powertrial-hud"><span>TARGET <b id="powerTrialRound">1 / 5</b></span><span>ATTACK <b id="powerTrialAttack">60</b></span><span>SCORE <b id="powerTrialScore">0</b></span></div>
          <div class="powertrial-arena">
            <div class="powertrial-target-wrap"><div id="powerTrialGolden" class="powertrial-golden" hidden>★ GOLDEN TARGET ★</div><div id="powerTrialTarget" class="powertrial-target" data-kind="crate"><i></i><b id="powerTrialTargetName">Training Crate</b><small id="powerTrialThreshold">POWER 48 TO CLEAR</small></div></div>
            <div class="powertrial-pokemon"><img id="powerTrialPokemon" src="arcade/sprites/actors/pokemon/25.png" alt=""><b id="powerTrialPokemonName">Pokémon</b></div>
            <div id="powerTrialFeedback" class="powertrial-feedback"><b>HOLD CHARGE</b><span>Release near the peak.</span></div>
          </div>
          <div class="powertrial-meter charge"><div class="powertrial-meter-head"><b>CHARGE</b><span>Too long = power drops</span></div><div class="powertrial-track"><i id="powerTrialChargeFill"></i><em></em></div></div>
          <div class="powertrial-meter impact"><div class="powertrial-meter-head"><b>IMPACT</b><span>Hit the centre line</span></div><div class="powertrial-impact-track"><i></i><em id="powerTrialImpactMarker"></em></div></div>
          <div class="powertrial-controls"><button id="powerTrialCharge" type="button"><b>CHARGE</b><span>HOLD & RELEASE</span></button><button id="powerTrialHit" type="button" disabled><b>HIT!</b><span>TIME IT</span></button></div>
        </section>
      </div>`;
    return host;
  }

  function refreshParticipants(){
    participants=platform()?.challengeParticipants?.('attack')||[];const ps=powerState(),remembered=ps?.lastPokemonKey;selectedKey=participants.some(x=>x.key===remembered)?remembered:(participants[0]?.key||null);renderSetup();
  }
  function renderSetup(){
    const grid=$('powerTrialPicker');if(!grid)return;grid.innerHTML=participants.map(row=>`<button type="button" data-power-pokemon="${esc(row.key)}" class="${row.key===selectedKey?'selected':''}"><img src="${esc(row.image)}" alt=""><span><b>${row.shiny?'★ ':''}${esc(row.name)}</b><small>Lv.${row.level} · ATTACK ${row.baseStat}</small></span></button>`).join('');
    $('powerTrialEmpty').hidden=participants.length>0;$('powerTrialStart').disabled=!selectedKey;
    for(const btn of document.querySelectorAll('[data-power-difficulty]'))btn.classList.toggle('active',btn.dataset.powerDifficulty===difficulty);
    const best=Number(powerState()?.bestScores?.[difficulty]||0);$('powerTrialBest').textContent=String(best);
  }
  function setSetupVisible(value){$('powerTrialSetup').hidden=!value;$('powerTrialPlay').hidden=!!value;}
  function setTarget(index){
    const target=core.TARGETS[index],golden=run?.goldenIndex===index,node=$('powerTrialTarget');if(!target||!node)return;
    node.dataset.kind=target.id;node.className=`powertrial-target${golden?' is-golden':''}`;node.classList.remove('is-cleared','is-failed','is-perfect');
    $('powerTrialTargetName').textContent=target.name;$('powerTrialThreshold').textContent=`POWER ${core.thresholdFor(index,difficulty)} TO CLEAR`;$('powerTrialGolden').hidden=!golden;$('powerTrialRound').textContent=`${index+1} / ${core.TARGETS.length}`;
  }
  function setParticipant(row){if(!row)return;$('powerTrialAttack').textContent=String(row.baseStat);$('powerTrialPokemon').src=row.image;$('powerTrialPokemon').alt=row.name;$('powerTrialPokemonName').textContent=`${row.shiny?'★ ':''}${row.name}`;}
  function resetMeters(){$('powerTrialChargeFill').style.width='0%';$('powerTrialImpactMarker').style.left='0%';$('powerTrialHit').disabled=true;}
  function beginTarget(){
    const index=run?.strikes?.length||0;if(index>=core.TARGETS.length)return finishRun();setTarget(index);resetMeters();chargePressedAt=null;lockedCharge=0;impactStartedAt=0;lastStrike=null;phase='charge';$('powerTrialCharge').disabled=false;$('powerTrialFeedback').innerHTML='<b>HOLD CHARGE</b><span>Release near the peak — holding too long drains it.</span>';session()?.update?.('powerTrial',{runText:'5 increasingly heavy targets · charge + impact timing',rewardText:'Attack trial score · Lucky Coins · rare Golden Target',liveLabel:'TARGET',liveValue:`${index+1}/5`});schedule();
  }
  function startRun(){
    const row=currentParticipant();if(!row)return false;const ps=powerState();if(ps)ps.lastPokemonKey=row.key;saveState();session()?.hideResult?.();run=core.createRun({difficulty,participant:row,rng:Math.random,goldenRate:rareRate()});completionHandled=false;phase='charge';setSetupVisible(false);setParticipant(row);$('powerTrialScore').textContent='0';beginTarget();return true;
  }
  function pressCharge(pointerId=null){if(phase!=='charge'||chargePressedAt!=null)return false;chargePressedAt=now();chargePointer=pointerId;$('powerTrialCharge').classList.add('active');return true;}
  function releaseCharge(){
    if(phase!=='charge'||chargePressedAt==null)return false;const t=now(),elapsed=t-chargePressedAt;lockedCharge=core.chargeQuality(elapsed,profile());chargePressedAt=null;chargePointer=null;$('powerTrialCharge').classList.remove('active');$('powerTrialCharge').disabled=true;phase='impact';impactStartedAt=t;$('powerTrialHit').disabled=false;$('powerTrialFeedback').innerHTML=`<b>CHARGE ${Math.round(lockedCharge*100)}%</b><span>Now HIT when the marker crosses the centre.</span>`;schedule();return true;
  }
  function strike(impactOverride=null){
    if(phase!=='impact'||!run)return false;const q=impactOverride==null?core.impactQuality(now()-impactStartedAt,profile()):Math.max(0,Math.min(1,Number(impactOverride)||0));lastStrike=core.applyStrike(run,{chargeQuality:lockedCharge,impactQuality:q});if(!lastStrike)return false;phase='result';resultUntil=now()+1050;$('powerTrialHit').disabled=true;
    const target=$('powerTrialTarget');target.classList.add(lastStrike.cleared?'is-cleared':'is-failed');if(lastStrike.perfect)target.classList.add('is-perfect');$('powerTrialScore').textContent=String(run.score);
    const bonus=lastStrike.golden&&lastStrike.cleared?' · GOLD +50':'';$('powerTrialFeedback').innerHTML=`<b>${lastStrike.grade} · ${lastStrike.power.toFixed(1)} POWER</b><span>${lastStrike.cleared?`${lastStrike.target.visual}! +${lastStrike.score}${bonus}`:`Needed ${lastStrike.threshold} · +${lastStrike.score}`}</span>`;root.navigator?.vibrate?.(lastStrike.perfect?[22,28,38]:lastStrike.cleared?25:12);schedule();return true;
  }
  function commitResult(){
    if(completionHandled||!run?.finished)return null;completionHandled=true;const ps=powerState(),goldStrike=run.goldenIndex>=0?run.strikes[run.goldenIndex]:null,full=run.clears===core.TARGETS.length,newBest=run.score>Number(ps?.bestScores?.[difficulty]||0);
    if(ps){ps.gamesPlayed++;ps.fullClears+=full?1:0;ps.hardClears+=full&&difficulty==='hard'?1:0;ps.bestScore=Math.max(Number(ps.bestScore)||0,run.score);ps.bestScores[difficulty]=Math.max(Number(ps.bestScores?.[difficulty])||0,run.score);ps.bestSingleHit=Math.max(Number(ps.bestSingleHit)||0,run.bestSingleHit);ps.bestPerfects=Math.max(Number(ps.bestPerfects)||0,run.perfects);ps.perfectHits+=run.perfects;ps.totalTargetsCleared+=run.clears;if(run.goldenIndex>=0)ps.goldenTargetsSeen++;if(goldStrike?.cleared)ps.goldenTargetsCleared++;ps.lastPokemonKey=run.participant?.key||ps.lastPokemonKey;}
    const award=platform()?.awardRun?.({gameId:'powerTrial',label:'Power Trial',score:run.score,coins:core.rewardForRun(run),dailyEligible:false})||{coinsAwarded:0};saveState();return {award,full,newBest,goldStrike};
  }
  function finishRun(){
    stopLoop();phase='finished';const committed=commitResult();if(!committed)return false;const {award,full,newBest,goldStrike}=committed,row=run.participant,ps=powerState();
    const review={title:'POWER TRIAL COMPLETE',mode:'Attack Event',difficulty:profile().label,metricLabel:'SCORE',metricValue:String(run.score),stats:[{label:'Pokémon',value:`${row.shiny?'★ ':''}${row.name}`},{label:'Base Attack',value:String(row.baseStat)},{label:'Targets Cleared',value:`${run.clears}/5`},{label:'Perfect Strikes',value:String(run.perfects)},{label:'Best Hit',value:`${run.bestSingleHit.toFixed(1)} power`},...(run.goldenIndex>=0?[{label:'Golden Target',value:goldStrike?.cleared?'CLEARED':'MISSED'}]:[])],pbs:[{label:`${profile().label} Best`,value:String(ps?.bestScores?.[difficulty]||run.score),isNew:newBest}],rewards:[{label:'Lucky Coins',value:String(award.coinsAwarded||0)}]};
    session()?.showResult?.('powerTrial',{title:'POWER TRIAL COMPLETE',metricLabel:'SCORE',metricValue:run.score,coinsAwarded:award.coinsAwarded,itemAwarded:award.itemAwarded,bestText:newBest?'NEW BEST SCORE':full?'ALL FIVE CLEARED':'',details:[{title:`${row.shiny?'★ ':''}${row.name}`,subtitle:`Attack ${row.baseStat} · ${profile().label}`,kind:'racer'},{title:`${run.clears}/5 targets`,subtitle:`${run.perfects} perfect · best ${run.bestSingleHit.toFixed(1)}`,kind:'score'}],review,replayLabel:'TRY AGAIN',changeLabel:'CHANGE POKÉMON',onReplay:()=>startRun(),onChange:()=>showSetup(),onBack:()=>root.LuckyDexArcadeWorld?.backFromGame?.()});return true;
  }
  function showSetup(){stopLoop();phase='setup';run=null;setSetupVisible(true);refreshParticipants();return true;}
  function frame(t){
    rafId=0;if(!opened)return;
    if(phase==='charge'&&chargePressedAt!=null){const elapsed=t-chargePressedAt,q=core.chargeQuality(elapsed,profile());$('powerTrialChargeFill').style.width=`${Math.round(q*100)}%`;if(elapsed>=profile().maxChargeMs)releaseCharge();}
    else if(phase==='impact'){const elapsed=t-impactStartedAt,pos=core.impactPosition(elapsed,profile());$('powerTrialImpactMarker').style.left=`${(pos*100).toFixed(1)}%`;if(elapsed>=profile().impactTimeoutMs)strike(0);}
    else if(phase==='result'&&t>=resultUntil){if(run?.finished)finishRun();else beginTarget();}
    schedule();
  }
  function onClick(e){
    const d=e.target.closest?.('[data-power-difficulty]');if(d&&phase==='setup'){difficulty=core.DIFFICULTIES[d.dataset.powerDifficulty]?d.dataset.powerDifficulty:'normal';renderSetup();return;}
    const p=e.target.closest?.('[data-power-pokemon]');if(p&&phase==='setup'){if(participants.some(x=>x.key===p.dataset.powerPokemon)){selectedKey=p.dataset.powerPokemon;renderSetup();}return;}
    if(e.target.closest?.('#powerTrialStart')){startRun();return;}if(e.target.closest?.('#powerTrialHit')){strike();return;}
  }
  function bind(){
    const host=$('powerTrialGame');hostClick=onClick;host.addEventListener('click',hostClick);
    const charge=$('powerTrialCharge');charge.addEventListener('pointerdown',e=>{if(e.button!==undefined&&e.button!==0)return;if(pressCharge(e.pointerId)){charge.setPointerCapture?.(e.pointerId);e.preventDefault();}});charge.addEventListener('pointerup',e=>{if(chargePointer==null||e.pointerId===chargePointer){releaseCharge();charge.releasePointerCapture?.(e.pointerId);e.preventDefault();}});charge.addEventListener('pointercancel',()=>releaseCharge());
    keyDown=e=>{if(e.repeat)return;if((e.code==='Space'||e.key===' ')&&phase==='charge'){pressCharge('keyboard');e.preventDefault();}else if((e.code==='Enter'||String(e.key).toLowerCase()==='a')&&phase==='impact'){strike();e.preventDefault();}};
    keyUp=e=>{if((e.code==='Space'||e.key===' ')&&chargePointer==='keyboard'){releaseCharge();e.preventDefault();}};root.addEventListener?.('keydown',keyDown);root.addEventListener?.('keyup',keyUp);
  }
  function unbind(){const host=$('powerTrialGame');if(host&&hostClick)host.removeEventListener('click',hostClick);if(keyDown)root.removeEventListener?.('keydown',keyDown);if(keyUp)root.removeEventListener?.('keyup',keyUp);hostClick=keyDown=keyUp=null;chargePointer=null;}
  function open(){opened=true;shell();session()?.mount?.('powerTrial',$('powerTrialGame'));bind();difficulty='normal';refreshParticipants();showSetup();return true;}
  function close(){opened=false;stopLoop();unbind();session()?.hideResult?.();phase='closed';run=null;chargePressedAt=null;return true;}
  function pause(){stopLoop();return true;}
  function resume(){schedule();return true;}
  function snapshot(){return {opened,phase,difficulty,selectedKey,run:run?{difficulty:run.difficulty,score:run.score,clears:run.clears,perfects:run.perfects,goldenIndex:run.goldenIndex,strikes:run.strikes.length}:null};}
  return Object.freeze({open,close,pause,resume,startRun,showSetup,pressCharge,releaseCharge,strike,snapshot});
});
