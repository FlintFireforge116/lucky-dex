# LuckyDex v0.25.3 Fossil Museum / Mining sprite sources

The active v0.25.3 museum uses local pixel-art sprites only. Runtime display uses nearest-neighbour scaling; no remote image requests are required.

## Pokémon Platinum Underground mining art

The following are exact PNG assets from `pret/pokeplatinum`, `res/graphics/mining/objects/`:
- `armor-fossil` — `armor_fossil.png`
- `claw-fossil` — `claw_fossil.png`
- `dome-fossil` — `dome_fossil.png`
- `helix-fossil` — `helix_fossil.png`
- `odd-keystone` — `odd_keystone.png`
- `root-fossil` — `root_fossil.png`
- `skull-fossil` — `skull_fossil.png`

## Existing packaged pixel item sprites

- `old-amber` — existing packaged PokeAPI item sprite.
The remaining museum IDs retain the small offline pixel-art sprites already packaged with LuckyDex v0.25.0. They replace the v0.25.2 large painted excavation stand-ins and are copied into the v0.25.3 namespace so the active museum/mining renderer never falls back to the painted set.

- `cover-fossil`
- `plume-fossil`
- `jaw-fossil`
- `sail-fossil`
- `fossilized-bird`
- `fossilized-dino`
- `fossilized-drake`
- `fossilized-fish`
- `relic-copper`
- `relic-silver`
- `relic-gold`
- `relic-vase`
- `relic-band`
- `relic-statue`
- `relic-crown`
- `hard-stone`
- `everstone`
- `fire-stone`
- `water-stone`
- `thunder-stone`
- `leaf-stone`
- `moon-stone`

## Auxiliary mining sprites

- `star-piece`
- `rare-bone`
