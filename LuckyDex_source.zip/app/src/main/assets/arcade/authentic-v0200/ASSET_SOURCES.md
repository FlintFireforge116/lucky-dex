# LuckyDex v0.20.0 Arcade asset sources

These files are fetched during the GitHub Actions build and packaged locally in the APK. The game does **not** load them from the internet at runtime.

- **Pokémon-Amie (X/Y and OR/AS)** — Berry Picker, Head It, Tile Puzzle and the Amie venue use actual Pokémon-Amie screenshots from ORAS Wiki; additional extracted X/Y sheets come from The Spriters Resource.
- **HeartGold / SoulSilver** — Goldenrod Game Corner, Celadon Game Corner, Ruins of Alph and Indigo Plateau use actual HGSS game screenshots. Voltorb Flip UI pieces come from `samualtnorman/voltorb-flip`, a faithful reconstruction using extracted/recreated HGSS visual assets.
- **Pokémon Emerald — Berry Blender** — `center.png`, `outer.png`, `arrow.png`, `start.png` and particle graphics come from the `pret/pokeemerald` decompilation's `graphics/berry_blender/` directory. The Lilycove venue uses an actual Emerald game screenshot.
- **Pokémon Stadium — Clefairy Says** — the classroom scene is an actual Pokémon Stadium capture used as the visual base.
- **Sinnoh Underground / Oreburgh Mining** — Oreburgh uses an actual BDSP game screenshot and the mining board uses official Pokémon Sinnoh-region gameplay imagery showing the digging interface.

Every exact URL is declared in `scripts/fetch_arcade_v0200_assets.py`. If any required source is unavailable or returns non-image content, CI fails before Gradle rather than substituting generated artwork.
