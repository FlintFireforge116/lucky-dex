# LuckyDex v0.25.5 Fossil Dig / Museum item-art sources

The active v0.25.5 Fossil Dig and Oreburgh Museum continue to use one local pixel-art item namespace.

## v0.25.5 replacements

The remaining simplified archaeology stand-ins were replaced with the packaged item sprites from `PokeAPI/sprites` for:

- Comet Shard
- Relic Copper
- Relic Silver
- Relic Gold
- Relic Vase
- Relic Band
- Relic Statue
- Relic Crown

These same files are used by both the dig wall and museum display. Relic Copper/Silver/Gold also provide the coin-like archaeology art used by the relic/coin presentation, instead of the old flat painted discs.

All other v0.25.4 authentic fossil, stone, Ball, treasure and card sprites were carried forward unchanged. Everything remains packaged locally for offline use and rendered with nearest-neighbour/pixelated scaling.
