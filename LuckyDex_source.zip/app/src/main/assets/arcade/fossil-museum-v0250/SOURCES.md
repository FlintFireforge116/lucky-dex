# LuckyDex v0.25.0 Fossil Museum asset provenance

- `oreburgh-museum-dppt-empty.png`: based on the Oreburgh Mining Museum interior reference supplied by the user in this project. The central player/guide sprites were removed with pixel-preserving local edits, while the counter staff remain part of the authentic room. Three empty display cases are duplicated from the room's own case artwork into otherwise unused floor space so every LuckyDex exhibit can sit in a physical case/pedestal. The final image is nearest-neighbour enlarged for the phone UI.
- Existing `arcade/sprites/items/*.png` entries are the already-packaged PokeAPI item sprites documented by `scripts/fetch_arcade_sprites.py` (`https://github.com/PokeAPI/sprites`).
- Missing v0.25.0 archaeology/treasure icons are small local pixel reconstructions stored under `items/` so the Android runtime never depends on remote image loading. Their stable IDs deliberately match PokeAPI/Pokémon item names so they can be replaced one-for-one by exact source sprites later without changing saves or gameplay.
- Underground rock/soil textures continue to use `arcade/authentic-v0200/mining/*`.

## v0.25.1 museum polish
- `oreburgh-museum-dppt-empty-v0251.png`: derives from the reviewed v0.25.0 Oreburgh room. The added small glass case that overlapped the lower entrance was removed from the doorway and relocated to open floor space above the central pedestal; no remote runtime asset is introduced.
