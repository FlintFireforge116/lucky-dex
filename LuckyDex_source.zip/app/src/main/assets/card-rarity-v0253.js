/* LuckyDex v0.25.3 — canonical printed-rarity / finish / chase classification. */
(function(root,factory){
  const api=factory();
  if(typeof module==='object'&&module.exports)module.exports=api;
  else root.LuckyDexCardRarity=api;
})(typeof window==='object'?window:globalThis,function(){
  'use strict';
  const OVERRIDES=Object.freeze({});
  const norm=v=>String(v??'').toLowerCase().replace(/[‐‑‒–—]/g,'-').replace(/[_]+/g,' ').replace(/\s+/g,' ').trim();
  const uniq=a=>[...new Set(a.filter(Boolean))];
  const classTier=Object.freeze({common:0,uncommon:1,rare:2,'double-rare':3,ultra:4,illustration:4,'special-illustration':5,secret:6,promo:2,unknown:1});

  function canonicalId(card){return String(card?.id||card?._libraryCanonicalId||'').trim();}
  function explicitRarity(card){
    const id=canonicalId(card),override=OVERRIDES[id];
    if(override?.rarity)return String(override.rarity);
    return String(card?.rarity??card?.printedRarity??'').trim();
  }
  function sourceText(card){
    const explicit=explicitRarity(card);
    if(explicit && !/^(unknown|n\/a|none|-)$/i.test(explicit))return {text:norm(explicit),authoritative:true,original:explicit};
    const fallback=[card?.rarityLabel,card?.variant,card?.subtype,card?.subtypes,card?.category,card?.name].flat().filter(Boolean).join(' ');
    return {text:norm(fallback),authoritative:false,original:explicit||''};
  }
  function chaseTraitsFor(card,source){
    const structured=[card?.chaseTraits,card?.traits,card?._traits,card?.variant,card?._variant].flat().filter(Boolean).join(' ');
    // When printed rarity is known, use it plus structured metadata. Card-name inference is fallback only.
    const text=norm([source.text,structured,source.authoritative?'':card?.name].filter(Boolean).join(' '));
    const out=[];
    if(/\bgold\b/.test(text))out.push('gold');
    if(/\bhyper\b/.test(text))out.push('hyper');
    if(/\bcrown\b/.test(text))out.push('crown');
    if(/\brainbow\b/.test(text))out.push('rainbow');
    if(/\bsecret\b/.test(text)||/\bhyper rare\b/.test(text)||/\bgold rare\b/.test(text)||/\bcrown rare\b/.test(text))out.push('secret');
    if(/\bspecial illustration\b|\bsir\b/.test(text))out.push('special-illustration');
    if(/\bfull art\b/.test(text))out.push('full-art');
    if(/\btextured\b/.test(text))out.push('textured');
    return uniq(out);
  }
  function rarityClassFor(card,source,traits){
    const r=source.text;
    if(card?._achievementReward===true)return 'promo';
    if(/\bpromo\b/.test(r))return 'promo';
    // Secret/jackpot printed labels are their own rarity class.
    if(/\bsecret(?: rare)?\b|\brare secret\b|\bhyper rare\b|\bgold rare\b|\bcrown rare\b/.test(r))return 'secret';
    if(/\bspecial illustration(?: rare)?\b|\brare rainbow\b|\brainbow rare\b|\bshiny ultra rare\b|\btwo star\b|\b2 star\b|\btwo shiny\b/.test(r))return 'special-illustration';
    if(/\billustration rare\b|\bcharacter rare\b|\bone star\b|\b1 star\b/.test(r))return 'illustration';
    if(/\bultra rare\b|\brare ultra\b|\bfull art\b|\bradiant rare\b|\bradiant\b|\bamazing rare\b|\bace spec\b|\bshining\b|\brare holo (?:ex|gx|v|max|vmax|vstar|lv\.?x)\b|\brare break\b|\brare prime\b/.test(r))return 'ultra';
    if(/\bdouble rare\b|\bfour diamond\b|\b4 diamond\b/.test(r))return 'double-rare';
    if(/\buncommon\b|\btwo diamond\b|\b2 diamond\b/.test(r))return 'uncommon';
    if(/\bcommon\b|\bone diamond\b|\b1 diamond\b/.test(r))return 'common';
    if(/\brare\b|\bholo\b|\bthree diamond\b|\b3 diamond\b/.test(r))return 'rare';
    if(traits.includes('secret'))return 'secret';
    if(traits.includes('special-illustration')||traits.includes('rainbow'))return 'special-illustration';
    return 'unknown';
  }
  function finishFor(card,source){
    const id=canonicalId(card),override=OVERRIDES[id];
    const text=norm([override?.finish,card?._foil,card?.finish,card?.foil,card?.printing,card?.surface].filter(Boolean).join(' '));
    if(/reverse/.test(text))return 'reverse-holo';
    if(/textur/.test(text))return 'textured';
    if(/special foil|cosmos|galaxy|shatter|cracked ice/.test(text))return 'special-foil';
    if(/holo|foil/.test(text))return 'holo';
    // Printed rarity can explicitly say Holo, but this never changes rarityClass.
    if(/\bholo\b/.test(source.text))return 'holo';
    return 'normal';
  }
  function labelFor(rarityClass,traits){
    const secret=rarityClass==='secret'||traits.includes('secret');
    if(secret){
      if(traits.includes('gold'))return 'GOLD SECRET RARE — JACKPOT';
      if(traits.includes('hyper'))return 'HYPER SECRET RARE — JACKPOT';
      if(traits.includes('crown'))return 'CROWN SECRET RARE — JACKPOT';
      return 'SECRET RARE';
    }
    if(traits.includes('rainbow'))return 'RAINBOW RARE';
    return {common:'',uncommon:'UNCOMMON',rare:'RARE / HOLO','double-rare':'DOUBLE RARE',ultra:'ULTRA RARE',illustration:'ILLUSTRATION HIT','special-illustration':'SPECIAL ILLUSTRATION',promo:'PROMO',unknown:''}[rarityClass]||'';
  }
  function classify(card={},set=null){
    if(typeof card==='string')card={rarity:card};
    const source=sourceText(card),traits=chaseTraitsFor(card,source);
    const rarityClass=rarityClassFor(card,source,traits);
    const tier=classTier[rarityClass]??1;
    const finish=finishFor(card,source);
    let impactTier=tier,impactStyle='normal';
    if(rarityClass==='secret'||traits.some(x=>['gold','hyper','crown','secret'].includes(x))){impactTier=6;impactStyle=traits.some(x=>['gold','hyper','crown'].includes(x))?'gold':'secret';}
    else if(rarityClass==='special-illustration'||traits.includes('rainbow')){impactTier=5;impactStyle=traits.includes('rainbow')?'prismatic':'special';}
    else if(rarityClass==='illustration'){impactTier=4;impactStyle='illustration';}
    else if(rarityClass==='ultra'){impactTier=4;impactStyle='ultra';}
    else if(rarityClass==='double-rare'){impactTier=3;impactStyle='ultra';}
    else if(rarityClass==='rare'){impactTier=2;impactStyle='holo';}
    else if(finish==='reverse-holo'){impactTier=Math.max(2,impactTier);impactStyle='reverse';}
    else if(finish!=='normal'){impactTier=Math.max(2,impactTier);impactStyle='holo';}
    const originalRarity=source.original||String(card?.rarity||'Unknown');
    return Object.freeze({
      originalRarity,rarityClass,tier,finish,chaseTraits:Object.freeze(traits.slice()),impactTier,impactStyle,
      revealLabel:labelFor(rarityClass,traits),isRareHit:tier>=3||rarityClass==='secret'
    });
  }
  function tier(cardOrRarity){return classify(typeof cardOrRarity==='string'?{rarity:cardOrRarity}:cardOrRarity||{}).tier;}
  function finish(card){return classify(card||{}).finish;}
  function tradeClass(card,set=null){
    if(card?._achievementReward===true)return 'achievement';
    const c=classify(card||{},set);
    return c.rarityClass==='promo'?'promo':c.tier;
  }
  function dustTier(card){return classify(card||{}).tier;}
  return Object.freeze({OVERRIDES,classify,tier,finish,tradeClass,dustTier});
});
