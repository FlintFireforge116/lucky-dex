(function(root){
'use strict';
function text(v){return String(v||'').trim().toLowerCase();}
function explicitKind(card){
  const f=text(card?._foil||card?.foilVariant||'');
  if(f.includes('reverse'))return 'reverse';
  if(f.includes('holo')||f==='foil')return 'holo';
  return '';
}
function kind(card){
  if(!card)return '';
  const explicit=explicitKind(card);if(explicit)return explicit;
  const stored=text(card.foilKind);
  if(stored==='holo'||stored==='reverse')return stored;
  const counts=card.foilCounts||{};
  if(Number(counts.holo||0)>0)return 'holo';
  if(Number(counts.reverse||0)>0)return 'reverse';
  // Save compatibility: old LuckyDex builds did not persist the transient
  // _foil field. Printed Holo rarities can still be recognised safely; old
  // Reverse Holo pulls cannot be reconstructed without inventing data.
  if(/\bholo\b/.test(text(card.rarity)))return 'holo';
  return '';
}
function className(card){const k=kind(card);return k?`foil-${k}`:'';}
function recordPull(stored,pulled){
  if(!stored||typeof stored!=='object')return stored;
  const counts=stored.foilCounts&&typeof stored.foilCounts==='object'?stored.foilCounts:{};
  stored.foilCounts={normal:Number(counts.normal||0),reverse:Number(counts.reverse||0),holo:Number(counts.holo||0)};
  const k=explicitKind(pulled);
  stored.foilCounts[k||'normal']++;
  if(k==='holo')stored.foilKind='holo';
  else if(k==='reverse'&&stored.foilKind!=='holo')stored.foilKind='reverse';
  return stored;
}
function badges(card){
  const c=card?.foilCounts||{},out=[];
  if(Number(c.holo||0)>0)out.push(`Holo ×${Number(c.holo)}`);
  if(Number(c.reverse||0)>0)out.push(`Reverse Holo ×${Number(c.reverse)}`);
  if(!out.length){const k=kind(card);if(k==='holo')out.push('Holo');else if(k==='reverse')out.push('Reverse Holo');}
  return out;
}
function resetMotion(el){if(!el?.style)return;el.style.setProperty('--foil-x','50%');el.style.setProperty('--foil-y','50%');el.style.setProperty('--foil-tilt','0deg');}
function bindMotion(el){
  if(!el||el.dataset?.foilMotion==='1')return ()=>{};
  if(el.dataset)el.dataset.foilMotion='1';resetMotion(el);
  const move=(clientX,clientY)=>{const r=el.getBoundingClientRect?.();if(!r?.width||!r?.height)return;const x=Math.max(0,Math.min(100,(clientX-r.left)/r.width*100)),y=Math.max(0,Math.min(100,(clientY-r.top)/r.height*100));el.style.setProperty('--foil-x',`${x.toFixed(1)}%`);el.style.setProperty('--foil-y',`${y.toFixed(1)}%`);el.style.setProperty('--foil-tilt',`${((x-50)/18).toFixed(2)}deg`);};
  const pointer=e=>move(e.clientX,e.clientY),touch=e=>{const t=e.touches?.[0]||e.changedTouches?.[0];if(t)move(t.clientX,t.clientY);};
  el.addEventListener?.('pointermove',pointer,{passive:true});el.addEventListener?.('pointerleave',()=>resetMotion(el),{passive:true});el.addEventListener?.('touchmove',touch,{passive:true});el.addEventListener?.('touchend',()=>resetMotion(el),{passive:true});
  return ()=>resetMotion(el);
}
function apply(el,card,{motion=false}={}){if(!el)return '';el.classList?.remove('foil-holo','foil-reverse');const cls=className(card);if(cls)el.classList?.add(cls);if(motion&&cls)bindMotion(el);return cls;}
const api={kind,className,recordPull,badges,bindMotion,apply};
root.LuckyDexCardFoil=api;
if(typeof module!=='undefined'&&module.exports)module.exports=api;
})(typeof window!=='undefined'?window:globalThis);
