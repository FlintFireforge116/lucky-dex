(function(root){
'use strict';
const $=id=>typeof document!=='undefined'?document.getElementById(id):null;
const SHELVES={
 berryPicker:{button:'berryPickerStartBtn',stage:'.berry-picker-stage'},
 headIt:{button:'headItStartBtn',stage:'#headItPlayfield'},
 tilePuzzle:{button:'tilePuzzleStartBtn',stage:'#tilePuzzleBoard',wrap:'tile-authentic-frame-v0200'},
 berry:{button:'berryStartBtn',stage:'.berry-machine'},
 clefairy:{button:'clefairyStartV019',stage:'.clefairy-classroom-v019'},
 quiz:{button:'quizStartBtn',stage:'.quiz-stage'},
 ballDrop:{button:'ballDropBtn',stage:'.ball-drop-machine'},
 unown:{button:'unownStartBtn',stage:'.unown-chamber'}
};
function frameAround(stage,extra=''){
 if(!stage)return null;
 if(stage.closest('.arcade-authentic-frame-v0200'))return stage.closest('.arcade-authentic-frame-v0200');
 if(stage.matches('.berry-picker-stage,.berry-picker-stage-v019,#headItPlayfield,.berry-machine,.clefairy-classroom-v019,.quiz-stage,.ball-drop-machine,.unown-chamber')){stage.classList.add('arcade-authentic-frame-v0200');if(extra)stage.classList.add(extra);return stage;}
 const frame=document.createElement('div');frame.className=`arcade-authentic-frame-v0200 ${extra}`.trim();stage.parentNode.insertBefore(frame,stage);frame.appendChild(stage);return frame;
}
function installOne(gameId){const cfg=SHELVES[gameId],button=$(cfg?.button);if(!cfg||!button)return false;const game=button.closest('.arcade-game');const stage=game?.querySelector(cfg.stage);if(!game||!stage)return false;const frame=frameAround(stage,cfg.wrap||'');if(!frame)return false;let shelf=frame.querySelector(':scope > .arcade-start-shelf-v0200');if(!shelf){shelf=document.createElement('div');shelf.className='arcade-start-shelf-v0200';frame.appendChild(shelf);}const actions=button.closest('.game-actions');if(actions&&actions.parentNode!==shelf)shelf.appendChild(actions);else if(!actions&&button.parentNode!==shelf)shelf.appendChild(button);return true;}
function installStartShelves(){Object.keys(SHELVES).forEach(installOne);}
function refresh(gameId){installOne(gameId);document.body?.classList.add('arcade-v0200-game-open');requestAnimationFrame(()=>{const cfg=SHELVES[gameId],b=$(cfg?.button);b?.scrollIntoView?.({block:'nearest',inline:'nearest'});});}
function leaveGame(){document.body?.classList.remove('arcade-v0200-game-open');}
function init(){installStartShelves();}
const api={SHELVES,installStartShelves,refresh,leaveGame};root.LuckyDexArcadeFidelityV0200=api;if(typeof module!=='undefined'&&module.exports)module.exports=api;if(typeof document!=='undefined'){if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',init,{once:true});else init();}
})(typeof window!=='undefined'?window:globalThis);
