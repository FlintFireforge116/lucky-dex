(function(root,factory){
  const core=root.LuckyDexClearCutCore||(typeof require==='function'?require('./arcade-clear-cut-core.js'):null);
  const api=factory(root,core);root.LuckyDexClearCut=api;if(typeof module!=='undefined'&&module.exports)module.exports=api;
})(typeof window!=='undefined'?window:globalThis,function(root,core){
  'use strict';
  if(!core)throw new Error('LuckyDexClearCutCore required');
  const $=id=>typeof document!=='undefined'?document.getElementById(id):null;
  const now=()=>typeof performance!=='undefined'&&typeof performance.now==='function'?performance.now():Date.now();
  const raf=fn=>(root.requestAnimationFrame||globalThis.requestAnimationFrame||((f)=>setTimeout(()=>f(now()),16)))(fn);
  const caf=id=>(root.cancelAnimationFrame||globalThis.cancelAnimationFrame||clearTimeout)(id);
  const session=()=>root.LuckyDexArcadeSession||globalThis.LuckyDexArcadeSession;
  const platform=()=>root.LuckyDexArcadePlatform||globalThis.LuckyDexArcadePlatform;
  const racerIds=['clearCutPlayer','clearCutCpu1','clearCutCpu2','clearCutCpu3'];
  let opened=false,phase='closed',difficulty='normal',playerDex=123,match=null,rafId=0,phaseUntil=0,pausedFrom=null,pauseStartedAt=0,completionHandled=false,finalResult=null,rng=Math.random,frozenProgress=0;

  function stopLoop(){if(rafId){caf(rafId);rafId=0;}}
  function schedule(){if(!rafId&&['ready-round','dropping','result'].includes(phase))rafId=raf(frame);}
  function profile(){return core.difficultyProfile(difficulty);}
  function activeRound(){return match?.activeRound||null;}
  function setControls(active){const ready=$('clearCutReady'),controls=$('clearCutControls');if(ready)ready.hidden=active;if(controls)controls.hidden=!active;const cut=$('clearCutButton');if(cut)cut.disabled=phase!=='dropping';}
  function renderDifficulty(){
    if($('clearCutDifficultyLabel'))$('clearCutDifficultyLabel').textContent=profile().label.toUpperCase();
    if(typeof document!=='undefined')for(const btn of document.querySelectorAll?.('[data-clear-cut-difficulty]')||[]){const active=btn.dataset.clearCutDifficulty===difficulty;btn.classList?.toggle?.('active',active);btn.setAttribute?.('aria-pressed',String(active));}
    const best=Number(root.state?.arcade?.clearCutChallenge?.bestScores?.[difficulty]||0);if($('clearCutBest'))$('clearCutBest').textContent=best?`BEST ${best}/100`:'BEST —';
  }
  function renderPokemonPicker(){
    if(typeof document==='undefined')return;for(const btn of document.querySelectorAll?.('[data-clear-cut-pokemon]')||[]){const active=Number(btn.dataset.clearCutPokemon)===playerDex;btn.classList?.toggle?.('active',active);btn.setAttribute?.('aria-pressed',String(active));}
    const img=$('clearCutPlayer')?.querySelector?.('img');if(img){img.src=`arcade/sprites/actors/pokemon/${playerDex}.png`;img.alt=`Your ${core.CUTTERS.find(x=>x.dex===playerDex)?.name||'cutter'}`;}
  }
  function resetRoundVisual(index=0){
    const log=$('clearCutLog'),actual=$('clearCutActual'),slash=$('clearCutSlash'),judge=$('clearCutJudgement');
    if(log){log.classList.remove('is-cut','slash-left','slash-right');log.style.transform='translate3d(-50%,-120%,0)';}
    if(actual){actual.hidden=true;actual.style.top='50%';}
    if(slash)slash.hidden=true;if(judge){judge.hidden=true;judge.className='clearcut-judgement';judge.textContent='';}
    if($('clearCutRound'))$('clearCutRound').textContent=`${index+1}/5`;
  }
  function renderRacers(){
    if(!match)return;match.racers.forEach((r,i)=>{const el=$(racerIds[i]);if(!el)return;const img=el.querySelector?.('img');if(img){img.src=`arcade/sprites/actors/pokemon/${r.species.dex}.png`;img.alt=r.id==='player'?`Your ${r.species.name}`:`${r.label} ${r.species.name}`;}const total=el.querySelector?.('[data-clear-total]');if(total)total.textContent=String(r.total);const latest=el.querySelector?.('[data-clear-latest]');if(latest){const row=r.roundResults.at?.(-1);latest.textContent=row?`${row.judgement} ${row.score>=0?'+':''}${row.score}`:'—';latest.dataset.judgement=row?.judgement||'';}});
  }
  function positionTarget(log){const target=$('clearCutTarget');if(target)target.style.top=`${(Number(log?.targetPct||.5)*100).toFixed(1)}%`;}
  function logProgressAt(t){const round=activeRound();if(!round)return 0;return phase==='result'?frozenProgress:core.motionProgress(round.log,t);}
  function renderLog(t){
    const round=activeRound(),zone=$('clearCutDropZone'),logEl=$('clearCutLog');if(!round||!zone||!logEl)return;
    positionTarget(round.log);const progress=logProgressAt(t),zoneH=Math.max(260,Number(zone.clientHeight)||360),logH=Math.max(180,Number(logEl.offsetHeight)||250),bladeY=zoneH*.54,targetLocal=logH*Number(round.log.targetPct||.5),idealProgress=core.motionProgress(round.log,round.log.idealTimeMs),travel=zoneH+logH*1.35,startTop=bladeY-targetLocal-idealProgress*travel,top=startTop+progress*travel;
    logEl.style.transform=`translate3d(-50%,${top.toFixed(2)}px,0)`;
  }
  function showRoundResult(out){
    if(!out?.accepted)return;const result=out.result,round=out.round,log=$('clearCutLog'),actual=$('clearCutActual'),slash=$('clearCutSlash'),judge=$('clearCutJudgement');frozenProgress=core.motionProgress(round.log,result.cutAt);
    if(actual){const actualPct=Math.max(3,Math.min(97,Number(round.log.targetPct||.5)*100-Number(result.errorPct||0)));actual.style.top=`${actualPct.toFixed(1)}%`;actual.hidden=false;}
    if(log){log.classList.add('is-cut');log.classList.toggle('slash-left',result.errorPct<0);log.classList.toggle('slash-right',result.errorPct>=0);}
    if(slash){slash.hidden=false;slash.classList.remove('flash');void slash.offsetWidth;slash.classList.add('flash');}
    if(judge){judge.hidden=false;judge.className=`clearcut-judgement is-${result.judgement.toLowerCase()}`;judge.innerHTML=`<b>${result.judgement}</b><strong>${result.score>=0?'+':''}${result.score}</strong><small>${Math.abs(result.errorPct).toFixed(2)}% OFF</small>`;}
    renderRacers();if($('clearCutTotal'))$('clearCutTotal').textContent=String(match.player.total);if($('clearCutPlace'))$('clearCutPlace').textContent=String(core.placeFor(match,'player'));root.navigator?.vibrate?.(result.score===20?[20,25,30]:16);
  }
  function render(t=now()){
    if(!match)return;if($('clearCutTotal'))$('clearCutTotal').textContent=String(match.player.total);if($('clearCutPlace'))$('clearCutPlace').textContent=String(core.placeFor(match,'player'));renderRacers();if(['dropping','result'].includes(phase))renderLog(t);
    const status=$('clearCutStatus');if(status){if(phase==='ready-round')status.textContent='READY';else if(phase==='dropping')status.textContent='CUT THE LINE';else if(phase==='result')status.textContent='CUT SCORED';else status.textContent='';}
    session()?.update?.('clearCutChallenge',{runText:'5 logs · One cut each · Closest to the line wins',rewardText:'Placement · Lucky Coins',liveLabel:'TOTAL',liveValue:`${match.player.total}/100`});
  }
  function showReady({difficulty:key=difficulty,playerDex:dex=playerDex}={}){
    stopLoop();session()?.hideResult?.();difficulty=core.DIFFICULTIES[key]?key:'normal';playerDex=core.CUTTERS.some(x=>x.dex===Number(dex))?Number(dex):123;phase='idle';match=core.createMatch({difficulty,playerDex,rng,nowMs:now()});pausedFrom=null;completionHandled=false;finalResult=null;phaseUntil=0;setControls(false);resetRoundVisual(0);renderDifficulty();renderPokemonPicker();render();return true;
  }
  function selectDifficulty(key){if(!['idle','finished'].includes(phase)||!core.DIFFICULTIES[key])return false;difficulty=key;match=core.createMatch({difficulty,playerDex,rng,nowMs:now()});renderDifficulty();renderRacers();return true;}
  function selectPokemon(dex){if(!['idle','finished'].includes(phase))return false;const n=Number(dex);if(!core.CUTTERS.some(x=>x.dex===n))return false;playerDex=n;match=core.createMatch({difficulty,playerDex,rng,nowMs:now()});renderPokemonPicker();renderRacers();return true;}
  function prepareRound(index,t=now()){
    resetRoundVisual(index);phase='ready-round';phaseUntil=t+core.CONFIG.readyHoldMs;setControls(true);const banner=$('clearCutRoundBanner');if(banner){banner.hidden=false;banner.textContent=`LOG ${index+1}`;}renderRacers();schedule();
  }
  function beginDrop(t=now()){
    const index=Math.max(0,match?.currentRoundIndex+1||0);const round=core.startRound(match,index,t);if(!round)return false;phase='dropping';phaseUntil=0;const banner=$('clearCutRoundBanner');if(banner)banner.hidden=true;const btn=$('clearCutButton');if(btn)btn.disabled=false;render(t);return true;
  }
  function startMatch(){if(!opened||phase==='dropping'||phase==='ready-round'||phase==='result')return false;session()?.hideResult?.();match=core.createMatch({difficulty,playerDex,rng,nowMs:now()});completionHandled=false;finalResult=null;setControls(true);prepareRound(0,now());render();return true;}
  function cut(){
    if(phase!=='dropping'||!match)return {accepted:false,reason:'inactive'};const t=now(),out=core.cutPlayer(match,t,rng);if(!out.accepted)return out;phase='result';phaseUntil=t+core.CONFIG.resultHoldMs;const btn=$('clearCutButton');if(btn)btn.disabled=true;showRoundResult(out);render(t);schedule();return out;
  }
  function advanceFromResult(t){
    if(match?.finalized)return finishMatch(t);const next=(match?.currentRoundIndex||0)+1;prepareRound(next,t);return true;
  }
  function pause(){if(!['ready-round','dropping','result'].includes(phase))return false;pauseStartedAt=now();pausedFrom=phase;phase='paused';stopLoop();if($('clearCutPauseOverlay'))$('clearCutPauseOverlay').hidden=false;return true;}
  function resume(){if(phase!=='paused'||!pausedFrom)return false;const t=now(),delta=Math.max(0,t-pauseStartedAt);if(pausedFrom==='dropping')core.shiftActiveRound(match,delta);else if(phaseUntil)phaseUntil+=delta;phase=pausedFrom;pausedFrom=null;if($('clearCutPauseOverlay'))$('clearCutPauseOverlay').hidden=true;render(t);schedule();return true;}
  function frame(){
    rafId=0;if(!['ready-round','dropping','result'].includes(phase))return;const t=now();
    if(phase==='ready-round'&&t>=phaseUntil)beginDrop(t);
    else if(phase==='dropping'){
      const auto=core.autoMissIfNeeded(match,t,rng);if(auto?.accepted){phase='result';phaseUntil=t+core.CONFIG.resultHoldMs;showRoundResult(auto);}render(t);
    }else if(phase==='result'&&t>=phaseUntil)advanceFromResult(t);else render(t);
    schedule();
  }
  function finishMatch(t=now()){
    if(finalResult)return finalResult;if(!match)return null;const ranking=core.rankMatch(match),place=core.placeFor(match,'player'),player=match.player,reward=core.rewardFor(place,difficulty);finalResult={place,reward,difficulty,total:player.total,perfects:player.perfects,closestCutPct:player.closestCutPct,roundScores:[...player.roundScores],ranking:ranking.map(r=>r.id)};phase='finished';stopLoop();setControls(false);renderRacers();
    if(completionHandled)return finalResult;completionHandled=true;const p=platform();if(!root.state||!p?.ensureArcadeState)return finalResult;root.state.arcade=p.ensureArcadeState(root.state.arcade);const rec=root.state.arcade.clearCutChallenge,prevBest=Number(rec.bestScores?.[difficulty]||0),prevClosest=rec.closestCutPct==null?null:Number(rec.closestCutPct);
    rec.gamesPlayed=Number(rec.gamesPlayed||0)+1;if(place===1){rec.wins=Number(rec.wins||0)+1;rec.winsByDifficulty[difficulty]=Number(rec.winsByDifficulty?.[difficulty]||0)+1;}if(place<=3)rec.podiums=Number(rec.podiums||0)+1;rec.bestScore=Math.max(Number(rec.bestScore||0),Number(player.total||0));rec.bestScores[difficulty]=Math.max(Number(rec.bestScores?.[difficulty]||0),Number(player.total||0));rec.totalPerfects=Number(rec.totalPerfects||0)+Number(player.perfects||0);if(player.closestCutPct!=null&&(rec.closestCutPct==null||Number(player.closestCutPct)<Number(rec.closestCutPct)))rec.closestCutPct=Number(player.closestCutPct);
    const award=p.awardRun?.({gameId:'clearCutChallenge',label:'Clear Cut Challenge',score:Math.max(0,5-place),coins:reward})||{coinsAwarded:reward};root.save?.();const ordinal=place===1?'1ST':place===2?'2ND':place===3?'3RD':'4TH',scoreboard=ranking.map((r,i)=>({rank:String(i+1),label:r.id==='player'?'YOU':r.label,value:`${r.total}/100`,subtitle:`${r.perfects} PERFECT · ${r.closestCutPct==null?'—':r.closestCutPct.toFixed(2)+'%'} CLOSEST`,player:r.id==='player'}));
    const stats=player.roundScores.map((score,i)=>({label:`Log ${i+1}`,value:`${score>=0?'+':''}${score}`}));stats.push({label:'Perfect Cuts',value:String(player.perfects)},{label:'Closest Cut',value:player.closestCutPct==null?'—':`${player.closestCutPct.toFixed(2)}%`});
    const review={title:place===1?'MASTER CUTTER!':'CHALLENGE COMPLETE',mode:'Clear Cut Challenge',difficulty:profile().label,metricLabel:'TOTAL',metricValue:`${player.total}/100`,scoreboard,stats,pbs:[{label:`${profile().label} Best`,value:`${rec.bestScores[difficulty]}/100`,isNew:player.total>prevBest},{label:'Closest Ever',value:rec.closestCutPct==null?'—':`${Number(rec.closestCutPct).toFixed(2)}%`,isNew:player.closestCutPct!=null&&(prevClosest==null||player.closestCutPct<prevClosest)}],rewards:[{label:'Lucky Coins',value:String(award.coinsAwarded||0)}]};
    session()?.showResult?.('clearCutChallenge',{title:place===1?'MASTER CUTTER!':'CHALLENGE COMPLETE',metricLabel:'TOTAL',metricValue:`${player.total}/100`,coinsAwarded:award.coinsAwarded,bestText:`BEST ${rec.bestScore}/100`,review,replayLabel:'PLAY AGAIN',onReplay:()=>showReady({difficulty,playerDex}),onBack:()=>root.LuckyDexArcadeWorld?.backFromGame?.()});return finalResult;
  }
  function open(){opened=true;session()?.mount?.('clearCutChallenge',$('clearCutGame'));showReady({difficulty:'normal',playerDex});return true;}
  function close(){opened=false;stopLoop();phase='closed';match=null;pausedFrom=null;completionHandled=false;finalResult=null;setControls(false);if($('clearCutPauseOverlay'))$('clearCutPauseOverlay').hidden=true;return true;}
  function keydown(e){if(e?.repeat)return false;const k=String(e?.key||'').toLowerCase();if(!['a',' ','enter'].includes(k))return false;const out=cut();if(out?.accepted)e?.preventDefault?.();return !!out?.accepted;}
  function snapshot(){return {phase,difficulty,playerDex,roundIndex:match?.currentRoundIndex??-1,total:match?.player?.total??0,place:match?core.placeFor(match,'player'):null,activeResult:match?.activeRound?.playerResult?{...match.activeRound.playerResult}:null,finalResult:finalResult?JSON.parse(JSON.stringify(finalResult)):null};}
  function wire(){if(typeof document==='undefined')return;$('clearCutStart')?.addEventListener?.('click',startMatch);$('clearCutResume')?.addEventListener?.('click',resume);$('clearCutButton')?.addEventListener?.('pointerdown',e=>{e.preventDefault?.();cut();});for(const btn of document.querySelectorAll?.('[data-clear-cut-difficulty]')||[])btn.addEventListener?.('click',()=>selectDifficulty(btn.dataset.clearCutDifficulty));for(const btn of document.querySelectorAll?.('[data-clear-cut-pokemon]')||[])btn.addEventListener?.('click',()=>selectPokemon(btn.dataset.clearCutPokemon));document.addEventListener?.('keydown',keydown,{capture:true});document.addEventListener?.('visibilitychange',()=>{if(document.hidden&&opened)pause();});root.addEventListener?.('pagehide',()=>{if(opened)pause();});}
  wire();return {open,close,showReady,startMatch,cut,pause,resume,finishMatch,selectDifficulty,selectPokemon,snapshot};
});
