/* The sole Arcade navigation and lifecycle owner. Save keys are unchanged. */
(()=>{'use strict';
const VENUES=[
 {id:'amieGarden',name:'Kalos Amie Garden',kicker:'Pokémon-Amie',art:'amie-garden.jpg',games:['berryPicker','tilePuzzle']},
 {id:'goldenrod',name:'Goldenrod Game Corner',kicker:'Johto · HGSS',art:'goldenrod-game-corner.jpg',games:['voltorb']},
 {id:'celadonPrize',name:'Celadon Game Corner',kicker:'Kanto · HGSS',art:'celadon-game-corner.jpg',games:['ballDrop']},
 {id:'lilycoveContest',name:'Lilycove Contest Hall',kicker:'Hoenn · ORAS',art:'lilycove-contest-hall.jpg',games:['berry']},
 {id:'moonStage',name:'Moon Stage',kicker:'Clefairy Match',art:'moon-stage.png',games:['clefairy']},
 {id:'oreburghMuseum',name:'Oreburgh Mining Museum',kicker:'Sinnoh · BDSP',art:'oreburgh-museum.png',games:['fossil']},
 {id:'ruinsAlph',name:'Ruins of Alph',kicker:'Johto · HGSS',art:'ruins-of-alph.jpg',games:['unown']},
 {id:'indigoQuiz',name:'Indigo Plateau',kicker:'Johto/Kanto · HGSS',art:'indigo-plateau.jpg',games:['quiz']}
].map(v=>({...v,art:'arcade/authentic-v0200/venues/'+v.art}));
const GAME_NAMES={berryPicker:'Berry Picker',tilePuzzle:'Tile Puzzle',voltorb:'Voltorb Flip',ballDrop:'Poké Ball Drop',berry:'Berry Blender',clefairy:'Clefairy Match',fossil:'Fossil Excavation',unown:'Unown Decoder',quiz:"Who's That Pokémon?"};
const GAME_OBJECTIVES={berryPicker:'Serve each requested berry.',tilePuzzle:'Tap two tiles to swap them.',voltorb:'Read the clues. Avoid Voltorb.',ballDrop:'Aim, then drop three balls.',berry:'Tap A as the pointer reaches YOU.',clefairy:'Watch the moon-stage sequence, then repeat it.',fossil:'Reveal the fossil fragments before your digs run out.',unown:'Read the Unown message.',quiz:'Name the silhouette.'};
const $=id=>document.getElementById(id);
const migrateLegacyVenue=id=>({amie:'amieGarden',gameCorner:'goldenrod',discovery:'oreburghMuseum',performance:'lilycoveContest',moonStage:'moonStage',stadiumClassroom:'moonStage'}[id]||'amieGarden');
let active=null,selected='amieGarden';
const owners={
 berryPicker:()=>window.LuckyDexAmie,tilePuzzle:()=>window.LuckyDexAmie,
 voltorb:()=>window.LuckyDexArcadeClassicsV0190,clefairy:()=>window.LuckyDexClefairyGame,fossil:()=>window.LuckyDexArcadeClassicsV0190,
 berry:()=>({open:()=>LuckyDexBerryBlender.reset(),close:()=>LuckyDexBerryBlender.stop()}),
 ballDrop:()=>({open:()=>LuckyDexBallDropV0180.open(),close:()=>LuckyDexBallDropV0180.stop()}),
 unown:()=>window.LuckyDexUnown,quiz:()=>window.LuckyDexQuiz
};
function selectedVenue(){const a=window.state?.arcade||{};return VENUES.some(v=>v.id===a.lastArcadeVenue)?a.lastArcadeVenue:migrateLegacyVenue(a.lastArcadeVenue||a.lastArcadeZone);}
function selectVenue(id){if(!VENUES.some(v=>v.id===id))return false;selected=id;window.state.arcade.lastArcadeVenue=id;window.save();return true;}
const venueForGame=id=>VENUES.find(v=>v.games.includes(id))?.id||null;
function cleanup(){
 const old=active;active=null;
 if(old)owners[old]()?.close?.(old);
 window.LuckyDexArcadeSession.hideResult();
 document.querySelectorAll('.arcade-game').forEach(n=>n.hidden=true);
 document.body.classList.remove('arcade-open');
 return old;
}
function renderWorld(){
 const v=VENUES.find(v=>v.id===selected),i=VENUES.indexOf(v),host=$('arcadeWorldRoute');
 host.innerHTML=`<div class="world-scene" style="--venue-art:url(\'${v.art}\')"><img src="${v.art}" alt="${v.name}" draggable="false"><div class="world-caption"><small>${v.kicker}</small><h2>${v.name}</h2></div></div><button type="button" class="world-enter" data-enter-venue="${v.id}">ENTER LOCATION <span>›</span></button><div class="world-stops">${VENUES.map((s,n)=>`<button type="button" data-world-dot="${n}" aria-label="${s.name}" aria-current="${s===v?'true':'false'}">${n+1}</button>`).join('')}</div>`;
 $('arcadeWorldPrev').disabled=i===0;$('arcadeWorldNext').disabled=i===VENUES.length-1;
}
function openWorld({focusVenueId,activateMode=true}={}){cleanup();if(activateMode)document.body.classList.add('arcade-mode');selectVenue(focusVenueId||selectedVenue());$('arcadeWorldView').hidden=false;$('arcadeVenueView').hidden=true;document.body.classList.remove('arcade-venue-open');renderWorld();return true;}
function renderVenue(id){const v=VENUES.find(v=>v.id===id);if(!v)return false;
 $('arcadeVenueArt').src=v.art;$('arcadeVenueArt').alt=v.name;$('arcadeVenueView').style.setProperty('--venue-art',`url(\"${v.art}\")`);$('arcadeVenueTitle').textContent=v.name;
 $('arcadeVenueDescription').textContent=v.kicker;
 $('arcadeVenueGames').innerHTML=v.games.map(g=>`<button type="button" class="arcade-venue-game" data-venue-game="${g}"><b>${GAME_NAMES[g]}</b><span>${GAME_OBJECTIVES[g]}</span><em>PLAY ›</em></button>`).join('');return true;
}
function openVenue(id){if(!VENUES.some(v=>v.id===id))return false;cleanup();document.body.classList.add('arcade-mode');selectVenue(id);renderVenue(id);$('arcadeWorldView').hidden=true;$('arcadeVenueView').hidden=false;document.body.classList.add('arcade-venue-open');return true;}
function openGame(id){if(!owners[id])return false;cleanup();document.body.classList.add('arcade-mode');selectVenue(venueForGame(id));active=id;
 $('arcadeWorldView').hidden=true;$('arcadeVenueView').hidden=true;
 owners[id]()?.open?.(id);$(`${id}Game`).hidden=false;document.body.classList.add('arcade-open');
 $(`${id}Game`).querySelector('[data-exit-game]').textContent='‹ '+VENUES.find(v=>v.id===selected).name;
 return true;
}
function backFromGame(){if(!active)return false;const id=venueForGame(active);cleanup();return openVenue(id);}
function backFromVenue(){return openWorld({focusVenueId:selected});}
function leave(){cleanup();$('arcadeVenueView').hidden=true;document.body.classList.remove('arcade-venue-open','arcade-mode');return true;}
function suspend(){if(active)backFromGame();window.LuckyDexTrade?.leave();}
const previousBack=window.handleLuckyBack;
window.handleLuckyBack=()=>{
 if(window.LuckyDexTrade?.cancelOverlay?.())return true;
 if(document.querySelector('dialog[open]'))return previousBack();
 if(document.querySelector('[data-page="arcade"].active')){
   if(active)return backFromGame();
   if(!$('arcadeVenueView').hidden)return backFromVenue();
   leave();navigate('adventure');return true;
 }
 const page=document.querySelector('.page.active');
 if(page&&page.dataset.page!=='adventure'){navigate('adventure');return true;}
 return previousBack();
};
document.addEventListener('click',e=>{
 const exit=e.target.closest('[data-exit-game]');if(exit){backFromGame();return;}
 const venue=e.target.closest('[data-enter-venue]');if(venue){openVenue(venue.dataset.enterVenue);return;}
 const game=e.target.closest('[data-venue-game]');if(game){openGame(game.dataset.venueGame);return;}
 const dot=e.target.closest('[data-world-dot]');if(dot){selectVenue(VENUES[Number(dot.dataset.worldDot)].id);renderWorld();}
});
$('arcadeWorldPrev').onclick=()=>{const n=VENUES.findIndex(v=>v.id===selected);if(n>0){selectVenue(VENUES[n-1].id);renderWorld();}};
$('arcadeWorldNext').onclick=()=>{const n=VENUES.findIndex(v=>v.id===selected);if(n<VENUES.length-1){selectVenue(VENUES[n+1].id);renderWorld();}};
$('arcadeWorldBack').onclick=backFromVenue;
document.addEventListener('visibilitychange',()=>{if(document.hidden)suspend();else if(document.querySelector('[data-page="trade"].active'))window.LuckyDexTrade?.enter();});
window.addEventListener('pagehide',suspend);
window.LuckyDexArcadeWorld={VENUES,GAME_NAMES,GAME_OBJECTIVES,openWorld,openVenue,openGame,backFromGame,backFromVenue,leave,suspend,activeGame:()=>active,selectedVenue,selectVenue,venueForGame,migrateLegacyVenue,renderWorld,renderVenue};
openWorld({activateMode:false});
})();
