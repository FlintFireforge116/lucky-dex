/* The sole Arcade navigation and lifecycle owner. Save keys are unchanged. */
(()=>{'use strict';
const VENUES=[
 {id:"amieGarden",name:"Kalos Amie Garden",kicker:"Kalos · Pokémon-Amie",art:"arcade/venues-v0223/kalos-amie-nature-xy.png",position:"50% 50%",games:['berryPicker','tilePuzzle']},
 {id:"goldenrod",name:"Goldenrod Game Corner",kicker:"Johto · HGSS",art:"arcade/venues-v0223/goldenrod-game-corner-hgss.png",position:"50% 45%",games:['voltorb','roulette','slotMachine']},
 {id:"celadonPrize",name:"Celadon Game Corner",kicker:"Kanto · HGSS",art:"arcade/venues-v0223/celadon-game-corner-hgss.png",position:"50% 25%",games:['ballDrop']},
 {id:"lilycoveContest",name:"Lilycove Contest Hall",kicker:"Hoenn · Emerald",art:"arcade/venues-v0223/lilycove-contest-emerald.png",position:"50% 40%",games:['berry']},
 {id:"oreburghMuseum",name:"Oreburgh Mining Museum",kicker:"Sinnoh · DPPt",art:"arcade/venues-v0223/oreburgh-museum-dppt.png",position:"50% 40%",games:['fossil','museum'],activityLabel:'ACTIVITIES'},
 {id:"ruinsAlph",name:"Ruins of Alph",kicker:"Johto · HGSS",art:"arcade/venues-v0223/ruins-alph-hgss-day.png",position:"65% 50%",games:['unown']},
 {id:"indigoQuiz",name:"Indigo Plateau",kicker:"Johto/Kanto · HGSS",art:"arcade/venues-v0223/indigo-plateau-hgss.png",position:"50% 10%",games:['quiz']},
 {id:"dashCourse",name:"Pokémon Challenge Course",kicker:"Goldenrod · Pokéathlon Dome",art:"https://archives.bulbagarden.net/media/upload/3/33/Pok%C3%A9athlon_Dome_HGSS.png",fallbackArt:"arcade/dash-course-v0290.svg",position:"63% 52%",games:['dash','powerTrial','impactTrial','targetRange','elementalGauntlet','enduranceExpedition']},
 {id:"stadiumKidsClub",name:"Pokémon Stadium 1 · Kids Club",kicker:"Kids Club · Gen III Remix",art:"arcade/kids-club/kids-club-venue.webp",position:"50% 50%",games:['ekansHoop','digDigDig','magikarpSplash','rockHarden','clefairy','thunderingDynamo','snoreWar','runRattataRun','sushiGoRound']},
 {id:"stadium2KidsClub",name:"Pokémon Stadium 2 · Kids Club",kicker:"Stadium 2 · Gen III Remix",art:"https://www.vizzed.com/vizzedboard/retro/user_screenshots/saves49/495938/NINTENDO64--Pokemon%20Stadium%202_Jul10%200_30_15.png",fallbackArt:"arcade/kids-club/kids-club-2-venue.svg",position:"50% 50%",games:['clearCutChallenge']}
];
const GAME_NAMES={berryPicker:'Berry Picker',tilePuzzle:'Tile Puzzle',voltorb:'Voltorb Flip',roulette:'Mauville Roulette',slotMachine:'Mauville Slot Machine',ballDrop:'Poké Ball Drop',berry:'Berry Blender',clefairy:'Clefairy Says',fossil:'Fossil Dig',museum:'Museum Collection',unown:'Unown Decoder',quiz:"Who's That Pokémon?",dash:'Pokémon Dash',powerTrial:'Power Trial',impactTrial:'Impact Trial',targetRange:'Target Range',elementalGauntlet:'Elemental Gauntlet',enduranceExpedition:'Endurance Expedition',ekansHoop:'Ekans’ Hoop Hurl',digDigDig:'Dig! Dig! Dig!',magikarpSplash:'Magikarp’s Splash',rockHarden:'Rock Harden',thunderingDynamo:'Thundering Dynamo',snoreWar:'Snore War',runRattataRun:'Run, Rattata, Run',sushiGoRound:'Sushi-Go-Round',clearCutChallenge:'Clear Cut Challenge'};
const GAME_OBJECTIVES={berryPicker:'Serve each requested berry.',tilePuzzle:'Tap two tiles to swap them.',voltorb:'Read the clues. Avoid Voltorb.',roulette:'Bet a slot, Pokémon or colour across a six-ball Gen III roulette wheel.',slotMachine:'Stop three reels across up to five paylines, build Pika Power and chase Reel Time.',ballDrop:'Aim, then drop three balls.',berry:'Tap A as the pointer reaches YOU.',clefairy:'Watch Clefairy’s sequence, then repeat it.',fossil:'Excavate buried Pokémon-world finds before the wall collapses.',museum:"Inspect the artifacts you've unearthed.",unown:'Read the Unown message.',quiz:'Name the silhouette.',dash:'Outdoor Exhibition, Division Cups and 18 themed Type Cups.',powerTrial:'Charge and time five Attack targets in Exhibition or Goldenrod Cups.',impactTrial:'Harden through five hazards in Exhibition or Goldenrod Cups.',targetRange:'Aim special attacks through wind and distance in Exhibition or Goldenrod Cups.',elementalGauntlet:'Dodge elemental attacks and use Sp. Def to survive mistakes in Exhibition or Goldenrod Cups.',enduranceExpedition:'Steer through a five-zone survival course where HP sets your endurance pool.',ekansHoop:'Pull back and release Ekans to hoop Diglett, Dugtrio and rare shinies.',digDigDig:'Alternate LEFT and RIGHT to out-dig three COM Sandshrew.',magikarpSplash:'Hold for height, then time the landing rebound rhythm.',rockHarden:'Time Harden against falling rocks while preserving HP.',thunderingDynamo:'Match the blue A or green B lamp and charge your generator first.',snoreWar:'Press A at the red centre marker. Play last-awake Match or chase an accelerating Endless streak.',runRattataRun:'Mash RUN to sprint and JUMP cleanly over each hurdle.',sushiGoRound:'Eat valuable sushi, chain matching dishes and avoid the hot tea.',clearCutChallenge:'Cut five angled targets for accuracy, then Perfect the Mystery Bag for a prize.'};
const GAME_VENUES=new Map(VENUES.flatMap(v=>v.games.map(g=>[g,v])));
const ALL_GAMES=VENUES.flatMap(v=>v.games).filter((g,i,a)=>a.indexOf(g)===i);
const $=id=>document.getElementById(id);
const migrateLegacyVenue=id=>({amie:'amieGarden',gameCorner:'goldenrod',discovery:'oreburghMuseum',performance:'lilycoveContest',moonStage:'stadiumKidsClub',stadiumClassroom:'stadiumKidsClub'}[id]||'amieGarden');
let active=null,selected='amieGarden',browserMode='games',launchOrigin='venue';
const owners={
 berryPicker:()=>window.LuckyDexAmie,tilePuzzle:()=>window.LuckyDexAmie,
 voltorb:()=>window.LuckyDexArcadeClassicsV0190,roulette:()=>window.LuckyDexRoulette,slotMachine:()=>window.LuckyDexSlotMachine,clefairy:()=>window.LuckyDexClefairyGame,fossil:()=>window.LuckyDexFossilMuseum,museum:()=>window.LuckyDexFossilMuseum,
 berry:()=>({open:()=>LuckyDexBerryBlender.reset(),close:()=>LuckyDexBerryBlender.stop()}),
 ballDrop:()=>({open:()=>LuckyDexBallDropV0180.open(),close:()=>LuckyDexBallDropV0180.stop()}),
 unown:()=>window.LuckyDexUnown,quiz:()=>window.LuckyDexQuiz,dash:()=>window.LuckyDexDash,powerTrial:()=>window.LuckyDexPowerTrial,impactTrial:()=>window.LuckyDexImpactTrial,targetRange:()=>window.LuckyDexTargetRange,elementalGauntlet:()=>window.LuckyDexElementalGauntlet,enduranceExpedition:()=>window.LuckyDexEnduranceExpedition,ekansHoop:()=>window.LuckyDexEkansHoop,digDigDig:()=>window.LuckyDexDigDigDig,magikarpSplash:()=>window.LuckyDexMagikarpSplash,rockHarden:()=>window.LuckyDexRockHarden,thunderingDynamo:()=>window.LuckyDexThunderingDynamo,snoreWar:()=>window.LuckyDexSnoreWar,runRattataRun:()=>window.LuckyDexRunRattataRun,sushiGoRound:()=>window.LuckyDexSushiGoRound,clearCutChallenge:()=>window.LuckyDexClearCut
};
function selectedVenue(){const a=window.state?.arcade||{};return VENUES.some(v=>v.id===a.lastArcadeVenue)?a.lastArcadeVenue:migrateLegacyVenue(a.lastArcadeVenue||a.lastArcadeZone);}
function selectVenue(id){if(!VENUES.some(v=>v.id===id))return false;selected=id;window.state.arcade.lastArcadeVenue=id;window.save();return true;}
const venueForGame=id=>VENUES.find(v=>v.games.includes(id))?.id||null;
function returnLabelForGame(id){if(launchOrigin==='catalog')return 'ALL GAMES';const venue=GAME_VENUES.get(id);return String(venue?.name||'VENUE').toUpperCase();}
function cleanup(){
 const old=active;active=null;
 if(old)owners[old]()?.close?.(old);
 window.LuckyDexArcadeSession.hideResult();
 document.querySelectorAll('.arcade-game').forEach(n=>n.hidden=true);
 document.body.classList.remove('arcade-open');
 const recordsView=$('arcadeRecordsView');if(recordsView)recordsView.hidden=true;
 return old;
}
function browserTabs(){return `<div class="arcade-browser-tabs" role="tablist" aria-label="Arcade browser"><button type="button" role="tab" data-arcade-browser="games" aria-selected="${browserMode==='games'}">ALL GAMES</button><button type="button" role="tab" data-arcade-browser="locations" aria-selected="${browserMode==='locations'}">LOCATIONS</button></div>`;}
function worldToolbar(label){return `<div class="world-toolbar"><button type="button" class="world-home" data-world-home>‹ ADVENTURE</button><span>${label}</span><button type="button" class="world-records" data-arcade-records>ARCADE RECORDS</button></div>`;}
function syncWorldArrows(){const show=browserMode==='locations',i=VENUES.findIndex(v=>v.id===selected),prev=$('arcadeWorldPrev'),next=$('arcadeWorldNext');if(prev){prev.hidden=!show;prev.disabled=i<=0;}if(next){next.hidden=!show;next.disabled=i<0||i>=VENUES.length-1;}}
function renderCatalog(){
 const host=$('arcadeWorldRoute');if(!host)return false;host.classList.add('is-catalog');
 host.innerHTML=`${worldToolbar('LUCKYDEX ARCADE')}${browserTabs()}<div class="arcade-catalog-head"><div><small>PLAY ANYTHING</small><h2>All Arcade Games</h2></div><b>${ALL_GAMES.length} GAMES</b></div><div class="arcade-catalog-grid">${ALL_GAMES.map(g=>{const v=GAME_VENUES.get(g);return `<button type="button" class="arcade-catalog-game" data-catalog-game="${g}"><span><small class="arcade-catalog-venue">${v?.name||'Arcade'}</small><b>${GAME_NAMES[g]||g}</b><em>${GAME_OBJECTIVES[g]||''}</em></span><strong>PLAY ›</strong></button>`;}).join('')}</div>`;
 syncWorldArrows();return true;
}
function renderLocations(){
 const v=VENUES.find(v=>v.id===selected),host=$('arcadeWorldRoute');if(!v||!host)return false;host.classList.remove('is-catalog');
 host.innerHTML=`${worldToolbar('ARCADE LOCATIONS')}${browserTabs()}<div class="world-scene" style="--venue-position:${v.position||'center'}"><img src="${v.art}" alt="${v.name}" draggable="false"><div class="world-caption"><small>${v.kicker}</small><h2>${v.name}</h2></div></div><div class="world-summary"><span>${v.games.length} ${v.activityLabel||`GAME${v.games.length===1?'':'S'}`}</span><b>${v.games.map(g=>GAME_NAMES[g]).join(' · ')}</b></div><button type="button" class="world-enter" data-enter-venue="${v.id}">ENTER LOCATION <span>›</span></button><div class="world-stops">${VENUES.map((s,n)=>`<button type="button" data-world-dot="${n}" aria-label="${s.name}" aria-current="${s===v?'true':'false'}">${n+1}</button>`).join('')}</div>`;
 const worldArt=host.querySelector('.world-scene img');if(worldArt&&v.fallbackArt)worldArt.onerror=()=>{worldArt.onerror=null;worldArt.src=v.fallbackArt;};syncWorldArrows();return true;
}
function renderWorld(){return browserMode==='locations'?renderLocations():renderCatalog();}
function openWorld({focusVenueId,activateMode=true,mode='games'}={}){cleanup();if(activateMode)document.body.classList.add('arcade-mode');selectVenue(focusVenueId||selectedVenue());browserMode=mode==='locations'?'locations':'games';$('arcadeWorldView').hidden=false;$('arcadeVenueView').hidden=true;if($('arcadeRecordsView'))$('arcadeRecordsView').hidden=true;document.body.classList.remove('arcade-venue-open');renderWorld();return true;}
function renderVenue(id){const v=VENUES.find(v=>v.id===id);if(!v)return false;
 $('arcadeVenueView').style.setProperty('--venue-position',v.position||'center');const venueArt=$('arcadeVenueArt');venueArt.onerror=null;venueArt.src=v.art;venueArt.alt=v.name;if(v.fallbackArt)venueArt.onerror=()=>{venueArt.onerror=null;venueArt.src=v.fallbackArt;};$('arcadeVenueView').style.setProperty('--venue-art',`url(\"${v.fallbackArt||v.art}\")`);$('arcadeVenueTitle').textContent=v.name;
 $('arcadeVenueDescription').textContent=v.kicker;
 const kids={ekansHoop:{sprite:'23.png',mechanic:'Aim · trajectory'},digDigDig:{sprite:'27.png',mechanic:'Alternate · speed'},magikarpSplash:{sprite:'129.png',mechanic:'Hold · landing rhythm'},rockHarden:{sprite:'11.png',mechanic:'Hold · precision · survival'},clefairy:{sprite:'35.png',mechanic:'Memory · sequence'},thunderingDynamo:{sprite:'25.png',mechanic:'React · rapid input'},snoreWar:{sprite:'96.png',mechanic:'Timing · survival'},runRattataRun:{sprite:'19.png',mechanic:'Mash · jump · sprint'},sushiGoRound:{sprite:'108.png',mechanic:'Choose · combo · value'},clearCutChallenge:{sprite:'123.png',mechanic:'Precision · timing · cut'}};
 const renderKids=()=>{$('arcadeVenueGames').innerHTML=v.games.map(g=>`<button type="button" class="arcade-venue-game kids-club-game" data-venue-game="${g}"><img src="arcade/sprites/actors/pokemon/${kids[g].sprite}" alt="" draggable="false"><span class="kids-club-game-copy"><b>${GAME_NAMES[g]}</b><span>${kids[g].mechanic}</span><small>${GAME_OBJECTIVES[g]}</small></span><em>PLAY ›</em></button>`).join('');};
 const challenges=[{id:'dash',stat:'SPEED',sprite:'25.png',mechanic:'Race · stamina · racing lines',status:'play'},{id:'powerTrial',stat:'ATTACK',sprite:'68.png',mechanic:'Charge · impact timing',status:'play'},{id:'impactTrial',stat:'DEFENSE',sprite:'306.png',mechanic:'Read · dodge · brace',status:'play'},{id:'targetRange',name:'Target Range',stat:'SP. ATK',sprite:'65.png',mechanic:'Aim · wind · distance · combos',status:'play'},{id:'elementalGauntlet',name:'Elemental Gauntlet',stat:'SP. DEF',sprite:'197.png',mechanic:'Dodge · resist · survive',status:'play'},{id:'enduranceExpedition',name:'Endurance Expedition',stat:'HP',sprite:'242.png',mechanic:'Steer · dodge · endure',status:'play'}];
 if(id==='dashCourse'){const goldenrod=window.LuckyDexGoldenrod;if(goldenrod?.open){$('arcadeVenueGames').innerHTML='';goldenrod.open();}else $('arcadeVenueGames').innerHTML=challenges.map(c=>c.status==='play'?`<button type="button" class="arcade-venue-game challenge-course-game" data-venue-game="${c.id}" data-stat="${c.stat}"><img src="arcade/sprites/actors/pokemon/${c.sprite}" alt="" draggable="false"><span><small>${c.stat} EVENT</small><b>${GAME_NAMES[c.id]}</b><em>${c.mechanic}</em><i>${GAME_OBJECTIVES[c.id]}</i></span><strong>PLAY ›</strong></button>`:`<div class="arcade-venue-game challenge-course-game is-coming" data-stat="${c.stat}"><img src="arcade/sprites/actors/pokemon/${c.sprite}" alt="" draggable="false"><span><small>${c.stat} EVENT</small><b>${c.name}</b><em>${c.mechanic}</em><i>Coming Soon</i></span><strong>SOON</strong></div>`).join('');}
 else if(id==='stadiumKidsClub'){renderKids();}
 else if(id==='stadium2KidsClub'){renderKids();}
 else $('arcadeVenueGames').innerHTML=v.games.map(g=>`<button type="button" class="arcade-venue-game" data-venue-game="${g}"><b>${GAME_NAMES[g]}</b><span>${GAME_OBJECTIVES[g]}</span><em>PLAY ›</em></button>`).join('');return true;
}
function openVenue(id){if(!VENUES.some(v=>v.id===id))return false;cleanup();launchOrigin='venue';document.body.classList.add('arcade-mode');selectVenue(id);renderVenue(id);$('arcadeWorldView').hidden=true;$('arcadeVenueView').hidden=false;if($('arcadeRecordsView'))$('arcadeRecordsView').hidden=true;document.body.classList.add('arcade-venue-open');return true;}
function openGame(id,{origin='venue'}={}){if(!owners[id])return false;cleanup();launchOrigin=origin==='catalog'?'catalog':'venue';document.body.classList.add('arcade-mode');selectVenue(venueForGame(id));active=id;
 $('arcadeWorldView').hidden=true;$('arcadeVenueView').hidden=true;if($('arcadeRecordsView'))$('arcadeRecordsView').hidden=true;
 const panelId=id==='clearCutChallenge'?'clearCutGame':`${id}Game`;owners[id]()?.open?.(id);$(panelId).hidden=false;document.body.classList.add('arcade-open');
 const exit=$(panelId).querySelector('[data-exit-game]');if(exit)exit.textContent=launchOrigin==='catalog'?'‹ ALL GAMES':'‹ '+VENUES.find(v=>v.id===selected).name;
 return true;
}
function backFromGame(){if(!active)return false;const id=venueForGame(active),origin=launchOrigin;if(id==='dashCourse'&&window.LuckyDexGoldenrod?.activeCup?.())window.LuckyDexGoldenrod.abandonActiveCup();cleanup();if(origin==='catalog')return openWorld({focusVenueId:id,mode:'games'});return openVenue(id);}
function backFromVenue(){if(selected==='dashCourse'){window.LuckyDexGoldenrod?.abandonActiveCup?.();window.LuckyDexGoldenrod?.close?.();}return openWorld({focusVenueId:selected,mode:'locations'});}
function leave(){cleanup();$('arcadeVenueView').hidden=true;if($('arcadeRecordsView'))$('arcadeRecordsView').hidden=true;document.body.classList.remove('arcade-venue-open','arcade-mode');return true;}
function suspend(){window.save?.();window.LuckyDexTrade?.leave();}
const previousBack=window.handleLuckyBack;
window.handleLuckyBack=()=>{
 if(window.LuckyDexTrade?.cancelOverlay?.())return true;
 if(document.querySelector('dialog[open]'))return previousBack();
 if(document.querySelector('[data-page="arcade"].active')){
   if(window.LuckyDexArcadeRecords?.isOpen?.()){window.LuckyDexArcadeRecords.close();return true;}
   if(active)return backFromGame();
   if(!$('arcadeVenueView').hidden)return backFromVenue();
   leave();navigate('adventure');return true;
 }
 const page=document.querySelector('.page.active');
 if(page&&page.dataset.page!=='adventure'){navigate('adventure');return true;}
 return previousBack();
};
document.addEventListener('click',e=>{
 const home=e.target.closest('[data-world-home]');if(home){leave();navigate('adventure');return;}
 const records=e.target.closest('[data-arcade-records]');if(records){window.LuckyDexArcadeRecords?.open?.();return;}
 const browser=e.target.closest('[data-arcade-browser]');if(browser){browserMode=browser.dataset.arcadeBrowser==='locations'?'locations':'games';renderWorld();return;}
 const exit=e.target.closest('[data-exit-game]');if(exit){backFromGame();return;}
 const catalogGame=e.target.closest('[data-catalog-game]');if(catalogGame){openGame(catalogGame.dataset.catalogGame,{origin:'catalog'});return;}
 const venue=e.target.closest('[data-enter-venue]');if(venue){openVenue(venue.dataset.enterVenue);return;}
 const game=e.target.closest('[data-venue-game]');if(game){openGame(game.dataset.venueGame,{origin:'venue'});return;}
 const dot=e.target.closest('[data-world-dot]');if(dot){selectVenue(VENUES[Number(dot.dataset.worldDot)].id);renderWorld();}
});
$('arcadeWorldPrev').onclick=()=>{if(browserMode!=='locations')return;const n=VENUES.findIndex(v=>v.id===selected);if(n>0){selectVenue(VENUES[n-1].id);renderWorld();}};
$('arcadeWorldNext').onclick=()=>{if(browserMode!=='locations')return;const n=VENUES.findIndex(v=>v.id===selected);if(n<VENUES.length-1){selectVenue(VENUES[n+1].id);renderWorld();}};
$('arcadeWorldBack').onclick=backFromVenue;
document.addEventListener('visibilitychange',()=>{if(document.hidden)suspend();else if(document.querySelector('[data-page="trade"].active'))window.LuckyDexTrade?.enter();});
window.addEventListener('pagehide',suspend);
window.LuckyDexArcadeWorld={VENUES,ALL_GAMES,GAME_NAMES,GAME_OBJECTIVES,openWorld,openVenue,openGame,backFromGame,backFromVenue,leave,suspend,activeGame:()=>active,selectedVenue,selectVenue,venueForGame,returnLabelForGame,migrateLegacyVenue,renderWorld,renderCatalog,renderLocations,renderVenue,browserMode:()=>browserMode};
openWorld({activateMode:false});
})();
