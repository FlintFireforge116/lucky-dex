(function(root){
  'use strict';

  const VENUES=[
    {id:'amieGarden',name:'Kalos Amie Garden',description:'A bright garden for quick partner games.',art:'arcade/venues/amie-garden.webp',games:['berryPicker','headIt','tilePuzzle']},
    {id:'goldenrod',name:'Goldenrod Game Corner',description:'Read the board and know when to bank.',art:'arcade/venues/goldenrod-game-corner.webp',games:['voltorb']},
    {id:'celadonPrize',name:'Celadon Prize Machine',description:'Line up a Poké Ball and chase the centre jackpot.',art:'arcade/venues/celadon-prize-machine.webp',games:['ballDrop']},
    {id:'lilycoveContest',name:'Lilycove Contest Hall',description:'Put your timing on stage.',art:'arcade/venues/lilycove-contest-hall.webp',games:['berry']},
    {id:'moonStage',name:'Moon Stage',description:'Follow Clefairy beneath the moonlight.',art:'arcade/venues/moon-stage.webp',games:['clefairy']},
    {id:'oreburghMuseum',name:'Oreburgh Mining Museum',description:'Unearth a fossil before your tools run out.',art:'arcade/venues/oreburgh-museum.webp',games:['fossil']},
    {id:'ruinsAlph',name:'Ruins of Alph',description:'Decode the message hidden in ancient glyphs.',art:'arcade/venues/ruins-of-alph.webp',games:['unown']},
    {id:'indigoQuiz',name:'Indigo League Quiz Studio',description:'Silhouettes, streaks and Pokédex knowledge.',art:'arcade/venues/indigo-quiz-studio.webp',games:['quiz']}
  ];
  const GAME_NAMES={berryPicker:'Berry Picker',headIt:'Head It',tilePuzzle:'Tile Puzzle',voltorb:'Voltorb Flip',ballDrop:'Poké Ball Drop',berry:'Berry Blender',clefairy:'Clefairy Match',fossil:'Fossil Excavation',unown:'Unown Decoder',quiz:"Who's That Pokémon?"};
  const GAME_OBJECTIVES={berryPicker:'Serve the requested berries before patience runs out.',headIt:'Bump falling yarn at the timing point.',tilePuzzle:'Slide the pieces into one complete picture.',voltorb:'Find every multiplier without uncovering a Voltorb.',ballDrop:'Drop three balls through the prize machine.',berry:'Hit the timing window as the blender accelerates.',clefairy:'Repeat the growing sequence and decide when to bank.',fossil:'Reveal every fossil fragment with limited tools.',unown:'Decode five glyph messages.',quiz:'Identify the Pokémon before time expires.'};
  const MIGRATION={amie:'amieGarden',gameCorner:'goldenrod',discovery:'oreburghMuseum',performance:'lilycoveContest'};
  let activeGame=null;
  let legacyOpen=null,legacyClose=null,legacyBack=null;
  let wired=false;

  function state(){return root.state||globalThis.state;}
  function el(id){return typeof document!=='undefined'?document.getElementById(id):null;}
  function validVenue(id){return VENUES.some(v=>v.id===id);}
  function migrateLegacyVenue(zone){return MIGRATION[zone]||'amieGarden';}
  function selectedVenue(){
    const a=state()?.arcade||{};
    if(validVenue(a.lastArcadeVenue))return a.lastArcadeVenue;
    if(!('lastArcadeVenue' in a)&&a.lastArcadeZone)return migrateLegacyVenue(a.lastArcadeZone);
    return 'amieGarden';
  }
  function persistVenue(id){
    const s=state();if(!s)return;
    s.arcade=s.arcade||{};s.arcade.lastArcadeVenue=id;
    try{root.save?.();}catch(_){ }
  }
  function venueForGame(gameId){const v=VENUES.find(v=>v.games.includes(gameId));return v?v.id:null;}
  function gameRule(id){return root.LuckyDexArcadeSession?.ruleFor?.(id)||root.LuckyDexArcadeSession?.GAME_RULES?.[id]||{run:'Complete the run',reward:'Lucky Coins'};}
  function dailyBadge(venue){
    const p=root.LuckyDexArcadePlatform;if(!p?.dailyClaimAvailable)return '';
    const ready=venue.games.filter(g=>['berryPicker','headIt','tilePuzzle'].includes(g)&&p.dailyClaimAvailable(g)).length;
    return ready?`<span class="world-daily-badge">${ready} DAILY READY</span>`:'';
  }
  function renderWorld(){
    const host=el('arcadeWorldRoute');if(!host)return;
    const sel=selectedVenue();
    host.innerHTML=VENUES.map((v,i)=>`<article class="arcade-world-stop ${v.id===sel?'selected':''}" data-world-stop="${v.id}" data-index="${i}" tabindex="0"><div class="world-landmark-wrap"><img src="${v.art}" alt="${v.name} landmark" onerror="this.classList.add('art-failed')">${dailyBadge(v)}</div><div class="world-stop-copy"><small>STOP ${i+1} / ${VENUES.length}</small><h3>${v.name}</h3><p>${v.description}</p><button type="button" class="primary world-enter" data-enter-venue="${v.id}">ENTER</button></div></article>`).join('');
    host.querySelectorAll('[data-world-stop]').forEach(stop=>stop.addEventListener('click',ev=>{if(ev.target.closest('[data-enter-venue]'))return;selectVenue(stop.dataset.worldStop);}));
    host.querySelectorAll('[data-enter-venue]').forEach(btn=>btn.addEventListener('click',()=>openVenue(btn.dataset.enterVenue)));
    requestAnimationFrame?.(()=>selectVenue(sel,{scroll:true}));
  }
  function updateSelectedClass(id){el('arcadeWorldRoute')?.querySelectorAll?.('[data-world-stop]')?.forEach?.(n=>n.classList.toggle('selected',n.dataset.worldStop===id));}
  function selectVenue(venueId,{scroll=true}={}){
    if(!validVenue(venueId))return false;
    persistVenue(venueId);updateSelectedClass(venueId);
    if(scroll&&typeof document!=='undefined')el('arcadeWorldRoute')?.querySelector?.(`[data-world-stop="${venueId}"]`)?.scrollIntoView?.({behavior:'smooth',inline:'center',block:'nearest'});
    return true;
  }
  function renderVenue(venueId){
    const venue=VENUES.find(v=>v.id===venueId);if(!venue)return false;
    const art=el('arcadeVenueArt'),title=el('arcadeVenueTitle'),copy=el('arcadeVenueDescription'),games=el('arcadeVenueGames');
    if(art){art.src=venue.art;art.alt=`${venue.name} landmark`;}
    if(title)title.textContent=venue.name;if(copy)copy.textContent=venue.description;
    if(games)games.innerHTML=venue.games.map(id=>{const r=gameRule(id);return `<button type="button" class="arcade-venue-game" data-venue-game="${id}"><span class="venue-game-copy"><b>${GAME_NAMES[id]||id}</b><small>${GAME_OBJECTIVES[id]||''}</small><em><strong>RUN</strong> ${r.run}</em><em><strong>REWARD</strong> ${r.reward}</em></span><i>PLAY ›</i></button>`;}).join('');
    games?.querySelectorAll?.('[data-venue-game]')?.forEach?.(btn=>btn.addEventListener('click',()=>openGame(btn.dataset.venueGame)));
    return true;
  }
  function showWorldOnly(){if(el('arcadeWorldView'))el('arcadeWorldView').hidden=false;if(el('arcadeVenueView'))el('arcadeVenueView').hidden=true;}
  function showVenueOnly(){if(el('arcadeWorldView'))el('arcadeWorldView').hidden=true;if(el('arcadeVenueView'))el('arcadeVenueView').hidden=false;}
  function hideNavigation(){if(el('arcadeWorldView'))el('arcadeWorldView').hidden=true;if(el('arcadeVenueView'))el('arcadeVenueView').hidden=true;}
  function openWorld({focusVenueId}={}){
    if(typeof document==='undefined'){if(focusVenueId)selectVenue(focusVenueId,{scroll:false});return true;}
    const id=validVenue(focusVenueId)?focusVenueId:selectedVenue();activeGame=null;renderWorld();showWorldOnly();selectVenue(id,{scroll:true});return true;
  }
  function openVenue(venueId){
    if(!validVenue(venueId))return false;selectVenue(venueId,{scroll:false});renderVenue(venueId);showVenueOnly();activeGame=null;return true;
  }
  function setExitLabel(gameId){const venue=VENUES.find(v=>v.id===venueForGame(gameId));const game=el(`${gameId}Game`);game?.querySelectorAll?.('[data-exit-game]')?.forEach?.(b=>b.textContent=`‹ ${String(venue?.name||'VENUE').toUpperCase()}`);}
  function openGame(gameId){
    const venueId=venueForGame(gameId);if(!venueId)return false;
    selectVenue(venueId,{scroll:false});activeGame=gameId;hideNavigation();root.LuckyDexArcadeSession?.hideResult?.();
    const amie=root.LuckyDexAmieV0180||root.LuckyDexAmie;
    if(['berryPicker','headIt','tilePuzzle'].includes(gameId)&&amie?.open)amie.open(gameId);
    else if(gameId==='ballDrop'&&root.LuckyDexBallDropV0180?.open)root.LuckyDexBallDropV0180.open();
    else if(typeof legacyOpen==='function')legacyOpen(gameId);
    root.LuckyDexArcadeSession?.mount?.(gameId);setExitLabel(gameId);return true;
  }
  function backFromGame(force=false){
    if(!activeGame&&typeof document!=='undefined'&&!document.body?.classList?.contains('arcade-open'))return false;
    const gameId=activeGame||root.LuckyDexAmieV0180?.activeGame?.()||root.LuckyDexAmie?.activeGame?.();const venueId=venueForGame(gameId)||selectedVenue();
    root.LuckyDexArcadeSession?.hideResult?.();
    let closed=true;
    const amie=root.LuckyDexAmieV0180||root.LuckyDexAmie;
    if(['berryPicker','headIt','tilePuzzle'].includes(gameId)&&amie?.activeGame?.())closed=amie.close(force)!==false;
    else if(gameId==='ballDrop'&&root.LuckyDexBallDropV0180?.stop)root.LuckyDexBallDropV0180.stop();
    else if(typeof legacyClose==='function')closed=legacyClose(force)!==false;
    if(!closed)return false;activeGame=null;openVenue(venueId);return true;
  }
  function backFromVenue(){openWorld({focusVenueId:selectedVenue()});return true;}
  function moveWorld(delta){const cur=VENUES.findIndex(v=>v.id===selectedVenue()),next=Math.max(0,Math.min(VENUES.length-1,cur+delta));return selectVenue(VENUES[next].id,{scroll:true});}
  function arcadePageActive(){return !!document?.querySelector?.('.page[data-page="arcade"].active');}
  function wire(){
    if(wired||typeof document==='undefined')return;wired=true;
    legacyOpen=typeof root.openArcadeGame==='function'?root.openArcadeGame:null;
    legacyClose=typeof root.closeArcadeGame==='function'?root.closeArcadeGame:null;
    legacyBack=typeof root.handleLuckyBack==='function'?root.handleLuckyBack:null;
    const initial=selectedVenue();persistVenue(initial);
    el('arcadeWorldPrev')?.addEventListener('click',()=>moveWorld(-1));el('arcadeWorldNext')?.addEventListener('click',()=>moveWorld(1));el('arcadeWorldBack')?.addEventListener('click',backFromVenue);
    document.querySelectorAll('[data-exit-game]').forEach(btn=>btn.onclick=ev=>{ev.preventDefault();backFromGame(false);});
    root.closeArcadeGame=(force=false)=>backFromGame(force);
    root.handleLuckyBack=function(){
      if(activeGame||document.body.classList.contains('arcade-open'))return backFromGame(false);
      if(arcadePageActive()&&el('arcadeVenueView')&&!el('arcadeVenueView').hidden)return backFromVenue();
      return typeof legacyBack==='function'?legacyBack():false;
    };
    document.querySelector('[data-nav="arcade"]')?.addEventListener('click',()=>setTimeout(()=>openWorld({focusVenueId:selectedVenue()}),0));
    renderWorld();openWorld({focusVenueId:initial});
  }

  const api={VENUES,GAME_NAMES,venueForGame,migrateLegacyVenue,selectedVenue,selectVenue,openWorld,openVenue,openGame,backFromGame,backFromVenue,renderWorld,renderVenue};
  root.LuckyDexArcadeWorld=api;
  if(typeof module!=='undefined'&&module.exports)module.exports=api;
  if(typeof document!=='undefined')wire();
})(typeof window!=='undefined'?window:globalThis);
