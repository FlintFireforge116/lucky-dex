(function(root){
  'use strict';

  const FALLBACK_NAMES={25:'Pikachu',133:'Eevee',175:'Togepi',183:'Marill'};
  const ITEM_KEYS=new Set(['berry','potion','pokeball','greatball','ultraball']);
  const ARCADE_DEFAULTS={
    dailyRewards:{},
    bestBerryPicker:{easy:0,normal:0,hard:0},
    bestHeadIt:{easy:0,normal:0,hard:0,unlimited:0,unlimitedStreak:0},
    bestTilePuzzle:{easy:null,normal:null,hard:null},
    lastArcadeZone:'amie',
    lastArcadeVenue:'amieGarden',
    museum:{exhibits:{}},
    dash:{lastRacerKey:null,races:0,wins:0,podiums:0,bestTimeMs:null,lastQuickRacerKey:null,lastLeagueRacerKey:null,quickBestTimes:{easy:null,normal:null,hard:null,expert:null},leagueRecords:{}},
    powerTrial:{gamesPlayed:0,fullClears:0,hardClears:0,bestScore:0,bestScores:{easy:0,normal:0,hard:0},bestSingleHit:0,bestPerfects:0,perfectHits:0,totalTargetsCleared:0,goldenTargetsSeen:0,goldenTargetsCleared:0,lastPokemonKey:null},
    ekansHoop:{gamesPlayed:0,wins:0,bestScore:0,bestStreak:0,totalHoops:0,shinyHits:0},
    digDigDig:{gamesPlayed:0,wins:0,podiums:0,bestTimeMs:null,bestTimes:{easy:null,normal:null,hard:null},winsByDifficulty:{easy:0,normal:0,hard:0}},
    magikarpSplash:{gamesPlayed:0,wins:0,podiums:0,bestScore:0,bestScores:{easy:0,normal:0,hard:0},winsByDifficulty:{easy:0,normal:0,hard:0},bestQuickChain:0},
    rockHarden:{gamesPlayed:0,wins:0,podiums:0,bestScore:0,bestScores:{easy:0,normal:0,hard:0},winsByDifficulty:{easy:0,normal:0,hard:0},bestPerfects:0,perfectBlocks:0,totalBlocks:0,bestHpRemaining:0,goldRocksSeen:0,goldRocksPerfected:0,goldRewardsClaimed:0},
    thunderingDynamo:{gamesPlayed:0,wins:0,podiums:0,bestTimeMs:null,bestTimes:{easy:null,normal:null,hard:null},winsByDifficulty:{easy:0,normal:0,hard:0},bestAccuracy:0,totalCorrect:0,totalWrong:0},
    snoreWar:{gamesPlayed:0,wins:0,podiums:0,bestStreak:0,bestAccuracy:0,totalHits:0,totalMisses:0,winsByDifficulty:{easy:0,normal:0,hard:0},endlessRuns:0,bestEndlessHits:0,bestEndlessStreak:0,bestEndlessPeriodMs:null},
    runRattataRun:{gamesPlayed:0,wins:0,podiums:0,bestTimeMs:null,bestTimes:{easy:null,normal:null,hard:null},winsByDifficulty:{easy:0,normal:0,hard:0},flawlessWins:0,totalHurdlesCleared:0,totalHurdlesHit:0},
    sushiGoRound:{gamesPlayed:0,wins:0,podiums:0,bestBill:0,bestBills:{easy:0,normal:0,hard:0},winsByDifficulty:{easy:0,normal:0,hard:0},bestCombo:0,totalSushiEaten:0,hotPenalties:0},
    clearCutChallenge:{gamesPlayed:0,wins:0,podiums:0,bestScore:0,bestScores:{easy:0,normal:0,hard:0},winsByDifficulty:{easy:0,normal:0,hard:0},totalPerfects:0,closestCutPct:null,totalAbsErrorPct:0,totalCuts:0,bagsPerfect:0,bagPrizes:0},
    records:{version:1,games:{}}
  };
  const ZONES={
    amie:{id:'amie',name:'Kalos Amie Garden',icon:'🌸',games:['berryPicker','tilePuzzle']},
    gameCorner:{id:'gameCorner',name:'Game Corner',icon:'🎰',games:['voltorb','ballDrop']},
    discovery:{id:'discovery',name:'Discovery District',icon:'🔬',games:['fossil','ditto','unown','quiz']},
    performance:{id:'performance',name:'Performance Stage',icon:'🎭',games:['berry','clefairy']}
  };

  function clone(v){return JSON.parse(JSON.stringify(v));}
  function clamp(n,a,b){return Math.max(a,Math.min(b,n));}
  function nonNegativeNumber(value,fallback=0){
    const n=Number(value);return Number.isFinite(n)&&n>=0?n:(Number(fallback)||0);
  }
  function numericDifficultyRecord(defaults,value){
    const src=value&&typeof value==='object'?value:{};
    const out={...defaults};
    for(const key of Object.keys(defaults)){
      const n=Number(src[key]);
      out[key]=Number.isFinite(n)&&n>=0?n:Number(defaults[key])||0;
    }
    return out;
  }

  function recordsCore(){
    if(root.LuckyDexArcadeRecordsCore)return root.LuckyDexArcadeRecordsCore;
    if(typeof require==='function'){try{return require('./arcade-records-core.js');}catch(_){}}
    return null;
  }
  function normalizeArcadeRecords(value){
    const core=recordsCore();
    if(core?.appendHistory){
      const src=value&&typeof value==='object'?value:{};const games={};
      const source=src.games&&typeof src.games==='object'?src.games:{};
      for(const [gameId,bucket] of Object.entries(source)){
        const recent=(Array.isArray(bucket?.recent)?bucket.recent:[]).map(row=>core.normalizeHistoryEntry(gameId,row)).filter(Boolean).sort((a,b)=>b.completedAt-a.completedAt).slice(0,10);
        games[gameId]={...(bucket&&typeof bucket==='object'?bucket:{}),recent};
      }
      return {version:1,games};
    }
    const src=value&&typeof value==='object'?value:{};const games={};
    for(const [gameId,bucket] of Object.entries(src.games&&typeof src.games==='object'?src.games:{}))games[gameId]={...(bucket&&typeof bucket==='object'?bucket:{}),recent:Array.isArray(bucket?.recent)?bucket.recent.slice(0,10):[]};
    return {version:1,games};
  }

  function ensureArcadeState(arcade){
    const src=(arcade&&typeof arcade==='object')?arcade:{};
    const srcDash=(src.dash&&typeof src.dash==='object')?src.dash:{};
    const dash={
      ...ARCADE_DEFAULTS.dash,
      ...srcDash,
      quickBestTimes:{...ARCADE_DEFAULTS.dash.quickBestTimes,...(srcDash.quickBestTimes&&typeof srcDash.quickBestTimes==='object'?srcDash.quickBestTimes:{})},
      leagueRecords:{...(srcDash.leagueRecords&&typeof srcDash.leagueRecords==='object'?srcDash.leagueRecords:{})}
    };
    if((srcDash.lastQuickRacerKey===undefined||srcDash.lastQuickRacerKey===null)&&srcDash.lastRacerKey)dash.lastQuickRacerKey=srcDash.lastRacerKey;
    return {
      ...src,
      dailyRewards:{...ARCADE_DEFAULTS.dailyRewards,...(src.dailyRewards||{})},
      bestBerryPicker:{...ARCADE_DEFAULTS.bestBerryPicker,...(src.bestBerryPicker||{})},
      bestHeadIt:{...ARCADE_DEFAULTS.bestHeadIt,...(src.bestHeadIt||{})},
      bestTilePuzzle:{...ARCADE_DEFAULTS.bestTilePuzzle,...(src.bestTilePuzzle||{})},
      museum:{...(src.museum&&typeof src.museum==='object'?src.museum:{}),exhibits:{...((src.museum&&typeof src.museum.exhibits==='object'&&src.museum.exhibits)||{})}},
      dash,
      powerTrial:(()=>{const r=src.powerTrial&&typeof src.powerTrial==='object'?src.powerTrial:{};return {
        gamesPlayed:nonNegativeNumber(r.gamesPlayed),fullClears:nonNegativeNumber(r.fullClears),hardClears:nonNegativeNumber(r.hardClears),bestScore:nonNegativeNumber(r.bestScore),
        bestScores:numericDifficultyRecord(ARCADE_DEFAULTS.powerTrial.bestScores,r.bestScores),bestSingleHit:nonNegativeNumber(r.bestSingleHit),bestPerfects:nonNegativeNumber(r.bestPerfects),perfectHits:nonNegativeNumber(r.perfectHits),totalTargetsCleared:nonNegativeNumber(r.totalTargetsCleared),goldenTargetsSeen:nonNegativeNumber(r.goldenTargetsSeen),goldenTargetsCleared:nonNegativeNumber(r.goldenTargetsCleared),lastPokemonKey:typeof r.lastPokemonKey==='string'?r.lastPokemonKey:null
      };})(),
      ekansHoop:{...ARCADE_DEFAULTS.ekansHoop,...(src.ekansHoop&&typeof src.ekansHoop==='object'?src.ekansHoop:{})},
      digDigDig:{...ARCADE_DEFAULTS.digDigDig,...(src.digDigDig&&typeof src.digDigDig==='object'?src.digDigDig:{}),bestTimes:{...ARCADE_DEFAULTS.digDigDig.bestTimes,...(src.digDigDig&&typeof src.digDigDig.bestTimes==='object'?src.digDigDig.bestTimes:{})},winsByDifficulty:{...ARCADE_DEFAULTS.digDigDig.winsByDifficulty,...(src.digDigDig&&typeof src.digDigDig.winsByDifficulty==='object'?src.digDigDig.winsByDifficulty:{})}},
      magikarpSplash:{...ARCADE_DEFAULTS.magikarpSplash,...(src.magikarpSplash&&typeof src.magikarpSplash==='object'?src.magikarpSplash:{}),bestScores:numericDifficultyRecord(ARCADE_DEFAULTS.magikarpSplash.bestScores,src.magikarpSplash?.bestScores),winsByDifficulty:numericDifficultyRecord(ARCADE_DEFAULTS.magikarpSplash.winsByDifficulty,src.magikarpSplash?.winsByDifficulty)},
      records:normalizeArcadeRecords(src.records),
      thunderingDynamo:(()=>{const r=src.thunderingDynamo&&typeof src.thunderingDynamo==='object'?src.thunderingDynamo:{};return {
        gamesPlayed:nonNegativeNumber(r.gamesPlayed),wins:nonNegativeNumber(r.wins),podiums:nonNegativeNumber(r.podiums),bestTimeMs:r.bestTimeMs==null?null:nonNegativeNumber(r.bestTimeMs),
        bestTimes:{easy:r.bestTimes?.easy==null?null:nonNegativeNumber(r.bestTimes.easy),normal:r.bestTimes?.normal==null?null:nonNegativeNumber(r.bestTimes.normal),hard:r.bestTimes?.hard==null?null:nonNegativeNumber(r.bestTimes.hard)},
        winsByDifficulty:numericDifficultyRecord(ARCADE_DEFAULTS.thunderingDynamo.winsByDifficulty,r.winsByDifficulty),bestAccuracy:nonNegativeNumber(r.bestAccuracy),totalCorrect:nonNegativeNumber(r.totalCorrect),totalWrong:nonNegativeNumber(r.totalWrong)
      };})(),
      snoreWar:(()=>{const r=src.snoreWar&&typeof src.snoreWar==='object'?src.snoreWar:{};return {
        gamesPlayed:nonNegativeNumber(r.gamesPlayed),wins:nonNegativeNumber(r.wins),podiums:nonNegativeNumber(r.podiums),bestStreak:nonNegativeNumber(r.bestStreak),bestAccuracy:nonNegativeNumber(r.bestAccuracy),totalHits:nonNegativeNumber(r.totalHits),totalMisses:nonNegativeNumber(r.totalMisses),winsByDifficulty:numericDifficultyRecord(ARCADE_DEFAULTS.snoreWar.winsByDifficulty,r.winsByDifficulty),endlessRuns:nonNegativeNumber(r.endlessRuns),bestEndlessHits:nonNegativeNumber(r.bestEndlessHits),bestEndlessStreak:nonNegativeNumber(r.bestEndlessStreak),bestEndlessPeriodMs:r.bestEndlessPeriodMs==null?null:nonNegativeNumber(r.bestEndlessPeriodMs)
      };})(),
      runRattataRun:(()=>{const r=src.runRattataRun&&typeof src.runRattataRun==='object'?src.runRattataRun:{};return {
        gamesPlayed:nonNegativeNumber(r.gamesPlayed),wins:nonNegativeNumber(r.wins),podiums:nonNegativeNumber(r.podiums),bestTimeMs:r.bestTimeMs==null?null:nonNegativeNumber(r.bestTimeMs),bestTimes:{easy:r.bestTimes?.easy==null?null:nonNegativeNumber(r.bestTimes.easy),normal:r.bestTimes?.normal==null?null:nonNegativeNumber(r.bestTimes.normal),hard:r.bestTimes?.hard==null?null:nonNegativeNumber(r.bestTimes.hard)},winsByDifficulty:numericDifficultyRecord(ARCADE_DEFAULTS.runRattataRun.winsByDifficulty,r.winsByDifficulty),flawlessWins:nonNegativeNumber(r.flawlessWins),totalHurdlesCleared:nonNegativeNumber(r.totalHurdlesCleared),totalHurdlesHit:nonNegativeNumber(r.totalHurdlesHit)
      };})(),
      sushiGoRound:(()=>{const r=src.sushiGoRound&&typeof src.sushiGoRound==='object'?src.sushiGoRound:{};return {
        gamesPlayed:nonNegativeNumber(r.gamesPlayed),wins:nonNegativeNumber(r.wins),podiums:nonNegativeNumber(r.podiums),bestBill:nonNegativeNumber(r.bestBill),bestBills:numericDifficultyRecord(ARCADE_DEFAULTS.sushiGoRound.bestBills,r.bestBills),winsByDifficulty:numericDifficultyRecord(ARCADE_DEFAULTS.sushiGoRound.winsByDifficulty,r.winsByDifficulty),bestCombo:nonNegativeNumber(r.bestCombo),totalSushiEaten:nonNegativeNumber(r.totalSushiEaten),hotPenalties:nonNegativeNumber(r.hotPenalties)
      };})(),
      clearCutChallenge:(()=>{const r=src.clearCutChallenge&&typeof src.clearCutChallenge==='object'?src.clearCutChallenge:{};return {
        gamesPlayed:nonNegativeNumber(r.gamesPlayed),wins:nonNegativeNumber(r.wins),podiums:nonNegativeNumber(r.podiums),bestScore:nonNegativeNumber(r.bestScore),bestScores:numericDifficultyRecord(ARCADE_DEFAULTS.clearCutChallenge.bestScores,r.bestScores),winsByDifficulty:numericDifficultyRecord(ARCADE_DEFAULTS.clearCutChallenge.winsByDifficulty,r.winsByDifficulty),totalPerfects:nonNegativeNumber(r.totalPerfects),closestCutPct:r.closestCutPct==null?null:nonNegativeNumber(r.closestCutPct),totalAbsErrorPct:nonNegativeNumber(r.totalAbsErrorPct),totalCuts:nonNegativeNumber(r.totalCuts),bagsPerfect:nonNegativeNumber(r.bagsPerfect),bagPrizes:nonNegativeNumber(r.bagPrizes)
      };})(),
      rockHarden:(()=>{const r=src.rockHarden&&typeof src.rockHarden==='object'?src.rockHarden:{};return {
        gamesPlayed:nonNegativeNumber(r.gamesPlayed),wins:nonNegativeNumber(r.wins),podiums:nonNegativeNumber(r.podiums),bestScore:nonNegativeNumber(r.bestScore),
        bestScores:numericDifficultyRecord(ARCADE_DEFAULTS.rockHarden.bestScores,r.bestScores),winsByDifficulty:numericDifficultyRecord(ARCADE_DEFAULTS.rockHarden.winsByDifficulty,r.winsByDifficulty),
        bestPerfects:nonNegativeNumber(r.bestPerfects),perfectBlocks:nonNegativeNumber(r.perfectBlocks),totalBlocks:nonNegativeNumber(r.totalBlocks),bestHpRemaining:nonNegativeNumber(r.bestHpRemaining),
        goldRocksSeen:nonNegativeNumber(r.goldRocksSeen),goldRocksPerfected:nonNegativeNumber(r.goldRocksPerfected),goldRewardsClaimed:nonNegativeNumber(r.goldRewardsClaimed)
      };})(),
      lastArcadeZone:typeof src.lastArcadeZone==='string'&&src.lastArcadeZone?src.lastArcadeZone:ARCADE_DEFAULTS.lastArcadeZone,
      lastArcadeVenue:['amieGarden','goldenrod','celadonPrize','lilycoveContest','oreburghMuseum','ruinsAlph','indigoQuiz','dashCourse','stadiumKidsClub','stadium2KidsClub'].includes(src.lastArcadeVenue)?src.lastArcadeVenue:['moonStage','stadiumClassroom'].includes(src.lastArcadeVenue)?'stadiumKidsClub':({amie:'amieGarden',gameCorner:'goldenrod',discovery:'oreburghMuseum',performance:'lilycoveContest',moonStage:'stadiumKidsClub'}[src.lastArcadeZone]||'amieGarden')
    };
  }
  function todayKey(date){
    const d=date instanceof Date?date:new Date();
    const y=d.getFullYear(),m=String(d.getMonth()+1).padStart(2,'0'),day=String(d.getDate()).padStart(2,'0');
    return `${y}-${m}-${day}`;
  }
  function getState(){return root.state||globalThis.state;}
  function dailyClaimAvailable(gameId,dateKey){
    const s=getState();
    if(!s)return false;
    s.arcade=ensureArcadeState(s.arcade);
    const key=dateKey||todayKey();
    return s.arcade.dailyRewards[String(gameId)]!==key;
  }
  function awardRun({gameId,label,score=0,coins=0,dailyEligible=false,dailyReward=null,dateKey=null}={}){
    const s=getState();
    if(!s)throw new Error('LuckyDex state unavailable');
    s.arcade=ensureArcadeState(s.arcade);
    const rawCoins=Math.max(0,Math.round(Number(coins)||0));
    const awardFn=root.awardArcadeCoins||globalThis.awardArcadeCoins;
    const awarded=typeof awardFn==='function'?Number(awardFn(rawCoins,label||'Arcade',gameId||'all')):rawCoins;
    let itemAwarded=null;
    const key=dateKey||todayKey();
    if(dailyEligible&&dailyReward&&ITEM_KEYS.has(dailyReward.key)&&Number(dailyReward.amount)>0&&dailyClaimAvailable(gameId,key)){
      const amount=Math.max(1,Math.round(Number(dailyReward.amount)));
      s.inventory=s.inventory||{};
      s.inventory[dailyReward.key]=Number(s.inventory[dailyReward.key]||0)+amount;
      s.arcade.dailyRewards[String(gameId)]=key;
      itemAwarded={key:dailyReward.key,amount};
      const saveFn=root.save||globalThis.save;
      if(typeof saveFn==='function')saveFn();
      const toastFn=root.showToast||globalThis.showToast;
      if(typeof toastFn==='function')toastFn(`${label||'Arcade'} daily bonus: +${amount} ${dailyReward.key}`);
    }
    return {coinsAwarded:Number.isFinite(awarded)?awarded:rawCoins,itemAwarded};
  }
  function fallbackName(id){return FALLBACK_NAMES[Number(id)]||`Pokémon ${id}`;}
  function spriteFor(id,shiny){
    const api=root.API||globalThis.API;
    return `arcade/sprites/actors/pokemon/${shiny?'shiny/':''}${id}.png`;
  }
  function displayName(entry,id){
    const raw=entry?.name||fallbackName(id);
    const tc=root.titleCase||globalThis.titleCase;
    return typeof tc==='function'?tc(raw):String(raw).replaceAll('-',' ').replace(/\b\w/g,c=>c.toUpperCase());
  }
  function caughtParticipants(limit,fallbackIds=[25,133,175,183]){
    const max=Math.max(0,Math.floor(Number(limit)||0));
    if(!max)return [];
    const s=getState()||{};
    const seen=new Set();
    const result=[];
    for(const entry of Object.values(s.pokemon||{})){
      const id=Number(entry?.id);
      if(!Number.isFinite(id)||id<=0)continue;
      const identity=`${id}:${entry?.shiny?'s':'n'}`;
      if(seen.has(identity))continue;
      seen.add(identity);
      result.push({id,name:displayName(entry,id),shiny:!!entry?.shiny,image:spriteFor(id,!!entry?.shiny)});
      if(result.length>=max)return result;
    }
    for(const rawId of fallbackIds||[]){
      const id=Number(rawId);
      if(!Number.isFinite(id)||id<=0)continue;
      const identity=`${id}:n`;
      if(seen.has(identity))continue;
      seen.add(identity);
      result.push({id,name:fallbackName(id),shiny:false,image:spriteFor(id,false)});
      if(result.length>=max)break;
    }
    return result;
  }
  function dashRacers(){
    const s=getState()||{};
    const dataset=root.LuckyDexAdventureSpecies||globalThis.LuckyDexAdventureSpecies||{};
    const byId=dataset.byId||{};
    const neutral=Number(dataset.fallback?.baseStats?.speed)||60;
    return Object.entries(s.pokemon||{}).map(([key,entry])=>{
      const id=Number(entry?.id);
      if(!Number.isFinite(id)||id<=0)return null;
      const species=byId[id]||byId[String(id)]||null;
      const speciesSpeed=Number(species?.baseStats?.speed);
      const entrySpeed=Number(entry?.baseStats?.speed);
      const baseSpeed=Number.isFinite(speciesSpeed)&&speciesSpeed>0?speciesSpeed:(Number.isFinite(entrySpeed)&&entrySpeed>0?entrySpeed:neutral);
      const racer={key:String(key),id,name:displayName(entry,id),shiny:!!entry?.shiny,level:Math.max(1,Math.round(Number(entry?.level)||1)),baseSpeed,types:Array.isArray(species?.types)?species.types.map(x=>String(x).toLowerCase()):[],image:spriteFor(id,!!entry?.shiny)};
      const speciesHeight=Number(species?.height),speciesWeight=Number(species?.weight);
      if(Number.isFinite(speciesHeight)&&speciesHeight>0)racer.height=speciesHeight;
      if(Number.isFinite(speciesWeight)&&speciesWeight>0)racer.weight=speciesWeight;
      return racer;
    }).filter(Boolean).sort((a,b)=>a.id-b.id||Number(a.shiny)-Number(b.shiny)||a.key.localeCompare(b.key));
  }
  function challengeParticipants(statKey='attack'){
    const s=getState()||{},dataset=root.LuckyDexAdventureSpecies||globalThis.LuckyDexAdventureSpecies||{},byId=dataset.byId||{},key=String(statKey||'attack'),neutral=Number(dataset.fallback?.baseStats?.[key])||60;
    return Object.entries(s.pokemon||{}).map(([saveKey,entry])=>{
      const id=Number(entry?.id);if(!Number.isFinite(id)||id<=0)return null;const species=byId[id]||byId[String(id)]||null,speciesStat=Number(species?.baseStats?.[key]),entryStat=Number(entry?.baseStats?.[key]);
      const baseStat=Number.isFinite(speciesStat)&&speciesStat>0?speciesStat:(Number.isFinite(entryStat)&&entryStat>0?entryStat:neutral);
      return {key:String(saveKey),id,name:displayName(entry,id),shiny:!!entry?.shiny,level:Math.max(1,Math.round(Number(entry?.level)||1)),statKey:key,baseStat,types:Array.isArray(species?.types)?species.types.map(x=>String(x).toLowerCase()):[],image:spriteFor(id,!!entry?.shiny)};
    }).filter(Boolean).sort((a,b)=>b.baseStat-a.baseStat||a.name.localeCompare(b.name)||a.key.localeCompare(b.key));
  }
  function ballDropPayout({ordinaryPoints=0,jackpots=0}={}){
    const points=Math.max(0,Number(ordinaryPoints)||0);
    const ordinaryCoins=points<=0?0:clamp(Math.round(points*0.06),15,90);
    const jackpotCoins=Math.max(0,Math.floor(Number(jackpots)||0))*1000;
    return {ordinaryCoins,jackpotCoins,totalCoins:ordinaryCoins+jackpotCoins};
  }

  const api={ZONES,ensureArcadeState,normalizeArcadeRecords,todayKey,dailyClaimAvailable,awardRun,caughtParticipants,dashRacers,challengeParticipants,ballDropPayout};
  root.LuckyDexArcadePlatform=api;
  if(root.state)root.state.arcade=ensureArcadeState(root.state.arcade);
  if(typeof module!=='undefined'&&module.exports)module.exports=api;
})(typeof window!=='undefined'?window:globalThis);
