(function(root){
  'use strict';

  const FALLBACK_NAMES={25:'Pikachu',133:'Eevee',175:'Togepi',183:'Marill'};
  const ITEM_KEYS=new Set(['berry','potion','pokeball','greatball','ultraball']);
  const ARCADE_DEFAULTS={
    dailyRewards:{},
    bestBerryPicker:{easy:0,normal:0,hard:0},
    bestHeadIt:{easy:0,normal:0,hard:0,unlimited:0,unlimitedStreak:0},
    bestTilePuzzle:{easy:null,normal:null,hard:null},
    lastArcadeZone:'amie',
    lastArcadeVenue:'amieGarden',
    museum:{exhibits:{}}
  };
  const ZONES={
    amie:{id:'amie',name:'Kalos Amie Garden',icon:'🌸',games:['berryPicker','tilePuzzle']},
    gameCorner:{id:'gameCorner',name:'Game Corner',icon:'🎰',games:['voltorb','ballDrop']},
    discovery:{id:'discovery',name:'Discovery District',icon:'🔬',games:['fossil','ditto','unown','quiz']},
    performance:{id:'performance',name:'Performance Stage',icon:'🎭',games:['berry','clefairy']}
  };

  function clone(v){return JSON.parse(JSON.stringify(v));}
  function clamp(n,a,b){return Math.max(a,Math.min(b,n));}
  function ensureArcadeState(arcade){
    const src=(arcade&&typeof arcade==='object')?arcade:{};
    return {
      ...src,
      dailyRewards:{...ARCADE_DEFAULTS.dailyRewards,...(src.dailyRewards||{})},
      bestBerryPicker:{...ARCADE_DEFAULTS.bestBerryPicker,...(src.bestBerryPicker||{})},
      bestHeadIt:{...ARCADE_DEFAULTS.bestHeadIt,...(src.bestHeadIt||{})},
      bestTilePuzzle:{...ARCADE_DEFAULTS.bestTilePuzzle,...(src.bestTilePuzzle||{})},
      museum:{...(src.museum&&typeof src.museum==='object'?src.museum:{}),exhibits:{...((src.museum&&typeof src.museum.exhibits==='object'&&src.museum.exhibits)||{})}},
      lastArcadeZone:typeof src.lastArcadeZone==='string'&&src.lastArcadeZone?src.lastArcadeZone:ARCADE_DEFAULTS.lastArcadeZone,
      lastArcadeVenue:['amieGarden','goldenrod','celadonPrize','lilycoveContest','moonStage','oreburghMuseum','ruinsAlph','indigoQuiz'].includes(src.lastArcadeVenue)?src.lastArcadeVenue:src.lastArcadeVenue==='stadiumClassroom'?'moonStage':({amie:'amieGarden',gameCorner:'goldenrod',discovery:'oreburghMuseum',performance:'lilycoveContest'}[src.lastArcadeZone]||'amieGarden')
    };
  }
  function todayKey(date){
    const d=date instanceof Date?date:new Date();
    const y=d.getFullYear(),m=String(d.getMonth()+1).padStart(2,'0'),day=String(d.getDate()).padStart(2,'0');
    return `${y}-${m}-${day}`;
  }
  function getState(){return root.state||globalThis.state;}
  function dailyClaimAvailable(gameId,dateKey){
    const s=getState();
    if(!s)return false;
    s.arcade=ensureArcadeState(s.arcade);
    const key=dateKey||todayKey();
    return s.arcade.dailyRewards[String(gameId)]!==key;
  }
  function awardRun({gameId,label,score=0,coins=0,dailyEligible=false,dailyReward=null,dateKey=null}={}){
    const s=getState();
    if(!s)throw new Error('LuckyDex state unavailable');
    s.arcade=ensureArcadeState(s.arcade);
    const rawCoins=Math.max(0,Math.round(Number(coins)||0));
    const awardFn=root.awardArcadeCoins||globalThis.awardArcadeCoins;
    const awarded=typeof awardFn==='function'?Number(awardFn(rawCoins,label||'Arcade',gameId||'all')):rawCoins;
    let itemAwarded=null;
    const key=dateKey||todayKey();
    if(dailyEligible&&dailyReward&&ITEM_KEYS.has(dailyReward.key)&&Number(dailyReward.amount)>0&&dailyClaimAvailable(gameId,key)){
      const amount=Math.max(1,Math.round(Number(dailyReward.amount)));
      s.inventory=s.inventory||{};
      s.inventory[dailyReward.key]=Number(s.inventory[dailyReward.key]||0)+amount;
      s.arcade.dailyRewards[String(gameId)]=key;
      itemAwarded={key:dailyReward.key,amount};
      const saveFn=root.save||globalThis.save;
      if(typeof saveFn==='function')saveFn();
      const toastFn=root.showToast||globalThis.showToast;
      if(typeof toastFn==='function')toastFn(`${label||'Arcade'} daily bonus: +${amount} ${dailyReward.key}`);
    }
    return {coinsAwarded:Number.isFinite(awarded)?awarded:rawCoins,itemAwarded};
  }
  function fallbackName(id){return FALLBACK_NAMES[Number(id)]||`Pokémon ${id}`;}
  function spriteFor(id,shiny){
    const api=root.API||globalThis.API;
    return `arcade/sprites/actors/pokemon/${shiny?'shiny/':''}${id}.png`;
  }
  function displayName(entry,id){
    const raw=entry?.name||fallbackName(id);
    const tc=root.titleCase||globalThis.titleCase;
    return typeof tc==='function'?tc(raw):String(raw).replaceAll('-',' ').replace(/\b\w/g,c=>c.toUpperCase());
  }
  function caughtParticipants(limit,fallbackIds=[25,133,175,183]){
    const max=Math.max(0,Math.floor(Number(limit)||0));
    if(!max)return [];
    const s=getState()||{};
    const seen=new Set();
    const result=[];
    for(const entry of Object.values(s.pokemon||{})){
      const id=Number(entry?.id);
      if(!Number.isFinite(id)||id<=0)continue;
      const identity=`${id}:${entry?.shiny?'s':'n'}`;
      if(seen.has(identity))continue;
      seen.add(identity);
      result.push({id,name:displayName(entry,id),shiny:!!entry?.shiny,image:spriteFor(id,!!entry?.shiny)});
      if(result.length>=max)return result;
    }
    for(const rawId of fallbackIds||[]){
      const id=Number(rawId);
      if(!Number.isFinite(id)||id<=0)continue;
      const identity=`${id}:n`;
      if(seen.has(identity))continue;
      seen.add(identity);
      result.push({id,name:fallbackName(id),shiny:false,image:spriteFor(id,false)});
      if(result.length>=max)break;
    }
    return result;
  }
  function ballDropPayout({ordinaryPoints=0,jackpots=0}={}){
    const points=Math.max(0,Number(ordinaryPoints)||0);
    const ordinaryCoins=points<=0?0:clamp(Math.round(points*0.06),15,90);
    const jackpotCoins=Math.max(0,Math.floor(Number(jackpots)||0))*1000;
    return {ordinaryCoins,jackpotCoins,totalCoins:ordinaryCoins+jackpotCoins};
  }

  const api={ZONES,ensureArcadeState,todayKey,dailyClaimAvailable,awardRun,caughtParticipants,ballDropPayout};
  root.LuckyDexArcadePlatform=api;
  if(root.state)root.state.arcade=ensureArcadeState(root.state.arcade);
  if(typeof module!=='undefined'&&module.exports)module.exports=api;
})(typeof window!=='undefined'?window:globalThis);
