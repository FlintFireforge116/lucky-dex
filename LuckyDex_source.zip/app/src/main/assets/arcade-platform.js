(function(root){
  'use strict';

  const FALLBACK_NAMES={25:'Pikachu',133:'Eevee',175:'Togepi',183:'Marill'};
  const ITEM_KEYS=new Set(['berry','potion','pokeball','greatball','ultraball']);
  const ARCADE_DEFAULTS={
    dailyRewards:{},
    bestBerryPicker:{easy:0,normal:0,hard:0},
    bestHeadIt:{easy:0,normal:0,hard:0,unlimited:0,unlimitedStreak:0},
    bestTilePuzzle:{easy:null,normal:null,hard:null},
    lastArcadeZone:'amie',
    lastArcadeVenue:'amieGarden',
    museum:{exhibits:{}},
    dash:{lastRacerKey:null,races:0,wins:0,podiums:0,bestTimeMs:null,lastQuickRacerKey:null,lastLeagueRacerKey:null,quickBestTimes:{easy:null,normal:null,hard:null,expert:null},leagueRecords:{}},
    ekansHoop:{gamesPlayed:0,wins:0,bestScore:0,bestStreak:0,totalHoops:0,shinyHits:0},
    digDigDig:{gamesPlayed:0,wins:0,podiums:0,bestTimeMs:null,bestTimes:{easy:null,normal:null,hard:null},winsByDifficulty:{easy:0,normal:0,hard:0}}
  };
  const ZONES={
    amie:{id:'amie',name:'Kalos Amie Garden',icon:'🌸',games:['berryPicker','tilePuzzle']},
    gameCorner:{id:'gameCorner',name:'Game Corner',icon:'🎰',games:['voltorb','ballDrop']},
    discovery:{id:'discovery',name:'Discovery District',icon:'🔬',games:['fossil','ditto','unown','quiz']},
    performance:{id:'performance',name:'Performance Stage',icon:'🎭',games:['berry','clefairy']}
  };

  function clone(v){return JSON.parse(JSON.stringify(v));}
  function clamp(n,a,b){return Math.max(a,Math.min(b,n));}
  function ensureArcadeState(arcade){
    const src=(arcade&&typeof arcade==='object')?arcade:{};
    const srcDash=(src.dash&&typeof src.dash==='object')?src.dash:{};
    const dash={
      ...ARCADE_DEFAULTS.dash,
      ...srcDash,
      quickBestTimes:{...ARCADE_DEFAULTS.dash.quickBestTimes,...(srcDash.quickBestTimes&&typeof srcDash.quickBestTimes==='object'?srcDash.quickBestTimes:{})},
      leagueRecords:{...(srcDash.leagueRecords&&typeof srcDash.leagueRecords==='object'?srcDash.leagueRecords:{})}
    };
    if((srcDash.lastQuickRacerKey===undefined||srcDash.lastQuickRacerKey===null)&&srcDash.lastRacerKey)dash.lastQuickRacerKey=srcDash.lastRacerKey;
    return {
      ...src,
      dailyRewards:{...ARCADE_DEFAULTS.dailyRewards,...(src.dailyRewards||{})},
      bestBerryPicker:{...ARCADE_DEFAULTS.bestBerryPicker,...(src.bestBerryPicker||{})},
      bestHeadIt:{...ARCADE_DEFAULTS.bestHeadIt,...(src.bestHeadIt||{})},
      bestTilePuzzle:{...ARCADE_DEFAULTS.bestTilePuzzle,...(src.bestTilePuzzle||{})},
      museum:{...(src.museum&&typeof src.museum==='object'?src.museum:{}),exhibits:{...((src.museum&&typeof src.museum.exhibits==='object'&&src.museum.exhibits)||{})}},
      dash,
      ekansHoop:{...ARCADE_DEFAULTS.ekansHoop,...(src.ekansHoop&&typeof src.ekansHoop==='object'?src.ekansHoop:{})},
      digDigDig:{...ARCADE_DEFAULTS.digDigDig,...(src.digDigDig&&typeof src.digDigDig==='object'?src.digDigDig:{}),bestTimes:{...ARCADE_DEFAULTS.digDigDig.bestTimes,...(src.digDigDig&&typeof src.digDigDig.bestTimes==='object'?src.digDigDig.bestTimes:{})},winsByDifficulty:{...ARCADE_DEFAULTS.digDigDig.winsByDifficulty,...(src.digDigDig&&typeof src.digDigDig.winsByDifficulty==='object'?src.digDigDig.winsByDifficulty:{})}},
      lastArcadeZone:typeof src.lastArcadeZone==='string'&&src.lastArcadeZone?src.lastArcadeZone:ARCADE_DEFAULTS.lastArcadeZone,
      lastArcadeVenue:['amieGarden','goldenrod','celadonPrize','lilycoveContest','moonStage','oreburghMuseum','ruinsAlph','indigoQuiz','dashCourse','stadiumKidsClub'].includes(src.lastArcadeVenue)?src.lastArcadeVenue:src.lastArcadeVenue==='stadiumClassroom'?'moonStage':({amie:'amieGarden',gameCorner:'goldenrod',discovery:'oreburghMuseum',performance:'lilycoveContest'}[src.lastArcadeZone]||'amieGarden')
    };
  }
  function todayKey(date){
    const d=date instanceof Date?date:new Date();
    const y=d.getFullYear(),m=String(d.getMonth()+1).padStart(2,'0'),day=String(d.getDate()).padStart(2,'0');
    return `${y}-${m}-${day}`;
  }
  function getState(){return root.state||globalThis.state;}
  function dailyClaimAvailable(gameId,dateKey){
    const s=getState();
    if(!s)return false;
    s.arcade=ensureArcadeState(s.arcade);
    const key=dateKey||todayKey();
    return s.arcade.dailyRewards[String(gameId)]!==key;
  }
  function awardRun({gameId,label,score=0,coins=0,dailyEligible=false,dailyReward=null,dateKey=null}={}){
    const s=getState();
    if(!s)throw new Error('LuckyDex state unavailable');
    s.arcade=ensureArcadeState(s.arcade);
    const rawCoins=Math.max(0,Math.round(Number(coins)||0));
    const awardFn=root.awardArcadeCoins||globalThis.awardArcadeCoins;
    const awarded=typeof awardFn==='function'?Number(awardFn(rawCoins,label||'Arcade',gameId||'all')):rawCoins;
    let itemAwarded=null;
    const key=dateKey||todayKey();
    if(dailyEligible&&dailyReward&&ITEM_KEYS.has(dailyReward.key)&&Number(dailyReward.amount)>0&&dailyClaimAvailable(gameId,key)){
      const amount=Math.max(1,Math.round(Number(dailyReward.amount)));
      s.inventory=s.inventory||{};
      s.inventory[dailyReward.key]=Number(s.inventory[dailyReward.key]||0)+amount;
      s.arcade.dailyRewards[String(gameId)]=key;
      itemAwarded={key:dailyReward.key,amount};
      const saveFn=root.save||globalThis.save;
      if(typeof saveFn==='function')saveFn();
      const toastFn=root.showToast||globalThis.showToast;
      if(typeof toastFn==='function')toastFn(`${label||'Arcade'} daily bonus: +${amount} ${dailyReward.key}`);
    }
    return {coinsAwarded:Number.isFinite(awarded)?awarded:rawCoins,itemAwarded};
  }
  function fallbackName(id){return FALLBACK_NAMES[Number(id)]||`Pokémon ${id}`;}
  function spriteFor(id,shiny){
    const api=root.API||globalThis.API;
    return `arcade/sprites/actors/pokemon/${shiny?'shiny/':''}${id}.png`;
  }
  function displayName(entry,id){
    const raw=entry?.name||fallbackName(id);
    const tc=root.titleCase||globalThis.titleCase;
    return typeof tc==='function'?tc(raw):String(raw).replaceAll('-',' ').replace(/\b\w/g,c=>c.toUpperCase());
  }
  function caughtParticipants(limit,fallbackIds=[25,133,175,183]){
    const max=Math.max(0,Math.floor(Number(limit)||0));
    if(!max)return [];
    const s=getState()||{};
    const seen=new Set();
    const result=[];
    for(const entry of Object.values(s.pokemon||{})){
      const id=Number(entry?.id);
      if(!Number.isFinite(id)||id<=0)continue;
      const identity=`${id}:${entry?.shiny?'s':'n'}`;
      if(seen.has(identity))continue;
      seen.add(identity);
      result.push({id,name:displayName(entry,id),shiny:!!entry?.shiny,image:spriteFor(id,!!entry?.shiny)});
      if(result.length>=max)return result;
    }
    for(const rawId of fallbackIds||[]){
      const id=Number(rawId);
      if(!Number.isFinite(id)||id<=0)continue;
      const identity=`${id}:n`;
      if(seen.has(identity))continue;
      seen.add(identity);
      result.push({id,name:fallbackName(id),shiny:false,image:spriteFor(id,false)});
      if(result.length>=max)break;
    }
    return result;
  }
  function dashRacers(){
    const s=getState()||{};
    const dataset=root.LuckyDexAdventureSpecies||globalThis.LuckyDexAdventureSpecies||{};
    const byId=dataset.byId||{};
    const neutral=Number(dataset.fallback?.baseStats?.speed)||60;
    return Object.entries(s.pokemon||{}).map(([key,entry])=>{
      const id=Number(entry?.id);
      if(!Number.isFinite(id)||id<=0)return null;
      const species=byId[id]||byId[String(id)]||null;
      const speciesSpeed=Number(species?.baseStats?.speed);
      const entrySpeed=Number(entry?.baseStats?.speed);
      const baseSpeed=Number.isFinite(speciesSpeed)&&speciesSpeed>0?speciesSpeed:(Number.isFinite(entrySpeed)&&entrySpeed>0?entrySpeed:neutral);
      const racer={key:String(key),id,name:displayName(entry,id),shiny:!!entry?.shiny,level:Math.max(1,Math.round(Number(entry?.level)||1)),baseSpeed,types:Array.isArray(species?.types)?species.types.map(x=>String(x).toLowerCase()):[],image:spriteFor(id,!!entry?.shiny)};
      const speciesHeight=Number(species?.height),speciesWeight=Number(species?.weight);
      if(Number.isFinite(speciesHeight)&&speciesHeight>0)racer.height=speciesHeight;
      if(Number.isFinite(speciesWeight)&&speciesWeight>0)racer.weight=speciesWeight;
      return racer;
    }).filter(Boolean).sort((a,b)=>a.id-b.id||Number(a.shiny)-Number(b.shiny)||a.key.localeCompare(b.key));
  }
  function ballDropPayout({ordinaryPoints=0,jackpots=0}={}){
    const points=Math.max(0,Number(ordinaryPoints)||0);
    const ordinaryCoins=points<=0?0:clamp(Math.round(points*0.06),15,90);
    const jackpotCoins=Math.max(0,Math.floor(Number(jackpots)||0))*1000;
    return {ordinaryCoins,jackpotCoins,totalCoins:ordinaryCoins+jackpotCoins};
  }

  const api={ZONES,ensureArcadeState,todayKey,dailyClaimAvailable,awardRun,caughtParticipants,dashRacers,ballDropPayout};
  root.LuckyDexArcadePlatform=api;
  if(root.state)root.state.arcade=ensureArcadeState(root.state.arcade);
  if(typeof module!=='undefined'&&module.exports)module.exports=api;
})(typeof window!=='undefined'?window:globalThis);
