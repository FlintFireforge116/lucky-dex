(function(root){
'use strict';
const BERRIES=[
{id:'razz',name:'Razz',image:'arcade/sprites/items/razz-berry.png'},
{id:'bluk',name:'Bluk',image:'arcade/sprites/items/bluk-berry.png'},
{id:'pinap',name:'Pinap',image:'arcade/sprites/items/pinap-berry.png'},
{id:'wepear',name:'Wepear',image:'arcade/sprites/items/wepear-berry.png'},
{id:'magost',name:'Magost',image:'arcade/sprites/items/magost-berry.png'},
{id:'durin',name:'Durin',image:'arcade/sprites/items/durin-berry.png'},
{id:'nomel',name:'Nomel',image:'arcade/sprites/items/nomel-berry.png'}];
const BERRY_MODES={easy:{durationMs:60000,berries:3,maxCustomers:1,missLimit:null},normal:{durationMs:60000,berries:5,maxCustomers:2,missLimit:null},hard:{durationMs:60000,berries:7,maxCustomers:3,missLimit:null},unlimited:{durationMs:null,berries:5,maxCustomers:3,missLimit:3}};
const BERRY_META={easy:{patience:6500,cap:70,daily:15},normal:{patience:5200,cap:100,daily:25},hard:{patience:4100,cap:140,daily:35},unlimited:{patience:3600,cap:150,daily:45}};
const HEAD_MODES={easy:{durationMs:60000,activeLanes:1,missLimit:null,cap:70},normal:{durationMs:60000,activeLanes:2,missLimit:null,cap:100},hard:{durationMs:60000,activeLanes:3,missLimit:null,cap:140},unlimited:{durationMs:null,activeLanes:3,missLimit:3,cap:150}};
const FEVER_COMBO=15;
const YARN_TYPES=[{id:'pink',speed:1,points:100},{id:'slow',speed:.68,points:120},{id:'purple',speed:1.55,points:150},{id:'bonus',speed:.72,points:600}];
const TILE_MODES={easy:{rows:4,cols:5},normal:{rows:5,cols:6},hard:{rows:6,cols:8}};
let active=null,berryMode='easy',headMode='easy',tileMode='easy',berry=null,head=null,tile=null;
const $=id=>typeof document!=='undefined'?document.getElementById(id):null;

const platform=()=>root.LuckyDexArcadePlatform;
const session=()=>root.LuckyDexArcadeSession;
const clamp=(v,a,b)=>Math.max(a,Math.min(b,v));
const choose=a=>a[Math.floor(Math.random()*a.length)];
const berryObj=id=>BERRIES.find(b=>b.id===id)||BERRIES[0];
const backdrop=name=>`arcade/authentic-v0200/amie/${name}-backdrop.png`;
const imageCache=new Map();
function participants(n){
 const supplied=platform()?.caughtParticipants?.(n,[25,133,175])||[];
 return Array.from({length:n},(_,i)=>{
  const p=supplied[i]||{id:[25,133,175][i%3],name:['Pikachu','Eevee','Togepi'][i%3]};
  return {...p,image:p.image||`arcade/sprites/actors/pokemon/${p.shiny?'shiny/':''}${p.id}.png`};
 });
}
function award(gameId,label,score,coins,dailyEligible=false,dailyReward=null){
 return platform()?.awardRun?.({gameId,label,score,coins,dailyEligible,dailyReward})||{coinsAwarded:coins,itemAwarded:null};
}
function shuffled(n){const a=Array.from({length:n},(_,i)=>i);for(let i=n-1;i>0;i--){const j=Math.floor(Math.random()*(i+1));[a[i],a[j]]=[a[j],a[i]];}return a;}
function swapTiles(board,a,b){if(Array.isArray(board)&&a>=0&&b>=0&&a<board.length&&b<board.length)[board[a],board[b]]=[board[b],board[a]];return board;}
function isSolvedSwap(board){return Array.isArray(board)&&board.every((v,i)=>v===i);}
function tileRect(value,rows,cols){return {row:Math.floor(value/cols),col:value%cols,x:(value%cols)/cols,y:Math.floor(value/cols)/rows,w:1/cols,h:1/rows};}
function runState(extra){return {running:false,finished:false,disposed:false,timeouts:new Set(),raf:null,interval:null,drag:null,...extra};}
function later(run,callback,ms){
 const id=setTimeout(()=>{run.timeouts.delete(id);if(!run.disposed&&run.running)callback();},ms);
 run.timeouts.add(id);return id;
}
function dispose(run){
 if(!run)return;
 run.disposed=true;run.running=false;
 if(run.raf!=null)cancelAnimationFrame(run.raf);
 if(run.interval!=null)clearInterval(run.interval);
 run.timeouts.forEach(clearTimeout);run.timeouts.clear();run.drag?.();
 run.raf=run.interval=null;
}
function resetAll(){dispose(berry);dispose(head);dispose(tile);berry=head=tile=null;}
function text(id,value){const el=$(id);if(el)el.textContent=value;}
function message(game,value){text(`${game}Message`,value);}
function controls(game,running,label){
 const start=$(`${game}StartBtn`),restart=$(`${game}RestartBtn`);
 if(start){start.hidden=running;start.textContent=label;}
 if(restart)restart.hidden=!running;
 document.querySelectorAll(`[data-${game==='berryPicker'?'berry':game==='headIt'?'head':'tile'}-mode]`).forEach(b=>b.disabled=running);
}
function result(game,data){
 if(session()?.showResult)session().showResult(game,data);
 else message(game,`${data.title} ${data.metricValue} · ${data.coinsAwarded} coins`);
}

/* Berry Picker: stable requesters and a run-owned pointer gesture. */
function berryNewRequest(c){c.request=choose(BERRIES.slice(0,BERRY_MODES[berryMode].berries)).id;c.expires=performance.now()+BERRY_META[berryMode].patience;c.reaction='';}
function prepareBerry(running=false){
 const cfg=BERRY_MODES[berryMode];
 berry=runState({running,score:0,served:0,combo:0,misses:0,selected:null,ends:cfg.durationMs?performance.now()+cfg.durationMs:null,customers:participants(cfg.maxCustomers).map(p=>({p}))});
 berry.customers.forEach(berryNewRequest);berryScene();renderBerryHud();controls('berryPicker',running,'START PICKER');
 message('berryPicker',running?'Match each requested berry. Drag it to the Pokémon, or tap the berry then the Pokémon.':'Choose a mode, then start. Match the berries your Pokémon request.');
}
function berryScene(){
 const stage=$('berryPickerStage');if(!stage||!berry)return;
 stage.replaceChildren();
 const tree=document.createElement('div');tree.className='amie-berry-tree';
 BERRIES.slice(0,BERRY_MODES[berryMode].berries).forEach((b,i)=>{
  const button=document.createElement('button');button.type='button';button.className=`amie-berry berry-pos-${i}`;button.dataset.berryPick=b.id;button.setAttribute('aria-label',`${b.name} Berry`);
  const img=document.createElement('img');img.src=b.image;img.alt='';button.append(img);tree.append(button);
  button.addEventListener('pointerdown',e=>startBerryDrag(e,b.id));
  button.addEventListener('click',()=>{if(!berry?.running)return;berry.selected=b.id;stage.querySelectorAll('[data-berry-pick]').forEach(x=>x.classList.toggle('selected',x===button));});
 });
 const customers=document.createElement('div');customers.id='berryCustomers';customers.className='amie-customers';
 berry.customers.forEach((c,i)=>{
  const button=document.createElement('button');button.type='button';button.className='amie-requester';button.dataset.berryCustomer=i;
  const thought=document.createElement('span');thought.className='berry-thought';const request=document.createElement('img');const patience=document.createElement('progress');patience.max=1;thought.append(request,patience);
  const img=document.createElement('img');img.src=c.p.image;img.alt=c.p.name;img.className='amie-pokemon';
  button.append(thought,img);button.addEventListener('click',()=>{if(berry?.selected)deliverBerry(i,berry.selected);});customers.append(button);
 });
 stage.append(tree,customers);renderBerryCustomers();
}
function renderBerryCustomers(){
 if(!berry)return;const now=performance.now();
 $('berryCustomers')?.querySelectorAll('[data-berry-customer]').forEach((el,i)=>{
  const c=berry.customers[i],b=berryObj(c.request),remaining=berry.running?clamp((c.expires-now)/BERRY_META[berryMode].patience,0,1):1;
  el.className=`amie-requester ${c.reaction||''} ${remaining<.28?'impatient':''}`;
  el.setAttribute('aria-label',`${c.p.name} requests ${b.name} Berry`);
  const img=el.querySelector('.berry-thought img');if(img.getAttribute('src')!==b.image)img.src=b.image;img.alt=b.name;
  el.querySelector('progress').value=remaining;
 });
}
function startBerryDrag(ev,id){
 const run=berry;if(!run?.running)return;ev.preventDefault();run.drag?.();run.selected=id;
 const ghost=document.createElement('img');ghost.src=berryObj(id).image;ghost.className='berry-drag';document.body.append(ghost);
 const pointerId=ev.pointerId;
 const move=e=>{if(e.pointerId!==pointerId)return;ghost.style.left=`${e.clientX}px`;ghost.style.top=`${e.clientY}px`;};
 let cleaned=false;
 const cleanup=()=>{if(cleaned)return;cleaned=true;root.removeEventListener('pointermove',move);root.removeEventListener('pointerup',up);root.removeEventListener('pointercancel',cancel);ghost.remove();if(run.drag===cleanup)run.drag=null;};
 const up=e=>{if(e.pointerId!==pointerId)return;cleanup();if(run.disposed||!run.running)return;const target=document.elementFromPoint(e.clientX,e.clientY)?.closest('[data-berry-customer]');if(target)deliverBerry(Number(target.dataset.berryCustomer),id);};
 const cancel=e=>{if(e.pointerId===pointerId)cleanup();};
 run.drag=cleanup;root.addEventListener('pointermove',move);root.addEventListener('pointerup',up);root.addEventListener('pointercancel',cancel);move(ev);
}
function berryMiss(c,wrong=false){
 const run=berry;if(!run?.running||c.reaction)return;run.combo=0;run.misses++;c.reaction=wrong?'wrong':'timeout';
 later(run,()=>{berryNewRequest(c);renderBerryCustomers();},360);
 if(BERRY_MODES[berryMode].missLimit&&run.misses>=BERRY_MODES[berryMode].missLimit)finishBerry();
}
function deliverBerry(index,id){
 const run=berry,c=run?.customers[index];if(!run?.running||!c||c.reaction)return;
 if(c.request!==id){berryMiss(c,true);renderBerryCustomers();renderBerryHud();return;}
 const remaining=clamp((c.expires-performance.now())/BERRY_META[berryMode].patience,0,1);
 run.score+=Math.round(100+remaining*60+Math.min(run.combo,12)*8);run.served++;run.combo++;c.reaction=remaining>.55?'great':'good';root.vibrate?.(12);
 later(run,()=>{berryNewRequest(c);renderBerryCustomers();},250);renderBerryCustomers();renderBerryHud();
}
function renderBerryHud(){
 if(!berry)return;const left=berry.ends==null?null:Math.max(0,berry.ends-performance.now());
 text('berryPickerTimer',left==null?'∞':Math.ceil(left/1000));text('berryPickerScore',berry.score);text('berryPickerCombo',berry.combo);text('berryPickerCorrect',berry.served);
 session()?.update?.('berryPicker',{runText:left==null?`${berry.misses}/3 misses · ${berry.served} served`:`${Math.ceil(left/1000)}s · ${berry.served} served`,liveLabel:'SCORE',liveValue:berry.score});
}
function startBerry(){if(active!=='berryPicker')return;dispose(berry);session()?.hideResult?.();prepareBerry(true);const run=berry;run.interval=setInterval(()=>{if(run.disposed||!run.running)return;const now=performance.now();for(const c of run.customers)if(now>=c.expires&&!c.reaction)berryMiss(c);renderBerryCustomers();renderBerryHud();if(run.ends!=null&&now>=run.ends)finishBerry();},90);}
function finishBerry(){
 if(!berry?.running||berry.finished)return;const run=berry;run.finished=true;dispose(run);
 const best=root.state?.arcade?.bestBerryPicker;
 if(best&&Object.hasOwn(best,berryMode))best[berryMode]=Math.max(Number(best[berryMode])||0,run.score);
 const meta=BERRY_META[berryMode],coins=clamp(Math.round(run.score/24),20,meta.cap),reward=award('berryPicker','Berry Picker',run.score,coins,run.served>=meta.daily,{key:'berry',amount:berryMode==='hard'?4:berryMode==='normal'?3:2});
 root.save?.();
 controls('berryPicker',false,'PLAY AGAIN');result('berryPicker',{title:berryMode==='unlimited'?'THREE MISSES':'TIME!',metricLabel:'BERRIES SERVED',metricValue:`${run.served} · ${run.score} pts`,...reward,bestText:run.combo>=FEVER_COMBO?'HOT STREAK':'',onReplay:startBerry,onBack:()=>root.LuckyDexArcadeWorld?.backFromGame?.(true)});
}
function setBerryMode(m){if(!BERRY_MODES[m]||berry?.running)return;berryMode=m;modeButtons('berry',m);if(active==='berryPicker'){dispose(berry);prepareBerry();}}

/* Head It: lane buttons survive every frame; all delays belong to their run. */
function prepareHead(running=false){
 head=runState({running,started:performance.now(),elapsed:0,score:0,combo:0,bestCombo:0,misses:0,fever:false,bonusPhase:false,ball:null,feedback:null,ps:participants(3)});
 buildHeadLanes();drawHead();renderHeadHud();controls('headIt',running,'START HEAD IT');message('headIt',running?'Tap the Pokémon when the yarn reaches the ring. Build 15 headers for Fever.':'Choose a mode, then tap a Pokémon as the yarn reaches the ring.');
}
function buildHeadLanes(){
 const lanes=$('headItLanes');if(!lanes)return;lanes.replaceChildren();lanes.style.setProperty('--lanes',HEAD_MODES[headMode].activeLanes);
 for(let i=0;i<HEAD_MODES[headMode].activeLanes;i++){
  const button=document.createElement('button');button.type='button';button.className='head-lane';button.dataset.headLane=i;button.setAttribute('aria-label',`Header with ${head.ps[i].name}`);
  const ring=document.createElement('span');ring.className='head-contact';const yarn=document.createElement('img');yarn.className='amie-yarn';yarn.src='arcade/authentic-v0200/amie/yarn-pink.png';yarn.alt='Yarn';yarn.hidden=true;
  const pokemon=document.createElement('img');pokemon.className='head-pokemon';pokemon.src=head.ps[i].image;pokemon.alt=head.ps[i].name;const grade=document.createElement('b');grade.className='head-grade';
  button.append(ring,yarn,pokemon,grade);button.addEventListener('pointerdown',e=>{e.preventDefault();headHit(i);});button.addEventListener('keydown',e=>{if(e.key==='Enter'||e.key===' '){e.preventDefault();headHit(i);}});lanes.append(button);
 }
}
function headSpawn(forceBonus=false){
 if(!head?.running)return;const mode=HEAD_MODES[headMode],roll=Math.random(),type=forceBonus?YARN_TYPES[3]:(roll<.12?YARN_TYPES[2]:roll<.23?YARN_TYPES[1]:YARN_TYPES[0]);
 head.ball={lane:Math.floor(Math.random()*mode.activeLanes),type,start:performance.now(),dur:Math.max(620,1550-head.elapsed/1000*9)/type.speed,y:0,hit:false,bonus:forceBonus};
}
function headHit(lane){
 const run=head,b=run?.ball;if(!run?.running||!b||b.hit)return;if(lane!==b.lane){headMiss('WRONG');return;}
 const delta=Math.abs(b.y-.84),grade=delta<=.055?'PERFECT':delta<=.13?'GOOD':'MISS';if(grade==='MISS'){headMiss();return;}
 b.hit=true;run.combo++;run.bestCombo=Math.max(run.bestCombo,run.combo);run.fever=run.combo>=FEVER_COMBO;run.score+=Math.round((grade==='PERFECT'?b.type.points:b.type.points*.6)*(run.fever?2:1));run.feedback={lane,text:run.fever?`${grade} · FEVER!`:grade,until:performance.now()+420};root.vibrate?.(grade==='PERFECT'?[8,15,10]:10);
 later(run,()=>{if(run.ball!==b)return;run.ball=null;if(b.bonus)finishHead(true);else headSpawn();},170);renderHeadHud();
}
function headMiss(value='MISS'){
 const run=head;if(!run?.running)return;run.misses++;run.combo=0;run.fever=false;run.feedback={lane:run.ball?.lane||0,text:value,until:performance.now()+420};run.ball=null;
 if(HEAD_MODES[headMode].missLimit&&run.misses>=HEAD_MODES[headMode].missLimit){finishHead(false);return;}
 later(run,()=>{if(!run.ball)headSpawn();},180);renderHeadHud();
}
function drawHead(){
 if(!head)return;$('headItLanes')?.querySelectorAll('[data-head-lane]').forEach((lane,i)=>{
  lane.classList.toggle('fever',head.fever);const yarn=lane.querySelector('.amie-yarn'),b=head.ball;const visible=b&&b.lane===i;
  yarn.hidden=!visible;if(visible){yarn.className=`amie-yarn ${b.type.id}`;const source=`arcade/authentic-v0200/amie/yarn-${b.type.id==='slow'?'blue':b.type.id}.png`;if(yarn.getAttribute('src')!==source)yarn.src=source;yarn.style.top=`${b.y*100}%`;yarn.alt=`${b.type.id} yarn`;}
  const feedback=head.feedback&&head.feedback.lane===i&&performance.now()<head.feedback.until?head.feedback.text:'';lane.querySelector('.head-grade').textContent=feedback;
 });
}
function renderHeadHud(){
 if(!head)return;text('headItScore',head.score);text('headItCombo',head.combo);text('headItMisses',head.misses);const remaining=HEAD_MODES[headMode].durationMs?`${Math.max(0,Math.ceil((60000-head.elapsed)/1000))}s`:`${Math.max(0,3-head.misses)} misses left`;text('headItTimer',remaining);
 session()?.update?.('headIt',{runText:remaining,liveLabel:head.fever?'FEVER':'COMBO',liveValue:head.combo});
}
function headFrame(run,now){
 if(run.disposed||!run.running||head!==run)return;run.elapsed=now-run.started;
 if(run.ball&&!run.ball.hit){run.ball.y=(now-run.ball.start)/run.ball.dur;if(run.ball.y>=1.04){if(run.ball.bonus){run.ball=null;finishHead(true);return;}headMiss();}}
 if(HEAD_MODES[headMode].durationMs&&run.elapsed>=60000&&!run.bonusPhase){run.bonusPhase=true;run.ball=null;headSpawn(true);}
 drawHead();renderHeadHud();if(run.running)run.raf=requestAnimationFrame(now=>headFrame(run,now));
}
function startHead(){if(active!=='headIt')return;dispose(head);session()?.hideResult?.();prepareHead(true);headSpawn();const run=head;run.raf=requestAnimationFrame(now=>headFrame(run,now));}
function finishHead(afterBonus){
 if(!head?.running||head.finished)return;const run=head;run.finished=true;dispose(run);drawHead();
 const best=root.state?.arcade?.bestHeadIt;
 if(best){if(Object.hasOwn(best,headMode))best[headMode]=Math.max(Number(best[headMode])||0,run.score);if(headMode==='unlimited'&&Object.hasOwn(best,'unlimitedStreak'))best.unlimitedStreak=Math.max(Number(best.unlimitedStreak)||0,run.bestCombo);}
 const cfg=HEAD_MODES[headMode],coins=clamp(Math.round(run.score/28),20,cfg.cap),reward=award('headIt','Head It',run.score,coins,run.score>=(headMode==='hard'?3200:1800),{key:'potion',amount:1});
 root.save?.();
 controls('headIt',false,'PLAY AGAIN');result('headIt',{title:headMode==='unlimited'?'HEADER DOWN!':afterBonus?'FINAL YARN!':'TIME!',metricLabel:'SCORE',metricValue:`${run.score} · best combo ${run.bestCombo}`,...reward,bestText:run.bestCombo>=FEVER_COMBO?'FEVER REACHED':'',onReplay:startHead,onBack:()=>root.LuckyDexArcadeWorld?.backFromGame?.(true)});
}
function setHeadMode(m){if(!HEAD_MODES[m]||head?.running)return;headMode=m;modeButtons('head',m);if(active==='headIt'){dispose(head);prepareHead();}}

/* Tile Puzzle: real source backdrop and aspect-preserving local sprites. */
function loadedImage(url,onload){
 let im=imageCache.get(url);if(!im){im=new Image();imageCache.set(url,im);im.src=url;}
 if(im.complete&&im.naturalWidth)onload?.();else if(onload)im.addEventListener('load',onload,{once:true});return im;
}
function drawCover(ctx,im,w,h){if(!im?.complete||!im.naturalWidth)return;const scale=Math.max(w/im.naturalWidth,h/im.naturalHeight),dw=im.naturalWidth*scale,dh=im.naturalHeight*scale;ctx.drawImage(im,(w-dw)/2,(h-dh)/2,dw,dh);}
function tileSource(ctx,w,h,now,run){
 ctx.clearRect(0,0,w,h);drawCover(ctx,run.backdrop,w,h);
 const pos=[[.23,.78],[.5,.73],[.77,.79]];
 run.ps.forEach((p,i)=>{const im=p.imageNode;if(!im?.complete||!im.naturalWidth)return;const boxW=w*.25,boxH=h*.48,scale=Math.min(boxW/im.naturalWidth,boxH/im.naturalHeight),dw=im.naturalWidth*scale,dh=im.naturalHeight*scale,bob=run.running?Math.sin(now/420+i*1.7)*h*.018:0;ctx.drawImage(im,pos[i][0]*w-dw/2,pos[i][1]*h-dh+bob,dw,dh);});
}
function renderTileCanvas(run,now){
 if(run.disposed||tile!==run)return;const canvas=$('tilePuzzleCanvas');if(!canvas)return;const rect=canvas.getBoundingClientRect(),dpr=Math.min(2,root.devicePixelRatio||1),w=Math.max(1,Math.round(rect.width*dpr)),h=Math.round(w*3/5);
 if(canvas.width!==w||canvas.height!==h){canvas.width=w;canvas.height=h;}run.source.width=w;run.source.height=h;tileSource(run.source.getContext('2d'),w,h,now,run);
 const ctx=canvas.getContext('2d'),{rows,cols}=TILE_MODES[tileMode],cw=w/cols,ch=h/rows;ctx.clearRect(0,0,w,h);
 run.board.forEach((value,index)=>{const r=tileRect(value,rows,cols),x=index%cols*cw,y=Math.floor(index/cols)*ch;ctx.drawImage(run.source,r.x*w,r.y*h,r.w*w,r.h*h,x,y,cw,ch);if(run.running){ctx.strokeStyle=index===run.selected?'#ffe777':'rgba(255,255,255,.6)';ctx.lineWidth=index===run.selected?4:1;ctx.strokeRect(x+.5,y+.5,cw-1,ch-1);}});
 text('tilePuzzleTimer',run.running?((now-run.started)/1000).toFixed(1):run.finished?run.elapsed.toFixed(1):'0.0');text('tilePuzzleMoves',run.moves);
 if(run.running)run.raf=requestAnimationFrame(now=>renderTileCanvas(run,now));
}
function prepareTile(running=false){
 const cfg=TILE_MODES[tileMode],n=cfg.rows*cfg.cols;let board=running?shuffled(n):Array.from({length:n},(_,i)=>i);if(running&&isSolvedSwap(board))swapTiles(board,0,1);
 const run=tile=runState({running,started:performance.now(),board,selected:null,moves:0,ps:participants(3),source:document.createElement('canvas')});
 const repaint=()=>{if(tile===run&&!run.disposed&&!run.running)renderTileCanvas(run,performance.now());};
 run.backdrop=loadedImage(backdrop('tile-puzzle'),repaint);run.ps.forEach(p=>p.imageNode=loadedImage(p.image,repaint));
 const canvas=$('tilePuzzleCanvas');canvas?.setAttribute('aria-label',`${cfg.rows} by ${cfg.cols} moving picture swap puzzle`);canvas?.classList.remove('tile-solved');
 controls('tilePuzzle',running,'START PUZZLE');message('tilePuzzle',running?'Tap two tiles to swap them and restore the moving picture.':'Choose a difficulty, then restore this Pokémon picture by swapping two tiles.');
 if(running)run.raf=requestAnimationFrame(now=>renderTileCanvas(run,now));else renderTileCanvas(run,performance.now());
}
function tileTap(ev){
 if(!tile?.running)return;ev.preventDefault();const c=$('tilePuzzleCanvas'),r=c.getBoundingClientRect(),cfg=TILE_MODES[tileMode];
 const col=clamp(Math.floor((ev.clientX-r.left)/r.width*cfg.cols),0,cfg.cols-1),row=clamp(Math.floor((ev.clientY-r.top)/r.height*cfg.rows),0,cfg.rows-1),idx=row*cfg.cols+col;
 if(tile.selected==null){tile.selected=idx;return;}if(tile.selected===idx){tile.selected=null;return;}swapTiles(tile.board,tile.selected,idx);tile.moves++;tile.selected=null;text('tilePuzzleMoves',tile.moves);if(isSolvedSwap(tile.board))finishTile();
}
function startTile(){if(active!=='tilePuzzle')return;dispose(tile);session()?.hideResult?.();prepareTile(true);session()?.update?.('tilePuzzle',{runText:`${TILE_MODES[tileMode].rows}×${TILE_MODES[tileMode].cols} swap puzzle`,liveLabel:'MOVES',liveValue:0});}
function finishTile(){
 if(!tile?.running||tile.finished)return;const run=tile;run.finished=true;run.elapsed=(performance.now()-run.started)/1000;run.running=false;if(run.raf!=null)cancelAnimationFrame(run.raf);run.raf=null;renderTileCanvas(run,performance.now());
 const best=root.state?.arcade?.bestTilePuzzle;
 if(best&&Object.hasOwn(best,tileMode)){const previous=best[tileMode];if(previous==null||run.elapsed<Number(previous))best[tileMode]=Number(run.elapsed.toFixed(2));}
 const cfg=TILE_MODES[tileMode],elapsed=run.elapsed,coins=clamp(Math.round(cfg.rows*cfg.cols*2.2-Math.min(35,elapsed/6)-Math.min(35,run.moves/10)),25,tileMode==='hard'?130:tileMode==='normal'?90:60),score=Math.max(1,Math.round(12000-elapsed*12-run.moves*8)),reward=award('tilePuzzle','Tile Puzzle',score,coins,elapsed<(tileMode==='hard'?300:tileMode==='normal'?180:100),{key:'berry',amount:tileMode==='hard'?3:2});
 root.save?.();
 $('tilePuzzleCanvas')?.classList.add('tile-solved');controls('tilePuzzle',false,'NEW PUZZLE');result('tilePuzzle',{title:'PICTURE COMPLETE!',metricLabel:'TIME / MOVES',metricValue:`${elapsed.toFixed(1)}s · ${run.moves}`,...reward,bestText:'MOVING PICTURE RESTORED',onReplay:startTile,onBack:()=>root.LuckyDexArcadeWorld?.backFromGame?.(true)});
}
function setTileMode(m){if(!TILE_MODES[m]||tile?.running)return;tileMode=m;modeButtons('tile',m);if(active==='tilePuzzle'){dispose(tile);prepareTile();}}

function modeButtons(type,mode){document.querySelectorAll(`[data-${type}-mode]`).forEach(b=>b.classList.toggle('active',b.dataset[`${type}Mode`]===mode));}
function open(gameId){
 if(!['berryPicker','headIt','tilePuzzle'].includes(gameId))return false;resetAll();active=gameId;
 ['berryPicker','headIt','tilePuzzle'].forEach(g=>{const n=$(`${g}Game`);if(n)n.hidden=g!==gameId;});document.body.classList.add('arcade-open');root.Android?.setImmersive?.(true);session()?.mount?.(gameId);
 if(gameId==='berryPicker'){modeButtons('berry',berryMode);prepareBerry();}else if(gameId==='headIt'){modeButtons('head',headMode);prepareHead();}else{modeButtons('tile',tileMode);prepareTile();}return true;
}
function close(){resetAll();['berryPicker','headIt','tilePuzzle'].forEach(g=>{const n=$(`${g}Game`);if(n)n.hidden=true;});active=null;document.body?.classList.remove('arcade-open');root.Android?.setImmersive?.(false);return true;}
function activeGame(){return active;}
function install(){
 const stage=$('berryPickerGame')?.querySelector('.berry-picker-stage');if(stage){stage.id='berryPickerStage';const msg=$('berryPickerMessage');if(msg)stage.after(msg);}
 const board=$('tilePuzzleBoard');if(board){const c=document.createElement('canvas');c.id='tilePuzzleCanvas';c.className='tile-puzzle-canvas';c.width=800;c.height=480;c.addEventListener('pointerdown',tileTap);board.replaceWith(c);}
 for(const [type,setter] of [['berry',setBerryMode],['head',setHeadMode],['tile',setTileMode]])document.querySelectorAll(`[data-${type}-mode]`).forEach(b=>b.addEventListener('click',()=>setter(b.dataset[`${type}Mode`])));
 for(const [id,handler] of [['berryPickerStartBtn',startBerry],['berryPickerRestartBtn',startBerry],['headItStartBtn',startHead],['tilePuzzleStartBtn',startTile],['tilePuzzleRestartBtn',startTile]])$(id)?.addEventListener('click',handler);
 root.addEventListener('resize',()=>{if(tile&&!tile.running&&!tile.disposed)renderTileCanvas(tile,performance.now());});
}
const api={BERRIES,BERRY_MODES,HEAD_MODES,FEVER_COMBO,YARN_TYPES,TILE_MODES,swapTiles,isSolvedSwap,tileRect,startBerry,startHead,startTile,setBerryMode,setHeadMode,setTileMode,open,close,activeGame};
root.LuckyDexAmie=api;if(typeof module!=='undefined'&&module.exports)module.exports=api;if(typeof document!=='undefined')install();
})(typeof window!=='undefined'?window:globalThis);

