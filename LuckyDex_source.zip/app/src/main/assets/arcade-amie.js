(function(root){
'use strict';
const BERRIES=[
{id:'razz',name:'Razz',image:'arcade/sprites/items/razz-berry.png'},
{id:'bluk',name:'Bluk',image:'arcade/sprites/items/bluk-berry.png'},
{id:'pinap',name:'Pinap',image:'arcade/sprites/items/pinap-berry.png'},
{id:'wepear',name:'Wepear',image:'arcade/sprites/items/wepear-berry.png'},
{id:'magost',name:'Magost',image:'arcade/sprites/items/magost-berry.png'},
{id:'durin',name:'Durin',image:'arcade/sprites/items/durin-berry.png'},
{id:'nomel',name:'Nomel',image:'arcade/sprites/items/nomel-berry.png'}];
const BERRY_MODES={easy:{durationMs:60000,berries:3,maxCustomers:1,missLimit:null},normal:{durationMs:60000,berries:5,maxCustomers:2,missLimit:null},hard:{durationMs:60000,berries:7,maxCustomers:3,missLimit:null},unlimited:{durationMs:null,berries:5,maxCustomers:3,missLimit:3}};
const BERRY_META={easy:{patience:6500,cap:70,daily:15},normal:{patience:5200,cap:100,daily:25},hard:{patience:4100,cap:140,daily:35},unlimited:{patience:3600,cap:150,daily:45}};
const BERRY_STREAK=15;
const TILE_MODES={easy:{rows:4,cols:5},normal:{rows:5,cols:6},hard:{rows:6,cols:8}};
const TILE_BACKDROPS=[
 'arcade/authentic-v0200/amie/berry-picker-backdrop.png',
 'arcade/authentic-v0200/amie/head-it-backdrop.png',
 'arcade/authentic-v0200/amie/head-it-upper-backdrop.png'
];
const TILE_SCENE_RECIPES=[
 {actors:[[.20,.80],[.50,.72],[.79,.81]],props:[[.08,.73,.07],[.90,.68,.06],[.15,.24,.055],[.82,.30,.05]]},
 {actors:[[.26,.73],[.59,.80],[.82,.67]],props:[[.10,.22,.06],[.91,.25,.055],[.12,.80,.065],[.72,.30,.05]]},
 {actors:[[.18,.67],[.48,.82],[.76,.71]],props:[[.07,.42,.055],[.93,.76,.065],[.28,.22,.05],[.77,.18,.055]]}
];
let active=null,berryMode='easy',tileMode='easy',berry=null,tile=null;
const $=id=>typeof document!=='undefined'?document.getElementById(id):null;

const platform=()=>root.LuckyDexArcadePlatform;
const session=()=>root.LuckyDexArcadeSession;
const clamp=(v,a,b)=>Math.max(a,Math.min(b,v));
const choose=a=>a[Math.floor(Math.random()*a.length)];
const berryObj=id=>BERRIES.find(b=>b.id===id)||BERRIES[0];
const backdrop=name=>`arcade/authentic-v0200/amie/${name}-backdrop.png`;
const imageCache=new Map();
function participants(n){
 const supplied=platform()?.caughtParticipants?.(n,[25,133,175])||[];
 return Array.from({length:n},(_,i)=>{
  const p=supplied[i]||{id:[25,133,175][i%3],name:['Pikachu','Eevee','Togepi'][i%3]};
  return {...p,image:p.image||`arcade/sprites/actors/pokemon/${p.shiny?'shiny/':''}${p.id}.png`};
 });
}
function award(gameId,label,score,coins,dailyEligible=false,dailyReward=null){
 return platform()?.awardRun?.({gameId,label,score,coins,dailyEligible,dailyReward})||{coinsAwarded:coins,itemAwarded:null};
}
function shuffled(n){const a=Array.from({length:n},(_,i)=>i);for(let i=n-1;i>0;i--){const j=Math.floor(Math.random()*(i+1));[a[i],a[j]]=[a[j],a[i]];}return a;}
function swapTiles(board,a,b){if(Array.isArray(board)&&a>=0&&b>=0&&a<board.length&&b<board.length)[board[a],board[b]]=[board[b],board[a]];return board;}
function isSolvedSwap(board){return Array.isArray(board)&&board.every((v,i)=>v===i);}
function tileRect(value,rows,cols){return {row:Math.floor(value/cols),col:value%cols,x:(value%cols)/cols,y:Math.floor(value/cols)/rows,w:1/cols,h:1/rows};}
function runState(extra){return {running:false,finished:false,disposed:false,timeouts:new Set(),raf:null,interval:null,drag:null,...extra};}
function later(run,callback,ms){
 const id=setTimeout(()=>{run.timeouts.delete(id);if(!run.disposed&&run.running)callback();},ms);
 run.timeouts.add(id);return id;
}
function dispose(run){
 if(!run)return;
 run.disposed=true;run.running=false;
 if(run.raf!=null)cancelAnimationFrame(run.raf);
 if(run.interval!=null)clearInterval(run.interval);
 run.timeouts.forEach(clearTimeout);run.timeouts.clear();run.drag?.();
 run.raf=run.interval=null;
}
function resetAll(){dispose(berry);dispose(tile);berry=tile=null;}
function text(id,value){const el=$(id);if(el)el.textContent=value;}
function message(game,value){text(`${game}Message`,value);}
function controls(game,running,label){
 const start=$(`${game}StartBtn`),restart=$(`${game}RestartBtn`);
 if(start){start.hidden=running;start.textContent=label;}
 if(restart)restart.hidden=!running;
 document.querySelectorAll(`[data-${game==='berryPicker'?'berry':'tile'}-mode]`).forEach(b=>b.disabled=running);
}
function result(game,data){
 if(session()?.showResult)session().showResult(game,data);
 else message(game,`${data.title} ${data.metricValue} · ${data.coinsAwarded} coins`);
}

/* Berry Picker: stable requesters and a run-owned pointer gesture. */
function berryNewRequest(c){c.request=choose(BERRIES.slice(0,BERRY_MODES[berryMode].berries)).id;c.expires=performance.now()+BERRY_META[berryMode].patience;c.reaction='';}
function prepareBerry(running=false){
 const cfg=BERRY_MODES[berryMode];
 berry=runState({running,score:0,served:0,combo:0,misses:0,selected:null,ends:cfg.durationMs?performance.now()+cfg.durationMs:null,customers:participants(cfg.maxCustomers).map(p=>({p}))});
 berry.customers.forEach(berryNewRequest);berryScene();renderBerryHud();controls('berryPicker',running,'START PICKER');
 message('berryPicker',running?'Match each requested berry. Drag it to the Pokémon, or tap the berry then the Pokémon.':'Choose a mode, then start. Match the berries your Pokémon request.');
}
function berryScene(){
 const stage=$('berryPickerStage');if(!stage||!berry)return;
 stage.replaceChildren();
 const tree=document.createElement('div');tree.className='amie-berry-tree';tree.dataset.berryCount=BERRY_MODES[berryMode].berries;
 BERRIES.slice(0,BERRY_MODES[berryMode].berries).forEach((b,i)=>{
  const button=document.createElement('button');button.type='button';button.className=`amie-berry berry-pos-${i}`;button.dataset.berryPick=b.id;button.setAttribute('aria-label',`${b.name} Berry`);
  const img=document.createElement('img');img.src=b.image;img.alt='';button.append(img);tree.append(button);
  button.setAttribute('aria-pressed','false');
  // Android WebView supports PointerEvent; only older engines need touch fallback.
  // Register one gesture path so a physical touch cannot start two drags.
  if(root.PointerEvent)button.addEventListener('pointerdown',e=>startBerryDrag(e,b.id));
  else button.addEventListener('touchstart',e=>startBerryTouchDrag(e,b.id),{passive:false});
  button.addEventListener('click',()=>{if(!berry?.running||berry.drag)return;if(berry.suppressClick===button){berry.suppressClick=null;return;}selectBerry(berry,b.id);});
 });
 const customers=document.createElement('div');customers.id='berryCustomers';customers.className='amie-customers';
 berry.customers.forEach((c,i)=>{
  const button=document.createElement('button');button.type='button';button.className='amie-requester';button.dataset.berryCustomer=i;
  const thought=document.createElement('span');thought.className='berry-thought';const request=document.createElement('img');const patience=document.createElement('progress');patience.max=1;thought.append(request,patience);
  const img=document.createElement('img');img.src=c.p.image;img.alt=c.p.name;img.className='amie-pokemon';
  button.append(thought,img);
  const feedSelected=()=>{if(berry?.selected&&!berry.drag)deliverBerry(i,berry.selected);};
  button.addEventListener('click',feedSelected);
  // Some WebViews suppress a compatibility click immediately after a drag.
  // A physical touch release still completes the tap-to-feed fallback.
  if(root.PointerEvent)button.addEventListener('pointerup',e=>{if(e.pointerType==='touch'||e.pointerType==='pen')feedSelected();});
  else button.addEventListener('touchend',feedSelected);
  customers.append(button);
 });
 stage.append(tree,customers);renderBerryCustomers();
}
function renderBerryCustomers(){
 if(!berry)return;const now=performance.now();
 $('berryCustomers')?.querySelectorAll('[data-berry-customer]').forEach((el,i)=>{
  const c=berry.customers[i],b=berryObj(c.request),remaining=berry.running?clamp((c.expires-now)/BERRY_META[berryMode].patience,0,1):1;
  el.className=`amie-requester ${c.reaction||''} ${remaining<.28?'impatient':''}`;
  el.setAttribute('aria-label',`${c.p.name} requests ${b.name} Berry`);
  const img=el.querySelector('.berry-thought img');if(img.getAttribute('src')!==b.image)img.src=b.image;img.alt=b.name;
  el.querySelector('progress').value=remaining;
 });
}
function selectBerry(run,id){
 if(run!==berry||run.disposed)return;run.selected=id;
 $('berryPickerStage')?.querySelectorAll('[data-berry-pick]').forEach(el=>{const selected=el.dataset.berryPick===id;el.classList.toggle('selected',selected);el.setAttribute('aria-pressed',String(selected));});
}
function berryDropTarget(point){
 const hit=document.elementFromPoint(point.clientX,point.clientY)?.closest('[data-berry-customer]');if(hit)return hit;
 // Capture retargets events to the berry; physical release coordinates decide drops.
 return [...($('berryCustomers')?.querySelectorAll('[data-berry-customer]')||[])].find(el=>{const r=el.getBoundingClientRect();return point.clientX>=r.left&&point.clientX<=r.right&&point.clientY>=r.top&&point.clientY<=r.bottom;});
}
function startBerryDrag(ev,id){if(ev.isPrimary===false||ev.button>0)return;startBerryGesture(ev,id,false);}
function startBerryTouchDrag(ev,id){startBerryGesture(ev,id,true);}
function startBerryGesture(ev,id,touch){
 const run=berry,source=ev.currentTarget;if(!run?.running||!source||run.drag)return;
 const first=touch?(ev.changedTouches?.[0]||ev.touches?.[0]):ev;if(!first)return;
 const gestureId=touch?first.identifier:ev.pointerId;run.suppressClick=null;selectBerry(run,id);
 let ghost=null,dragging=false,cleaned=false;
 const locate=list=>{if(!list)return null;for(const t of list)if(t.identifier===gestureId)return t;return null;};
 const point=(e,end=false)=>touch?locate(end?e.changedTouches:e.touches):(e.pointerId===gestureId?e:null);
 const move=e=>{
  const p=point(e);if(!p)return;
  if(!dragging&&Math.hypot(p.clientX-first.clientX,p.clientY-first.clientY)<8)return;
  if(!dragging){dragging=true;ghost=document.createElement('img');ghost.src=berryObj(id).image;ghost.className='berry-drag';ghost.alt='';document.body.append(ghost);}
  if(e.cancelable)e.preventDefault();ghost.style.left=`${p.clientX}px`;ghost.style.top=`${p.clientY}px`;
 };
 const cleanup=()=>{
  if(cleaned)return;cleaned=true;
  if(touch){document.removeEventListener('touchmove',move,true);document.removeEventListener('touchend',up,true);document.removeEventListener('touchcancel',cancel,true);}
  else{document.removeEventListener('pointermove',move,true);document.removeEventListener('pointerup',up,true);document.removeEventListener('pointercancel',cancel,true);source.removeEventListener('lostpointercapture',lost);try{if(source.hasPointerCapture?.(gestureId))source.releasePointerCapture(gestureId);}catch(_){}}
  ghost?.remove();if(run.drag===cleanup)run.drag=null;
 };
 const up=e=>{
  const p=point(e,true);if(!p)return;
  const target=dragging?berryDropTarget(p):null;
  if(dragging){if(e.cancelable)e.preventDefault();run.suppressClick=source;}
  cleanup();if(run.disposed||!run.running)return;if(target)deliverBerry(Number(target.dataset.berryCustomer),id);
 };
 const cancel=e=>{if(point(e,true))cleanup();};
 const lost=e=>{if(e.pointerId===gestureId)cleanup();};
 run.drag=cleanup;
 if(touch){document.addEventListener('touchmove',move,{capture:true,passive:false});document.addEventListener('touchend',up,{capture:true,passive:false});document.addEventListener('touchcancel',cancel,{capture:true,passive:false});}
 else{document.addEventListener('pointermove',move,{capture:true,passive:false});document.addEventListener('pointerup',up,{capture:true,passive:false});document.addEventListener('pointercancel',cancel,true);source.addEventListener('lostpointercapture',lost);try{source.setPointerCapture?.(gestureId);}catch(_){}}
}
function berryMiss(c,wrong=false){
 const run=berry;if(!run?.running||c.reaction)return;run.combo=0;run.misses++;c.reaction=wrong?'wrong':'timeout';
 later(run,()=>{berryNewRequest(c);renderBerryCustomers();},360);
 if(BERRY_MODES[berryMode].missLimit&&run.misses>=BERRY_MODES[berryMode].missLimit)finishBerry();
}
function deliverBerry(index,id){
 const run=berry,c=run?.customers[index];if(!run?.running||!c||c.reaction)return;
 selectBerry(run,null);
 if(c.request!==id){berryMiss(c,true);renderBerryCustomers();renderBerryHud();return;}
 const remaining=clamp((c.expires-performance.now())/BERRY_META[berryMode].patience,0,1);
 run.score+=Math.round(100+remaining*60+Math.min(run.combo,12)*8);run.served++;run.combo++;c.reaction=remaining>.55?'great':'good';root.vibrate?.(12);
 later(run,()=>{berryNewRequest(c);renderBerryCustomers();},250);renderBerryCustomers();renderBerryHud();
}
function renderBerryHud(){
 if(!berry)return;const left=berry.ends==null?null:Math.max(0,berry.ends-performance.now());
 text('berryPickerTimer',left==null?'∞':Math.ceil(left/1000));text('berryPickerScore',berry.score);text('berryPickerCombo',berry.combo);text('berryPickerCorrect',berry.served);
 session()?.update?.('berryPicker',{runText:left==null?`${berry.misses}/3 misses · ${berry.served} served`:`${Math.ceil(left/1000)}s · ${berry.served} served`,liveLabel:'SCORE',liveValue:berry.score});
}
function startBerry(){if(active!=='berryPicker')return;dispose(berry);session()?.hideResult?.();prepareBerry(true);const run=berry;run.interval=setInterval(()=>{if(run.disposed||!run.running)return;const now=performance.now();for(const c of run.customers)if(now>=c.expires&&!c.reaction)berryMiss(c);renderBerryCustomers();renderBerryHud();if(run.ends!=null&&now>=run.ends)finishBerry();},90);}
function finishBerry(){
 if(!berry?.running||berry.finished)return;const run=berry;run.finished=true;dispose(run);
 const best=root.state?.arcade?.bestBerryPicker;
 if(best&&Object.hasOwn(best,berryMode))best[berryMode]=Math.max(Number(best[berryMode])||0,run.score);
 const meta=BERRY_META[berryMode],coins=clamp(Math.round(run.score/24),20,meta.cap),reward=award('berryPicker','Berry Picker',run.score,coins,run.served>=meta.daily,{key:'berry',amount:berryMode==='hard'?4:berryMode==='normal'?3:2});
 root.save?.();
 controls('berryPicker',false,'PLAY AGAIN');result('berryPicker',{title:berryMode==='unlimited'?'THREE MISSES':'TIME!',metricLabel:'BERRIES SERVED',metricValue:`${run.served} · ${run.score} pts`,...reward,bestText:run.combo>=BERRY_STREAK?'HOT STREAK':'',onReplay:startBerry,onBack:()=>root.LuckyDexArcadeWorld?.backFromGame?.(true)});
}
function setBerryMode(m){if(!BERRY_MODES[m]||berry?.running)return;berryMode=m;modeButtons('berry',m);if(active==='berryPicker'){dispose(berry);prepareBerry();}}

/* Tile Puzzle: real source backdrop and aspect-preserving local sprites. */
function loadedImage(url,onload){
 let im=imageCache.get(url);if(!im){im=new Image();imageCache.set(url,im);im.src=url;}
 if(im.complete&&im.naturalWidth)onload?.();else if(onload)im.addEventListener('load',onload,{once:true});return im;
}
function drawCover(ctx,im,w,h){if(!im?.complete||!im.naturalWidth)return;const scale=Math.max(w/im.naturalWidth,h/im.naturalHeight),dw=im.naturalWidth*scale,dh=im.naturalHeight*scale;ctx.drawImage(im,(w-dw)/2,(h-dh)/2,dw,dh);}
function tileSource(ctx,w,h,now,run){
 ctx.clearRect(0,0,w,h);drawCover(ctx,run.backdrop,w,h);
 // Use real local item art as foreground/midground landmarks so the picture is
 // more than three actors floating on an empty backdrop.
 const propPos=run.scene?.props||TILE_SCENE_RECIPES[0].props;
 (run.props||[]).forEach((im,i)=>{if(!im?.complete||!im.naturalWidth)return;const [x,y,scaleW]=propPos[i%propPos.length],dw=w*scaleW,dh=dw*(im.naturalHeight/im.naturalWidth);ctx.globalAlpha=i<2?.96:.78;ctx.drawImage(im,x*w-dw/2,y*h-dh/2,dw,dh);ctx.globalAlpha=1;});
 const pos=run.scene?.actors||TILE_SCENE_RECIPES[0].actors;
 run.ps.forEach((p,i)=>{const im=p.imageNode;if(!im?.complete||!im.naturalWidth)return;const boxW=w*.25,boxH=h*.48,scale=Math.min(boxW/im.naturalWidth,boxH/im.naturalHeight),dw=im.naturalWidth*scale,dh=im.naturalHeight*scale,bob=run.running?Math.sin(now/420+i*1.7)*h*.018:0;ctx.drawImage(im,pos[i][0]*w-dw/2,pos[i][1]*h-dh+bob,dw,dh);});
}
function updateTileTarget(run){const target=$('tilePuzzleTarget');if(!target||!run?.source?.width)return;try{target.src=run.source.toDataURL('image/png');target.alt='Completed puzzle target';text('tilePuzzleTargetName',run.ps.map(p=>p.name).join(' · '));}catch(_){}}

function renderTileCanvas(run,now){
 if(run.disposed||tile!==run)return;const canvas=$('tilePuzzleCanvas');if(!canvas)return;const rect=canvas.getBoundingClientRect(),dpr=Math.min(2,root.devicePixelRatio||1),w=Math.max(1,Math.round(rect.width*dpr)),h=Math.round(w*3/5);
 if(canvas.width!==w||canvas.height!==h){canvas.width=w;canvas.height=h;}run.source.width=w;run.source.height=h;tileSource(run.source.getContext('2d'),w,h,now,run);if(!run.targetReady){updateTileTarget(run);run.targetReady=true;}
 const ctx=canvas.getContext('2d'),{rows,cols}=TILE_MODES[tileMode],cw=w/cols,ch=h/rows;ctx.clearRect(0,0,w,h);
 run.board.forEach((value,index)=>{const r=tileRect(value,rows,cols),x=index%cols*cw,y=Math.floor(index/cols)*ch;ctx.drawImage(run.source,r.x*w,r.y*h,r.w*w,r.h*h,x,y,cw,ch);if(run.running){ctx.strokeStyle=index===run.selected?'#ffe777':'rgba(255,255,255,.6)';ctx.lineWidth=index===run.selected?4:1;ctx.strokeRect(x+.5,y+.5,cw-1,ch-1);}});
 text('tilePuzzleTimer',run.running?((now-run.started)/1000).toFixed(1):run.finished?run.elapsed.toFixed(1):'0.0');text('tilePuzzleMoves',run.moves);
 if(run.running)run.raf=requestAnimationFrame(now=>renderTileCanvas(run,now));
}
function prepareTile(running=false){
 const cfg=TILE_MODES[tileMode],n=cfg.rows*cfg.cols;let board=running?shuffled(n):Array.from({length:n},(_,i)=>i);if(running&&isSolvedSwap(board))swapTiles(board,0,1);
 const sceneIndex=Math.floor(Math.random()*TILE_SCENE_RECIPES.length),scene=TILE_SCENE_RECIPES[sceneIndex],backdropPath=TILE_BACKDROPS[sceneIndex%TILE_BACKDROPS.length];
 const run=tile=runState({running,started:performance.now(),board,selected:null,moves:0,ps:participants(3),source:document.createElement('canvas'),targetReady:false,props:[],scene,backdropPath});
 const repaint=()=>{if(tile===run&&!run.disposed&&!run.running)renderTileCanvas(run,performance.now());};
 run.backdrop=loadedImage(backdropPath,()=>{run.targetReady=false;repaint();});run.ps.forEach(p=>p.imageNode=loadedImage(p.image,()=>{run.targetReady=false;repaint();}));run.props=[BERRIES[0],BERRIES[2],BERRIES[4],BERRIES[5]].map(b=>loadedImage(b.image,()=>{run.targetReady=false;repaint();}));
 const canvas=$('tilePuzzleCanvas');canvas?.setAttribute('aria-label',`${cfg.rows} by ${cfg.cols} moving picture swap puzzle`);canvas?.classList.remove('tile-solved');
 controls('tilePuzzle',running,'START PUZZLE');message('tilePuzzle',running?'Tap two tiles to swap them and restore the moving picture.':'Choose a difficulty, then restore this Pokémon picture by swapping two tiles.');
 if(running)run.raf=requestAnimationFrame(now=>renderTileCanvas(run,now));else renderTileCanvas(run,performance.now());
}
function tileTap(ev){
 if(!tile?.running)return;ev.preventDefault();const c=$('tilePuzzleCanvas'),r=c.getBoundingClientRect(),cfg=TILE_MODES[tileMode];
 const col=clamp(Math.floor((ev.clientX-r.left)/r.width*cfg.cols),0,cfg.cols-1),row=clamp(Math.floor((ev.clientY-r.top)/r.height*cfg.rows),0,cfg.rows-1),idx=row*cfg.cols+col;
 if(tile.selected==null){tile.selected=idx;return;}if(tile.selected===idx){tile.selected=null;return;}swapTiles(tile.board,tile.selected,idx);tile.moves++;tile.selected=null;text('tilePuzzleMoves',tile.moves);if(isSolvedSwap(tile.board))finishTile();
}
function startTile(){if(active!=='tilePuzzle')return;dispose(tile);session()?.hideResult?.();prepareTile(true);session()?.update?.('tilePuzzle',{runText:`${TILE_MODES[tileMode].rows}×${TILE_MODES[tileMode].cols} swap puzzle`,liveLabel:'MOVES',liveValue:0});}
function finishTile(){
 if(!tile?.running||tile.finished)return;const run=tile;run.finished=true;run.elapsed=(performance.now()-run.started)/1000;run.running=false;if(run.raf!=null)cancelAnimationFrame(run.raf);run.raf=null;renderTileCanvas(run,performance.now());
 const best=root.state?.arcade?.bestTilePuzzle;
 if(best&&Object.hasOwn(best,tileMode)){const previous=best[tileMode];if(previous==null||run.elapsed<Number(previous))best[tileMode]=Number(run.elapsed.toFixed(2));}
 const cfg=TILE_MODES[tileMode],elapsed=run.elapsed,coins=clamp(Math.round(cfg.rows*cfg.cols*2.2-Math.min(35,elapsed/6)-Math.min(35,run.moves/10)),25,tileMode==='hard'?130:tileMode==='normal'?90:60),score=Math.max(1,Math.round(12000-elapsed*12-run.moves*8)),reward=award('tilePuzzle','Tile Puzzle',score,coins,elapsed<(tileMode==='hard'?300:tileMode==='normal'?180:100),{key:'berry',amount:tileMode==='hard'?3:2});
 root.save?.();
 $('tilePuzzleCanvas')?.classList.add('tile-solved');controls('tilePuzzle',false,'NEW PUZZLE');result('tilePuzzle',{title:'PICTURE COMPLETE!',metricLabel:'TIME / MOVES',metricValue:`${elapsed.toFixed(1)}s · ${run.moves}`,...reward,bestText:'MOVING PICTURE RESTORED',onReplay:startTile,onBack:()=>root.LuckyDexArcadeWorld?.backFromGame?.(true)});
}
function setTileMode(m){if(!TILE_MODES[m]||tile?.running)return;tileMode=m;modeButtons('tile',m);if(active==='tilePuzzle'){dispose(tile);prepareTile();}}

function modeButtons(type,mode){document.querySelectorAll(`[data-${type}-mode]`).forEach(b=>b.classList.toggle('active',b.dataset[`${type}Mode`]===mode));}
function open(gameId){
 if(!['berryPicker','tilePuzzle'].includes(gameId))return false;resetAll();active=gameId;
 ['berryPicker','tilePuzzle'].forEach(g=>{const n=$(`${g}Game`);if(n)n.hidden=g!==gameId;});document.body.classList.add('arcade-open','arcade-mode');session()?.mount?.(gameId);
 if(gameId==='berryPicker'){modeButtons('berry',berryMode);prepareBerry();}else{modeButtons('tile',tileMode);prepareTile();}return true;
}
function close(){resetAll();['berryPicker','tilePuzzle'].forEach(g=>{const n=$(`${g}Game`);if(n)n.hidden=true;});active=null;document.body?.classList.remove('arcade-open');return true;}
function activeGame(){return active;}
function install(){
 const stage=$('berryPickerGame')?.querySelector('.berry-picker-stage');if(stage){stage.id='berryPickerStage';const msg=$('berryPickerMessage');if(msg)stage.after(msg);}
 const board=$('tilePuzzleBoard');if(board){const c=document.createElement('canvas');c.id='tilePuzzleCanvas';c.className='tile-puzzle-canvas';c.width=800;c.height=480;c.addEventListener('pointerdown',tileTap);board.replaceWith(c);}
 for(const [type,setter] of [['berry',setBerryMode],['tile',setTileMode]])document.querySelectorAll(`[data-${type}-mode]`).forEach(b=>b.addEventListener('click',()=>setter(b.dataset[`${type}Mode`])));
 for(const [id,handler] of [['berryPickerStartBtn',startBerry],['berryPickerRestartBtn',startBerry],['tilePuzzleStartBtn',startTile],['tilePuzzleRestartBtn',startTile]])$(id)?.addEventListener('click',handler);
 root.addEventListener('resize',()=>{if(tile&&!tile.running&&!tile.disposed)renderTileCanvas(tile,performance.now());});
}
const api={BERRIES,BERRY_MODES,TILE_MODES,TILE_BACKDROPS,TILE_SCENE_RECIPES,swapTiles,isSolvedSwap,tileRect,startBerry,startTile,setBerryMode,setTileMode,open,close,activeGame};
root.LuckyDexAmie=api;if(typeof module!=='undefined'&&module.exports)module.exports=api;if(typeof document!=='undefined')install();
})(typeof window!=='undefined'?window:globalThis);

