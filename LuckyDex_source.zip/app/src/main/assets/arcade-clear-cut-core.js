(function(root,factory){
  const api=factory();
  if(typeof module!=='undefined'&&module.exports)module.exports=api;
  root.LuckyDexClearCutCore=api;
})(typeof window!=='undefined'?window:globalThis,function(){
  'use strict';

  const CONFIG=Object.freeze({
    rounds:5,
    maxScore:20,
    minScore:-10,
    perfectErrorPct:1.5,
    earlyPenaltyMultiplier:1.20,
    penaltyPerPct:.70,
    resultHoldMs:1050,
    readyHoldMs:700
  });
  const CUTTERS=Object.freeze([
    Object.freeze({dex:123,name:'Scyther'}),
    Object.freeze({dex:127,name:'Pinsir'}),
    Object.freeze({dex:212,name:'Scizor'})
  ]);
  const CUTTER_BY_DEX=Object.freeze(Object.fromEntries(CUTTERS.map(x=>[x.dex,x])));
  const DIFFICULTIES=Object.freeze({
    easy:Object.freeze({key:'easy',label:'Easy',durationMinMs:3000,durationMaxMs:3600,speedVariation:.045,targetMin:.34,targetMax:.66,cpuErrorMs:130,perfectChance:.015}),
    normal:Object.freeze({key:'normal',label:'Normal',durationMinMs:2350,durationMaxMs:3000,speedVariation:.095,targetMin:.29,targetMax:.71,cpuErrorMs:80,perfectChance:.045}),
    hard:Object.freeze({key:'hard',label:'Hard',durationMinMs:1800,durationMaxMs:2350,speedVariation:.16,targetMin:.24,targetMax:.76,cpuErrorMs:45,perfectChance:.10})
  });
  const REWARDS=Object.freeze({easy:Object.freeze([110,70,45,25]),normal:Object.freeze([140,90,60,35]),hard:Object.freeze([175,115,75,45])});
  const clamp=(n,a,b)=>Math.max(a,Math.min(b,n));
  const rand=rng=>clamp(Number((rng||Math.random)())||0,0,.999999);
  const round3=n=>Math.round(Number(n)*1000)/1000;

  function difficultyProfile(key){return DIFFICULTIES[key]||DIFFICULTIES.normal;}
  function judgementForScore(score){const s=Number(score)||0;return s>=20?'PERFECT':s>=17?'GREAT':s>=12?'GOOD':s>=5?'CLOSE':'MISS';}
  function scoreCut(errorPct){
    const error=Number(errorPct)||0,abs=Math.abs(error);
    let score;
    if(abs<=CONFIG.perfectErrorPct)score=CONFIG.maxScore;
    else{
      const penaltyDistance=abs*(error<0?CONFIG.earlyPenaltyMultiplier:1);
      score=Math.round(CONFIG.maxScore-penaltyDistance*CONFIG.penaltyPerPct);
      score=clamp(score,CONFIG.minScore,CONFIG.maxScore);
    }
    return {score,judgement:judgementForScore(score)};
  }
  function cutterForDex(dex){return CUTTER_BY_DEX[Number(dex)]||CUTTERS[0];}
  function createRacer(id,index,species){return {id,index,label:id==='player'?'YOU':`COM ${index}`,species:{...species},total:0,perfects:0,totalAbsError:0,closestCutPct:null,roundScores:[],roundResults:[]};}
  function generateLog({difficulty='normal',roundIndex=0,rng=Math.random,startAt=0}={}){
    const profile=difficultyProfile(difficulty),round=Math.max(0,Math.min(CONFIG.rounds-1,Math.trunc(Number(roundIndex)||0)));
    const base=profile.durationMinMs+rand(rng)*(profile.durationMaxMs-profile.durationMinMs);
    const durationMs=Math.max(profile.durationMinMs*.82,base*(1-round*.035));
    const targetPct=profile.targetMin+rand(rng)*(profile.targetMax-profile.targetMin);
    const curve=(rand(rng)*2-1)*profile.speedVariation;
    const idealU=clamp(.50+(targetPct-.5)*.44,.34,.66);
    const startedAt=Number(startAt)||0;
    const log={roundIndex:round,difficulty:profile.key,targetPct:round3(targetPct),durationMs:round3(durationMs),curve:round3(curve),idealU:round3(idealU),startedAt,idealTimeMs:startedAt+durationMs*idealU,endsAt:startedAt+durationMs};
    return log;
  }
  function retimeLog(log,startAt){
    const start=Number(startAt)||0;log.startedAt=start;log.idealTimeMs=start+log.durationMs*log.idealU;log.endsAt=start+log.durationMs;return log;
  }
  function motionProgress(log,at){
    const d=Math.max(1,Number(log?.durationMs)||1),u=clamp(((Number(at)||0)-Number(log?.startedAt||0))/d,0,1),curve=Number(log?.curve)||0;
    return clamp(u+curve*Math.sin(Math.PI*u),0,1);
  }
  function cutErrorPctAtTime(log,at){
    const idealProgress=motionProgress(log,log.idealTimeMs),actual=motionProgress(log,at);
    return round3((actual-idealProgress)*100);
  }
  function simulateCpuCut(log,difficulty='normal',rng=Math.random){
    const profile=difficultyProfile(difficulty);
    let offset;
    if(rand(rng)<profile.perfectChance)offset=0;
    else{
      const centred=((rand(rng)+rand(rng))/2-.5)*2;
      offset=centred*profile.cpuErrorMs*1.65;
    }
    const cutAt=Number(log.idealTimeMs)+offset,errorPct=cutErrorPctAtTime(log,cutAt),scored=scoreCut(errorPct);
    return {cutAt,errorPct,...scored};
  }
  function createMatch({difficulty='normal',playerDex=123,rng=Math.random,nowMs=0}={}){
    const profile=difficultyProfile(difficulty),playerSpecies=cutterForDex(playerDex),racers=[createRacer('player',0,playerSpecies)];
    for(let i=1;i<4;i++)racers.push(createRacer(`cpu${i}`,i,CUTTERS[Math.floor(rand(rng)*CUTTERS.length)]));
    const logs=[];for(let i=0;i<CONFIG.rounds;i++)logs.push(generateLog({difficulty:profile.key,roundIndex:i,rng,startAt:nowMs}));
    return {difficulty:profile.key,playerDex:playerSpecies.dex,racers,player:racers[0],logs,rounds:new Array(CONFIG.rounds).fill(null),currentRoundIndex:-1,activeRound:null,finalized:false,ranking:null};
  }
  function startRound(match,index,nowMs=0){
    if(!match||match.finalized)return null;const i=clamp(Math.trunc(Number(index)||0),0,CONFIG.rounds-1),log=retimeLog(match.logs[i],nowMs);
    const round={index:i,log,resolved:false,playerResult:null,cpuResults:[],resolvedAt:null};match.rounds[i]=round;match.activeRound=round;match.currentRoundIndex=i;return round;
  }
  function applyResult(racer,result){
    racer.total+=Number(result.score)||0;racer.perfects+=result.score===CONFIG.maxScore?1:0;racer.totalAbsError+=Math.abs(Number(result.errorPct)||0);racer.closestCutPct=racer.closestCutPct==null?Math.abs(Number(result.errorPct)||0):Math.min(racer.closestCutPct,Math.abs(Number(result.errorPct)||0));racer.roundScores.push(Number(result.score)||0);racer.roundResults.push({...result});
  }
  function resolveCpuCuts(match,round,rng){
    if(round.cpuResults.length)return round.cpuResults;
    for(let i=1;i<match.racers.length;i++){const result=simulateCpuCut(round.log,match.difficulty,rng);round.cpuResults.push(result);applyResult(match.racers[i],result);}return round.cpuResults;
  }
  function cutPlayer(match,at,rng=Math.random){
    const round=match?.activeRound;if(!round)return {accepted:false,reason:'inactive'};if(round.resolved)return {accepted:false,reason:'already-cut'};
    const errorPct=cutErrorPctAtTime(round.log,at),scored=scoreCut(errorPct),result={cutAt:Number(at)||0,errorPct,...scored};
    round.playerResult=result;round.resolved=true;round.resolvedAt=Number(at)||0;applyResult(match.player,result);resolveCpuCuts(match,round,rng);
    if(round.index>=CONFIG.rounds-1){match.finalized=true;match.ranking=rankMatch(match);}return {accepted:true,result,cpuResults:round.cpuResults,round};
  }
  function autoMissIfNeeded(match,at,rng=Math.random){
    const round=match?.activeRound;if(!round||round.resolved||Number(at)<round.log.endsAt)return null;return cutPlayer(match,round.log.endsAt,rng);
  }
  function rankMatch(match){return (match?.racers||[]).slice().sort((a,b)=>Number(b.total)-Number(a.total)||Number(b.perfects)-Number(a.perfects)||Number(a.totalAbsError)-Number(b.totalAbsError)||a.index-b.index);}
  function placeFor(match,id='player'){const i=rankMatch(match).findIndex(r=>r.id===id);return i<0?4:i+1;}
  function rewardFor(place,difficulty='normal'){const row=REWARDS[difficulty]||REWARDS.normal,idx=clamp(Math.trunc(Number(place)||1)-1,0,3);return row[idx];}
  function shiftActiveRound(match,deltaMs){
    const round=match?.activeRound,delta=Number(deltaMs)||0;if(!round||!delta)return round;round.log.startedAt+=delta;round.log.idealTimeMs+=delta;round.log.endsAt+=delta;if(round.resolvedAt!=null)round.resolvedAt+=delta;if(round.playerResult?.cutAt!=null)round.playerResult.cutAt+=delta;for(const r of round.cpuResults||[])if(r.cutAt!=null)r.cutAt+=delta;return round;
  }

  return {CONFIG,CUTTERS,DIFFICULTIES,REWARDS,difficultyProfile,judgementForScore,scoreCut,generateLog,motionProgress,cutErrorPctAtTime,simulateCpuCut,createMatch,startRound,cutPlayer,autoMissIfNeeded,rankMatch,placeFor,rewardFor,shiftActiveRound};
});
