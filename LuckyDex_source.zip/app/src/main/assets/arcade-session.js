(function(root){
  'use strict';

  const GAME_RULES={
    berryPicker:{run:'60 seconds · Unlimited ends after 3 misses',reward:'Up to 150 coins · Daily item'},
    tilePuzzle:{run:'Swap the moving picture back together',reward:'Up to 130 coins · Daily item'},
    voltorb:{run:'Clear every ×2 and ×3 tile without hitting Voltorb',reward:'Lucky Coins awarded on a cleared board'},
    ballDrop:{run:'Ball 1 / 3',reward:'Coins · Cards · Sealed boosters · Mystery jackpot'},
    berry:{run:'Blend until the timer ends',reward:'Performance-based Lucky Coins'},
    clefairy:{run:'Watch the sequence, then repeat star / song / moon / spin',reward:'Banked Lucky Coins'},
    fossil:{run:'Excavate finds before wall stability reaches zero',reward:'Recovered finds · Museum exhibits · Cards · Lucky Coins'},
    unown:{run:'Decode 5 messages',reward:'Performance-based Lucky Coins'},
    quiz:{run:'Answer the quiz · Endless ends on failure',reward:'Performance-based Lucky Coins'},
    dash:{run:'Quick Race or 3-race Type League · Sprint and choose clean racing lines',reward:'Difficulty-scaled Quick Race coins · 3× League cup rewards'},
    ekansHoop:{run:'50–75 seconds · Choose difficulty · Solo hoop score attack',reward:'Score tiers · Lucky Coins'},
    digDigDig:{run:'80-dig race · 4 Sandshrew · Alternate LEFT and RIGHT',reward:'Placement-based Lucky Coins'},
    magikarpSplash:{run:'20 seconds · Hold for height · Time the landing rebound',reward:'Placement-based Lucky Coins'},
    rockHarden:{run:'Time Harden against falling rocks · Preserve HP while Harden drains it',reward:'Placement-based Lucky Coins · Rare Gold Rock prizes'}
  };
  let activeGame=null;
  let replayAction=null;
  let backAction=null;
  let changeAction=null;
  let showing=false;
  let currentResult=null;
  let revealIndex=0;

  function el(id){return typeof document!=='undefined'?document.getElementById(id):null;}
  function titleItem(key){return String(key||'item').replace(/[-_]/g,' ').replace(/\b\w/g,c=>c.toUpperCase());}
  function ruleFor(gameId){return GAME_RULES[gameId]||{run:'Complete the run',reward:'Lucky Coins'};}
  function sanitizeCardReveal(row){
    if(!row||typeof row!=='object'||!String(row.name||'').trim())return null;
    return {id:String(row.id||''),name:String(row.name||'Card').trim(),image:String(row.image||''),setName:String(row.setName||row.set||''),rarity:String(row.rarity||'')};
  }
  function resultModel({title='GAME COMPLETE',metricLabel='SCORE',metricValue='',coinsAwarded=0,itemAwarded=null,bestText='',details=[],cardReveals=[]}={}){
    const coins=Math.max(0,Math.round(Number(coinsAwarded)||0));
    const amount=Math.max(0,Math.round(Number(itemAwarded?.amount)||0));
    const safeDetails=(Array.isArray(details)?details:[]).filter(row=>row&&typeof row==='object'&&String(row.title||'').trim()).slice(0,16).map(row=>({title:String(row.title).trim(),subtitle:String(row.subtitle||''),kind:String(row.kind||'find')}));
    const safeCards=(Array.isArray(cardReveals)?cardReveals:[]).map(sanitizeCardReveal).filter(Boolean).slice(0,24);
    return {
      title:String(title||'GAME COMPLETE'),
      metricLabel:String(metricLabel||'SCORE'),
      metricValue:String(metricValue??''),
      coinsAwarded:coins,
      coinsText:`+${coins} Lucky Coins`,
      itemAwarded:itemAwarded&&amount>0?{key:String(itemAwarded.key||'item'),amount}:null,
      itemText:itemAwarded&&amount>0?`+${amount} ${titleItem(itemAwarded.key)}`:'',
      bestText:String(bestText||''),
      details:safeDetails,
      cardReveals:safeCards
    };
  }
  function createCompletionGuard(){
    let complete=false;
    return function completeOnce(fn){
      if(complete)return false;
      complete=true;
      if(typeof fn==='function')fn();
      return true;
    };
  }
  function ensureStrip(gameId,host){
    if(typeof document==='undefined')return null;
    const game=host||el(`${gameId}Game`);
    if(!game)return null;
    let strip=game.querySelector('.arcade-session-strip');
    if(!strip){
      strip=document.createElement('div');strip.className='arcade-session-strip';strip.dataset.sessionGame=gameId;
      strip.innerHTML='<span><small>RUN</small><b data-session-run></b></span><span><small>REWARD</small><b data-session-reward></b></span><span data-session-live-wrap hidden><small data-session-live-label>LIVE</small><b data-session-live></b></span>';
      const head=game.querySelector('.arcade-full-head');
      if(head?.nextSibling)game.insertBefore(strip,head.nextSibling);else game.prepend(strip);
    }
    return strip;
  }
  function mount(gameId,host){
    activeGame=gameId;
    return ruleFor(gameId);
  }
  function update(gameId,{runText,rewardText,liveLabel,liveValue}={}){
    const strip=el(`${gameId}Game`)?.querySelector('.arcade-session-strip');if(!strip)return false;
    if(runText!==undefined)strip.querySelector('[data-session-run]').textContent=String(runText);
    if(rewardText!==undefined)strip.querySelector('[data-session-reward]').textContent=String(rewardText);
    const live=strip.querySelector('[data-session-live-wrap]');
    if(liveValue!==undefined){live.hidden=false;strip.querySelector('[data-session-live]').textContent=String(liveValue);strip.querySelector('[data-session-live-label]').textContent=String(liveLabel||'LIVE');}
    return true;
  }
  function renderReveal(index=0){
    if(!currentResult?.cardReveals?.length)return false;
    revealIndex=Math.max(0,Math.min(currentResult.cardReveals.length-1,Number(index)||0));
    const card=currentResult.cardReveals[revealIndex],count=currentResult.cardReveals.length;
    const image=el('arcadeResultRevealImage');if(image){image.src=card.image||'';image.alt=card.name;image.hidden=!card.image;}
    const fallback=el('arcadeResultRevealFallback');if(fallback){fallback.hidden=!!card.image;fallback.textContent=card.name;}
    if(el('arcadeResultRevealName'))el('arcadeResultRevealName').textContent=card.name;
    if(el('arcadeResultRevealMeta'))el('arcadeResultRevealMeta').textContent=[card.setName,card.rarity].filter(Boolean).join(' · ');
    if(el('arcadeResultRevealCount'))el('arcadeResultRevealCount').textContent=`${revealIndex+1} / ${count}`;
    const next=el('arcadeResultRevealNext');if(next)next.textContent=revealIndex===count-1?'VIEW RESULTS':'NEXT CARD';
    const stage=el('arcadeResultCardReveal');if(stage){stage.classList.remove('reveal-pop');void stage.offsetWidth;stage.classList.add('reveal-pop');}
    return card;
  }
  function showSummary(){
    const reveal=el('arcadeResultCardReveal'),summary=el('arcadeResultSummary');if(reveal)reveal.hidden=true;if(summary)summary.hidden=false;return true;
  }
  function advanceReveal(){
    if(!currentResult?.cardReveals?.length)return showSummary();
    if(revealIndex<currentResult.cardReveals.length-1)return renderReveal(revealIndex+1);
    return showSummary();
  }
  function hideResult(){
    const sheet=el('arcadeResultSheet');if(sheet)sheet.hidden=true;
    const reveal=el('arcadeResultCardReveal'),summary=el('arcadeResultSummary');if(reveal)reveal.hidden=true;if(summary)summary.hidden=false;
    showing=false;replayAction=null;backAction=null;changeAction=null;currentResult=null;revealIndex=0;
  }
  function showResult(gameId,opts={}){
    if(showing)return false;
    const model=resultModel(opts);activeGame=gameId;showing=true;currentResult=model;revealIndex=0;
    if(typeof document==='undefined')return model;
    const sheet=el('arcadeResultSheet');if(!sheet){showing=false;currentResult=null;return false;}
    el('arcadeResultTitle').textContent=model.title;
    el('arcadeResultMetricLabel').textContent=model.metricLabel;
    el('arcadeResultMetricValue').textContent=model.metricValue;
    el('arcadeResultCoins').textContent=model.coinsText;
    const item=el('arcadeResultItem');item.textContent=model.itemText;item.hidden=!model.itemText;
    const best=el('arcadeResultBest');best.textContent=model.bestText;best.hidden=!model.bestText;
    const details=el('arcadeResultDetails');
    if(details){
      details.replaceChildren();
      for(const row of model.details){
        const itemRow=document.createElement('div');itemRow.className=`arcade-result-detail arcade-result-detail-${row.kind}`;
        const strong=document.createElement('b');strong.textContent=row.title;itemRow.appendChild(strong);
        if(row.subtitle){const span=document.createElement('span');span.textContent=row.subtitle;itemRow.appendChild(span);}
        details.appendChild(itemRow);
      }
      details.hidden=model.details.length===0;
    }
    const replay=el('arcadeResultReplay');replay.textContent=opts.replayLabel||'PLAY AGAIN';
    const change=el('arcadeResultChange');if(change){change.textContent=opts.changeLabel||'CHANGE';change.hidden=typeof opts.onChange!=='function';}
    const venueName=root.LuckyDexArcadeWorld?.venueForGame?.(gameId);const venue=root.LuckyDexArcadeWorld?.VENUES?.find?.(v=>v.id===venueName);
    el('arcadeResultBack').textContent=`BACK TO ${String(venue?.name||'VENUE').toUpperCase()}`;
    replayAction=typeof opts.onReplay==='function'?opts.onReplay:null;
    backAction=typeof opts.onBack==='function'?opts.onBack:null;
    changeAction=typeof opts.onChange==='function'?opts.onChange:null;
    const reveal=el('arcadeResultCardReveal'),summary=el('arcadeResultSummary');
    if(model.cardReveals.length){if(summary)summary.hidden=true;if(reveal)reveal.hidden=false;renderReveal(0);}else{if(reveal)reveal.hidden=true;if(summary)summary.hidden=false;}
    sheet.hidden=false;
    return model;
  }
  function wire(){
    el('arcadeResultRevealNext')?.addEventListener('click',advanceReveal);
    el('arcadeResultReplay')?.addEventListener('click',()=>{const fn=replayAction;hideResult();fn?.();});
    el('arcadeResultChange')?.addEventListener('click',()=>{const fn=changeAction;hideResult();fn?.();});
    el('arcadeResultBack')?.addEventListener('click',()=>{const fn=backAction;hideResult();if(fn)fn();else root.LuckyDexArcadeWorld?.backFromGame?.(true);});
  }

  const api={GAME_RULES,ruleFor,resultModel,createCompletionGuard,mount,update,showResult,hideResult,advanceReveal,isShowing:()=>showing,activeGame:()=>activeGame};
  root.LuckyDexArcadeSession=api;
  if(typeof module!=='undefined'&&module.exports)module.exports=api;
  if(typeof document!=='undefined')wire();
})(typeof window!=='undefined'?window:globalThis);
