(function(root,factory){const api=factory();if(typeof module==='object'&&module.exports){module.exports=api;return;}root.LuckyDexPikachuBeachDxContent=api;})(typeof window!=='undefined'?window:globalThis,function(){
'use strict';
const DIFFICULTIES=Object.freeze({
 easy:Object.freeze({key:'easy',label:'Easy',enemyIntervalMs:1900,damageMultiplier:.72,enemyHpMultiplier:.8,forwardMultiplier:.96,scoreMultiplier:1}),
 normal:Object.freeze({key:'normal',label:'Normal',enemyIntervalMs:1400,damageMultiplier:1,enemyHpMultiplier:1,forwardMultiplier:1,scoreMultiplier:1.2}),
 hard:Object.freeze({key:'hard',label:'Hard',enemyIntervalMs:950,damageMultiplier:1.35,enemyHpMultiplier:1.28,forwardMultiplier:1.04,scoreMultiplier:1.45})
});
const DISTANCES=Object.freeze({
 short:Object.freeze({key:'short',label:'5 KM',target:60}),
 standard:Object.freeze({key:'standard',label:'10 KM',target:105}),
 long:Object.freeze({key:'long',label:'20 KM',target:165})
});
const ENEMIES=Object.freeze({
 wingull:{id:'wingull',name:'Wingull',sprite:'s_wingull',hp:1,damage:8,score:90,speed:.15,radius:.045},
 sharpedo:{id:'sharpedo',name:'Sharpedo',sprite:'s_sharpedo',hp:3,damage:15,score:180,speed:.25,radius:.065},
 pelipper:{id:'pelipper',name:'Pelipper',sprite:'s_pelipper1',hp:3,damage:12,score:170,speed:.12,radius:.06},
 qwilfish:{id:'qwilfish',name:'Qwilfish',sprite:'s_qwilfish',hp:2,damage:12,score:130,speed:.13,radius:.05},
 starmie:{id:'starmie',name:'Starmie',sprite:'s_starmie',hp:3,damage:13,score:190,speed:.11,radius:.055},
 toxapex:{id:'toxapex',name:'Toxapex',sprite:'s_toxapex',hp:4,damage:16,score:230,speed:.08,radius:.065},
 octillery:{id:'octillery',name:'Octillery',sprite:'s_octillery',hp:3,damage:13,score:190,speed:.1,radius:.055},
 drifloon:{id:'drifloon',name:'Drifloon',sprite:'s_drifloon',hp:2,damage:10,score:140,speed:.1,radius:.05},
 voltorb:{id:'voltorb',name:'Voltorb',sprite:'s_voltorb',hp:1,damage:20,score:120,speed:.2,radius:.045},
 tentacruel:{id:'tentacruel',name:'Tentacruel',sprite:'s_tentacruel_idle',hp:6,damage:18,score:350,speed:.07,radius:.09}
});
const ALLIES=Object.freeze({
 seaking:Object.freeze({id:'seaking',name:'Seaking',sprite:'s_seaking1',spawnAt:.20,effect:'ringSweep'}),
 lapras:Object.freeze({id:'lapras',name:'Lapras',sprite:'s_lapras',spawnAt:.45,effect:'shield'}),
 natu:Object.freeze({id:'natu',name:'Natu',sprite:'s_natu1',spawnAt:.70,effect:'assistFire'})
});
const PICKUPS=Object.freeze({hpUp:Object.freeze({id:'hpUp',name:'HP Up',sprite:'s_hpUp',heal:35,radius:.055})});
const BOSSES=Object.freeze([
 Object.freeze({id:'articuno',name:'Articuno',sprite:'s_articuno_0',attackSprite:'s_icebeam2',spawnAt:.16,hp:70,attackEveryMs:1500,damage:12,score:1800,pattern:'iceBeam'}),
 Object.freeze({id:'zapdos',name:'Zapdos',sprite:'s_zapdos_0',attackSprite:'s_lightning',spawnAt:.33,hp:82,attackEveryMs:1350,damage:14,score:2200,pattern:'lightning'}),
 Object.freeze({id:'moltres',name:'Moltres',sprite:'s_moltress_0',attackSprite:'s_fire',spawnAt:.50,hp:94,attackEveryMs:1250,damage:15,score:2600,pattern:'fire'}),
 Object.freeze({id:'lugia',name:'Lugia',sprite:'s_lugia_idle',attackSprite:'s_aeroblast',spawnAt:.68,hp:115,attackEveryMs:1150,damage:17,score:3300,pattern:'aeroblast'}),
 Object.freeze({id:'wailord',name:'Wailord',sprite:'s_wailord_idle',attackSprite:'s_hydropump',spawnAt:.86,hp:145,attackEveryMs:1000,damage:19,score:4200,pattern:'waterSpout'})
]);
return Object.freeze({DIFFICULTIES,DISTANCES,ENEMIES,ALLIES,PICKUPS,BOSSES});
});
