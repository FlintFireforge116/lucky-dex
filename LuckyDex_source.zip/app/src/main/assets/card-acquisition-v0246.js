/* LuckyDex v0.24.6 card acquisition routing.
   Acquisition is decided per card so promo/trophy cards cannot leak out of
   generically named catalogue sets such as Miscellaneous. */
(function(root,factory){
  const api=factory();
  if(typeof module==='object'&&module.exports)module.exports=api;
  else root.LuckyDexCardAcquisition=api;
})(typeof window==='object'?window:globalThis,function(){
  'use strict';

  const ACHIEVEMENT_SET_NAME='Achievement Rewards';
  const ACHIEVEMENT_SET_KEY='achievement-rewards';

  function norm(value=''){
    return String(value||'').toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g,'').replace(/pok[eé]mon/g,'pokemon').replace(/[^a-z0-9]+/g,' ').trim();
  }
  function resolvedSet(card,set){
    if(set)return set;
    if(card?.set&&typeof card.set==='object')return card.set;
    return {id:card?.setId||'',name:card?.setName||card?.set||''};
  }
  function isExplicitAchievementCard(card,set=null){
    const s=resolvedSet(card,set),name=norm(card?.name),setName=norm(s?.name||card?.setName),setId=norm(s?.id||card?.setId);
    if(name==='ancient mew')return true;
    if(name==='victory medal'&&(setName==='victory medals'||setId.includes('victory medal')))return true;
    return !!card?._achievementReward;
  }
  function isDedicatedPromoSet(set){
    const name=norm(set?.name),id=norm(set?.id),series=norm(set?.series||set?._librarySeries);
    return /\bpromos?\b/.test(name)||/\bpromos?\b/.test(id)||series==='promos'||series==='promo';
  }
  function isSpecialOneOffSet(set){
    const name=norm(set?.name),id=norm(set?.id);
    if(name==='miscellaneous'||id==='miscellaneous'||id==='misc')return true;
    if(name==='victory medals'||id==='victory medals'||id.startsWith('victory medal '))return true;
    if(/\bcard creator pack\b/.test(name)||/\bcard creator pack\b/.test(id))return true;
    if(name==='world collection'||name.startsWith('world collection ')||id==='world collection'||id.startsWith('world collection '))return true;
    return false;
  }
  function isPromoCard(card,set=null){
    const s=resolvedSet(card,set),rarity=norm(card?.rarity),kind=norm(card?.supertype||card?.category||card?.type);
    if(card?._promo===true||card?._promoOnly===true)return true;
    if(/\bpromo\b/.test(rarity)||/\bpromo\b/.test(kind))return true;
    return isDedicatedPromoSet(s)||isSpecialOneOffSet(s);
  }
  function classify(card,set=null){
    if(isExplicitAchievementCard(card,set))return 'achievement_reward';
    if(isPromoCard(card,set))return 'promo_vault';
    return 'booster';
  }
  function boosterEligible(card,set=null){return classify(card,set)==='booster';}
  function promoVaultEligible(card,set=null){return classify(card,set)==='promo_vault';}
  function achievementEligible(card,set=null){return classify(card,set)==='achievement_reward';}
  function setMayContainPromoCards(set){
    const name=norm(set?.name),id=norm(set?.id);
    return isDedicatedPromoSet(set)||isSpecialOneOffSet(set);
  }
  function setBoosterCatalogEligible(set){
    const name=norm(set?.name),id=norm(set?.id);
    if(isDedicatedPromoSet(set)||isSpecialOneOffSet(set))return false;
    return true;
  }
  function displaySetName(card){
    if(achievementEligible(card))return ACHIEVEMENT_SET_NAME;
    return card?.set?.name||card?.setName||card?.set||card?.setId||'Unknown set';
  }
  function displaySetKey(card){
    if(achievementEligible(card))return ACHIEVEMENT_SET_KEY;
    return card?.set?.id||card?.setId||card?.setName||card?.set||'Unknown set';
  }

  return Object.freeze({
    ACHIEVEMENT_SET_NAME,ACHIEVEMENT_SET_KEY,norm,classify,boosterEligible,promoVaultEligible,achievementEligible,
    isPromoCard,isDedicatedPromoSet,isSpecialOneOffSet,setMayContainPromoCards,setBoosterCatalogEligible,displaySetName,displaySetKey
  });
});
