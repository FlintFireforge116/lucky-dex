(function(root,factory){
  const api=factory();
  if(typeof module==='object'&&module.exports){module.exports=api;return;}
  root.LuckyDexFurretFrolicCore=api;
})(typeof window!=='undefined'?window:globalThis,function(){
  'use strict';

  const CONFIG=Object.freeze({
    width:720,height:720,durationMs:60000,goalDepth:74,goalHalfWidth:150,
    playerRadius:30,lungeRadius:132,returnSpeed:640,playerMoveSpeed:760,
    hitRadius:76,hitSpeed:640,bodyPushSpeed:135,hitCooldownMs:250,
    ballFriction:1.45,wallBounce:.82,spawnStartMs:700,spawnBaseMs:2100,spawnFastMs:1180,maxBalls:8,
    greatUnlockMs:15000,ultraUnlockMs:30000,masterUnlockMs:42000
  });

  const BALL_TYPES=Object.freeze({
    poke:Object.freeze({key:'poke',label:'Poké Ball',value:1,radius:18,weight:1}),
    great:Object.freeze({key:'great',label:'Great Ball',value:2,radius:23,weight:.74}),
    ultra:Object.freeze({key:'ultra',label:'Ultra Ball',value:3,radius:29,weight:.48}),
    master:Object.freeze({key:'master',label:'Master Ball',value:5,radius:36,weight:.22})
  });

  const DIFFICULTIES=Object.freeze({
    easy:Object.freeze({label:'Easy',reactionMs:430,hitAccuracy:.63,moveSpeed:.72,targetNoise:72,decisionJitter:180}),
    normal:Object.freeze({label:'Normal',reactionMs:235,hitAccuracy:.82,moveSpeed:.88,targetNoise:40,decisionJitter:90}),
    hard:Object.freeze({label:'Hard',reactionMs:110,hitAccuracy:.96,moveSpeed:1,targetNoise:16,decisionJitter:35})
  });

  const PLAYER_META=Object.freeze([
    Object.freeze({goal:'south',label:'YOU',colour:'blue',home:[360,430],goalVector:[0,1]}),
    Object.freeze({goal:'west',label:'COM 1',colour:'green',home:[290,360],goalVector:[-1,0]}),
    Object.freeze({goal:'north',label:'COM 2',colour:'red',home:[360,290],goalVector:[0,-1]}),
    Object.freeze({goal:'east',label:'COM 3',colour:'gold',home:[430,360],goalVector:[1,0]})
  ]);

  const clamp=(v,a,b)=>Math.max(a,Math.min(b,Number(v)||0));
  const r01=rng=>clamp(typeof rng==='function'?rng():Math.random(),0,.999999);
  const difficultyProfile=key=>DIFFICULTIES[key]||DIFFICULTIES.normal;
  const sq=v=>v*v;
  const distance=(a,b)=>Math.sqrt(sq((a?.x||0)-(b?.x||0))+sq((a?.y||0)-(b?.y||0)));
  const norm=(x,y)=>{const d=Math.hypot(x,y)||1;return [x/d,y/d];};
  const directionVector=input=>{
    const x=(input?.right?1:0)-(input?.left?1:0),y=(input?.down?1:0)-(input?.up?1:0);
    if(!x&&!y)return [0,0];return norm(x,y);
  };

  function availableBallKinds(elapsedMs){
    const t=Math.max(0,Number(elapsedMs)||0),out=['poke'];
    if(t>=CONFIG.greatUnlockMs)out.push('great');
    if(t>=CONFIG.ultraUnlockMs)out.push('ultra');
    if(t>=CONFIG.masterUnlockMs)out.push('master');
    return out;
  }

  function pickBallKind(run){
    const kinds=availableBallKinds(run.elapsedMs);
    if(kinds.includes('master')&&r01(run.rng)<clamp(run.masterBallRate,0,1))return 'master';
    const weighted=kinds.filter(k=>k!=='master').map(k=>({k,w:BALL_TYPES[k].weight}));
    let total=weighted.reduce((s,v)=>s+v.w,0),roll=r01(run.rng)*total;
    for(const row of weighted){if((roll-=row.w)<=0)return row.k;}
    return weighted[weighted.length-1]?.k||'poke';
  }

  function makePlayer(index,dex=162){
    const meta=PLAYER_META[index],isPlayer=index===0;
    return {index,isPlayer,label:meta.label,goal:meta.goal,colour:meta.colour,dex:Number(dex)||162,species:Number(dex)===203?'Girafarig':'Furret',
      homeX:meta.home[0],homeY:meta.home[1],x:meta.home[0],y:meta.home[1],vx:0,vy:0,heldDirection:null,score:0,ballsScored:0,
      pokeBalls:0,greatBalls:0,ultraBalls:0,masterBalls:0,hits:0,hitCooldownMs:0,hitFlashMs:0,aiThinkMs:0,aiTargetId:null,place:index+1};
  }

  function createMatch({difficulty='normal',rng=Math.random,masterBallRate=.08,playerDex=162}={}){
    const key=DIFFICULTIES[difficulty]?difficulty:'normal';
    const playerSpecies=Number(playerDex)===203?203:162;
    const run={difficulty:key,profile:difficultyProfile(key),rng,masterBallRate:clamp(masterBallRate,0,1),elapsedMs:0,remainingMs:CONFIG.durationMs,
      finished:false,players:[makePlayer(0,playerSpecies),makePlayer(1,162),makePlayer(2,162),makePlayer(3,162)],balls:[],events:[],ranking:[],spawnInMs:CONFIG.spawnStartMs,nextBallId:1,masterBallsSeen:0};
    return run;
  }

  function spawnBall(run,{force=false}={}){
    if(!run||run.finished)return null;
    if(!force&&run.balls.filter(b=>!b.scored).length>=CONFIG.maxBalls)return null;
    const kind=pickBallKind(run),type=BALL_TYPES[kind];
    const angle=r01(run.rng)*Math.PI*2,rad=25+r01(run.rng)*110;
    const ball={id:`ball-${run.nextBallId++}`,kind,value:type.value,radius:type.radius,x:CONFIG.width/2+Math.cos(angle)*rad,y:CONFIG.height/2+Math.sin(angle)*rad,
      vx:(r01(run.rng)-.5)*90,vy:(r01(run.rng)-.5)*90,scored:false,lastHitBy:null};
    run.balls.push(ball);if(kind==='master'){run.masterBallsSeen++;run.events.push({type:'master-spawn',ballId:ball.id,at:run.elapsedMs});}
    return ball;
  }

  function applyPlayerMotion(run,p,dt,input){
    const ms=Math.max(0,Number(dt)||0),sec=ms/1000,profile=run.profile;
    p.hitCooldownMs=Math.max(0,p.hitCooldownMs-ms);p.hitFlashMs=Math.max(0,p.hitFlashMs-ms);
    const [dx,dy]=directionVector(input);
    if(dx||dy){
      p.heldDirection={x:dx,y:dy};
      const tx=p.homeX+dx*CONFIG.lungeRadius,ty=p.homeY+dy*CONFIG.lungeRadius,speed=(p.isPlayer?CONFIG.playerMoveSpeed:CONFIG.playerMoveSpeed*profile.moveSpeed);
      const [nx,ny]=norm(tx-p.x,ty-p.y),dist=Math.hypot(tx-p.x,ty-p.y),step=Math.min(dist,speed*sec);p.x+=nx*step;p.y+=ny*step;p.vx=nx*speed;p.vy=ny*speed;
    }else{
      p.heldDirection=null;const [nx,ny]=norm(p.homeX-p.x,p.homeY-p.y),dist=Math.hypot(p.homeX-p.x,p.homeY-p.y),step=Math.min(dist,CONFIG.returnSpeed*sec);if(dist>1){p.x+=nx*step;p.y+=ny*step;p.vx=nx*CONFIG.returnSpeed;p.vy=ny*CONFIG.returnSpeed;}else{p.x=p.homeX;p.y=p.homeY;p.vx=p.vy=0;}
    }
    p.x=clamp(p.x,CONFIG.goalDepth+25,CONFIG.width-CONFIG.goalDepth-25);p.y=clamp(p.y,CONFIG.goalDepth+25,CONFIG.height-CONFIG.goalDepth-25);
  }

  function shotVectorForPlayer(p,accuracy=1,rng=Math.random){
    const meta=PLAYER_META[p.index],base=Math.atan2(meta.goalVector[1],meta.goalVector[0]);
    const maxError=(1-clamp(accuracy,0,1))*.72,angle=base+(r01(rng)-.5)*2*maxError;return [Math.cos(angle),Math.sin(angle)];
  }

  function hit(run,index=0,accuracy=1){
    const p=run?.players?.[index];if(!p||run.finished||p.hitCooldownMs>0)return {accepted:false,ballId:null};
    p.hitCooldownMs=CONFIG.hitCooldownMs;p.hitFlashMs=150;p.hits++;
    const candidates=run.balls.filter(b=>!b.scored&&distance(p,b)<=CONFIG.hitRadius+b.radius).sort((a,b)=>distance(p,a)-distance(p,b));
    if(!candidates.length){run.events.push({type:'whiff',player:index,at:run.elapsedMs});return {accepted:true,ballId:null};}
    const ball=candidates[0],[sx,sy]=shotVectorForPlayer(p,accuracy,run.rng),boost=CONFIG.hitSpeed*(.92+r01(run.rng)*.16);
    ball.vx=sx*boost;ball.vy=sy*boost;ball.lastHitBy=index;ball.x+=sx*4;ball.y+=sy*4;
    run.events.push({type:'hit',player:index,ballId:ball.id,kind:ball.kind,at:run.elapsedMs});return {accepted:true,ballId:ball.id};
  }

  function playerInputForAi(run,p){
    p.aiThinkMs-=run._lastDt||0;
    if(p.aiThinkMs<=0){
      const active=run.balls.filter(b=>!b.scored);let best=null,bestScore=-Infinity;
      for(const b of active){
        const d=distance(p,b),valueWeight=b.value*180,goal=PLAYER_META[p.index].goalVector;
        const forwardness=(b.x-CONFIG.width/2)*goal[0]+(b.y-CONFIG.height/2)*goal[1];
        const score=valueWeight-d+forwardness*.08+(r01(run.rng)-.5)*run.profile.targetNoise;
        if(score>bestScore){bestScore=score;best=b;}
      }
      p.aiTargetId=best?.id||null;p.aiThinkMs=run.profile.reactionMs+r01(run.rng)*run.profile.decisionJitter;
    }
    const ball=run.balls.find(b=>b.id===p.aiTargetId&&!b.scored);if(!ball)return {};
    const dx=ball.x-p.x,dy=ball.y-p.y,absX=Math.abs(dx),absY=Math.abs(dy);const input={};
    if(absX>absY){if(dx>10)input.right=true;else if(dx<-10)input.left=true;}else{if(dy>10)input.down=true;else if(dy<-10)input.up=true;}
    if(distance(p,ball)<=CONFIG.hitRadius+ball.radius-3&&p.hitCooldownMs<=0)hit(run,p.index,run.profile.hitAccuracy);
    return input;
  }

  function bodyPush(run,p,ball){
    const d=distance(p,ball),limit=CONFIG.playerRadius+ball.radius;if(d>=limit||d<=0)return;
    const [nx,ny]=norm(ball.x-p.x,ball.y-p.y),overlap=limit-d;ball.x+=nx*overlap;ball.y+=ny*overlap;ball.vx+=nx*CONFIG.bodyPushSpeed;ball.vy+=ny*CONFIG.bodyPushSpeed;
  }

  function goalOwner(ball){
    if(ball.y>=CONFIG.height-CONFIG.goalDepth&&Math.abs(ball.x-CONFIG.width/2)<=CONFIG.goalHalfWidth)return 0;
    if(ball.x<=CONFIG.goalDepth&&Math.abs(ball.y-CONFIG.height/2)<=CONFIG.goalHalfWidth)return 1;
    if(ball.y<=CONFIG.goalDepth&&Math.abs(ball.x-CONFIG.width/2)<=CONFIG.goalHalfWidth)return 2;
    if(ball.x>=CONFIG.width-CONFIG.goalDepth&&Math.abs(ball.y-CONFIG.height/2)<=CONFIG.goalHalfWidth)return 3;
    return -1;
  }

  function scoreBall(run,ball,playerIndex){
    if(ball.scored)return false;const p=run.players[playerIndex];if(!p)return false;ball.scored=true;p.score+=ball.value;p.ballsScored++;
    const key=`${ball.kind}Balls`;p[key]=(p[key]||0)+1;run.events.push({type:'score',player:playerIndex,ballId:ball.id,kind:ball.kind,points:ball.value,at:run.elapsedMs});return true;
  }

  function updateBalls(run,dt){
    const sec=dt/1000,drag=Math.exp(-CONFIG.ballFriction*sec);
    for(const ball of run.balls){if(ball.scored)continue;ball.x+=ball.vx*sec;ball.y+=ball.vy*sec;ball.vx*=drag;ball.vy*=drag;
      for(const p of run.players)bodyPush(run,p,ball);
      const owner=goalOwner(ball);if(owner>=0){scoreBall(run,ball,owner);continue;}
      const min=12+ball.radius,maxX=CONFIG.width-min,maxY=CONFIG.height-min;
      if(ball.x<min){ball.x=min;ball.vx=Math.abs(ball.vx)*CONFIG.wallBounce;}else if(ball.x>maxX){ball.x=maxX;ball.vx=-Math.abs(ball.vx)*CONFIG.wallBounce;}
      if(ball.y<min){ball.y=min;ball.vy=Math.abs(ball.vy)*CONFIG.wallBounce;}else if(ball.y>maxY){ball.y=maxY;ball.vy=-Math.abs(ball.vy)*CONFIG.wallBounce;}
    }
  }

  function spawnCadence(run){const t=clamp(run.elapsedMs/CONFIG.durationMs,0,1);return CONFIG.spawnBaseMs+(CONFIG.spawnFastMs-CONFIG.spawnBaseMs)*t;}

  function finishMatch(run){
    if(!run||run.finished)return run?.ranking||[];run.finished=true;run.remainingMs=0;
    run.ranking=run.players.slice().sort((a,b)=>b.score-a.score||b.masterBalls-a.masterBalls||a.index-b.index);run.ranking.forEach((p,i)=>{run.players[p.index].place=i+1;});
    run.events.push({type:'finish',at:run.elapsedMs});return run.ranking;
  }

  function stepMatch(run,dt,input={}){
    if(!run||run.finished)return run;const ms=Math.max(0,Number(dt)||0);run._lastDt=ms;run.elapsedMs=Math.min(CONFIG.durationMs,run.elapsedMs+ms);run.remainingMs=Math.max(0,CONFIG.durationMs-run.elapsedMs);
    applyPlayerMotion(run,run.players[0],ms,input);
    for(let i=1;i<run.players.length;i++){const aiInput=playerInputForAi(run,run.players[i]);applyPlayerMotion(run,run.players[i],ms,aiInput);}
    updateBalls(run,ms);
    run.spawnInMs-=ms;if(run.spawnInMs<=0){spawnBall(run);run.spawnInMs+=spawnCadence(run);}
    run.balls=run.balls.filter(b=>!b.scored||run.elapsedMs-(run.events.findLast?.(e=>e.type==='score'&&e.ballId===b.id)?.at||run.elapsedMs)<700);
    if(run.elapsedMs>=CONFIG.durationMs)finishMatch(run);return run;
  }

  function rewardForResult({place=4,score=0,difficulty='normal'}={}){
    const base=[0,460,310,210,140][clamp(Math.floor(place),1,4)]||140,mult={easy:.85,normal:1,hard:1.25}[difficulty]||1;
    return Math.max(0,Math.round((base+Math.max(0,Number(score)||0)*16)*mult));
  }

  return {CONFIG,BALL_TYPES,DIFFICULTIES,PLAYER_META,difficultyProfile,availableBallKinds,createMatch,spawnBall,hit,stepMatch,finishMatch,rewardForResult,goalOwner,scoreBall};
});
