(function(root,factory){
  const core=root.LuckyDexPikachuBeachCore||(typeof require==='function'?require('./arcade-pikachu-beach-core.js'):null);
  const api=factory(root,core);root.LuckyDexPikachuBeach=api;if(typeof module!=='undefined'&&module.exports)module.exports=api;
})(typeof window!=='undefined'?window:globalThis,function(root,core){
  'use strict';
  if(!core)throw new Error('LuckyDexPikachuBeachCore required');
  const $=id=>typeof document!=='undefined'?document.getElementById(id):null;
  const now=()=>typeof performance!=='undefined'&&performance.now?performance.now():Date.now();
  const raf=fn=>(root.requestAnimationFrame||((f)=>setTimeout(()=>f(now()),16)))(fn);
  const caf=id=>(root.cancelAnimationFrame||clearTimeout)(id);
  const session=()=>root.LuckyDexArcadeSession||globalThis.LuckyDexArcadeSession;
  const platform=()=>root.LuckyDexArcadePlatform||globalThis.LuckyDexArcadePlatform;
  const prizes=()=>root.LuckyDexPikachuBeachPrizes||globalThis.LuckyDexPikachuBeachPrizes;
  const clamp=(n,a,b)=>Math.max(a,Math.min(b,Number(n)||0));
  let opened=false,phase='closed',difficulty='normal',run=null,rafId=0,lastFrame=0,nextWaveAt=0,airStartedAt=0,pressed=new Set(),rng=Math.random,flash='',flashUntil=0,completionHandled=false,finalResult=null,luckyAttempt=null;

  function profile(){return core.difficultyProfile(difficulty);}
  function rareRate(){return clamp(root.state?.settings?.rareOdds?.pikachuBeachLuckyWave??core.CONFIG.luckyWaveRate,0,1);}
  function stopLoop(){if(rafId){caf(rafId);rafId=0;}}
  function schedule(){if(!rafId&&phase==='running')rafId=raf(frame);}
  function record(){return root.state?.arcade?.pikachuBeach||{};}
  function setFlash(text,ms=800){flash=String(text||'');flashUntil=now()+ms;}
  function showReady(next=difficulty){
    difficulty=core.DIFFICULTIES[next]?next:'normal';phase='ready';run=null;completionHandled=false;finalResult=null;luckyAttempt=null;pressed.clear();stopLoop();
    if($('pikachuBeachReady'))$('pikachuBeachReady').hidden=false;if($('pikachuBeachControls'))$('pikachuBeachControls').hidden=true;if($('pikachuBeachPauseOverlay'))$('pikachuBeachPauseOverlay').hidden=true;
    document.querySelectorAll?.('[data-pikachu-beach-difficulty]')?.forEach(btn=>{const on=btn.dataset.pikachuBeachDifficulty===difficulty;btn.classList.toggle('active',on);btn.setAttribute('aria-pressed',on?'true':'false');});
    if($('pikachuBeachReadyMeta'))$('pikachuBeachReadyMeta').textContent=`${profile().label.toUpperCase()} · 6000 HP · RADNESS + HP SCORE`;
    render();return true;
  }
  function selectDifficulty(key){if(phase!=='ready'||!core.DIFFICULTIES[key])return false;return showReady(key);}
  function startRun(){
    if(!opened||phase!=='ready')return false;session()?.hideResult?.();if(root.state&&platform()?.ensureArcadeState)root.state.arcade=platform().ensureArcadeState(root.state.arcade);
    run=core.createRun({difficulty,luckyWave:core.rollLuckyWave(rareRate(),rng),rng});phase='running';lastFrame=now();nextWaveAt=1100;airStartedAt=0;completionHandled=false;finalResult=null;luckyAttempt=null;flash='';flashUntil=0;
    if($('pikachuBeachReady'))$('pikachuBeachReady').hidden=true;if($('pikachuBeachControls'))$('pikachuBeachControls').hidden=false;setFlash('SURF TOWARD SHORE · HOLD ↶ OR ↷ WHEN AIRBORNE',1450);render();schedule();return true;
  }
  function startWave(){
    if(phase!=='running'||!run||run.air)return false;const air=core.startWave(run);if(!air)return false;airStartedAt=run.elapsedMs;
    if(air.lucky)setFlash('✦ LUCKY WAVE! LAND IT FOR A PRIZE ✦',1500);else setFlash('WAVE! SPIN, THEN LAND THE BOARD LEVEL',820);render();return true;
  }
  function reserveLuckyPrize(){if(!run?.luckyWaveLanded||luckyAttempt||!root.state)return luckyAttempt;try{luckyAttempt=prizes()?.reserve?.(root.state,rng)||null;}catch(_){luckyAttempt=null;}return luckyAttempt;}
  function land(){
    if(!run?.air)return null;const landing=core.finishLanding(run);if(landing.safe){const label=landing.points?`RAD +${landing.points}`:'CLEAN LANDING';setFlash(landing.lucky?`✦ LUCKY LANDING · ${label} · PRIZE RESERVED ✦`:`${label} · KEEP SURFING`,landing.lucky?1500:900);if(landing.lucky)reserveLuckyPrize();}
    else{setFlash('WIPEOUT! · SPEED DROPPED',1050);const splash=$('pikachuBeachSplash');if(splash){splash.classList.remove('show');void splash.offsetWidth;splash.classList.add('show');}}
    nextWaveAt=run.elapsedMs+Math.max(1200,profile().waveEveryMs-profile().airtimeMs);airStartedAt=0;render();return landing;
  }
  function inputDirection(){const left=pressed.has('left'),right=pressed.has('right');return left===right?null:(left?'left':'right');}
  function tick(dtMs){
    if(!run)return;core.advanceRun(run,dtMs);if(run.hp<=0){void finishRun();return;}
    if(run.air){const dir=inputDirection();if(dir)core.rotate(run,dir,dtMs);if(run.elapsedMs-airStartedAt>=profile().airtimeMs)land();}
    else if(run.progress>=1){void finishRun();return;}
    else if(run.elapsedMs>=nextWaveAt)startWave();
  }
  function render(){
    const hp=Math.max(0,Math.floor(run?.hp??core.CONFIG.startingHp)),rad=Number(run?.radness||0),pct=Math.round(clamp(run?.progress||0,0,1)*100);
    if($('pikachuBeachHp'))$('pikachuBeachHp').textContent=String(hp);if($('pikachuBeachRadness'))$('pikachuBeachRadness').textContent=rad.toLocaleString('en-GB');if($('pikachuBeachProgress'))$('pikachuBeachProgress').textContent=`${pct}%`;
    if($('pikachuBeachBest'))$('pikachuBeachBest').textContent=`BEST ${Number(record().bestScores?.[difficulty]||0).toLocaleString('en-GB')}`;
    const surfer=$('pikachuBeachSurfer'),wave=$('pikachuBeachWave'),sea=$('pikachuBeachSeaLines'),lucky=$('pikachuBeachLuckyBanner'),trick=$('pikachuBeachTrick'),play=$('pikachuBeachPlayfield');
    const x=18+clamp(run?.progress||0,0,1)*61;let bottom=20,rotation=0,airU=0;if(run?.air){airU=clamp((run.elapsedMs-airStartedAt)/profile().airtimeMs,0,1);bottom=20+Math.sin(Math.PI*airU)*48;rotation=Number(run.air.angleDeg)||0;}
    if(surfer){surfer.style.left=`${x}%`;surfer.style.bottom=`${bottom}%`;surfer.style.transform=`translate(-50%,50%) rotate(${rotation}deg)`;}
    if(wave){wave.style.left=`${Math.max(10,x-3)}%`;wave.classList.toggle('is-live',!!run?.air);wave.classList.toggle('is-lucky',!!run?.air?.lucky);}
    if(sea)sea.style.transform=`translateX(${-((run?.progress||0)*72).toFixed(1)}px)`;
    if(play)play.classList.toggle('is-airborne',!!run?.air);
    if(lucky){lucky.hidden=!(run?.air?.lucky);}
    if(trick){const visible=flash&&now()<flashUntil;trick.hidden=!visible;if(visible){trick.textContent=flash;trick.className='pikachu-beach-trick'+(/WIPEOUT/.test(flash)?' miss':/LUCKY/.test(flash)?' lucky':' good');}}
    if($('pikachuBeachStatus'))$('pikachuBeachStatus').textContent=run?.air?`AIRBORNE · ${run.air.flips.length}/3 FLIPS · LAND WITH BOARD LEVEL`:'WAIT FOR THE NEXT WAVE · SUCCESSFUL TRICKS SPEED UP THE SURF';
  }
  function frame(t){rafId=0;if(phase!=='running')return;const dt=Math.min(40,Math.max(0,t-lastFrame||0));lastFrame=t;tick(dt);if(phase==='running'){render();schedule();}}
  function pause(){if(phase!=='running')return false;phase='paused';stopLoop();pressed.clear();if($('pikachuBeachPauseOverlay'))$('pikachuBeachPauseOverlay').hidden=false;return true;}
  function resume(){if(phase!=='paused')return false;phase='running';lastFrame=now();if($('pikachuBeachPauseOverlay'))$('pikachuBeachPauseOverlay').hidden=true;render();schedule();return true;}
  async function finishRun(){
    if(finalResult)return finalResult;if(!run||phase==='finishing'||phase==='finished')return finalResult;phase='finishing';stopLoop();pressed.clear();if(run.air)land();const summary=core.finishRun(run),p=platform();if(!root.state||!p?.ensureArcadeState)return null;root.state.arcade=p.ensureArcadeState(root.state.arcade);const rec=root.state.arcade.pikachuBeach,prevScore=Number(rec.bestScores?.[difficulty]||0),prevRad=Number(rec.bestRadness||0),prevHp=Number(rec.bestRemainingHp||0);
    let prize={pending:false,label:'',reveal:null};if(summary.luckyWaveLanded){reserveLuckyPrize();if(luckyAttempt)prize=await (prizes()?.deliver?.(root.state,luckyAttempt)||Promise.resolve({pending:true,label:'Lucky Wave Prize Reserved'}));}
    rec.gamesPlayed=Number(rec.gamesPlayed||0)+1;if(summary.cleared)rec.clears=Number(rec.clears||0)+1;if(summary.cleared&&difficulty==='hard')rec.hardClears=Number(rec.hardClears||0)+1;if(summary.cleared&&summary.wipeouts===0)rec.flawlessClears=Number(rec.flawlessClears||0)+1;
    rec.bestScore=Math.max(Number(rec.bestScore||0),summary.finalScore);rec.bestScores[difficulty]=Math.max(Number(rec.bestScores?.[difficulty]||0),summary.finalScore);rec.bestRadness=Math.max(Number(rec.bestRadness||0),summary.radness);rec.bestRemainingHp=Math.max(Number(rec.bestRemainingHp||0),summary.remainingHp);rec.bestTrick=Math.max(Number(rec.bestTrick||0),summary.bestTrick);rec.maxFlips=Math.max(Number(rec.maxFlips||0),run.bestFlips);rec.totalRadness=Number(rec.totalRadness||0)+summary.radness;rec.totalWipeouts=Number(rec.totalWipeouts||0)+summary.wipeouts;if(summary.luckyWaveSeen)rec.luckyWavesSeen=Number(rec.luckyWavesSeen||0)+1;if(summary.luckyWaveLanded)rec.luckyWavesLanded=Number(rec.luckyWavesLanded||0)+1;
    const coins=core.rewardCoins(summary.finalScore,difficulty,summary.cleared),award=p.awardRun?.({gameId:'pikachuBeach',label:'Pikachu’s Beach',score:summary.finalScore,coins})||{coinsAwarded:coins};root.save?.();
    finalResult={...summary,coins:award.coinsAwarded||0,prize:prize.label||''};phase='finished';if(completionHandled)return finalResult;completionHandled=true;
    const title=summary.cleared?(summary.wipeouts===0?'PERFECT SURF!':'SHORE REACHED!'):'OUT OF HP!';const luckyText=summary.luckyWaveLanded?(prize.pending?'LANDED · PRIZE RESERVED':`LANDED · ${prize.label}`):summary.luckyWaveSeen?'MISSED':'—';
    const review={title,mode:'Route 19 · Pikachu’s Beach',difficulty:profile().label,metricLabel:'SCORE',metricValue:summary.finalScore.toLocaleString('en-GB'),stats:[{label:'Radness',value:summary.radness.toLocaleString('en-GB')},{label:'Remaining HP',value:String(summary.remainingHp)},{label:'Waves Landed',value:String(run.successfulLandings)},{label:'Wipeouts',value:String(summary.wipeouts)},{label:'Best Trick',value:summary.bestTrick?`+${summary.bestTrick}`:'—'},{label:'Lucky Wave',value:luckyText}],pbs:[{label:`${profile().label} Score`,value:Number(rec.bestScores[difficulty]||0).toLocaleString('en-GB'),isNew:summary.finalScore>prevScore},{label:'Best Radness',value:Number(rec.bestRadness||0).toLocaleString('en-GB'),isNew:summary.radness>prevRad},{label:'Best Remaining HP',value:String(rec.bestRemainingHp||0),isNew:summary.remainingHp>prevHp}],rewards:[{label:'Lucky Coins',value:String(award.coinsAwarded||0)},...(prize.label?[{label:'Lucky Wave',value:prize.label}]:[])]};
    session()?.showResult?.('pikachuBeach',{title,metricLabel:'SCORE',metricValue:summary.finalScore.toLocaleString('en-GB'),coinsAwarded:award.coinsAwarded,bestText:summary.finalScore>prevScore?'NEW BEST':`BEST ${Number(rec.bestScores[difficulty]||0).toLocaleString('en-GB')}`,rewardReveals:prize.reveal?[prize.reveal]:[],review,replayLabel:'PLAY AGAIN',onReplay:()=>showReady(difficulty),onBack:()=>root.LuckyDexArcadeWorld?.backFromGame?.()});return finalResult;
  }
  function open(){opened=true;session()?.mount?.('pikachuBeach',$('pikachuBeachGame'));if(root.state&&platform()?.ensureArcadeState)root.state.arcade=platform().ensureArcadeState(root.state.arcade);void prizes()?.retry?.(root.state);showReady(difficulty);return true;}
  function close(){opened=false;stopLoop();phase='closed';run=null;pressed.clear();completionHandled=false;finalResult=null;luckyAttempt=null;if($('pikachuBeachPauseOverlay'))$('pikachuBeachPauseOverlay').hidden=true;return true;}
  function press(dir,on){const key=dir==='right'?'right':'left';if(on)pressed.add(key);else pressed.delete(key);const btn=$(key==='left'?'pikachuBeachLeft':'pikachuBeachRight');btn?.classList?.toggle('is-held',!!on);}
  function keydown(e){const k=String(e?.key||'').toLowerCase();if(k==='arrowleft'){press('left',true);if(phase==='running')e.preventDefault?.();}else if(k==='arrowright'){press('right',true);if(phase==='running')e.preventDefault?.();}}
  function keyup(e){const k=String(e?.key||'').toLowerCase();if(k==='arrowleft')press('left',false);else if(k==='arrowright')press('right',false);}
  function bindHold(id,dir){const el=$(id);if(!el)return;const down=e=>{e.preventDefault?.();press(dir,true);};const up=()=>press(dir,false);el.addEventListener('pointerdown',down);el.addEventListener('pointerup',up);el.addEventListener('pointercancel',up);el.addEventListener('pointerleave',up);}
  function snapshot(){return {phase,difficulty,run:run?JSON.parse(JSON.stringify(run)):null,finalResult:finalResult?JSON.parse(JSON.stringify(finalResult)):null};}
  function wire(){if(typeof document==='undefined')return;$('pikachuBeachStart')?.addEventListener('click',startRun);$('pikachuBeachResume')?.addEventListener('click',resume);for(const btn of document.querySelectorAll?.('[data-pikachu-beach-difficulty]')||[])btn.addEventListener('click',()=>selectDifficulty(btn.dataset.pikachuBeachDifficulty));bindHold('pikachuBeachLeft','left');bindHold('pikachuBeachRight','right');document.addEventListener('keydown',keydown,{capture:true});document.addEventListener('keyup',keyup,{capture:true});document.addEventListener('visibilitychange',()=>{if(document.hidden&&opened)pause();});root.addEventListener?.('pagehide',()=>{if(opened)pause();});}
  wire();return {open,close,showReady,startRun,startWave,finishRun,pause,resume,selectDifficulty,snapshot,_setRng:fn=>{if(typeof fn==='function')rng=fn;}};
});
