/* LuckyDex v0.17.0 — Ditto Transform recognition game */
(function(root){
  'use strict';

  const FALLBACK_IDS=[25,133,35,54,39,52,37,1,4,7,81,100];
  const FACE_POSITIONS={
    1:{x:50,y:43,scale:.9},4:{x:51,y:38,scale:.9},7:{x:50,y:39,scale:.9},
    25:{x:50,y:39,scale:.88},35:{x:50,y:40,scale:1},37:{x:50,y:39,scale:.82},
    39:{x:50,y:41,scale:1},52:{x:50,y:38,scale:.88},54:{x:50,y:39,scale:.9},
    81:{x:50,y:42,scale:.85},100:{x:50,y:43,scale:.9},133:{x:50,y:39,scale:.85}
  };

  function dittoRoundConfig(round){
    const r=Math.max(1,Math.floor(Number(round)||1));
    if(r<=2)return{candidates:3,dittos:1,revealMs:1400,scrambleSteps:3,scrambleMs:360,selectMs:5000};
    if(r<=4)return{candidates:4,dittos:1,revealMs:1200,scrambleSteps:4,scrambleMs:320,selectMs:4400};
    if(r<=7)return{candidates:5,dittos:1,revealMs:1000,scrambleSteps:5,scrambleMs:280,selectMs:3900};
    if(r<=10)return{candidates:6,dittos:2,revealMs:900,scrambleSteps:6,scrambleMs:245,selectMs:3500};
    return{candidates:6,dittos:2,revealMs:750,scrambleSteps:8,scrambleMs:210,selectMs:3000};
  }
  function dittoRoundGain(round,dittos=1){
    const r=Math.max(1,Math.floor(Number(round)||1)),d=Math.max(1,Math.floor(Number(dittos)||1));
    return Math.min(180,25+r*12+d*10);
  }
  function dittoFacePosition(id){return FACE_POSITIONS[Number(id)]||{x:50,y:38,scale:1};}
  function shuffled(arr,rng=Math.random){
    const out=[...arr];
    for(let i=out.length-1;i>0;i--){const j=Math.floor(rng()*(i+1));[out[i],out[j]]=[out[j],out[i]];}
    return out;
  }
  function platform(){return root.LuckyDexArcadePlatform||globalThis.LuckyDexArcadePlatform;}
  function buildDittoLineup(round,rng=Math.random){
    const cfg=dittoRoundConfig(round),p=platform();
    const source=p&&typeof p.caughtParticipants==='function'?p.caughtParticipants(cfg.candidates,FALLBACK_IDS):[];
    const unique=[];const seen=new Set();
    for(const entry of source||[]){const id=Number(entry?.id);if(!id||id===132||seen.has(id))continue;seen.add(id);unique.push({...entry,id});if(unique.length>=cfg.candidates)break;}
    for(const id of FALLBACK_IDS){if(unique.length>=cfg.candidates)break;if(seen.has(id))continue;seen.add(id);unique.push({id,name:`Pokémon ${id}`,image:`https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/${id}.png`,shiny:false});}
    const picked=shuffled(unique.slice(0,cfg.candidates),rng);
    const targetSlots=new Set(shuffled(Array.from({length:picked.length},(_,i)=>i),rng).slice(0,cfg.dittos));
    return picked.map((pokemon,i)=>({id:i+1,pos:i,pokemon,isDitto:targetSlots.has(i),found:false}));
  }

  function esc(v){return String(v??'').replace(/[&<>'"]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;',"'":'&#39;','"':'&quot;'}[c]));}
  function sleep(ms){return new Promise(resolve=>setTimeout(resolve,ms));}
  function el(id){return typeof document!=='undefined'?document.getElementById(id):null;}
  function stateRef(){return root.state||globalThis.state;}
  function format(n){const f=root.fmt||globalThis.fmt;return typeof f==='function'?f(n):String(Math.round(Number(n)||0));}
  function haptic(pattern){const v=root.vibrate||globalThis.vibrate;if(typeof v==='function')v(pattern);}
  function saveState(){const s=root.save||globalThis.save;if(typeof s==='function')s();}
  function setGame(game){
    root.__dittoTransformGameV0170=game;
    try{if(typeof dittoGameV166!=='undefined')dittoGameV166=game;}catch(_){/* Node/test context */}
  }
  function getGame(){
    try{if(typeof dittoGameV166!=='undefined'&&dittoGameV166)return dittoGameV166;}catch(_){/* Node/test context */}
    return root.__dittoTransformGameV0170||null;
  }
  function stopDittoTransformV0170(){
    const g=getGame();if(!g)return;
    g.token=(g.token||0)+1;g.selecting=false;
    if(g.selectTimer){clearTimeout(g.selectTimer);g.selectTimer=null;}
    const fill=el('dittoScanFill');if(fill){fill.style.transition='none';fill.style.width='0%';}
  }
  function updateLabels(){
    const g=getGame();if(!g)return;
    if(el('dittoRound'))el('dittoRound').textContent=String(g.round||0);
    if(el('dittoBank'))el('dittoBank').textContent=format(g.bank||0);
    if(el('dittoBest'))el('dittoBest').textContent=format(stateRef()?.arcade?.bestDitto||0);
  }
  function faceHtml(pokemon){
    const f=dittoFacePosition(pokemon.id);
    return `<span class="ditto-face" style="--ditto-face-x:${f.x}%;--ditto-face-y:${f.y}%;--ditto-face-scale:${f.scale}"><i></i><i></i><b></b></span>`;
  }
  function renderCandidates(){
    const g=getGame(),track=el('dittoTrack');if(!g||!track)return;
    track.classList.toggle('shuffling',g.phase==='scrambling');
    track.classList.toggle('selecting',!!g.selecting);
    track.innerHTML=g.candidates.map(c=>{
      const transformed=g.phase!=='reveal';
      const src=c.isDitto&&!transformed?`https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/132.png`:c.pokemon.image;
      const alt=c.isDitto&&!transformed?'Ditto':c.pokemon.name;
      const face=c.isDitto&&transformed?faceHtml(c.pokemon):'';
      const cls=['ditto-subject',c.isDitto?'is-ditto':'',c.found?'found':'',g.phase==='transforming'&&c.isDitto?'transforming':''].filter(Boolean).join(' ');
      return `<button class="${cls}" data-ditto-subject="${c.id}" ${g.selecting&&!c.found?'':'disabled'} aria-label="Research subject ${c.id}"><span class="ditto-sprite-wrap"><img src="${esc(src)}" alt="${esc(alt)}">${face}<span class="ditto-transform-ring"></span></span><small>${transformed?esc(c.pokemon.name):c.isDitto?'DITTO':esc(c.pokemon.name)}</small></button>`;
    }).join('');
    track.querySelectorAll('[data-ditto-subject]').forEach(btn=>btn.addEventListener('click',()=>chooseDittoSubjectV0170(Number(btn.dataset.dittoSubject))));
    if(typeof requestAnimationFrame==='function')requestAnimationFrame(layoutCandidates);else layoutCandidates();
  }
  function layoutCandidates(){
    const g=getGame(),track=el('dittoTrack');if(!g||!track)return;
    const n=g.candidates.length,gap=n>=6?4:7,total=Math.max(260,track.clientWidth||340),w=Math.min(92,Math.max(48,(total-gap*(n-1)-8)/n)),used=n*w+(n-1)*gap,start=Math.max(4,(total-used)/2);
    track.querySelectorAll('[data-ditto-subject]').forEach(node=>{const c=g.candidates.find(x=>x.id===Number(node.dataset.dittoSubject));if(c){node.style.width=`${w}px`;node.style.transform=`translateX(${start+c.pos*(w+gap)}px)`;}});
  }
  function resetDittoTransformV0170(){
    stopDittoTransformV0170();
    const g={round:0,bank:0,selecting:false,failed:false,candidates:[],phase:'idle',token:1,selectTimer:null};setGame(g);
    updateLabels();
    if(el('dittoMessage'))el('dittoMessage').textContent="Press START TEST when you're ready.";
    if(el('dittoTrack')){el('dittoTrack').className='ditto-track';el('dittoTrack').innerHTML='<div class="ditto-idle-mark"><span>🧬</span><small>TRANSFORM SCANNER READY</small></div>';}
    const start=el('dittoStartBtn');if(start){start.disabled=false;start.textContent='START TEST';}
    const cash=el('dittoCashBtn');if(cash)cash.disabled=true;
    const fill=el('dittoScanFill');if(fill){fill.style.transition='none';fill.style.width='0%';}
  }
  function startSelectionTimer(g,cfg){
    const fill=el('dittoScanFill');
    if(fill){fill.style.transition='none';fill.style.width='100%';void fill.offsetWidth;fill.style.transition=`width ${cfg.selectMs}ms linear`;fill.style.width='0%';}
    g.selectTimer=setTimeout(()=>failDittoRoundV0170('SCAN EXPIRED'),cfg.selectMs+40);
  }
  async function startDittoTransformRoundV0170(){
    const g=getGame();if(!g||g.selecting)return;
    if(g.selectTimer){clearTimeout(g.selectTimer);g.selectTimer=null;}
    const token=++g.token;g.round+=1;g.failed=false;g.selecting=false;g.phase='reveal';g.candidates=buildDittoLineup(g.round);const cfg=dittoRoundConfig(g.round);
    updateLabels();
    const start=el('dittoStartBtn');if(start)start.disabled=true;
    const cash=el('dittoCashBtn');if(cash)cash.disabled=true;
    if(el('dittoMessage'))el('dittoMessage').textContent=cfg.dittos===1?'Watch Ditto — it is about to Transform.':'Two Ditto entered the test. Watch both Transform.';
    renderCandidates();
    await sleep(cfg.revealMs);if(getGame()!==g||token!==g.token)return;
    g.phase='transforming';if(el('dittoMessage'))el('dittoMessage').textContent='TRANSFORM!';renderCandidates();haptic([10,18,10]);
    await sleep(650);if(getGame()!==g||token!==g.token)return;
    g.phase='scrambling';if(el('dittoMessage'))el('dittoMessage').textContent='Research subjects repositioning…';renderCandidates();
    let last='';
    for(let i=0;i<cfg.scrambleSteps;i++){
      let a,b,key;do{a=Math.floor(Math.random()*g.candidates.length);b=Math.floor(Math.random()*g.candidates.length);key=[Math.min(a,b),Math.max(a,b)].join('-');}while(a===b||key===last);last=key;
      const ca=g.candidates.find(x=>x.pos===a),cb=g.candidates.find(x=>x.pos===b);ca.pos=b;cb.pos=a;layoutCandidates();
      await sleep(cfg.scrambleMs);if(getGame()!==g||token!==g.token)return;
    }
    g.phase='selecting';g.selecting=true;renderCandidates();
    if(el('dittoMessage'))el('dittoMessage').textContent=cfg.dittos===1?'Spot the imperfect Transform.':'Find both transformed Ditto before the scan expires.';
    startSelectionTimer(g,cfg);
  }
  function revealResultClasses(chosenId=null){
    const g=getGame(),track=el('dittoTrack');if(!g||!track)return;
    track.querySelectorAll('[data-ditto-subject]').forEach(node=>{const c=g.candidates.find(x=>x.id===Number(node.dataset.dittoSubject));node.disabled=true;if(c?.isDitto)node.classList.add('correct');else if(chosenId===c?.id)node.classList.add('wrong');});
  }
  function completeDittoRoundV0170(){
    const g=getGame();if(!g)return;g.selecting=false;g.phase='result';if(g.selectTimer){clearTimeout(g.selectTimer);g.selectTimer=null;}
    const cfg=dittoRoundConfig(g.round),gain=dittoRoundGain(g.round,cfg.dittos);g.bank+=gain;
    const s=stateRef();if(s){s.arcade=s.arcade||{};s.arcade.bestDitto=Math.max(Number(s.arcade.bestDitto||0),g.round);saveState();}
    updateLabels();revealResultClasses();
    if(el('dittoMessage'))el('dittoMessage').textContent=`Transform identified · +${format(gain)} added to the run bank.`;
    const start=el('dittoStartBtn');if(start){start.disabled=false;start.textContent='NEXT ROUND';}
    const cash=el('dittoCashBtn');if(cash)cash.disabled=false;
    haptic([14,18,30]);
  }
  function failDittoRoundV0170(reason='WRONG SUBJECT',chosenId=null){
    const g=getGame();if(!g||g.failed)return;g.selecting=false;g.failed=true;g.phase='result';if(g.selectTimer){clearTimeout(g.selectTimer);g.selectTimer=null;}
    const lost=g.bank;g.bank=0;updateLabels();renderCandidates();revealResultClasses(chosenId);haptic([28,28,55]);
    const s=stateRef();if(s){s.stats=s.stats||{};s.stats.arcadeGames=Number(s.stats.arcadeGames||0)+1;saveState();}
    if(el('dittoMessage'))el('dittoMessage').textContent=reason==='SCAN EXPIRED'?'Scan expired — Ditto revealed itself.':'That Pokémon was genuine — Ditto revealed itself.';
    const result=root.resultV166||globalThis.resultV166;
    if(typeof result==='function')result('DITTO TRANSFORM','🧬','DITTO GOT AWAY!',lost?`The lab fooled you and your ${format(lost)}-coin run bank was lost.`:'The Transform Pokémon slipped away.','NEW TEST',resetDittoTransformV0170);
    else{const start=el('dittoStartBtn');if(start){start.disabled=false;start.textContent='NEW TEST';start.onclick=resetDittoTransformV0170;}}
  }
  function chooseDittoSubjectV0170(id){
    const g=getGame();if(!g||!g.selecting)return;const chosen=g.candidates.find(x=>x.id===id);if(!chosen||chosen.found)return;
    if(!chosen.isDitto){failDittoRoundV0170('WRONG SUBJECT',id);return;}
    chosen.found=true;haptic(10);const remaining=g.candidates.filter(x=>x.isDitto&&!x.found).length;
    if(remaining===0){completeDittoRoundV0170();return;}
    renderCandidates();if(el('dittoMessage'))el('dittoMessage').textContent=`Correct — ${remaining} transformed Ditto still hiding.`;
  }
  function cashDittoTransformV0170(){
    const g=getGame();if(!g||g.bank<=0||g.selecting)return;const payout=g.bank;g.bank=0;updateLabels();
    const p=platform();if(p&&typeof p.awardRun==='function')p.awardRun({gameId:'ditto',label:'Ditto Transform',score:g.round,coins:payout,dailyEligible:false});
    else{const award=root.awardArcadeCoins||globalThis.awardArcadeCoins;if(typeof award==='function')award(payout,'Ditto Transform','ditto');}
    const result=root.resultV166||globalThis.resultV166;
    if(typeof result==='function')result('DITTO TRANSFORM','🧬','RESEARCH COMPLETE',`You safely banked ${format(payout)} Lucky Coins after reaching Round ${g.round}.`,'NEW TEST',resetDittoTransformV0170);
    else resetDittoTransformV0170();
  }

  function installBrowser(){
    if(typeof document==='undefined')return;
    root.stopDittoV166=stopDittoTransformV0170;
    root.resetDittoGameV166=resetDittoTransformV0170;
    root.startDittoRoundV166=startDittoTransformRoundV0170;
    root.chooseDittoPodV166=chooseDittoSubjectV0170;
    root.cashDittoV166=cashDittoTransformV0170;
    const start=el('dittoStartBtn');if(start)start.onclick=startDittoTransformRoundV0170;
    const cash=el('dittoCashBtn');if(cash)cash.onclick=cashDittoTransformV0170;
    root.addEventListener?.('resize',()=>{if(getGame()?.candidates?.length)layoutCandidates();});
  }

  const api={dittoRoundConfig,dittoRoundGain,dittoFacePosition,buildDittoLineup,resetDittoTransformV0170,startDittoTransformRoundV0170,chooseDittoSubjectV0170,cashDittoTransformV0170};
  root.LuckyDexDittoTransform=api;
  installBrowser();
  if(typeof module!=='undefined'&&module.exports)module.exports=api;
})(typeof window!=='undefined'?window:globalThis);
