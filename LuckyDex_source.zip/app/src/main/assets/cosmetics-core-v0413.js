(function(root,factory){
  const catalogue=(typeof module==='object'&&module.exports)?require('./cosmetics-catalog-v0413.js'):root.LuckyDexCosmeticsCatalogV0413;
  const api=factory(catalogue||{CATALOGUE:[],BY_ID:{}});
  if(typeof module==='object'&&module.exports){module.exports=api;return;}
  root.LuckyDexCosmeticsV0413=api;
})(typeof globalThis!=='undefined'?globalThis:this,function(catalogue){
  'use strict';
  const DEFAULT_SLEEVE_ID='luckydex-default';
  const registry=catalogue.BY_ID||Object.fromEntries((catalogue.CATALOGUE||[]).map(x=>[x.id,x]));
  const ALWAYS_UNLOCKED_IDS=(catalogue.CATALOGUE||[]).filter(x=>!x.hidden&&!x.sourceAchievementId).map(x=>x.id);
  let bridge={getState:null,save:null,showToast:null,onChange:null};
  let sessionUnlockAll=false;
  let pendingRecognition=null;
  const strings=v=>Array.isArray(v)?[...new Set(v.filter(x=>typeof x==='string'&&x.trim()).map(x=>x.trim()))]:[];
  function normaliseCosmetics(raw,customRegistry){
    const reg=customRegistry||registry;
    const src=raw&&typeof raw==='object'&&!Array.isArray(raw)?raw:{};
    const saved=strings(src.unlockedSleeves).filter(id=>!!reg[id]);
    const base=ALWAYS_UNLOCKED_IDS.filter(id=>!!reg[id]);
    if(reg[DEFAULT_SLEEVE_ID]&&!base.includes(DEFAULT_SLEEVE_ID))base.unshift(DEFAULT_SLEEVE_ID);
    const unlocked=[...base,...saved.filter(id=>!base.includes(id))];
    const active=(typeof src.activeSleeve==='string'&&unlocked.includes(src.activeSleeve)&&reg[src.activeSleeve])?src.activeSleeve:DEFAULT_SLEEVE_ID;
    return {unlockedSleeves:unlocked,activeSleeve:active,discoveredSecrets:strings(src.discoveredSecrets),claimedCosmeticRewards:strings(src.claimedCosmeticRewards)};
  }
  function ensureState(state){if(!state||typeof state!=='object')return normaliseCosmetics(null);state.cosmetics=normaliseCosmetics(state.cosmetics);return state.cosmetics;}
  function unlockSleeve(state,id,claimToken){
    const c=ensureState(state);id=String(id||'');
    if(!registry[id])return {ok:false,changed:false,id};
    let changed=false;
    if(!c.unlockedSleeves.includes(id)){c.unlockedSleeves.push(id);changed=true;}
    if(claimToken&&!c.claimedCosmeticRewards.includes(String(claimToken))){c.claimedCosmeticRewards.push(String(claimToken));changed=true;}
    return {ok:true,changed,id};
  }
  function equipSleeve(state,id){
    const c=ensureState(state);id=String(id||'');
    if(!registry[id])return {ok:false,changed:false,reason:'unknown'};
    if(!c.unlockedSleeves.includes(id)&&!sessionUnlockAll)return {ok:false,changed:false,reason:'locked'};
    const changed=c.activeSleeve!==id;c.activeSleeve=id;applyActiveSleeveCss(state);return {ok:true,changed};
  }
  function activeSleeve(state){const c=ensureState(state||bridge.getState?.()||{});return registry[c.activeSleeve]||registry[DEFAULT_SLEEVE_ID]||{id:DEFAULT_SLEEVE_ID,name:'LuckyDex Default',artPath:''};}
  function discoverSecret(state,secretId){const c=ensureState(state);secretId=String(secretId||'');if(!secretId||c.discoveredSecrets.includes(secretId))return false;c.discoveredSecrets.push(secretId);return true;}
  function isDiscovered(state,secretId){return ensureState(state).discoveredSecrets.includes(String(secretId||''));}
  function installBridge(next={}){bridge={...bridge,...next};applyActiveSleeveCss(bridge.getState?.());return api;}

  function defaultBackInnerHtml(){
    return `<span class="lucky-sleeve-back-inner" data-sleeve-id="${DEFAULT_SLEEVE_ID}"><span class="lucky-sleeve-fallback"><i></i></span></span>`;
  }
  function cardBackInnerHtml(stateOverride){
    const entry=activeSleeve(stateOverride||bridge.getState?.()||{}),id=entry?.id||DEFAULT_SLEEVE_ID,path=String(entry?.artPath||'');
    if(!path)return defaultBackInnerHtml();
    const safePath=path.replace(/&/g,'&amp;').replace(/"/g,'&quot;').replace(/</g,'&lt;');
    return `<span class="lucky-sleeve-back-inner" data-sleeve-id="${id}"><span class="lucky-sleeve-fallback"><i></i></span><img src="${safePath}" alt="" onerror="this.remove()"></span>`;
  }

  function applyActiveSleeveCss(stateOverride){
    const entry=activeSleeve(stateOverride||bridge.getState?.()||{}),path=String(entry?.artPath||'');
    if(typeof document!=='undefined'&&document.documentElement?.style?.setProperty){const safe=path.replace(/"/g,'%22');document.documentElement.style.setProperty('--luckydex-active-sleeve',path?`url("${safe}")`:'none');}
    return entry;
  }

  function reconcile(state,achievements=[]){
    ensureState(state);const byId=Object.fromEntries((achievements||[]).map(a=>[String(a?.id||''),a])),unlockedSleeves=[],discoveredSecrets=[],claimTokens=[],recognisedAchievements=[];
    const bindings=[];
    for(const entry of catalogue.CATALOGUE||[])if(entry.sourceAchievementId)bindings.push({achievementId:entry.sourceAchievementId,sleeveId:entry.id,hidden:!!entry.hidden});
    for(const a of achievements||[])if(a?.reward?.sleeve&&!bindings.some(b=>b.achievementId===a.id&&b.sleeveId===a.reward.sleeve))bindings.push({achievementId:a.id,sleeveId:a.reward.sleeve,hidden:!!a.hidden});
    for(const b of bindings){
      const a=byId[b.achievementId];if(!a)continue;
      let complete=!!state?.profile?.achievementClaims?.includes?.(a.id);
      if(!complete&&typeof a.progress==='function'){try{const [v,t]=a.progress();complete=Number(v||0)>=Math.max(1,Number(t||1));}catch(_){}}
      if(!complete)continue;
      const token=`achievement:${a.id}:sleeve:${b.sleeveId}`,had=ensureState(state).unlockedSleeves.includes(b.sleeveId),hadToken=ensureState(state).claimedCosmeticRewards.includes(token);
      let recognised=false;const r=unlockSleeve(state,b.sleeveId,token);if(r.ok&&!had&&r.changed){unlockedSleeves.push(b.sleeveId);recognised=true;}if(!hadToken&&ensureState(state).claimedCosmeticRewards.includes(token))claimTokens.push(token);
      if((a.hidden||b.hidden)&&!isDiscovered(state,a.id)){discoverSecret(state,a.id);discoveredSecrets.push(a.id);recognised=true;}
      if(recognised&&!recognisedAchievements.includes(a.id))recognisedAchievements.push(a.id);
    }
    if(unlockedSleeves.length||recognisedAchievements.length){pendingRecognition=pendingRecognition||{sleeves:[],achievements:[]};for(const id of unlockedSleeves)if(!pendingRecognition.sleeves.includes(id))pendingRecognition.sleeves.push(id);for(const id of recognisedAchievements)if(!pendingRecognition.achievements.includes(id))pendingRecognition.achievements.push(id);}
    return {unlockedSleeves,discoveredSecrets,claimTokens};
  }
  function consumeRecognitionSummary(){if(!pendingRecognition||(!pendingRecognition.sleeves.length&&!pendingRecognition.achievements.length))return null;const out={sleeves:[...pendingRecognition.sleeves],achievements:[...pendingRecognition.achievements]};pendingRecognition=null;return out;}
  function devUnlockAll({persist=false}={}){
    const ids=Object.keys(registry);sessionUnlockAll=true;
    if(persist&&bridge.getState){const s=bridge.getState();ids.forEach(id=>unlockSleeve(s,id,`dev:${id}`));bridge.save?.();bridge.onChange?.();}
    return ids;
  }
  function isOwned(state,id){return sessionUnlockAll||ensureState(state).unlockedSleeves.includes(id);}
  const api={DEFAULT_SLEEVE_ID,registry,catalogue:catalogue.CATALOGUE||[],normaliseCosmetics,ensureState,unlockSleeve,equipSleeve,activeSleeve,discoverSecret,isDiscovered,installBridge,defaultBackInnerHtml,cardBackInnerHtml,applyActiveSleeveCss,reconcile,consumeRecognitionSummary,devUnlockAll,isOwned};
  return api;
});
