(function(root){
  'use strict';

  const SLOT_POINTS=[150,250,400,1000,400,250,150];
  const PIN_BONUS=12;
  const BALL_RADIUS=30;
  let run=null,raf=null,landingTimer=null;
  const platform=()=>root.LuckyDexArcadePlatform||globalThis.LuckyDexArcadePlatform;
  const session=()=>root.LuckyDexArcadeSession||globalThis.LuckyDexArcadeSession;
  const el=id=>typeof document!=='undefined'?document.getElementById(id):null;
  const fmt=n=>Number(n||0).toLocaleString();

  function createRun(){return {round:0,ballsRemaining:3,score:0,ordinaryPoints:0,jackpots:0,dropping:false,finished:false,awarded:false,ball:null,settledSlot:null,token:0};}
  function payoutFor(model){return platform()?.ballDropPayout?.(model)||{ordinaryCoins:0,jackpotCoins:0,totalCoins:0};}
  function payoutDelta(before,after){const a=payoutFor(before),b=payoutFor(after);return {ordinaryCoins:b.ordinaryCoins-a.ordinaryCoins,jackpotCoins:b.jackpotCoins-a.jackpotCoins,totalCoins:b.totalCoins-a.totalCoins};}
  function applyLanding(model,{slot,slotPoints=SLOT_POINTS[slot]||0,pinBonus=0,pinHits=0}={}){
    if(!model||model.finished||model.round>=3) return null;
    const before={ordinaryPoints:model.ordinaryPoints,jackpots:model.jackpots};
    const bonus=Math.max(0,Number(pinBonus)||0),points=Math.max(0,Number(slotPoints)||0),jackpot=Number(slot)===3;
    model.round++;model.ballsRemaining=Math.max(0,3-model.round);model.score+=points+bonus;model.ordinaryPoints+=bonus;if(jackpot)model.jackpots++;else model.ordinaryPoints+=points;
    if(model.round>=3)model.finished=true;
    const after={ordinaryPoints:model.ordinaryPoints,jackpots:model.jackpots},delta=payoutDelta(before,after);
    const coinCopy=jackpot?`JACKPOT · +${delta.jackpotCoins} jackpot${delta.ordinaryCoins?` + ${fmt(delta.ordinaryCoins)} ordinary`:''} = +${fmt(delta.totalCoins)} coins`:`${fmt(points)} points · +${fmt(delta.totalCoins)} coins`;
    return {slot,slotPoints:points,pinBonus:bonus,pinHits:Number(pinHits)||0,jackpot,delta,message:coinCopy};
  }
  function clearTimers(){if(raf){cancelAnimationFrame(raf);raf=null;}if(landingTimer){clearTimeout(landingTimer);landingTimer=null;}}
  function stop(){clearTimers();if(run){run.token++;run.dropping=false;}const aim=el('ballDropAim');if(aim)aim.disabled=false;return true;}
  // Leave a full ball diameter beside the outer pegs and above slot dividers.
  // Staggered neighbours also remain farther apart than two collision radii.
  function pegs(){const out=[];for(let row=0;row<7;row++){const count=row%2?7:6,margin=row%2?74:122,span=(720-margin*2)/(count-1);for(let i=0;i<count;i++)out.push({id:`${row}:${i}`,x:margin+i*span,y:105+row*71,r:10});}return out;}
  const ballSprite=typeof Image==='undefined'?null:new Image();
  if(ballSprite){ballSprite.src='arcade/sprites/items/poke-ball.png';ballSprite.onload=()=>draw();}
  function drawPokeball(ctx,b){if(!ballSprite?.complete||!ballSprite.naturalWidth)return;ctx.save();ctx.translate(b.x,b.y);ctx.rotate(b.angle||0);ctx.imageSmoothingEnabled=false;ctx.drawImage(ballSprite,-b.r,-b.r,b.r*2,b.r*2);ctx.restore();}
  function draw(){
    const c=el('ballDropCanvas');if(!c)return;const ctx=c.getContext('2d'),w=c.width,h=c.height,sw=w/7,slotTop=610,floorY=686;ctx.clearRect(0,0,w,h);const bg=ctx.createLinearGradient(0,0,0,h);bg.addColorStop(0,'#17325d');bg.addColorStop(.7,'#09162b');bg.addColorStop(1,'#060d1a');ctx.fillStyle=bg;ctx.fillRect(0,0,w,h);ctx.strokeStyle='rgba(217,185,90,.24)';ctx.lineWidth=3;ctx.strokeRect(10,10,w-20,h-20);
    for(const p of pegs()){const g=ctx.createRadialGradient(p.x-3,p.y-4,1,p.x,p.y,p.r+2);g.addColorStop(0,'#fff1a5');g.addColorStop(.42,'#d6b756');g.addColorStop(1,'#655020');ctx.fillStyle=g;ctx.beginPath();ctx.arc(p.x,p.y,p.r,0,Math.PI*2);ctx.fill();ctx.strokeStyle='#3f3219';ctx.lineWidth=2;ctx.stroke();}
    ctx.strokeStyle='#536784';ctx.lineWidth=4;for(let i=0;i<=7;i++){ctx.beginPath();ctx.moveTo(i*sw,slotTop);ctx.lineTo(i*sw,floorY);ctx.stroke();}ctx.strokeStyle='#6f83a3';ctx.beginPath();ctx.moveTo(0,floorY);ctx.lineTo(w,floorY);ctx.stroke();
    if(Number.isInteger(run?.settledSlot)){ctx.fillStyle=run.settledSlot===3?'rgba(255,221,86,.22)':'rgba(104,163,255,.15)';ctx.fillRect(run.settledSlot*sw,slotTop,sw,floorY-slotTop);}
    ctx.textAlign='center';ctx.font='900 21px sans-serif';SLOT_POINTS.forEach((pts,i)=>{ctx.fillStyle=i===3?'#ffe46b':'#c6d3e8';ctx.fillText(i===3?'★ 1000 ★':String(pts),sw*(i+.5),730);});
    if(run?.ball)drawPokeball(ctx,run.ball);else{const aim=Number(el('ballDropAim')?.value||50)/100*w;drawPokeball(ctx,{x:aim,y:55,r:BALL_RADIUS,angle:0});}
  }
  function resolvePin(b,p,now){const dx=b.x-p.x,dy=b.y-p.y,min=b.r+p.r,dist=Math.hypot(dx,dy);if(dist<=0||dist>=min)return false;const nx=dx/dist,ny=dy/dist,tx=-ny,ty=nx,overlap=min-dist;b.x+=nx*overlap;b.y+=ny*overlap;const vn=b.vx*nx+b.vy*ny;if(vn<0){const restitution=.76,jn=-(1+restitution)*vn;b.vx+=jn*nx;b.vy+=jn*ny;const inertia=.5*b.r*b.r,relativeTangent=b.vx*tx+b.vy*ty-b.omega*b.r,tangentDenom=1+(b.r*b.r/inertia);let jt=-relativeTangent/tangentDenom;const maxFriction=Math.abs(jn)*.28;jt=Math.max(-maxFriction,Math.min(maxFriction,jt));b.vx+=jt*tx;b.vy+=jt*ty;b.omega-=jt*b.r/inertia;b.vx+=(Math.random()-.5)*7;if(-vn>75){b.pinCooldown ||= {};const last=Number(b.pinCooldown[p.id]||0);if(now-last>65){b.pinCooldown[p.id]=now;b.pinHits=Number(b.pinHits||0)+1;}}}return true;}
  function resolveWalls(b,w){const sw=w/7,slotTop=610,floorY=686;if(b.y+b.r>slotTop){for(let i=1;i<7;i++){const wall=i*sw,dx=b.x-wall;if(Math.abs(dx)<b.r&&b.y-b.r<floorY){const side=dx>=0?1:-1;b.x=wall+side*b.r;if(b.vx*side<0){b.vx=-b.vx*.55;b.omega+=-b.vx/b.r*.32;}}}}if(b.x-b.r<0){b.x=b.r;b.vx=Math.abs(b.vx)*.62;b.omega-=b.vy/b.r*.05;}if(b.x+b.r>w){b.x=w-b.r;b.vx=-Math.abs(b.vx)*.62;b.omega+=b.vy/b.r*.05;}}
  function clearContinuation(b,x,y,pinList,w){
    if(x<b.r+1||x>w-b.r-1||y>686-b.r)return false;
    if(pinList.some(p=>Math.hypot(x-p.x,y-p.y)<b.r+p.r+1))return false;
    if(y+b.r>610&&y-b.r<686){for(let i=1;i<7;i++)if(Math.abs(x-i*w/7)<b.r+1)return false;}
    return true;
  }
  function recoverBall(b,pinList,w){
    const direction=b.vx?Math.sign(b.vx):(b.x<w/2?1:-1);let best=null;
    // Find the nearest clear point just below the stalled ball, never a slot
    // selected by its reward. Recovery itself does not resolve/award pin hits.
    for(let dy=8;dy<=80;dy+=4)for(let dx=0;dx<=80;dx+=4)for(const side of [direction,-direction]){
      const x=b.x+dx*side,y=b.y+dy,distance=dx*dx+dy*dy;
      if((!best||distance<best.distance)&&clearContinuation(b,x,y,pinList,w))best={x,y,distance,side};
    }
    if(!best)return false;
    b.x=best.x;b.y=best.y;b.vx=best.side*55;b.vy=45;
    b.slowTime=0;b.stallTime=0;b.progressY=b.y;b.recoveries=Number(b.recoveries||0)+1;
    return true;
  }
  function stepBall(b,dt,now,pinList=pegs(),w=720){
    b.vy+=1300*dt;b.vx*=.999;b.omega*=.9985;b.x+=b.vx*dt;b.y+=b.vy*dt;b.angle+=b.omega*dt;
    resolveWalls(b,w);for(const p of pinList)resolvePin(b,p,now);
    if(b.y+b.r>=686)return Math.max(0,Math.min(6,Math.floor(b.x/(w/7))));
    b.progressY ??= b.y;b.slowTime=Math.hypot(b.vx,b.vy)<30?(b.slowTime||0)+dt:0;
    if(b.y>=b.progressY+4){b.progressY=b.y;b.stallTime=0;}else b.stallTime=(b.stallTime||0)+dt;
    if(b.slowTime>=.65||b.stallTime>=1.2)recoverBall(b,pinList,w);
    return null;
  }
  function renderRun(){if(!run)return;const next=Math.min(3,run.round+1);if(el('ballDropRound'))el('ballDropRound').textContent=String(run.finished?3:next);if(el('ballDropScore'))el('ballDropScore').textContent=fmt(run.score);session()?.update?.('ballDrop',{runText:`Ball ${run.finished?3:next} / 3`,liveLabel:'SCORE',liveValue:fmt(run.score)});}
  function showLanding(outcome){const box=el('ballDropLanding');if(!box)return;const title=el('ballDropLandingTitle'),score=el('ballDropLandingScore'),detail=el('ballDropLandingDetail');if(title)title.textContent=outcome.jackpot?'★ JACKPOT ★':`${fmt(outcome.slotPoints)} POINT SLOT`;if(score)score.textContent=outcome.message;if(detail)detail.textContent=`${fmt(outcome.pinBonus)} pin bonus · ${outcome.pinHits} hits`;box.classList.toggle('jackpot',outcome.jackpot);box.hidden=false;}
  function hideLanding(){const box=el('ballDropLanding');if(box){box.hidden=true;box.classList.remove('jackpot');}}
  function completeRun(model=run){if(!model||model.awarded||!model.finished)return false;model.awarded=true;const payout=payoutFor({ordinaryPoints:model.ordinaryPoints,jackpots:model.jackpots});const s=root.state||globalThis.state;if(s?.arcade){s.arcade.bestBallDrop=Math.max(Number(s.arcade.bestBallDrop||0),Number(model.score)||0);s.arcade.ballDropJackpots=Number(s.arcade.ballDropJackpots||0)+Number(model.jackpots||0);}root.save?.();const awarded=platform()?.awardRun?.({gameId:'ballDrop',label:'Poké Ball Drop',score:model.score,coins:payout.totalCoins,dailyEligible:false,dailyReward:null})||{coinsAwarded:payout.totalCoins,itemAwarded:null};root.save?.();session()?.showResult?.('ballDrop',{title:'PRIZE MACHINE COMPLETE',metricLabel:'SCORE',metricValue:`${fmt(model.score)} points${model.jackpots?` · ${model.jackpots} jackpot${model.jackpots===1?'':'s'}`:''}`,coinsAwarded:awarded.coinsAwarded,itemAwarded:awarded.itemAwarded,bestText:'',onReplay:startRun,onBack:()=>root.LuckyDexArcadeWorld?.backFromGame?.(true)});return true;}
  function settle(slot){const model=run,b=model?.ball,c=el('ballDropCanvas');if(!model||!b||!c)return;const sw=c.width/7;b.x=sw*(slot+.5);b.y=686-b.r;b.vx=0;b.vy=0;b.omega*=.18;model.settledSlot=slot;draw();const pinBonus=Math.min(300,Number(b.pinHits||0)*PIN_BONUS),outcome=applyLanding(model,{slot,slotPoints:SLOT_POINTS[slot],pinBonus,pinHits:b.pinHits});renderRun();showLanding(outcome);root.vibrate?.(outcome.jackpot?[18,20,30,20,70]:[10,16,20]);const hold=outcome.jackpot?1550:1100;landingTimer=setTimeout(()=>{landingTimer=null;if(run!==model)return;hideLanding();model.ball=null;model.settledSlot=null;model.dropping=false;draw();const aim=el('ballDropAim'),button=el('ballDropBtn');if(aim)aim.disabled=model.finished;if(button)button.disabled=model.finished;if(model.finished)completeRun(model);else{if(button)button.disabled=false;renderRun();}},hold);}
  function dropBall(){const model=run,c=el('ballDropCanvas');if(!model||!c||model.dropping||model.finished||model.round>=3)return false;model.dropping=true;const button=el('ballDropBtn'),aim=el('ballDropAim');if(button)button.disabled=true;if(aim)aim.disabled=true;hideLanding();const x=Number(aim?.value||50)/100*c.width;model.ball={x,y:54,r:BALL_RADIUS,vx:(Math.random()-.5)*34,vy:0,angle:0,omega:(Math.random()-.5)*1.2,pinHits:0,pinCooldown:{}};const token=++model.token,pinList=pegs();let last=performance.now();const frame=now=>{if(run!==model||token!==model.token||!model.ball)return;let dt=Math.min(.032,(now-last)/1000);last=now;const steps=Math.max(2,Math.ceil(dt/.008));dt/=steps;for(let k=0;k<steps;k++){const slot=stepBall(model.ball,dt,now,pinList,c.width);if(slot!==null){raf=null;settle(slot);return;}}draw();raf=requestAnimationFrame(frame);};raf=requestAnimationFrame(frame);return true;}
  function startRun(){stop();session()?.hideResult?.();run=createRun();const aim=el('ballDropAim'),button=el('ballDropBtn');if(aim){aim.value='50';aim.disabled=false;}if(button){button.disabled=false;button.textContent='DROP BALL';}hideLanding();renderRun();draw();return run;}
  function open(){if(typeof document!=='undefined'){['voltorbGame','clefairyGame','berryGame','fossilGame','dittoGame','quizGame','ballDropGame','unownGame','safariGame','berryPickerGame','tilePuzzleGame'].forEach(id=>{const n=el(id);if(n)n.hidden=id!=='ballDropGame';});document.body.classList.add('arcade-open','arcade-mode');}session()?.mount?.('ballDrop');startRun();return true;}
  function wire(){if(typeof document==='undefined')return;const button=el('ballDropBtn'),aim=el('ballDropAim');if(button)button.onclick=dropBall;if(aim)aim.oninput=()=>{if(!run?.dropping)draw();};}

  const api={SLOT_POINTS,PIN_BONUS,BALL_RADIUS,createRun,payoutDelta,applyLanding,completeRun,startRun,dropBall,stop,open,draw,pegs,stepBall};
  root.LuckyDexBallDropV0180=api;
  if(typeof module!=='undefined'&&module.exports)module.exports=api;
  if(typeof document!=='undefined')wire();
})(typeof window!=='undefined'?window:globalThis);
