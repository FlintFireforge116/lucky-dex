/* LuckyDex v0.34.1 — expanded, data-driven achievement catalogue. */
(function(root,factory){
  const api=factory(root);
  if(typeof module==='object'&&module.exports){module.exports=api;return;}
  root.LuckyDexAchievements=api;
  api.install();
})(typeof window!=='undefined'?window:globalThis,function(root){
  'use strict';

  const CATEGORIES={collection:'Collection',tcg:'TCG',tcgp:'TCGP',pokemon:'Pokémon',adventure:'Adventure',arcade:'Arcade',museum:'Museum'};
  const GEN_RANGES=[
    [1,'Kanto',1,151],[2,'Johto',152,251],[3,'Hoenn',252,386],[4,'Sinnoh',387,493],[5,'Unova',494,649],
    [6,'Kalos',650,721],[7,'Alola',722,809],[8,'Galar / Hisui',810,905],[9,'Paldea',906,1025]
  ];
  const TYPES=['normal','fire','water','electric','grass','ice','fighting','poison','ground','flying','psychic','bug','rock','ghost','dragon','dark','steel','fairy'];
  const norm=v=>String(v||'').trim().toLowerCase().replace(/[’']/g,"'").replace(/[^a-z0-9]+/g,' ').trim();
  const slug=v=>norm(v).replace(/\s+/g,'-')||'unknown';
  function sourceOf(card){if(card?.source==='tcgp')return 'tcgp';if(card?.source==='tcg')return 'tcg';const id=String(card?.setId||card?.set?.id||'').replace(/^library:/i,'');return /^[AB]\d/i.test(id)?'tcgp':'tcg';}
  function cardSetId(card){return String(card?.setId||card?.set?.id||'').replace(/^library:/i,'');}
  function cardSetName(card){return String(card?.setName||card?.set?.name||card?.set||'Unknown set');}
  function descriptor(set,source){const rawId=source==='tcg'?(set?._libraryKey||set?.id||set?.name):(set?.id||set?.name);return {source,id:String(rawId||'').replace(/^library:/i,''),name:String(set?.name||set?.id||'Unknown set'),total:Number(set?.cardCount?.total||set?.total||0)};}
  function setProgress(cards,desc){
    const rows=Object.values(cards||{}).filter(c=>sourceOf(c)===desc.source).filter(c=>{
      const id=cardSetId(c),name=cardSetName(c);return (desc.id&&String(id)===String(desc.id))||norm(name)===norm(desc.name);
    });
    const total=Math.max(Number(desc.total||0),...rows.map(c=>Number(c?.setTotal||c?.set?.cardCount?.total||0)),0);
    const owned=new Set(rows.map(c=>String(c.id||c.localId||c.number||c.name))).size;
    return [owned,total||Math.max(1,owned+1)];
  }
  function buildSetAchievements(physicalSets,pocketSets,getCards){
    const out=[],seen=new Set();
    for(const [source,sets] of [['tcg',physicalSets||[]],['tcgp',pocketSets||[]]]){
      for(const set of sets){
        const d=descriptor(set,source);if(!d.id||!d.name||!d.total)continue;
        const key=`${source}:${d.id}`;if(seen.has(key))continue;seen.add(key);
        const id=`set_${source}_${slug(d.id)}`;
        out.push({id,icon:source==='tcgp'?'◈':'▣',name:`${d.name} Master`,desc:`Collect every card in ${d.name}.`,category:source,_v0341Set:true,reward:{coins:source==='tcgp'?350:450,dust:40,tickets:1},progress:()=>setProgress(getCards?.()||{},d),setDescriptor:d});
      }
    }
    return out;
  }
  function values(obj){return Object.values(obj||{});}
  function uniquePokemon(s,min=1,max=1025){return new Set(values(s?.pokemon).filter(p=>Number(p?.id)>=min&&Number(p?.id)<=max).map(p=>Number(p.id))).size;}
  function uniqueCards(s,source=null){return new Set(values(s?.cards).filter(c=>!source||sourceOf(c)===source).map(c=>String(c.id))).size;}
  function shinyCount(s){return Number(s?.stats?.shinies||values(s?.pokemon).filter(p=>p?.shiny).reduce((n,p)=>n+Number(p.count||1),0));}
  function maxCopies(map){return Math.max(0,...values(map).map(x=>Number(x?.count||0)));}
  function completedSetCount(s,source=null){
    const groups=new Map();
    for(const c of values(s?.cards).filter(c=>!source||sourceOf(c)===source)){
      const key=`${sourceOf(c)}:${cardSetId(c)||norm(cardSetName(c))}`,row=groups.get(key)||{ids:new Set(),total:0};row.ids.add(String(c.id));row.total=Math.max(row.total,Number(c.setTotal||c?.set?.cardCount?.total||0));groups.set(key,row);
    }
    return [...groups.values()].filter(r=>r.total>0&&r.ids.size>=r.total).length;
  }
  function regionalClears(s,id){return Number(s?.adventureRegional?.records?.[id]?.clears||0);}
  function totalRegionalClears(s){return Object.values(s?.adventureRegional?.records||{}).reduce((n,r)=>n+Number(r?.clears||0),0);}
  function dashGoldTypes(s){const records=s?.arcade?.dash?.leagueRecords||{};return Object.values(records).filter(byDifficulty=>Object.values(byDifficulty||{}).some(r=>r?.trophy==='gold')).length;}
  function dashTrophyTypes(s){const records=s?.arcade?.dash?.leagueRecords||{};return Object.values(records).filter(byDifficulty=>Object.values(byDifficulty||{}).some(r=>r?.trophy)).length;}
  function museumCount(s){return values(s?.arcade?.museum?.exhibits).filter(x=>x?.discovered).length;}
  function museumMaxDuplicates(s){return Math.max(0,...values(s?.arcade?.museum?.exhibits).map(x=>Number(x?.foundCount||0)));}
  function def(id,icon,name,desc,category,reward,progress,extra={}){return {id,icon,name,desc,category,reward,progress,...extra};}
  function buildCoreAchievements(getState){
    const s=()=>getState?.()||{};const out=[];
    const push=(...a)=>out.push(def(...a));

    // Pokémon collection & battle history.
    push('catch_1','●','First Partner','Catch your first Pokémon.','pokemon',{coins:150},()=>[Number(s().stats?.catches||0),1]);
    for(const [n,reward] of [[10,250],[50,500],[100,800],[250,1200],[500,1800],[750,2400],[1025,4000]])push(`dex_unique_${n}`,'◆',`${n} Species`, `Own ${n} different Pokémon species.`,'pokemon',{coins:reward,dust:Math.max(20,Math.round(reward/20))},()=>[uniquePokemon(s()),n]);
    for(const [n,reward] of [[10,400],[25,700],[50,1200]])push(`shiny_${n}`,'✨',`${n} Shinies`,`Catch ${n} shiny Pokémon.`,'pokemon',{coins:reward,fragment:n>=25?1:0},()=>[shinyCount(s()),n]);
    for(const [gen,name,min,max] of GEN_RANGES)push(`dex_gen_${gen}`,'◉',`${name} Pokédex`, `Own every species in the ${name} Pokédex range.`,'pokemon',{coins:1800+gen*150,dust:100,tickets:1},()=>[uniquePokemon(s(),min,max),max-min+1]);
    for(const [n,reward] of [[100,300],[500,800],[1000,1500]])push(`encounters_${n}`,'◎',`Seen It All ${n}`,`Record ${n} wild encounters.`,'pokemon',{coins:reward},()=>[Number(s().stats?.encounters||0),n]);
    for(const [n,reward] of [[25,400],[100,900],[500,2000]])push(`battles_${n}`,'⚔',`${n} Victories`,`Win ${n} Pokémon battles.`,'pokemon',{coins:reward,dust:n>=100?50:0},()=>[Number(s().stats?.battlesWon||0),n]);
    push('pokemon_copy_10','◆','A Very Familiar Face','Own 10 copies of the same Pokémon.','pokemon',{coins:500},()=>[maxCopies(s().pokemon),10],{hidden:true});

    // Card collection & pack opening.
    for(const [n,reward] of [[1,100],[10,250],[50,700],[250,1600],[500,2600],[1000,5000]])push(`packs_${n}`,'▣',`${n} Packs Opened`,`Open ${n} booster packs.`,'collection',{coins:reward,dust:n>=50?50:0,tickets:n>=250?2:0},()=>[Number(s().stats?.packs||0),n]);
    for(const [n,reward] of [[100,250],[500,700],[1000,1200],[5000,3000],[10000,5000]])push(`cards_pulled_${n}`,'▤',`${n} Cards Pulled`,`Pull ${n} cards from boosters.`,'collection',{coins:reward,dust:Math.min(250,Math.round(n/20))},()=>[Number(s().stats?.cardsPulled||0),n]);
    for(const [n,reward] of [[50,300],[100,500],[250,900],[500,1500],[1000,3000],[2000,5000]])push(`cards_unique_${n}`,'◇',`${n} Unique Cards`,`Own ${n} unique cards across your binders.`,'collection',{coins:reward,dust:Math.min(300,Math.round(n/5))},()=>[uniqueCards(s()),n]);
    push('tcg_unique_500_gyarados_half_deck','▣','Gyarados Half Deck','Own 500 unique physical TCG cards.','tcg',{fixedProduct:'TK4G',fixedProductName:'HS Trainer Kit—Gyarados'},()=>[uniqueCards(s(),'tcg'),500]);
    push('tcg_unique_1000_raichu_half_deck','▣','Raichu Half Deck','Own 1,000 unique physical TCG cards.','tcg',{fixedProduct:'TK4R',fixedProductName:'HS Trainer Kit—Raichu'},()=>[uniqueCards(s(),'tcg'),1000]);
    for(const [n,reward] of [[1,600],[5,1200],[10,2200],[25,4000],[50,7000]])push(`sets_complete_${n}`,'★',n===1?'Set Complete!':`${n} Complete Sets`,`Complete ${n} card ${n===1?'set':'sets'}.`,'collection',{coins:reward,dust:n*20,tickets:n>=5?Math.min(5,Math.ceil(n/10)):1},()=>[completedSetCount(s()),n]);
    push('sets_tcg_10','▣','Physical Binder Veteran','Complete 10 physical TCG sets.','tcg',{coins:2500,dust:250,tickets:3},()=>[completedSetCount(s(),'tcg'),10]);
    push('sets_tcgp_5','◈','Pocket Collector','Complete 5 TCG Pocket sets.','tcgp',{coins:1800,dust:180,tickets:2},()=>[completedSetCount(s(),'tcgp'),5]);
    for(const [n,reward] of [[1,1000],[2,1800],[5,4000],[10,7500]])push(`god_pack_${n}`,'✦',n===1?'Arceus Smiled Upon Me':`${n} God Packs`,`Find ${n} God Pack${n===1?'':'s'}.`,'tcgp',{coins:reward,dust:n*100,tickets:Math.min(5,n)},()=>[Number(s().stats?.godPacks||0),n]);
    for(const [n,reward] of [[5,700],[10,1400],[25,3000]])push(`gold_cards_${n}`,'♛',`${n} Crown / Gold Pulls`,`Pull ${n} Crown or Gold rarity cards from TCG Pocket.`,'tcgp',{coins:reward,dust:n*20,tickets:n>=10?1:0},()=>[Number(s().stats?.goldCards||0),n]);
    for(const [n,reward] of [[10,400],[25,900],[50,1800]])push(`rare_hits_${n}`,'✧',`${n} Rare Hits`,`Record ${n} rare card pulls.`,'collection',{coins:reward,dust:n*4},()=>[Number(s().rareHits?.length||0),n]);
    push('card_copy_25','▤','Print Run','Own 25 copies of one card.','collection',{coins:600,dust:75},()=>[maxCopies(s().cards),25],{hidden:true});
    push('card_copy_50','▤','Warehouse Stock','Own 50 copies of one card.','collection',{coins:1200,dust:150},()=>[maxCopies(s().cards),50],{hidden:true});

    // Regional Adventure.
    push('regional_clear_1','♛','Regional Champion','Complete your first Regional Adventure.','adventure',{coins:1200,dust:75,tickets:1},()=>[totalRegionalClears(s()),1]);
    push('regional_kanto','🔴','Kanto Champion','Defeat Kanto’s Champion.','adventure',{coins:1800,dust:100,tickets:2},()=>[regionalClears(s(),'kanto'),1]);
    push('regional_johto','🟡','Johto Champion','Defeat Johto’s Champion.','adventure',{coins:1800,dust:100,tickets:2},()=>[regionalClears(s(),'johto'),1]);
    push('regional_hoenn','🟢','Hoenn Champion','Defeat Hoenn’s Champion.','adventure',{coins:2000,dust:125,tickets:2},()=>[regionalClears(s(),'hoenn'),1]);
    for(const [n,reward] of [[3,1500],[10,3500],[25,7000]])push(`regional_clears_${n}`,'♜',`${n} Regional Clears`,`Complete ${n} Regional Adventure runs.`,'adventure',{coins:reward,dust:n*15,tickets:Math.min(4,Math.ceil(n/5))},()=>[totalRegionalClears(s()),n]);
    push('legacy_adventure_10','🗺','Seasoned Explorer','Complete 10 Adventure runs across any supported mode.','adventure',{coins:1800,dust:100,tickets:2},()=>[Number(s().stats?.adventureClears||0),10]);

    // Arcade-wide and individual minigames.
    for(const [n,reward] of [[10,250],[50,700],[100,1200],[500,3500]])push(`arcade_games_${n}`,'✦',`${n} Arcade Runs`,`Finish ${n} Arcade games.`,'arcade',{coins:reward,tickets:n>=100?1:0},()=>[Number(s().stats?.arcadeGames||0),n]);
    for(const [n,reward] of [[1000,300],[50000,2500],[100000,5000]])push(`arcade_coins_${n}`,'◉',`${n.toLocaleString()} Arcade Coins`,`Earn ${n.toLocaleString()} Lucky Coins from Arcade games.`,'arcade',{coins:reward,tickets:n>=50000?2:0},()=>[Number(s().stats?.arcadeCoins||0),n]);
    for(const [n,reward] of [[5,300],[10,600],[25,1200]])push(`berry_perfect_${n}`,'🍓',`${n} Perfect Blends`,`Hit ${n} perfect Berry Blender rounds.`,'arcade',{coins:reward,dust:n*2},()=>[Number(s().stats?.perfectBerryRounds||0),n]);
    for(const [n,reward] of [[10,500],[25,1200],[50,2500]])push(`quiz_endless_${n}`,'?',`${n} Silhouettes`,`Reach an Endless Who’s That Pokémon? streak of ${n}.`,'arcade',{coins:reward,tickets:n>=25?1:0},()=>[Number(s().arcade?.bestQuizEndless||0),n]);
    for(const [n,reward] of [[5,800],[10,1600]])push(`ball_drop_jackpots_${n}`,'●',`${n} Jackpots`,`Land ${n} Poké Ball Drop jackpots across your career.`,'arcade',{coins:reward,tickets:n>=10?2:1},()=>[Number(s().arcade?.ballDropJackpots||0),n]);
    push('unown_perfect_5','🔤','Unown Linguist','Decode five perfect Unown runs.','arcade',{coins:1500,tickets:2},()=>[Number(s().arcade?.unownPerfect||0),5]);
    push('safari_50','◆','Safari Veteran','Catch 50 Pokémon across Safari runs.','arcade',{coins:1600,dust:75},()=>[Number(s().arcade?.safariCaught||0),50]);
    for(const [n,reward] of [[1,150],[10,450],[50,1300],[100,2600]])push(`dash_races_${n}`,'➤',`${n} Dash Races`,`Finish ${n} Pokémon Dash races.`,'arcade',{coins:reward,dust:n>=50?50:0},()=>[Number(s().arcade?.dash?.races||0),n]);
    for(const [n,reward] of [[1,300],[10,900],[50,2500]])push(`dash_wins_${n}`,'🏁',n===1?'First Across the Line':`${n} Dash Wins`,`Win ${n} Pokémon Dash races.`,'arcade',{coins:reward,tickets:n>=50?2:n>=10?1:0},()=>[Number(s().arcade?.dash?.wins||0),n]);
    push('dash_podium_25','◆','Podium Regular','Finish on the Pokémon Dash podium 25 times.','arcade',{coins:1000,dust:50},()=>[Number(s().arcade?.dash?.podiums||0),25]);
    push('dash_trophy_5','🏆','League Contender','Earn a trophy in 5 different Type Leagues.','arcade',{coins:1000,tickets:1},()=>[dashTrophyTypes(s()),5]);
    push('dash_gold_1','🥇','Type League Champion','Earn your first Gold Type League trophy.','arcade',{coins:900,dust:50,tickets:1},()=>[dashGoldTypes(s()),1]);
    push('dash_gold_5','🥇','Five-Type Champion','Earn Gold trophies in 5 different Type Leagues.','arcade',{coins:1800,dust:100,tickets:2},()=>[dashGoldTypes(s()),5]);
    push('dash_all_types_gold','🏆','Master of All Types','Earn a Gold trophy in all 18 Type Leagues.','arcade',{coins:6000,dust:500,tickets:5},()=>[dashGoldTypes(s()),18]);

    // Ekans' Hoop Hurl.
    push('ekans_first_ring','◉','First Ring','Land your first Hoop Hurl target.','arcade',{coins:150},()=>[Number(s().arcade?.ekansHoop?.totalHoops||0),1]);
    push('ekans_hoops_25','◉','Snake Charmer','Land 25 Hoop Hurl targets across your career.','arcade',{coins:350,dust:20},()=>[Number(s().arcade?.ekansHoop?.totalHoops||0),25]);
    push('ekans_hoops_100','◉','Hoop Veteran','Land 100 Hoop Hurl targets across your career.','arcade',{coins:900,dust:50},()=>[Number(s().arcade?.ekansHoop?.totalHoops||0),100]);
    push('ekans_streak_12','↗','On a Roll','Reach a 12-hit Hoop Hurl streak.','arcade',{coins:600,tickets:1},()=>[Number(s().arcade?.ekansHoop?.bestStreak||0),12]);
    push('ekans_score_80','◎','Master Hooper','Score 80 or more in a single Hoop Hurl round.','arcade',{coins:1000,dust:75},()=>[Number(s().arcade?.ekansHoop?.bestScore||0),80]);
    push('ekans_shiny_1','✨','Shiny Ringer','Hit your first shiny target in Hoop Hurl.','arcade',{coins:750,dust:50},()=>[Number(s().arcade?.ekansHoop?.shinyHits||0),1],{hidden:true});
    push('ekans_shiny_5','✨','Shiny Sharpshooter','Hit five shiny targets in Hoop Hurl.','arcade',{coins:2000,tickets:1},()=>[Number(s().arcade?.ekansHoop?.shinyHits||0),5],{hidden:true});

    // Dig! Dig! Dig!.
    push('dig_first_win','⛏','Down We Go','Win your first Dig! Dig! Dig! race.','arcade',{coins:200},()=>[Number(s().arcade?.digDigDig?.wins||0),1]);
    push('dig_wins_10','⛏','Tunnel Vision','Win 10 Dig! Dig! Dig! races.','arcade',{coins:800,dust:40},()=>[Number(s().arcade?.digDigDig?.wins||0),10]);
    push('dig_hard_win','◆','Hard Ground','Win Dig! Dig! Dig! on Hard.','arcade',{coins:600,dust:30},()=>[Number(s().arcade?.digDigDig?.winsByDifficulty?.hard||0),1]);
    push('dig_time_12000','↯','Rapid Excavator','Finish Dig! Dig! Dig! in 12 seconds or less.','arcade',{coins:900,dust:60},()=>{const t=Number(s().arcade?.digDigDig?.bestTimeMs);return [t>0?Math.max(0,24000-t):0,12000];});

    // Museum / excavation display progression.
    for(const [n,reward] of [[1,250],[5,600],[10,1200],[20,2500]])push(`museum_exhibits_${n}`,'🏛',n===1?'First Exhibit':`${n} Museum Exhibits`,`Discover ${n} different museum exhibits.`,'museum',{coins:reward,dust:n*5,tickets:n>=20?2:n>=10?1:0},()=>[museumCount(s()),n]);
    push('museum_repeat_10','⛏','Favourite Exhibit','Excavate the same museum item 10 times.','museum',{coins:700,dust:75},()=>[museumMaxDuplicates(s()),10],{hidden:true});

    // Secrets that can be derived from durable state, not one-frame events.
    push('secret_zubat_5','🦇','Bat Country','Encounter Zubat five times in a row.','pokemon',{coins:500},()=>[Number(s().stats?.maxZubatStreak||0),5],{hidden:true});
    push('secret_fails_25','◌','The Ball Said No','Fail 25 catches across your play history.','pokemon',{coins:500},()=>[Number(s().stats?.failedCatches||0),25],{hidden:true});
    push('secret_loaded_4','✹','Stacked Deck','Pull four or more high-rarity cards from one pack.','collection',{coins:1200,dust:100,tickets:1},()=>[Number(s().stats?.maxBigHitsInPack||0),4],{hidden:true});
    push('secret_quiz_75','?','Professor’s Nightmare','Reach a 75-answer Endless silhouette streak.','arcade',{coins:3000,tickets:3},()=>[Number(s().arcade?.bestQuizEndless||0),75],{hidden:true});
    push('secret_dash_100_wins','➤','Blink and You Missed It','Win 100 Pokémon Dash races.','arcade',{coins:4000,dust:250,tickets:3},()=>[Number(s().arcade?.dash?.wins||0),100],{hidden:true});

    return out;
  }

  function install(){
    if(typeof document==='undefined'||typeof ACHIEVEMENTS==='undefined'||typeof state==='undefined')return false;
    const categoryById={first_shiny:'pokemon',ghost10:'pokemon',kanto_all:'pokemon',celestial_storm:'tcg',gold_card:'tcgp',haunted_visit:'adventure',haunted_clear:'adventure',packs25:'collection',packs100:'collection',arcade10k:'arcade',five_shiny:'pokemon',zubat3:'pokemon',fails3:'pokemon',loaded_pack:'collection',quiz_endless_20:'arcade',ball_drop_jackpot:'arcade',unown_perfect:'arcade',safari_ten:'arcade'};
    let category='all';
    const baseRewardText=rewardText;
    rewardText=function(r={}){const base=baseRewardText(r),dust=Number(r?.dust||0),fixed=String(r?.fixedProductName||'').trim();const extra=`✦ ${fmt(dust)} Dust`;const withDust=dust?(base?`${base} · ${extra}`:extra):base;return fixed?(withDust?`${withDust} · ${fixed}`:fixed):withDust;};
    const fixedRewardClaims=new Set();
    claimAchievement=async function(id){
      const a=ACHIEVEMENTS.find(x=>x.id===id);if(!a)return;const p=achievementProgress(a);if(!p.complete||p.claimed||fixedRewardClaims.has(id))return;
      if(a.reward?.fixedProduct){
        const grant=root.LuckyDexPackFlow?.grantFixedProductReward;if(typeof grant!=='function'){showToast('Half Deck reward is still loading. Try again in a moment.');return;}
        fixedRewardClaims.add(id);
        try{await grant(a.reward.fixedProduct);}catch(error){console.warn('[LuckyDex] fixed achievement reward failed',error);showToast('Could not grant that Half Deck yet. Please try again.');return;}finally{fixedRewardClaims.delete(id);}
      }
      state.profile.achievementClaims.push(id);state.profile.coins+=Number(a.reward?.coins||0);state.profile.tickets+=Number(a.reward?.tickets||0);state.profile.dust+=Number(a.reward?.dust||0);state.profile.shinyCharmFragments+=Number(a.reward?.fragment||0);if(a.reward?.card)queueAchievementCardRewardV0246(a.reward.card);addTrainerXp(100+Number(a.reward?.fragment||0)*100);save();vibrate([20,25,60]);showToast(`${a.name} complete · ${rewardText(a.reward)}`,2800);renderAchievements();renderProfile();if(a.reward?.card)await fulfilPendingAchievementRewardsV0246();
    };
    function annotateExisting(){for(const a of ACHIEVEMENTS){if(!a.category)a.category=categoryById[a.id]||(a.hidden?'collection':'collection');}}
    function addCore(){const existing=new Set(ACHIEVEMENTS.map(a=>a.id));for(const a of buildCoreAchievements(()=>state)){if(!existing.has(a.id)){ACHIEVEMENTS.push(a);existing.add(a.id);}}}
    function physicalSets(){try{return [...(setCache?.tcg||[])];}catch(_){return [];}}
    function pocketSets(){try{return [...(root.LuckyDexPocket?.BUILTIN_SETS||[])];}catch(_){return [];}}
    function syncSets(){
      for(let i=ACHIEVEMENTS.length-1;i>=0;i--)if(ACHIEVEMENTS[i]?._v0341Set)ACHIEVEMENTS.splice(i,1);
      const generated=buildSetAchievements(physicalSets(),pocketSets(),()=>state.cards||{});
      for(const a of generated){if(a.category==='tcg'&&norm(a.setDescriptor?.name)==='celestial storm'&&ACHIEVEMENTS.some(x=>x.id==='celestial_storm'))continue;ACHIEVEMENTS.push(a);}
    }
    function sync(){annotateExisting();addCore();syncSets();annotateExisting();}
    function render(){
      sync();const list=document.getElementById('achievementList');if(!list)return;
      const rows=ACHIEVEMENTS.map(a=>({a,p:achievementProgress(a)})),earned=rows.filter(x=>x.p.complete).length,pill=document.getElementById('achievementCountPill');if(pill)pill.textContent=`${earned}/${ACHIEVEMENTS.length} earned`;
      let shown=rows.filter(({a,p})=>challengeTab==='complete'?p.complete&&!a.hidden:challengeTab==='hidden'?a.hidden:(!a.hidden&&!p.claimed));
      if(category!=='all')shown=shown.filter(({a})=>a.category===category);
      if(challengeTab==='active')shown.sort((x,y)=>Number(y.p.complete)-Number(x.p.complete)||(y.p.value/y.p.target)-(x.p.value/x.p.target)||String(x.a.name).localeCompare(String(y.a.name)));
      else shown.sort((x,y)=>String(x.a.category).localeCompare(String(y.a.category))||String(x.a.name).localeCompare(String(y.a.name)));
      list.innerHTML=shown.length?shown.map(({a,p})=>{const secret=a.hidden&&!p.complete,pct=clamp(p.value/p.target*100,0,100),cat=CATEGORIES[a.category]||a.category||'Collection';return `<div class="achievement-row ${p.complete?'complete':''} ${p.claimed?'claimed':''} ${secret?'secret-card':''}"><div class="achievement-icon">${secret?'?':a.icon}</div><div><b>${secret?'Secret achievement':escapeHtml(a.name)}</b><span>${secret?'Keep exploring Lucky Dex to uncover this.':escapeHtml(a.desc)}</span>${!secret?`<span class="achievement-category">${escapeHtml(cat)}</span><div class="progress-track"><i style="width:${pct}%"></i></div><small>${Math.min(p.value,p.target)} / ${p.target}</small>`:''}</div><div>${!secret?`<span class="achievement-reward">${rewardText(a.reward)}</span>`:''}${p.complete&&!p.claimed?`<button class="primary" data-claim-achievement="${a.id}">CLAIM</button>`:p.claimed?'<span class="achievement-reward">✓ CLAIMED</span>':''}</div></div>`;}).join(''):'<div class="empty compact-empty">Nothing in this category yet.</div>';
      list.querySelectorAll('[data-claim-achievement]').forEach(b=>b.onclick=()=>claimAchievement(b.dataset.claimAchievement));
    }
    renderAchievements=render;
    const select=document.getElementById('achievementCategoryFilter');if(select){select.value='all';select.addEventListener('change',()=>{category=select.value||'all';renderAchievements();});}
    sync();
    return true;
  }

  return {CATEGORIES,GEN_RANGES,TYPES,sourceOf,setProgress,buildSetAchievements,buildCoreAchievements,install};
});
