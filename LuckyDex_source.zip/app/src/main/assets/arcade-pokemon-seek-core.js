(function(root,factory){
  const api=factory();
  if(typeof module!=='undefined'&&module.exports)module.exports=api;
  root.LuckyDexPokemonSeekCore=api;
})(typeof window!=='undefined'?window:globalThis,function(){
  'use strict';

  const CONFIG=Object.freeze({
    durationMs:90000,
    foundScore:5000,
    lostItemScore:5000,
    dreamScore:2500,
    timeScorePerSecond:500,
    dreamRate:.02
  });
  const DIFFICULTIES=Object.freeze({
    easy:Object.freeze({key:'easy',label:'Easy',decoys:3,rustleChance:.9}),
    normal:Object.freeze({key:'normal',label:'Normal',decoys:5,rustleChance:.68}),
    hard:Object.freeze({key:'hard',label:'Hard',decoys:7,rustleChance:.48})
  });
  const TARGETS=Object.freeze([
    {dex:172,label:'Pichu'},{dex:173,label:'Cleffa'},{dex:280,label:'Ralts'},{dex:238,label:'Smoochum'},
    {dex:360,label:'Wynaut'},{dex:438,label:'Bonsly'},{dex:406,label:'Budew'},{dex:446,label:'Munchlax'},
    {dex:425,label:'Drifloon'},{dex:278,label:'Wingull'},{dex:333,label:'Swablu'},{dex:441,label:'Chatot'},
    {dex:327,label:'Spinda'},{dex:231,label:'Phanpy'}
  ]);
  const HIDING_PLACES=Object.freeze(['CURTAIN','BOOKCASE','PLANTER','CHEST','ARMCHAIR','CLOCK','STATUE','CABINET']);
  const clamp=(n,a,b)=>Math.max(a,Math.min(b,Number(n)||0));
  const rand=rng=>clamp((rng||Math.random)(),0,.999999);
  const pick=(arr,rng)=>arr[Math.floor(rand(rng)*arr.length)]||arr[0];

  function difficultyProfile(key){return DIFFICULTIES[key]||DIFFICULTIES.normal;}
  function roomXY(index){const n=Math.max(0,Math.min(8,Math.floor(Number(index)||0)));return {x:n%3,y:Math.floor(n/3)};}
  function roomDistance(a,b){const aa=roomXY(a),bb=roomXY(b);return Math.abs(aa.x-bb.x)+Math.abs(aa.y-bb.y);}
  function roomsWithin(target,maxDistance){return Array.from({length:9},(_,i)=>i).filter(i=>roomDistance(i,target)<=maxDistance);}
  function chooseNearbyRoom(target,maxDistance,rng,{avoid=null}={}){
    let candidates=roomsWithin(target,maxDistance).filter(i=>i!==avoid);
    if(!candidates.length)candidates=roomsWithin(target,maxDistance);
    return pick(candidates,rng);
  }
  function makeRooms(rng){
    return Array.from({length:9},(_,roomIndex)=>({
      index:roomIndex,
      spots:[0,1].map(slot=>({id:`room-${roomIndex}-spot-${slot}`,label:HIDING_PLACES[(roomIndex*2+slot+Math.floor(rand(rng)*HIDING_PLACES.length))%HIDING_PLACES.length],kind:'empty',pokemon:null,searched:false,rustle:false}))
    }));
  }
  function createRun({difficulty='normal',rng=Math.random,dreamRate=CONFIG.dreamRate}={}){
    const profile=difficultyProfile(difficulty),rooms=makeRooms(rng),target=pick(TARGETS,rng),targetRoom=Math.floor(rand(rng)*9),targetSlot=Math.floor(rand(rng)*2);
    rooms[targetRoom].spots[targetSlot].kind='target';
    rooms[targetRoom].spots[targetSlot].pokemon=target;
    rooms[targetRoom].spots[targetSlot].rustle=rand(rng)<Math.min(1,profile.rustleChance+.12);

    const used=new Set([`${targetRoom}:${targetSlot}`]);
    let decoys=0,guard=0;
    while(decoys<profile.decoys&&guard++<80){
      const room=Math.floor(rand(rng)*9),slot=Math.floor(rand(rng)*2),key=`${room}:${slot}`;
      if(used.has(key))continue;
      const options=TARGETS.filter(p=>p.dex!==target.dex),pokemon=pick(options,rng),spot=rooms[room].spots[slot];
      used.add(key);spot.kind='pokemon';spot.pokemon=pokemon;spot.rustle=rand(rng)<profile.rustleChance;decoys++;
    }

    const itemRoom=chooseNearbyRoom(targetRoom,2,rng,{avoid:null});
    const rate=clamp(dreamRate,0,1),dreamEvent=rate>0&&rand(rng)<rate,dreamRoom=dreamEvent?chooseNearbyRoom(targetRoom,2,rng,{avoid:null}):null;
    return {
      difficulty:profile.key,elapsedMs:0,currentRoom:4,target,targetRoom,rooms,itemRoom,itemFound:false,
      dreamEvent,dreamRoom,dreamFound:false,dreamSeen:false,foundTarget:false,complete:false,
      listens:0,wrongFinds:0,emptySearches:0,searchedSpots:0,visitedRooms:[4]
    };
  }
  function move(run,direction){
    if(!run||run.complete)return false;const {x,y}=roomXY(run.currentRoom);let nx=x,ny=y;
    if(direction==='left')nx--;else if(direction==='right')nx++;else if(direction==='up')ny--;else if(direction==='down')ny++;else return false;
    if(nx<0||nx>2||ny<0||ny>2)return false;run.currentRoom=ny*3+nx;if(!run.visitedRooms.includes(run.currentRoom))run.visitedRooms.push(run.currentRoom);return true;
  }
  function listenHint(run){
    if(!run)return {distance:Infinity,message:''};run.listens=Number(run.listens||0)+1;const distance=roomDistance(run.currentRoom,run.targetRoom),name=run.target?.label||'Pokémon';let message;
    if(distance===0)message=`The voice is very close! ${name} must be here!`;
    else if(distance===1)message=`You can hear the voice! ${name} is near here!`;
    else if(distance===2)message=`The voice is faint. ${name} is not far from here!`;
    else message=`You can't hear the voice of ${name}.`;
    return {distance,message};
  }
  function currentRoom(run){return run?.rooms?.[run.currentRoom]||null;}
  function search(run,spotId){
    if(!run||run.complete)return {accepted:false,reason:'inactive'};const room=currentRoom(run),spot=room?.spots?.find(s=>s.id===spotId);if(!spot)return {accepted:false,reason:'missing'};
    if(spot.searched)return {accepted:false,reason:'searched',spot};spot.searched=true;run.searchedSpots++;
    if(spot.kind==='target'){run.foundTarget=true;run.complete=true;return {accepted:true,foundTarget:true,kind:'target',pokemon:spot.pokemon,spot};}
    if(spot.kind==='pokemon'){run.wrongFinds++;return {accepted:true,foundTarget:false,kind:'pokemon',pokemon:spot.pokemon,spot};}
    run.emptySearches++;return {accepted:true,foundTarget:false,kind:'empty',pokemon:null,spot};
  }
  function collectLostItem(run){
    if(!run||run.itemFound||run.currentRoom!==run.itemRoom)return {collected:false};run.itemFound=true;return {collected:true,score:CONFIG.lostItemScore};
  }
  function collectDreamSparkle(run){
    if(!run||!run.dreamEvent||run.dreamFound||run.currentRoom!==run.dreamRoom)return {collected:false};run.dreamSeen=true;run.dreamFound=true;return {collected:true,score:CONFIG.dreamScore};
  }
  function markDreamSeen(run){if(run?.dreamEvent&&run.currentRoom===run.dreamRoom)run.dreamSeen=true;return !!run?.dreamSeen;}
  function remainingMs(run){return Math.max(0,CONFIG.durationMs-Math.max(0,Number(run?.elapsedMs)||0));}
  function finalScore(run){
    if(!run)return 0;let score=0;if(run.foundTarget){score+=CONFIG.foundScore+Math.floor(remainingMs(run)/1000)*CONFIG.timeScorePerSecond;}if(run.itemFound)score+=CONFIG.lostItemScore;if(run.dreamFound)score+=CONFIG.dreamScore;return Math.max(0,Math.round(score));
  }
  function rewardForRun(run){const score=finalScore(run),mult=run?.difficulty==='hard'?1.12:run?.difficulty==='easy'?.94:1;return Math.max(20,Math.round(Math.min(650,30+score/110)*mult));}
  function roomLabel(index){const {x,y}=roomXY(index);return `${String.fromCharCode(65+x)}${y+1}`;}
  function snapshot(run){return run?JSON.parse(JSON.stringify(run)):null;}
  return Object.freeze({CONFIG,DIFFICULTIES,TARGETS,HIDING_PLACES,difficultyProfile,roomXY,roomDistance,roomsWithin,createRun,move,listenHint,currentRoom,search,collectLostItem,collectDreamSparkle,markDreamSeen,remainingMs,finalScore,rewardForRun,roomLabel,snapshot});
});
