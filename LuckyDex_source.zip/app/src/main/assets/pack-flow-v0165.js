/* The single pack orchestration path. Existing v0.13 caches and the existing
   commitPreparedPack economy function remain the persistence authorities. */
let packRun=null;
let packEpoch=0;
const catalogJobs=new Map();
const validatedPackArt=new Map();

function packStageLoading(copy='Preparing artwork…') {
  const stage=document.getElementById('packStage');stage.hidden=false;document.body.classList.add('pack-opening');
  stage.innerHTML=`<button class="pack-exit" id="packExitBtn">‹ SHOP</button><div class="loading pack-loading"><div class="spinner"></div><b>${escapeHtml(copy)}</b></div>`;
  document.getElementById('packExitBtn').onclick=()=>closePackOpening();return stage;
}
function cancelPackRun() {
  packEpoch++;
  if(!packRun)return;
  packRun.reveal?.destroy();packRun.abort.abort();
  packRun.urls.forEach(url=>URL.revokeObjectURL(url));packRun.urls.clear();packRun=null;
}
function newPackRun() {
  cancelPackRun();
  return packRun={epoch:packEpoch,abort:new AbortController(),urls:new Set(),art:new Map(),reveal:null};
}
function validPackRun(run) {return run===packRun&&!run.abort.signal.aborted;}
function packDelay(ms,signal) {
  return new Promise(resolve=>{
    let timer=null;
    const finish=value=>{clearTimeout(timer);signal.removeEventListener('abort',abort);resolve(value);};
    const abort=()=>finish(false);
    if(signal.aborted){resolve(false);return;}
    signal.addEventListener('abort',abort,{once:true});timer=setTimeout(()=>finish(true),ms);
  });
}
async function packFetch(url,signal,timeout=4500) {
  if(!isOnlineV13())throw new Error('offline');
  const controller=new AbortController(),abort=()=>controller.abort();
  if(signal?.aborted)controller.abort();signal?.addEventListener('abort',abort,{once:true});
  const timer=setTimeout(abort,timeout);
  try{const response=await fetch(url,{signal:controller.signal});if(!response.ok)throw new Error(String(response.status));return await response.json();}
  finally{clearTimeout(timer);signal?.removeEventListener('abort',abort);}
}
function renderSetOptionsV13(source,sets) {
  const select=document.getElementById('setSelect');if(!select)return;
  const old=select.value, ordered=LuckyDexPack.orderSets((sets||[]).filter(s=>s.cardCount?.total>0));
  setCache[source]=ordered;
  if(document.getElementById('cardSource').value!==source)return;
  select.innerHTML=ordered.map(s=>`<option value="${escapeHtml(s.id)}">${escapeHtml((LuckyDexPack.dateValue(s.releaseDate)!==null?s.releaseDate+' · ':'')+s.name)} (${s.cardCount.total})</option>`).join('');
  if(ordered.some(s=>s.id===old))select.value=old;
  try{updatePackButton();}catch(e){console.error('[LuckyDex] pack HUD update failed',e);}
  Promise.resolve().then(()=>updateOfflineHintV13()).catch(e=>console.error('[LuckyDex] offline hint failed',e));
}
async function loadSets(source) {
  const select=document.getElementById('setSelect');if(!select)return;
  let stored=readCatalogCacheV13()[source]?.sets||[];

  // v0.16.5: the deterministic LuckyDex artwork catalogue is the preferred
  // physical-TCG source. Each row maps to one validated set ZIP. If the draft
  // library is not reachable yet, retain the old TCGdex catalogue as a safe
  // transition fallback rather than leaving the pack shop empty.
  if(source==='tcg'&&window.LuckyDexCardArt){
    const localStored=stored.filter(s=>s?._libraryKey);
    if(localStored.length)renderSetOptionsV13(source,localStored);
    try{
      const exactSets=await LuckyDexCardArt.catalog();
      if(exactSets.length){saveCatalogCacheV13(source,exactSets);renderSetOptionsV13(source,exactSets);return exactSets;}
    }catch(error){console.warn('[LuckyDex] exact card-art catalogue unavailable',error);}
    if(localStored.length){updatePackButton();return localStored;}
  }

  // Pocket has a complete built-in set index. Render it synchronously and
  // never leave Android's native <select> sitting on "Loading sets…" while a
  // CDN/catalogue request is in flight.
  if(source==='tcgp'&&window.LuckyDexPocket){
    const immediate=LuckyDexPocket.mergeCatalog(stored);
    if(immediate.length){saveCatalogCacheV13(source,immediate);renderSetOptionsV13(source,immediate);}
    updatePackButton();updatePackFormatV5?.();
    // Refresh names/counts in the background only. The result is optional.
    if(isOnlineV13()&&!catalogJobs.has(source)){
      const job=LuckyDexPocket.catalog().then(sets=>{if(Array.isArray(sets)&&sets.length){saveCatalogCacheV13(source,sets);renderSetOptionsV13(source,sets);}}).catch(()=>{}).finally(()=>catalogJobs.delete(source));
      catalogJobs.set(source,job);
    }
    return immediate;
  }

  let cached=stored;
  try{cached=await LuckyDexPack.enrichSets(stored,{online:false,cached:id=>cachedSetV13(id,source)});}catch(_){cached=stored;}
  if(cached.length)saveCatalogCacheV13(source,cached);
  if(cached.length)renderSetOptionsV13(source,cached);
  if(!isOnlineV13()){
    if(!cached.length && document.getElementById('cardSource').value===source)select.innerHTML='<option value="">Connect once to sync set list</option>';
    updatePackButton();return cached;
  }
  if(catalogJobs.has(source))return catalogJobs.get(source);
  const job=(async()=>{
    if(!cached.length&&document.getElementById('cardSource').value===source)select.innerHTML='<option value="">Syncing release dates…</option>';
    try{
      const all=await packFetch(`${API.tcgSets}?sort:field=releaseDate&sort:order=DESC`,null,5000);
      let pocket=[...(setCache.tcgp||[]),...(window.LuckyDexPocket?.BUILTIN_SETS||[])];
      try{pocket.push(...((await packFetch(API.tcgSeries('tcgp'),null,3500)).sets||[]));}catch(_){ }
      const ids=new Set(pocket.map(s=>s.id));let sets=(all||[]).filter(s=>!ids.has(s.id)&&s.cardCount?.total>0);
      const previous=new Map(cached.map(s=>[s.id,s]));
      const enriched=await LuckyDexPack.enrichSets(sets,{
        online:isOnlineV13(),cached:id=>{const full=cachedSetV13(id,source);return LuckyDexPack.dateValue(full?.releaseDate)!==null?full:previous.get(id);},
        detail:id=>packFetch(API.tcgSet(id),null,3500),
        persist:s=>{previous.set(s.id,s);saveCatalogCacheV13(source,LuckyDexPack.orderSets(sets.map(row=>previous.get(row.id)||row)));}
      });
      saveCatalogCacheV13(source,enriched);renderSetOptionsV13(source,enriched);return enriched;
    }catch(_){if(!cached.length&&document.getElementById('cardSource').value===source)select.innerHTML='<option value="">Could not sync sets</option>';return cached;}
    finally{catalogJobs.delete(source);updatePackButton();}
  })();
  catalogJobs.set(source,job);return job;
}
async function packCachedBlob(id) {
  try{
    const db=await packDbV131();
    return await new Promise((resolve,reject)=>{const tx=db.transaction('images','readonly'),request=tx.objectStore('images').get(id);request.onsuccess=()=>resolve(request.result||null);request.onerror=()=>reject(request.error);});
  }catch(_){return null;}
}
async function packArtworkIsUsable(card,blob) {
  if(!blob?.size)return /^data:/i.test(card.image||'')?LuckyDexPack.decodeImage(card.image):false;
  let fingerprint=null;
  if(window.crypto?.subtle){
    const digest=await crypto.subtle.digest('SHA-256',await blob.arrayBuffer());
    fingerprint=Array.from(new Uint8Array(digest)).map(n=>n.toString(16).padStart(2,'0')).join('');
    const cached=validatedPackArt.get(card.id);if(cached?.fingerprint===fingerprint)return cached.usable;
  }
  const usable=(async()=>{const url=URL.createObjectURL(blob);try{return await LuckyDexPack.decodeImage(url);}finally{URL.revokeObjectURL(url);}})();
  if(fingerprint)validatedPackArt.set(card.id,{fingerprint,usable});return usable;
}
async function packArtworkCandidatesV163(card,run) {
  if(!validPackRun(run))return [];
  const urls=[],seen=new Set(),add=url=>{url=String(url||'');if(url&&!seen.has(url)){seen.add(url);urls.push(url);}};
  if(window.LuckyDexCardArt&&(card?._libraryNative||card?._librarySetKey)){
    try{const local=await LuckyDexCardArt.resolveLocal(card,preparedPack?.set||card?.set||null);if(local)add(local);}catch(_){ }
    if(urls.length)return urls;
  }
  if(!isOnlineV13())return [];
  const addBase=base=>{if(!base)return;add(cardImage(base,'high','webp'));add(cardImage(base,'high','png'));add(cardImage(base,'low','webp'));add(cardImage(base,'low','png'));};
  const source=preparedPack?.source||card?.source||'tcg';

  // v0.16.4: candidates must preserve card identity.  v0.16.3 guessed a
  // Limitless URL from "set code + local collector number".  That is unsafe
  // for reprint/subset catalogues whose local numbering differs from the image
  // provider (30th Classic #015 -> main-set #015 was the visible failure).
  // Resolve by exact card identity first; a missing image is preferable to a
  // confidently wrong image/name pairing.
  const original=card.image||deriveCardBase(card,preparedPack?.set);
  if(source==='tcg'){
    try{
      const alternate=await pokemonTcgArtworkBaseV5(card,preparedPack?.set,run.abort.signal);
      if(alternate)addBase(alternate);
      if(card._ptcgImageLarge)add(card._ptcgImageLarge);
      if(card._ptcgImageSmall)add(card._ptcgImageSmall);
    }catch(e){if(run.abort.signal.aborted)return [];}
    try{
      const scrydex=await scrydexArtworkBaseV164(card,preparedPack?.set,run.abort.signal);
      if(scrydex)addBase(scrydex);
      if(card._scrydexImageLarge)add(card._scrydexImageLarge);
      if(card._scrydexImageSmall)add(card._scrydexImageSmall);
    }catch(e){if(run.abort.signal.aborted)return [];}
    // This helper now emits only URLs carrying an explicit identity bridge.
    try{for(const url of physicalCardArtworkCandidatesV163(card,preparedPack?.set))add(url);}catch(_){ }
  }

  // TCGdex/Pocket bases are tied to the card record itself, so they remain
  // valid fallbacks.  Never resurrect an old unverified Limitless URL here.
  const safeBase=base=>!/limitlesstcg\.nyc3\.cdn\.digitaloceanspaces\.com/i.test(String(base||''));
  if(safeBase(card.image))addBase(card.image);
  if(source==='tcgp')for(const url of (card._tcgpFallbacks||[]))add(url);
  if(card._tcgdexImage&&safeBase(card._tcgdexImage))addBase(card._tcgdexImage);
  if(original&&original!==card.image&&safeBase(original))addBase(original);

  if(!urls.length){
    try{const resolved=await resolveCardArtwork(card,preparedPack?.set,source,run.abort.signal);if(safeBase(resolved)||card._artIdentityVerified)addBase(resolved);}catch(e){if(run.abort.signal.aborted)return [];}
  }
  card._remoteArtworkCandidatesV151=urls.slice();
  return urls;
}

async function cacheRemotePackArtworkV163(card,url,run) {
  if(!validPackRun(run)||!isOnlineV13()||!url||/^(?:data:|blob:)/i.test(url)||window.LuckyDexCardArt?.isLocalUrl?.(url))return;
  const controller=new AbortController(),abort=()=>controller.abort();run.abort.signal.addEventListener('abort',abort,{once:true});
  const timer=setTimeout(abort,10000);
  try{
    const response=await fetch(url,{signal:controller.signal,cache:'force-cache'});if(!response.ok)return;
    const blob=await response.blob();if(!blob.size||!validPackRun(run))return;
    // The card has already decoded from this same URL for display. Avoid doing
    // a second expensive decode here; persist the bytes for airplane-mode use.
    await putOfflineImageV131(card.id,blob);updateOfflineHintV13();
  }catch(_){}finally{clearTimeout(timer);run.abort.signal.removeEventListener('abort',abort);}
}

async function packNetworkBlob(card,run) {
  // Retained for compatibility with older callers. v0.16.3 displays verified
  // remote URLs immediately and caches them in the background instead of
  // blocking the reveal on a cross-origin blob fetch.
  const urls=await packArtworkCandidatesV163(card,run);
  for(const url of urls){
    if(!validPackRun(run)||!isOnlineV13())return null;
    try{
      if(await LuckyDexPack.decodeImage(url,run.abort.signal)){
        cacheRemotePackArtworkV163(card,url,run);
        card._resolvedArtworkUrl=url;
        return null;
      }
    }catch(_){}
  }
  return null;
}

function preloadPackCard(card,run=packRun) {
  if(!run||!card)return Promise.resolve(null);
  if(run.art.has(card.id))return run.art.get(card.id);
  const promise=(async()=>{
    // 1) Offline-first: use a previously cached real card image whenever it is
    // available. The resulting object URL is owned by this pack run.
    try{
      const blob=await packCachedBlob(card.id);
      if(blob?.size&&await packArtworkIsUsable(card,blob)&&validPackRun(run)){
        const url=URL.createObjectURL(blob);run.urls.add(url);card._packArtwork=url;
        return {url,owned:true,source:'cache'};
      }
    }catch(_){}
    if(!validPackRun(run))return {url:LuckyDexPack.placeholder(card.name),owned:false,source:'cancelled'};

    // 2) Local/data artwork and installed LuckyDex set-pack artwork can be
    // shown without any network connection.
    if(/^(?:data:|blob:)/i.test(card.image||'')||window.LuckyDexCardArt?.isLocalUrl?.(card.image||'')){
      try{if(await LuckyDexPack.decodeImage(card.image,run.abort.signal)){card._packArtwork=card.image;return {url:card.image,owned:false,source:window.LuckyDexCardArt?.isLocalUrl?.(card.image)?'library-pack':'local'};}}catch(_){}
    }

    // 3) Online path: resolve all known sources, verify the actual <img> URL,
    // then display it immediately. Blob caching happens in the background.
    // This avoids the old failure mode where a CDN disallowed fetch()/CORS but
    // was perfectly valid in an <img>, which produced LOCAL CARD PREVIEW.
    if(isOnlineV13()){
      const urls=await packArtworkCandidatesV163(card,run);
      for(const url of urls){
        if(!validPackRun(run))break;
        try{
          if(await LuckyDexPack.decodeImage(url,run.abort.signal)){
            card._resolvedArtworkUrl=url;card._packArtwork=url;
            if(!/^(?:data:|blob:)/i.test(url))card.image=url;
            cacheRemotePackArtworkV163(card,url,run);
            return {url,owned:false,source:'remote-direct'};
          }
        }catch(_){}
      }
    }

    const fallback=LuckyDexPack.placeholder(card.name);card._packArtwork=fallback;
    return {url:fallback,owned:false,source:'placeholder'};
  })();
  run.art.set(card.id,promise);return promise;
}

async function preparePack() {
  if(packRun?.building)return;
  const setId=document.getElementById('setSelect').value,source=document.getElementById('cardSource').value;if(!setId)return;
  const entitlement=packEntitlement();if(entitlement.mode==='coins'&&state.profile.coins<entitlement.cost){showToast('Not enough Lucky Coins.');return;}
  const run=newPackRun();run.building=true;preparedPack=null;
  const initialSet=setCache[source]?.find(s=>s.id===setId)||cachedSetV13(setId,source);
  const libraryInstall=source==='tcg'&&!!initialSet?._libraryKey;
  const stage=packStageLoading(libraryInstall?'Loading exact set artwork…':'Building your pack…'),btn=document.getElementById('openPackBtn');btn.disabled=true;
  const watchdog=setTimeout(()=>{
    if(run!==packRun||!run.building)return;
    run.timedOut=true;run.abort.abort();
    stage.innerHTML='<button class="pack-exit" id="packExitBtn">‹ SHOP</button><div class="empty"><b>PACK DATA TIMED OUT</b><br>The set did not finish loading. Your coins/ticket were not spent. Try again or use an installed/cached set.</div>';
    const exit=document.getElementById('packExitBtn');if(exit)exit.onclick=()=>closePackOpening();
  },libraryInstall?120000:10000);
  try{
    let set=initialSet,cards,luckyPack=Math.random()<1/2000;
    if(source==='tcg'&&set?._libraryKey&&window.LuckyDexCardArt){
      set=await LuckyDexCardArt.prepareSet(set,run.abort.signal);
      if(!validPackRun(run))return;
      const catalogueOnly={...set,cards:[]};cacheSetV13(catalogueOnly,source);
      cards=await buildBalancedPack(set,source,luckyPack,run.abort.signal);
    }else if(!isOnlineV13()){
      if(!set)throw new Error('offline-set-missing');cards=await buildOfflinePackV13(set,source,luckyPack);
    }else{
      if(source==='tcgp'&&window.LuckyDexPocket){
        if(set?._pocketDataset!=='flibustier-v2'||!set?.cards?.length){
          try{set=await LuckyDexPocket.setDetail(setId,run.abort.signal);}
          catch(err){
            // If the dedicated Pocket feed is temporarily unreachable, use any
            // previously cached full Pocket set before giving up.
            const cached=cachedSetV13(setId,source);if(cached?.cards?.length)set=cached;else throw err;
          }
        }
      }else if(!set?.cards?.length)set=await packFetch(API.tcgSet(setId),run.abort.signal,5000);
      if(!validPackRun(run))return;
      cacheSetV13(set,source);cards=await buildBalancedPack(set,source,luckyPack,run.abort.signal);
      if(!validPackRun(run))return;
      cacheCardsV13(cards,set,source);
    }
    if(!validPackRun(run))return;
    preparedPack={set,source,cards,luckyPack,revealed:new Set(),committed:false,entitlement,currentIndex:0};
    // Artwork must never block pack construction indefinitely. The first two
    // preloads get a small head start, but the sealed pack appears regardless.
    Promise.allSettled(cards.slice(0,2).map(c=>preloadPackCard(c,run)));
    cards.slice(2).forEach(c=>preloadPackCard(c,run));
    renderSealedPack();
  }catch(error){
    if(run.timedOut||run!==packRun)return;
    stage.innerHTML=`<button class="pack-exit" id="packExitBtn">‹ SHOP</button><div class="empty"><b>${isOnlineV13()?'PACK ERROR':'OFFLINE CACHE NEEDED'}</b><br>${isOnlineV13()?'Could not prepare this set. Please try again.':'Open this set online once to cache its cards and artwork.'}</div>`;
    document.getElementById('packExitBtn').onclick=()=>closePackOpening();
  }finally{
    clearTimeout(watchdog);
    if(run===packRun){run.building=false;updatePackButton();updateOfflineHintV13();}
  }
}
async function tearPack() {
  const run=packRun,pack=preparedPack;if(!run||!pack||pack.tearing||pack.committed)return;
  pack.tearing=true;const sealed=document.getElementById('sealedPack');if(sealed){sealed.disabled=true;sealed.classList.add('tearing');}
  vibrate([14,18,24]);
  if(!await packDelay(620,run.abort.signal)||!validPackRun(run)||preparedPack!==pack)return;
  commitPreparedPack();pack.currentIndex=0;await renderPackCard();
}
async function renderPackCard() {
  const run=packRun,pack=preparedPack;if(!run||!pack)return;
  run.reveal?.destroy();run.reveal=null;
  const index=pack.currentIndex,card=pack.cards[index];
  const stage=packStageLoading();
  const [art]=await Promise.all([preloadPackCard(card,run),preloadPackCard(pack.cards[index+1],run)]);
  if(!validPackRun(run)||preparedPack!==pack||pack.currentIndex!==index)return;
  run.reveal=LuckyDexPack.mountReveal(stage,{
    card,artwork:art.url,index,count:pack.cards.length,setName:pack.set.name,haptic:packHaptic,
    onExit:()=>closePackOpening(),onNext:advancePackCard,onPrevious:previousPackCard,
    onFullScreen:()=>openCardModal({...card,image:art.url,_packArtwork:art.url}),
    onSettle:()=>pack.revealed.add(index)
  });
}
function advancePackCard() {
  if(!packRun?.reveal?.session.ready||!preparedPack)return;
  if(preparedPack.currentIndex>=preparedPack.cards.length-1)renderPackSummary();
  else{preparedPack.currentIndex++;renderPackCard();}
}
function previousPackCard() {
  if(!packRun?.reveal?.session.ready||!preparedPack||preparedPack.currentIndex<=0)return;
  preparedPack.currentIndex--;renderPackCard();
}
function renderPackSummary() {
  const pack=preparedPack;if(!pack)return;
  packRun?.reveal?.destroy();if(packRun)packRun.reveal=null;
  const stage=document.getElementById('packStage');stage.dataset.packPhase='summary';
  stage.innerHTML=`<button class="pack-exit" id="packExitBtn">‹ SHOP</button><div class="v13-summary"><div class="screen-title"><div><div class="eyebrow">PACK COMPLETE</div><h2>${escapeHtml(pack.set.name)}</h2></div><span class="pill">${pack.cards.length} cards</span></div><div class="v13-summary-grid">${pack.cards.map(c=>`<button class="v13-summary-card level-${LuckyDexPack.profileFor(c).level}" data-summary-card="${escapeHtml(c.id)}"><div class="card-art-wrap"><img src="${escapeHtml(c._packArtwork||LuckyDexPack.placeholder(c.name))}" alt="${escapeHtml(c.name)}"></div><b>${c._wasNew?'NEW · ':''}${escapeHtml(c.name)}</b><span>${escapeHtml(c.rarity||c._foil)}</span></button>`).join('')}</div><button class="primary full v13-back-shop" id="shopAnotherPackBtn">BACK TO PACK SHOP</button></div>`;
  document.getElementById('packExitBtn').onclick=document.getElementById('shopAnotherPackBtn').onclick=()=>closePackOpening();
  stage.querySelectorAll('[data-summary-card]').forEach(button=>button.onclick=()=>{const c=pack.cards.find(c=>c.id===button.dataset.summaryCard);openCardModal({...c,image:c._packArtwork});});
}
function closePackOpening(force=false) {
  const stage=document.getElementById('packStage');if(!stage)return;
  if(!force&&preparedPack&&!preparedPack.committed&&!preparedPack.debug&&document.getElementById('sealedPack')&&!confirm('Leave this unopened pack? Nothing has been spent yet.'))return;
  const dialog=document.getElementById('cardDialog');if(dialog?.open)dialog.close();
  cancelPackRun();preparedPack=null;stage.hidden=true;stage.innerHTML='';delete stage.dataset.packPhase;document.body.classList.remove('pack-opening');updatePackButton();
}
function packHaptic(pattern) {
  if(!state.settings.vibration)return;
  if(window.Android?.packHaptic)window.Android.packHaptic(JSON.stringify(pattern));
  else vibrate(pattern);
}
window.LuckyDexDebug=Object.assign(window.LuckyDexDebug||{}, {
  async playPackTier(tier='crown') {
    if(preparedPack&&!preparedPack.debug)throw new Error('Close the active pack before replaying a preview.');
    const rarities=['Common','Rare','Double Rare','One Star','Two Star','Crown'];
    const aliases={common:0,rare:1,holo:1,illustration:3,'one-star':3,'two-star':4,'three-star':4,high:4,crown:5,top:5};
    const value=typeof tier==='number'?rarities[Math.max(0,Math.min(5,Math.floor(tier)))]:rarities[aliases[String(tier).toLowerCase()]]||String(tier);
    const run=newPackRun(),card={id:'local-debug-card',name:'Lucky Dex Preview',rarity:value,image:LuckyDexPack.placeholder('Lucky Dex Preview')};
    preparedPack={set:{id:'local-preview',name:'Local preview'},source:'tcgp',cards:[card],currentIndex:0,debug:true,committed:true,revealed:new Set()};
    await preloadPackCard(card,run);await renderPackCard();
  }
});
