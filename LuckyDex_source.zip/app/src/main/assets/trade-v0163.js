/* Lucky Dex v0.16.9 — exact-catalogue Global Link Trade marketplace.
   The market is deterministic for each real-world four-hour window and only
   reveals cards from sets the player has actually opened/discovered. The
   default board shows five featured listings; filters/search inspect the wider
   marketplace rather than only those five rows. */
(() => {
  'use strict';

  const REFRESH_HOURS = 4;
  const MARKET_SIZE = 24;
  const FEATURED_COUNT = 5;
  const MARKET_VERSION = 'v169-exact-global-market-1';
  const TRAINERS = [
    ['AceLuna','🌙'],['BerryByte','🍓'],['Route3Ranger','🧭'],['MewMint','✨'],['CardSage','🃏'],
    ['VoltVee','⚡'],['MoonBallMike','🌕'],['GengarFan','👻'],['PikaParcel','📦'],['DexDiver','🔎'],
    ['RareRin','💎'],['KantoKid','🔴'],['JohtoJules','🟡'],['SinnohSky','🏔️'],['PaldeaPal','🍇'],
    ['HoloHana','🌈'],['MiraidonMain','🏍️'],['SleeveQueen','🛡️'],['BoosterBen','🎴'],['CrownChaser','👑'],
    ['PokePost','✉️'],['ArtRareAri','🎨'],['TradeTower','🏙️'],['BinderBee','🐝'],['LuckyLink','🍀']
  ];
  let tradeMode = 'same';
  let tradeSource = 'all';
  let tradeView = 'featured';
  let tradeBuildSerial = 0;
  let tradeClockTimer = null;
  const tradeArtLookup = new Map();
  const tradeSetDetailCache = new Map();
  let tradeLibraryCatalogPromise = null;

  const $ = id => document.getElementById(id);
  const safe = value => typeof escapeHtml === 'function' ? escapeHtml(value ?? '') : String(value ?? '');
  const sourceOf = card => card?.source || (/^[AB]\d/i.test(String(card?.setId || card?.set?.id || '')) ? 'tcgp' : 'tcg');
  const setIdOf = card => String(card?.setId || card?.set?.id || card?.set || '');
  const setNameOf = card => String(card?.setName || card?.set?.name || card?.set || card?.setId || 'Unknown set');
  const countOf = card => Math.max(0, Number(card?.count || 0));
  const human = (value,fallback='Card') => typeof humanCardText==='function' ? humanCardText(value,fallback) : String(value||fallback);
  const norm = v => String(v||'').toLowerCase().replace(/[^a-z0-9]+/g,'');
  function ownedEntry(card){
    if(!card)return null;
    if(state.cards?.[card.id])return {key:card.id,card:state.cards[card.id]};
    const wantedName=norm(card.name),wantedNum=norm(card.localId||card.number),wantedSet=norm(card.setName||card.set?.name||''),wantedSource=sourceOf(card);
    const matches=Object.entries(state.cards||{}).filter(([,row])=>{
      if(countOf(row)<1||sourceOf(row)!==wantedSource)return false;
      if(wantedName&&norm(row.name)!==wantedName)return false;
      const rowNum=norm(row.localId||row.number);if(wantedNum&&rowNum&&rowNum!==wantedNum)return false;
      const rowSet=norm(row.setName||row.set?.name||'');if(wantedSet&&rowSet&&rowSet!==wantedSet)return false;
      return true;
    });
    return matches.length===1?{key:matches[0][0],card:matches[0][1]}:null;
  }


  function ensureTradeState(){
    if(!state.trade || typeof state.trade !== 'object') state.trade = {};
    if(!state.trade.openedSets || typeof state.trade.openedSets !== 'object') state.trade.openedSets = {};
    if(!state.trade.boards || typeof state.trade.boards !== 'object') state.trade.boards = {};
    if(!Number.isFinite(Number(state.trade.totalTrades))) state.trade.totalTrades = 0;
    // v0.16.9 deliberately changes board semantics from ownership-biased
    // rows to a larger random global market. Never reuse a stale v0.16.7 board.
    if(state.trade.marketVersion !== MARKET_VERSION){
      state.trade.marketVersion = MARKET_VERSION;
      state.trade.boards = {};
      state.trade.currentSlot = '';
    }

    // Existing saves predate the trade feature. Any set represented in the
    // binder was necessarily opened/discovered and is therefore safe to reveal.
    for(const card of Object.values(state.cards || {})){
      const setId = setIdOf(card); if(!setId) continue;
      const source = sourceOf(card), key = `${source}:${setId}`;
      state.trade.openedSets[key] = {source,setId,setName:setNameOf(card)};
    }
    return state.trade;
  }

  function localSlotInfo(date = new Date()){
    const y=date.getFullYear(), m=String(date.getMonth()+1).padStart(2,'0'), d=String(date.getDate()).padStart(2,'0');
    const bucket=Math.floor(date.getHours()/REFRESH_HOURS);
    const next=new Date(date);next.setMinutes(0,0,0);next.setHours((bucket+1)*REFRESH_HOURS);
    return {slot:`${y}-${m}-${d}:${bucket}`,next};
  }

  function formatCountdown(ms){
    ms=Math.max(0,ms);const total=Math.floor(ms/1000),h=Math.floor(total/3600),m=Math.floor((total%3600)/60),s=total%60;
    return `${String(h).padStart(2,'0')}:${String(m).padStart(2,'0')}:${String(s).padStart(2,'0')}`;
  }

  function updateTradeClock(){
    const el=$('tradeCountdown');if(!el)return;
    const info=localSlotInfo();el.textContent=formatCountdown(info.next-Date.now());
    const trade=ensureTradeState();
    if(trade.currentSlot && trade.currentSlot!==info.slot && document.querySelector('[data-page="trade"]')?.classList.contains('active')){
      renderTradeBoard(true);
    }
  }

  function hash32(text){
    let h=2166136261>>>0;for(let i=0;i<String(text).length;i++){h^=String(text).charCodeAt(i);h=Math.imul(h,16777619);}return h>>>0;
  }
  function mulberry32(seed){return function(){let t=seed+=0x6D2B79F5;t=Math.imul(t^t>>>15,t|1);t^=t+Math.imul(t^t>>>7,t|61);return ((t^t>>>14)>>>0)/4294967296;};}
  function pick(arr,rng){return arr?.length?arr[Math.floor(rng()*arr.length)]:null;}
  function shuffle(arr,rng){const out=[...arr];for(let i=out.length-1;i>0;i--){const j=Math.floor(rng()*(i+1));[out[i],out[j]]=[out[j],out[i]];}return out;}

  function discoveredSets(sourceFilter='all'){
    const trade=ensureTradeState(),seen=new Set(),out=[];
    for(const row of Object.values(trade.openedSets)){
      if(sourceFilter!=='all'&&row.source!==sourceFilter)continue;
      const identity=`${row.source}:${norm(row.setName||row.setId)}`;
      if(seen.has(identity))continue;
      seen.add(identity);out.push(row);
    }
    return out;
  }

  function ownedCards(sourceFilter='all'){
    return Object.values(state.cards||{}).filter(c=>countOf(c)>0 && (sourceFilter==='all'||sourceOf(c)===sourceFilter));
  }

  async function tradeLibraryCatalog(){
    if(!window.LuckyDexCardArt?.catalog)return [];
    if(!tradeLibraryCatalogPromise)tradeLibraryCatalogPromise=LuckyDexCardArt.catalog().catch(()=>[]);
    return tradeLibraryCatalogPromise;
  }

  async function exactLibrarySet(meta){
    if(!meta?.setId||meta.source!=='tcg'||!window.LuckyDexCardArt?.prepareSet)return null;
    try{
      const catalog=await tradeLibraryCatalog(),wantedId=String(meta.setId||'').replace(/^library:/i,'').toLowerCase(),wantedName=norm(meta.setName||'');
      const hits=catalog.filter(set=>{
        const key=String(set?._libraryKey||set?.id||'').replace(/^library:/i,'').toLowerCase();
        return (wantedId&&key===wantedId)||(wantedName&&norm(set?.name)===wantedName);
      });
      const unique=[];for(const set of hits)if(!unique.includes(set))unique.push(set);
      if(unique.length!==1)return null;
      const hydrated=await LuckyDexCardArt.prepareSet(unique[0]);
      return hydrated?.cards?.length?hydrated:null;
    }catch(_){return null;}
  }

  function looksLikeFullSet(set){
    const cards=Array.isArray(set?.cards)?set.cards:[],reported=Number(set?.cardCount?.total||set?.setTotal||0);
    if(!cards.length)return false;
    if(!reported)return cards.length>=12;
    return cards.length>=Math.min(reported,Math.max(12,Math.floor(reported*.88)));
  }

  async function ensureSetDetail(meta){
    if(!meta?.setId)return null;
    const cacheKey=`${meta.source}:${norm(meta.setName||meta.setId)}`;
    if(tradeSetDetailCache.has(cacheKey))return tradeSetDetailCache.get(cacheKey);
    const work=(async()=>{
      // Physical TCG trades use the same deterministic exact catalogue that
      // powers the binder artwork. This prevents the old failure mode where an
      // unavailable remote set API silently turned the player's owned cards
      // into the entire simulated global market.
      const library=await exactLibrarySet(meta);
      if(looksLikeFullSet(library))return library;

      let set=null;
      try{set=cachedSetV13(meta.setId,meta.source);}catch(_){ }
      if(!set)try{set=(setCache?.[meta.source]||[]).find(s=>s.id===meta.setId)||null;}catch(_){ }
      if(looksLikeFullSet(set))return set;
      try{
        if(meta.source==='tcgp' && window.LuckyDexPocket) set=await LuckyDexPocket.setDetail(meta.setId);
        else if(typeof packFetch==='function') set=await packFetch(API.tcgSet(meta.setId),null,5200);
        else set=await fetchJson(API.tcgSet(meta.setId),5200);
        if(set?.id)try{cacheSetV13(set,meta.source);}catch(_){ }
        return looksLikeFullSet(set)?set:null;
      }catch(_){
        // Never use the player's binder as a substitute catalogue. If the full
        // set is unavailable, skip that simulated listing instead of fabricating
        // an ownership-biased market.
        return null;
      }
    })();
    tradeSetDetailCache.set(cacheKey,work);
    const result=await work;
    if(!result)tradeSetDetailCache.delete(cacheKey);
    return result;
  }

  function normalizeTradeCard(card,set,source){
    if(!card)return null;
    const id=String(card.id||'');if(!id)return null;
    const out={
      id,name:card.name||'Unknown card',rarity:card.rarity||'Unknown',image:card.image||'',localId:card.localId||card.number||'',
      setId:card.set?.id||card.setId||set?.id||'',setName:card.set?.name||card.setName||set?.name||'',
      setTotal:Number(card.set?.cardCount?.total||card.setTotal||set?.cardCount?.total||0),source:source||card.source||'tcg'
    };
    try{
      const codes=typeof physicalSetCodesV163==='function'?physicalSetCodesV163(card,set):[];
      if(codes[0])out._limitlessSetCode=codes[0];
    }catch(_){if(card._limitlessSetCode)out._limitlessSetCode=card._limitlessSetCode;}
    if(card._tcgpFallbacks?.length)out._tcgpFallbacks=[...card._tcgpFallbacks];
    if(card._pocketImageFile)out._pocketImageFile=card._pocketImageFile;
    if(card._pocketNative)out._pocketNative=true;
    return out;
  }

  async function chooseOfferCard(set,source,targetTier,excludeIds,rng){
    const briefs=(set?.cards||[]).filter(c=>c?.id&&!excludeIds.has(c.id));
    if(!briefs.length)return null;

    let card=null;
    // Pocket set rows already contain normalized rarity, making this exact and
    // cheap. Physical TCG set cards may be briefs, so reuse the existing detail
    // picker which lazily enriches only a handful of candidates.
    const hasRarity=briefs.filter(c=>c.rarity && !/^(?:none|unknown)$/i.test(String(c.rarity)));
    if(source==='tcgp'||hasRarity.length>=Math.min(8,Math.ceil(briefs.length*.35))){
      const ranked=briefs.map(c=>({c,t:rarityTier(c.rarity||'Unknown')}));
      let pool=ranked.filter(x=>x.t===targetTier);
      if(!pool.length){const min=Math.min(...ranked.map(x=>Math.abs(x.t-targetTier)));pool=ranked.filter(x=>Math.abs(x.t-targetTier)===min);}
      // Marketplace offers are random within the intended rarity band.
      // Ownership is deliberately NOT part of selection; filters are applied
      // later when the player asks to see actionable listings.
      card=pick(pool,rng)?.c;
    }else{
      try{card=await pickCardForTier(briefs,targetTier,excludeIds);}catch(_){card=pick(briefs,rng);}
    }
    if(!card)return null;
    try{
      if((!card.rarity||/^(?:none|unknown)$/i.test(String(card.rarity)))&&source!=='tcgp')card=await getCardDetail(card);
    }catch(_){ }
    try{
      if(!card.image && typeof resolveCardArtwork==='function')card.image=await resolveCardArtwork(card,set,source);
    }catch(_){ }
    return normalizeTradeCard(card,set,source);
  }

  function relationRoll(rng,requestTier){
    // Usually equal rarity. Occasionally the simulated trainer asks one tier
    // above or below the card they're offering.
    const r=rng();let askDelta=0;
    if(r<.08)askDelta=-1;       // request lower than offer: good for player
    else if(r>.92)askDelta=1;   // request higher than offer: harder bargain
    let offerTier=requestTier-askDelta;
    if(offerTier<0||offerTier>6){askDelta=0;offerTier=requestTier;}
    return {askDelta,offerTier};
  }

  function requestCandidate(pool,rng,usedRequests){
    let available=pool.filter(c=>!usedRequests.has(c.id));if(!available.length)available=pool;
    const duplicates=available.filter(c=>countOf(c)>1);
    return pick(duplicates.length&&rng()<.72?duplicates:available,rng);
  }

  async function requestFromOpenedSet(sourceFilter,rng,usedRequests,preferUnowned=false){
    const metas=shuffle(discoveredSets(sourceFilter),rng);
    for(const meta of metas){
      const set=await ensureSetDetail(meta);
      let pool=(set?.cards||[]).filter(c=>c?.id&&!usedRequests.has(String(c.id)));
      if(!pool.length)pool=(set?.cards||[]).filter(c=>c?.id);
      if(!pool.length)continue;
      if(preferUnowned){
        const unseen=pool.filter(c=>countOf(state.cards?.[c.id])===0);
        if(unseen.length)pool=unseen;
      }
      let card=pick(pool,rng);if(!card)continue;
      try{
        if(meta.source!=='tcgp' && (!card.rarity||/^(?:none|unknown)$/i.test(String(card.rarity)))) card=await getCardDetail(card);
      }catch(_){ }
      try{
        if(!card.image && typeof resolveCardArtwork==='function')card.image=await resolveCardArtwork(card,set,meta.source);
      }catch(_){ }
      const normalized=normalizeTradeCard(card,set,meta.source);
      if(normalized)return normalized;
    }
    return null;
  }

  async function generateOffer(index,mode,sourceFilter,rng,usedRequests,usedOffers){
    const opened=discoveredSets(sourceFilter);
    if(!opened.length)return null;
    for(let attempt=0;attempt<10;attempt++){
      // Both sides of a listing are sampled from discovered sets, independent
      // of what the player owns. This makes the board look like a real global
      // market. Ownership only controls whether a listing is actionable.
      const request=await requestFromOpenedSet(sourceFilter,rng,usedRequests,false);
      if(!request)continue;

      const reqSource=sourceOf(request),reqSetId=setIdOf(request),reqTier=rarityTier(request.rarity||'Unknown');
      const relation=relationRoll(rng,reqTier);
      let sets=discoveredSets(sourceFilter);
      if(mode==='same')sets=sets.filter(s=>s.source===reqSource&&s.setId===reqSetId);
      else {
        const different=sets.filter(s=>!(s.source===reqSource&&s.setId===reqSetId));
        if(different.length)sets=different;
      }
      if(!sets.length)continue;
      const setMeta=pick(sets,rng),set=await ensureSetDetail(setMeta);if(!set?.cards?.length)continue;
      let offer=await chooseOfferCard(set,setMeta.source,relation.offerTier,new Set([...usedOffers,request.id]),rng);if(!offer)continue;
      // Rarity fairness matters more than making every row use a unique offered
      // card. If uniqueness pushes us outside the intended tier, allow a repeat
      // offer before accepting a lopsided bargain.
      if(rarityTier(offer.rarity||'Unknown')!==relation.offerTier){
        const retry=await chooseOfferCard(set,setMeta.source,relation.offerTier,new Set([request.id]),rng);
        if(retry && Math.abs(rarityTier(retry.rarity||'Unknown')-relation.offerTier)<Math.abs(rarityTier(offer.rarity||'Unknown')-relation.offerTier))offer=retry;
      }
      if(offer.id===request.id||Math.abs(rarityTier(offer.rarity||'Unknown')-reqTier)>1)continue;
      usedRequests.add(request.id);usedOffers.add(offer.id);
      const trainer=TRAINERS[(hash32(`${localSlotInfo().slot}:${mode}:${sourceFilter}:${index}:${request.id}:${offer.id}`)+index)%TRAINERS.length];
      const actualReqTier=rarityTier(request.rarity||'Unknown'),actualOfferTier=rarityTier(offer.rarity||'Unknown');
      return {
        id:`${index}-${hash32(`${request.id}|${offer.id}|${trainer[0]}`).toString(36)}`,
        trainer:trainer[0],avatar:trainer[1],accepted:false,
        request:normalizeTradeCard(request,{id:reqSetId,name:setNameOf(request)},reqSource),offer,
        reqTier:actualReqTier,offerTier:actualOfferTier
      };
    }
    return null;
  }

  async function buildBoard(mode,sourceFilter,slot){
    const rng=mulberry32(hash32(`LuckyDexTrade|${slot}|${mode}|${sourceFilter}`));
    const usedRequests=new Set(),usedOffers=new Set(),offers=[];
    // Build a wider marketplace. The normal screen still presents five
    // featured listings, while filters/search can reveal more of this pool.
    for(let attempt=0;attempt<60&&offers.length<MARKET_SIZE;attempt++){
      const offer=await generateOffer(offers.length,mode,sourceFilter,rng,usedRequests,usedOffers);
      if(offer)offers.push(offer);
    }
    return offers;
  }

  function boardKey(slot,mode,sourceFilter){return `${MARKET_VERSION}|${slot}|${mode}|${sourceFilter}`;}

  async function ensureBoard(force=false){
    const trade=ensureTradeState(),info=localSlotInfo(),key=boardKey(info.slot,tradeMode,tradeSource);
    if(trade.currentSlot!==info.slot){trade.currentSlot=info.slot;trade.boards={};}
    if(!force && Array.isArray(trade.boards[key]))return trade.boards[key];
    const serial=++tradeBuildSerial;
    const list=$('tradeOfferList');if(list)list.innerHTML='<div class="trade-loading"><div class="spinner"></div><b>Searching the Link Trade board…</b></div>';
    const offers=await buildBoard(tradeMode,tradeSource,info.slot);
    if(serial!==tradeBuildSerial)return [];
    trade.boards[key]=offers;
    try{localStorage.setItem('luckyDexSave',JSON.stringify(state));}catch(_){ }
    return offers;
  }

  function tradeDealClass(row){
    if(row.offerTier>row.reqTier)return ['good','They are offering the rarer card'];
    if(row.offerTier<row.reqTier)return ['risky','They are asking for the rarer card'];
    return ['','Matched rarity trade'];
  }

  function tradeArtworkCandidates(card){
    const candidates=[],add=url=>{url=String(url||'');if(url&&!candidates.includes(url))candidates.push(url);};
    // Prefer a verified/known image, then the deterministic physical CDN, then
    // the low-res and Pocket fallbacks. This keeps current promo sets usable
    // even when one catalogue is behind another.
    try{if(card.image)add(cardImage(card.image,'high'));}catch(_){ }
    try{if(typeof physicalCardArtworkCandidatesV163==='function')for(const url of physicalCardArtworkCandidatesV163(card,null))add(url);}catch(_){ }
    try{if(card.image)add(cardImage(card.image,'low'));}catch(_){ }
    for(const f of card._tcgpFallbacks||[])add(f);
    return candidates;
  }

  function tradeCardArt(card,token){
    const candidates=tradeArtworkCandidates(card);
    tradeArtLookup.set(token,{card,candidates,index:0});
    const src=candidates[0]||'';
    return `<div class="trade-card-art ${src?'':'broken'}"><img ${src?`src="${safe(src)}"`:''} data-trade-art="${safe(token)}" alt="${safe(card.name)}" onerror="tradeImageFallback(this)"><div class="trade-art-fallback">Artwork unavailable<br>${safe(card.name)}</div></div>`;
  }

  window.tradeImageFallback=function(img){
    const row=tradeArtLookup.get(img.dataset.tradeArt);if(!row){img.parentElement?.classList.add('broken');return;}
    row.index++;
    if(row.index<row.candidates.length){img.src=row.candidates[row.index];return;}
    img.parentElement?.classList.add('broken');
  };

  function tradeAnimationArt(card){return tradeArtworkCandidates(card)[0]||'';}

  function ensureTradeConfirm(){
    let modal=$('tradeConfirmModal');if(modal)return modal;
    modal=document.createElement('div');
    modal.id='tradeConfirmModal';modal.className='trade-confirm-overlay';modal.hidden=true;
    modal.innerHTML=`<div class="trade-confirm-backdrop" data-trade-confirm-cancel></div><section class="trade-confirm-sheet" role="dialog" aria-modal="true" aria-labelledby="tradeConfirmTitle"><div class="trade-confirm-head"><div class="trade-confirm-mark">⇄</div><div><small>GLOBAL LINK TRADE</small><h3 id="tradeConfirmTitle">Confirm trade</h3></div><button class="trade-confirm-close" type="button" data-trade-confirm-cancel aria-label="Cancel trade">✕</button></div><div class="trade-confirm-trainer" id="tradeConfirmTrainer"></div><div class="trade-confirm-pair"><div class="trade-confirm-card" id="tradeConfirmSend"></div><div class="trade-confirm-arrow"><span>⇄</span></div><div class="trade-confirm-card incoming" id="tradeConfirmReceive"></div></div><div class="trade-confirm-warning" id="tradeConfirmWarning"></div><div class="trade-confirm-actions"><button class="secondary" type="button" data-trade-confirm-cancel>KEEP CARD</button><button class="primary" type="button" id="tradeConfirmAccept">TRADE NOW</button></div></section>`;
    document.body.appendChild(modal);return modal;
  }

  function tradeConfirmCard(card,label,count){
    const src=tradeAnimationArt(card),owned=Math.max(0,Number(count||0));
    return `<span>${safe(label)}</span><div class="trade-confirm-art ${src?'':'missing'}">${src?`<img src="${safe(src)}" alt="${safe(card.name)}" onerror="this.parentElement.classList.add('missing');this.remove()">`:''}<div class="trade-confirm-art-fallback">${safe(card.name)}</div></div><b>${safe(human(card.name,'Unknown card'))}</b><small>${safe(human(card.setName||card.setId,'Unknown set'))}</small><em>OWNED ×${owned}</em>`;
  }

  function confirmTradeInApp(row,requested){
    const modal=ensureTradeConfirm(),sendCount=countOf(requested),recvCount=countOf(ownedEntry(row.offer)?.card);
    modal.querySelector('#tradeConfirmTrainer').innerHTML=`<b>${safe(row.avatar)} ${safe(row.trainer)}</b><span>is offering this Link Trade</span>`;
    modal.querySelector('#tradeConfirmSend').innerHTML=tradeConfirmCard(row.request,'YOU SEND',sendCount);
    modal.querySelector('#tradeConfirmReceive').innerHTML=tradeConfirmCard(row.offer,'YOU RECEIVE',recvCount);
    const warning=modal.querySelector('#tradeConfirmWarning');
    warning.className=`trade-confirm-warning ${sendCount===1?'last-copy':''}`;
    warning.innerHTML=sendCount===1?`<b>LAST COPY</b><span>This is your only ${safe(row.request.name)}. The trade cannot be undone.</span>`:`<b>READY TO TRADE</b><span>You will have ${Math.max(0,sendCount-1)} cop${sendCount-1===1?'y':'ies'} of ${safe(row.request.name)} remaining.</span>`;
    modal.hidden=false;requestAnimationFrame(()=>modal.classList.add('show'));
    return new Promise(resolve=>{
      let finished=false;
      const done=value=>{if(finished)return;finished=true;modal.classList.remove('show');setTimeout(()=>{modal.hidden=true;},170);cleanup();resolve(value);};
      const cancel=[...modal.querySelectorAll('[data-trade-confirm-cancel]')],accept=modal.querySelector('#tradeConfirmAccept');
      const onCancel=()=>done(false),onAccept=()=>done(true),onKey=e=>{if(e.key==='Escape')done(false);};
      const cleanup=()=>{cancel.forEach(el=>el.removeEventListener('click',onCancel));accept.removeEventListener('click',onAccept);document.removeEventListener('keydown',onKey);};
      cancel.forEach(el=>el.addEventListener('click',onCancel));accept.addEventListener('click',onAccept);document.addEventListener('keydown',onKey);
    });
  }

  function ensureTradeFx(){
    let fx=$('tradeExchangeFx');if(fx)return fx;
    fx=document.createElement('div');
    fx.id='tradeExchangeFx';fx.className='trade-exchange-fx';fx.hidden=true;
    fx.innerHTML=`<div class="trade-fx-backdrop"></div><div class="trade-fx-stage"><div class="trade-fx-burst"></div><div class="trade-fx-streaks"><i></i><i></i><i></i><i></i></div><div class="trade-fx-sparkles"></div><div class="trade-fx-card trade-fx-outgoing"></div><div class="trade-fx-card trade-fx-incoming"></div><div class="trade-fx-copy"><small>LINK TRADE</small><b>Trading…</b><span></span></div></div>`;
    document.body.appendChild(fx);return fx;
  }

  function fxCardFace(card){
    const src=tradeAnimationArt(card);
    return `<div class="trade-fx-face-art ${src?'':'missing'}">${src?`<img src="${safe(src)}" alt="${safe(card.name)}" onerror="this.parentElement.classList.add(\'missing\')" />`:''}<div class="trade-fx-face-fallback"><b>${safe(card.name)}</b><small>${safe(card.rarity||'Card')}</small></div></div>`;
  }

  function populateTradeFx(row){
    const fx=ensureTradeFx(),out=fx.querySelector('.trade-fx-outgoing'),incoming=fx.querySelector('.trade-fx-incoming');
    out.innerHTML=`<div class="trade-fx-flat">${fxCardFace(row.request)}<span>SENDING</span></div>`;
    incoming.innerHTML=`<div class="trade-fx-3d"><div class="trade-fx-back"><div class="trade-fx-ball"><i></i></div><b>LUCKY DEX</b></div><div class="trade-fx-front">${fxCardFace(row.offer)}</div></div><span class="trade-fx-receive-label">RECEIVING</span>`;
    const spark=fx.querySelector('.trade-fx-sparkles');spark.innerHTML='';
    const count=14+Math.max(0,Math.min(6,Number(row.offerTier||0)))*4;
    for(let i=0;i<count;i++){
      const el=document.createElement('i'),a=(i/count)*Math.PI*2+(i%3)*.19,r=80+(i%6)*18;
      el.style.setProperty('--sx',`${Math.cos(a)*r}px`);el.style.setProperty('--sy',`${Math.sin(a)*r}px`);el.style.setProperty('--sd',`${(i%7)*34}ms`);spark.appendChild(el);
    }
    const copy=fx.querySelector('.trade-fx-copy');copy.querySelector('b').textContent='Trading…';copy.querySelector('span').textContent=`${row.request.name}  ⇄  ${row.offer.name}`;
    fx.className=`trade-exchange-fx tier-${Math.max(0,Math.min(6,Number(row.offerTier||0)))}`;
    return fx;
  }

  function sleep(ms){return new Promise(resolve=>setTimeout(resolve,ms));}

  async function playTradeAnimation(row){
    const fx=populateTradeFx(row);fx.hidden=false;void fx.offsetWidth;fx.classList.add('running');
    try{vibrate([12,26,12]);}catch(_){ }
    await sleep(820);
    fx.classList.add('revealed');
    const copy=fx.querySelector('.trade-fx-copy');copy.querySelector('b').textContent='Trade complete!';copy.querySelector('span').textContent=`Received ${row.offer.name}`;
    try{vibrate([18,30,26,30,18]);}catch(_){ }
    await sleep(1250);
    fx.classList.add('leaving');await sleep(260);fx.hidden=true;fx.className='trade-exchange-fx';
  }

  function cardSide(card,kind,rowId){
    const entry=ownedEntry(card),owned=entry?.card,ownedCount=countOf(owned),isNew=!ownedCount;
    const meta=human(card.rarity||'','');
    const setName=human(card.setName||card.setId,'Unknown set');
    return `<div class="trade-card-side"><span class="trade-side-label">${kind==='offer'?'THEY OFFER':'THEY WANT'}</span><div class="trade-card-shell ${kind==='offer'?'offer-card':''}" data-trade-card="${safe(card.id)}" data-trade-row="${safe(rowId)}" data-trade-kind="${kind}">${kind==='offer'&&isNew?'<span class="trade-new">NEW</span>':''}<span class="trade-owned ${ownedCount>1?'has-spares':''} ${ownedCount===0?'zero':''}">OWNED ×${ownedCount}</span>${tradeCardArt(card,`${rowId}:${kind}`)}<b>${safe(human(card.name,'Unknown card'))}</b>${meta?`<small>${safe(meta)}</small>`:''}<small class="trade-set-name">${safe(setName)}</small></div></div>`;
  }

  function tradeCounts(offers){
    const rows=(offers||[]).filter(row=>!row.accepted);
    return {
      all:rows.length,
      ready:rows.filter(row=>countOf(ownedEntry(row.request)?.card)>0).length,
      spares:rows.filter(row=>countOf(ownedEntry(row.request)?.card)>1).length
    };
  }

  function updateTradeBrowser(offers){
    const counts=tradeCounts(offers);
    const all=$('tradeAllCount'),ready=$('tradeReadyCount'),spares=$('tradeSpareCount');
    if(all)all.textContent=counts.all;if(ready)ready.textContent=counts.ready;if(spares)spares.textContent=counts.spares;
    document.querySelectorAll('[data-trade-view]').forEach(btn=>btn.classList.toggle('active',btn.dataset.tradeView===tradeView));
    document.querySelectorAll('[data-trade-source]').forEach(btn=>btn.classList.toggle('active',btn.dataset.tradeSource===tradeSource));
    const clear=$('tradeSearchClear'),query=String($('tradeSearch')?.value||'').trim();if(clear)clear.hidden=!query;
  }

  function renderOffers(offers){
    const list=$('tradeOfferList');if(!list)return;
    const query=String($('tradeSearch')?.value||'').trim().toLowerCase();
    let filtered=(offers||[]).filter(row=>{
      const owned=countOf(ownedEntry(row.request)?.card);
      if(tradeView==='tradeable'&&owned<1)return false;
      if(tradeView==='spares'&&owned<2)return false;
      return !query||[row.trainer,row.offer?.name,row.request?.name,row.offer?.setName,row.request?.setName,row.offer?.rarity,row.request?.rarity].some(v=>String(v||'').toLowerCase().includes(query));
    });
    // Featured is a curated five-card front page. Search always scans the
    // complete current market so typing never feels artificially constrained.
    const visible=(tradeView==='featured'&&!query)?filtered.slice(0,FEATURED_COUNT):filtered;
    updateTradeBrowser(offers);
    if(!visible.length){
      const any=(offers||[]).length>0;
      list.innerHTML=`<div class="trade-empty"><b>${any?'No matching trades':'No trades available yet'}</b><span>${any?(tradeView==='spares'?'No live listing currently asks for a card you own twice.':tradeView==='tradeable'?'None of the live requests match a card in your binder.':'Try another card, trainer, rarity or set name.'):'Open a booster pack first. Only cards from sets you have discovered can enter the market.'}</span></div>`;
      return;
    }
    list.innerHTML=visible.map(row=>{
      const [dealClass,dealCopy]=tradeDealClass(row),owned=ownedEntry(row.request)?.card,can=countOf(owned)>0,last=countOf(owned)===1;
      let action='';
      if(row.accepted)action='<div class="trade-accepted-stamp trade-action-full">✓ TRADE COMPLETE</div>';
      else if(can)action=`<button class="primary trade-accept trade-action-full ${last?'last-copy':''}" data-accept-trade="${safe(row.id)}"><b>${last?'ACCEPT TRADE · LAST COPY':'ACCEPT TRADE'}</b><span>Give ${safe(row.request.name)} · Receive ${safe(row.offer.name)}</span></button>`;
      else action=`<button class="trade-accept trade-action-full unavailable" disabled><b>NEED ${safe(row.request.name).toUpperCase()}</b><span>Find this card in ${safe(row.request.setName||row.request.setId)} to accept</span></button>`;
      return `<article class="trade-offer ${row.accepted?'accepted':''} ${can?'trade-ready':'trade-missing'}" data-trade-offer="${safe(row.id)}"><div class="trade-person"><div class="trade-avatar">${row.avatar}</div><div class="trade-person-copy"><b>${safe(row.trainer)}</b><span>${row.accepted?'Trade completed':can?'You can make this trade':'Global listing · request not in your binder'}</span></div><div class="trade-online"><i></i>${row.accepted?'DONE':can?'READY':'ONLINE'}</div></div><div class="trade-pair">${cardSide(row.offer,'offer',row.id)}<div class="trade-arrow"><span>⇄</span></div>${cardSide(row.request,'request',row.id)}</div><div class="trade-meta"><div class="trade-deal-copy ${dealClass}"><b>${safe(dealCopy)}</b><span>${row.offerTier===row.reqTier?tierLabel(row.offerTier):`${tierLabel(row.offerTier)} ⇄ ${tierLabel(row.reqTier)}`} · ${tradeMode==='same'?'same set':'across discovered sets'}</span></div></div><div class="trade-action-row">${action}</div></article>`;
    }).join('');

    list.querySelectorAll('[data-accept-trade]').forEach(btn=>btn.onclick=()=>acceptTrade(btn.dataset.acceptTrade));
    list.querySelectorAll('[data-trade-card]').forEach(el=>el.onclick=()=>{
      const row=findCurrentOffer(el.dataset.tradeRow);const card=el.dataset.tradeKind==='offer'?row?.offer:row?.request;if(card)openCardModal(card);
    });
  }

  function currentBoard(){
    const trade=ensureTradeState(),info=localSlotInfo();return trade.boards[boardKey(info.slot,tradeMode,tradeSource)]||[];
  }
  function findCurrentOffer(id){return currentBoard().find(x=>x.id===id);}

  function addTradedCard(card){
    const existing=state.cards[card.id];
    if(existing){existing.count=Number(existing.count||0)+1;existing.image=card.image||existing.image;existing.rarity=card.rarity||existing.rarity;return;}
    state.cards[card.id]={...card,count:1,firstPulled:Date.now()};
  }

  let tradeAnimating=false;
  async function acceptTrade(id){
    const row=findCurrentOffer(id);if(!row||row.accepted||tradeAnimating)return;
    const requestedEntry=ownedEntry(row.request),requested=requestedEntry?.card;
    if(!requested||countOf(requested)<1){showToast(`You need ${row.request.name} before you can accept this trade.`);renderOffers(currentBoard());return;}
    // Use the in-app Link Trade confirmation for every exchange. Besides looking
    // like LuckyDex instead of Android/WebView chrome, it makes last-copy risk
    // explicit while showing both cards and owned quantities before committing.
    if(!await confirmTradeInApp(row,requested))return;

    // Commit the collection transaction before starting the cosmetic animation.
    // In v0.16.2 the mutation happened 820 ms into the animation, so an
    // interrupted WebView/animation could look accepted without actually
    // changing the binder. The animation is now presentation-only.
    tradeAnimating=true;
    document.querySelectorAll('[data-accept-trade]').forEach(btn=>btn.disabled=true);
    try{
      requested.count=Number(requested.count||0)-1;if(requested.count<=0)delete state.cards[requestedEntry.key];
      addTradedCard(row.offer);row.accepted=true;
      const trade=ensureTradeState();trade.totalTrades=Number(trade.totalTrades||0)+1;
      state.stats.trades=Number(state.stats.trades||0)+1;
      for(const card of [row.request,row.offer]){
        const source=sourceOf(card),name=setNameOf(card),existing=Object.values(trade.openedSets).find(s=>s.source===source&&norm(s.setName||s.setId)===norm(name));
        if(!existing){const key=`${source}:${setIdOf(card)}`;trade.openedSets[key]={source,setId:setIdOf(card),setName:name};}
      }
      try{if(typeof checkCardMilestones==='function')checkCardMilestones(row.offer.setId);}catch(_){ }
      save();
      try{if(collectionMode==='cards')renderCollection();}catch(_){ }
      try{await playTradeAnimation(row);}catch(_){ }
      showToast(`${row.trainer} traded you ${row.offer.name}!`,2400);
    }catch(err){
      console.error('Lucky Dex trade failed',err);
      showToast('Trade could not be completed. Please try again.',2400);
    }finally{
      tradeAnimating=false;
      renderOffers(currentBoard());renderDiscoveryText();
    }
  }

  function renderDiscoveryText(){
    const el=$('tradeDiscoveryText');if(!el)return;
    const sets=discoveredSets(tradeSource),owned=ownedCards(tradeSource),current=currentBoard(),counts=tradeCounts(current);
    const spares=owned.filter(c=>countOf(c)>1).length;
    el.innerHTML=`<span><b>${current.length||'…'}</b> LIVE</span><span><b>${FEATURED_COUNT}</b> FEATURED</span><span><b>${sets.length}</b> SET${sets.length===1?'':'S'}</span><span><b>${counts.ready}</b> READY</span><span><b>${spares}</b> SPARE CARD${spares===1?'':'S'}</span>`;
  }

  async function renderTradeBoard(force=false){
    ensureTradeState();updateTradeClock();renderDiscoveryText();
    const offers=await ensureBoard(force);renderDiscoveryText();renderOffers(offers);
  }
  window.renderTradeBoard=renderTradeBoard;

  function install(){
    ensureTradeState();
    document.querySelectorAll('[data-trade-mode]').forEach(btn=>btn.onclick=()=>{
      tradeMode=btn.dataset.tradeMode;document.querySelectorAll('[data-trade-mode]').forEach(x=>x.classList.toggle('active',x===btn));renderTradeBoard(false);
    });
    document.querySelectorAll('[data-trade-source]').forEach(btn=>btn.onclick=()=>{
      tradeSource=['tcg','tcgp'].includes(btn.dataset.tradeSource)?btn.dataset.tradeSource:'all';
      document.querySelectorAll('[data-trade-source]').forEach(x=>x.classList.toggle('active',x===btn));renderTradeBoard(false);
    });
    document.querySelectorAll('[data-trade-view]').forEach(btn=>btn.onclick=()=>{
      tradeView=['all','tradeable','spares'].includes(btn.dataset.tradeView)?btn.dataset.tradeView:'featured';
      document.querySelectorAll('[data-trade-view]').forEach(x=>x.classList.toggle('active',x===btn));renderOffers(currentBoard());
    });
    const search=$('tradeSearch');if(search)search.oninput=()=>renderOffers(currentBoard());
    const clear=$('tradeSearchClear');if(clear)clear.onclick=()=>{if(search){search.value='';search.focus();}renderOffers(currentBoard());};
    document.querySelectorAll('[data-nav="trade"]').forEach(btn=>btn.addEventListener('click',()=>renderTradeBoard(false)));
    if(tradeClockTimer)clearInterval(tradeClockTimer);tradeClockTimer=setInterval(updateTradeClock,1000);updateTradeClock();
    document.addEventListener('visibilitychange',()=>{if(!document.hidden)updateTradeClock();});
  }

  window.LuckyDexTrade={
    render:renderTradeBoard,clock:localSlotInfo,current:currentBoard,
    discovered:()=>discoveredSets(tradeSource),owned:()=>ownedCards(tradeSource),
    setMode:(mode)=>{tradeMode=mode==='global'?'global':'same';return renderTradeBoard(false);},
    setSource:(source)=>{tradeSource=['tcg','tcgp'].includes(source)?source:'all';return renderTradeBoard(false);},
    accept:acceptTrade
  };
  install();
})();
