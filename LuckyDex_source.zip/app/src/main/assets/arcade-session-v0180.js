(function(root){
  'use strict';

  const GAME_RULES={
    berryPicker:{run:'60 seconds · Unlimited ends after 3 misses',reward:'Up to 150 coins · Daily item'},
    headIt:{run:'60 seconds + final bonus yarn · Unlimited ends after 3 misses',reward:'Up to 150 coins · Daily item'},
    tilePuzzle:{run:'Swap the moving picture back together',reward:'Up to 130 coins · Daily item'},
    voltorb:{run:'Clear multipliers or cash out before a Voltorb',reward:'Banked Lucky Coins'},
    ballDrop:{run:'Ball 1 / 3',reward:'Ordinary payout + 1000 coin jackpot'},
    berry:{run:'Blend until the timer ends',reward:'Performance-based Lucky Coins'},
    clefairy:{run:'5 classroom rounds · 5 bonks ends the lesson',reward:'Performance-based Lucky Coins'},
    fossil:{run:'Expose buried finds before wall stability reaches zero',reward:'Performance-based Lucky Coins'},
    unown:{run:'Decode 5 messages',reward:'Performance-based Lucky Coins'},
    quiz:{run:'Answer the quiz · Endless ends on failure',reward:'Performance-based Lucky Coins'}
  };
  let activeGame=null;
  let replayAction=null;
  let backAction=null;
  let showing=false;

  function el(id){return typeof document!=='undefined'?document.getElementById(id):null;}
  function titleItem(key){return String(key||'item').replace(/[-_]/g,' ').replace(/\b\w/g,c=>c.toUpperCase());}
  function ruleFor(gameId){return GAME_RULES[gameId]||{run:'Complete the run',reward:'Lucky Coins'};}
  function resultModel({title='GAME COMPLETE',metricLabel='SCORE',metricValue='',coinsAwarded=0,itemAwarded=null,bestText=''}={}){
    const coins=Math.max(0,Math.round(Number(coinsAwarded)||0));
    const amount=Math.max(0,Math.round(Number(itemAwarded?.amount)||0));
    return {
      title:String(title||'GAME COMPLETE'),
      metricLabel:String(metricLabel||'SCORE'),
      metricValue:String(metricValue??''),
      coinsAwarded:coins,
      coinsText:`+${coins} Lucky Coins`,
      itemAwarded:itemAwarded&&amount>0?{key:String(itemAwarded.key||'item'),amount}:null,
      itemText:itemAwarded&&amount>0?`+${amount} ${titleItem(itemAwarded.key)}`:'',
      bestText:String(bestText||'')
    };
  }
  function createCompletionGuard(){
    let complete=false;
    return function completeOnce(fn){
      if(complete)return false;
      complete=true;
      if(typeof fn==='function')fn();
      return true;
    };
  }
  function ensureStrip(gameId,host){
    if(typeof document==='undefined')return null;
    const game=host||el(`${gameId}Game`);
    if(!game)return null;
    let strip=game.querySelector('.arcade-session-strip');
    if(!strip){
      strip=document.createElement('div');strip.className='arcade-session-strip';strip.dataset.sessionGame=gameId;
      strip.innerHTML='<span><small>RUN</small><b data-session-run></b></span><span><small>REWARD</small><b data-session-reward></b></span><span data-session-live-wrap hidden><small data-session-live-label>LIVE</small><b data-session-live></b></span>';
      const head=game.querySelector('.arcade-full-head');
      if(head?.nextSibling)game.insertBefore(strip,head.nextSibling);else game.prepend(strip);
    }
    return strip;
  }
  function mount(gameId,host){
    activeGame=gameId;
    const strip=ensureStrip(gameId,host);
    if(!strip)return ruleFor(gameId);
    const rule=ruleFor(gameId);
    strip.querySelector('[data-session-run]').textContent=rule.run;
    strip.querySelector('[data-session-reward]').textContent=rule.reward;
    const live=strip.querySelector('[data-session-live-wrap]');if(live)live.hidden=true;
    return rule;
  }
  function update(gameId,{runText,rewardText,liveLabel,liveValue}={}){
    const strip=ensureStrip(gameId);if(!strip)return false;
    if(runText!==undefined)strip.querySelector('[data-session-run]').textContent=String(runText);
    if(rewardText!==undefined)strip.querySelector('[data-session-reward]').textContent=String(rewardText);
    const live=strip.querySelector('[data-session-live-wrap]');
    if(liveValue!==undefined){live.hidden=false;strip.querySelector('[data-session-live]').textContent=String(liveValue);strip.querySelector('[data-session-live-label]').textContent=String(liveLabel||'LIVE');}
    return true;
  }
  function hideResult(){
    const sheet=el('arcadeResultSheet');if(sheet)sheet.hidden=true;
    showing=false;replayAction=null;backAction=null;
  }
  function showResult(gameId,opts={}){
    if(showing)return false;
    const model=resultModel(opts);activeGame=gameId;showing=true;
    if(typeof document==='undefined')return model;
    const sheet=el('arcadeResultSheet');if(!sheet){showing=false;return false;}
    el('arcadeResultTitle').textContent=model.title;
    el('arcadeResultMetricLabel').textContent=model.metricLabel;
    el('arcadeResultMetricValue').textContent=model.metricValue;
    el('arcadeResultCoins').textContent=model.coinsText;
    const item=el('arcadeResultItem');item.textContent=model.itemText;item.hidden=!model.itemText;
    const best=el('arcadeResultBest');best.textContent=model.bestText;best.hidden=!model.bestText;
    const replay=el('arcadeResultReplay');replay.textContent=opts.replayLabel||'PLAY AGAIN';
    const venueName=root.LuckyDexArcadeWorld?.venueForGame?.(gameId);const venue=root.LuckyDexArcadeWorld?.VENUES?.find?.(v=>v.id===venueName);
    el('arcadeResultBack').textContent=`BACK TO ${String(venue?.name||'VENUE').toUpperCase()}`;
    replayAction=typeof opts.onReplay==='function'?opts.onReplay:null;
    backAction=typeof opts.onBack==='function'?opts.onBack:null;
    sheet.hidden=false;
    return model;
  }
  function wire(){
    el('arcadeResultReplay')?.addEventListener('click',()=>{const fn=replayAction;hideResult();fn?.();});
    el('arcadeResultBack')?.addEventListener('click',()=>{const fn=backAction;hideResult();if(fn)fn();else root.LuckyDexArcadeWorld?.backFromGame?.(true);});
  }

  const api={GAME_RULES,ruleFor,resultModel,createCompletionGuard,mount,update,showResult,hideResult,isShowing:()=>showing,activeGame:()=>activeGame};
  root.LuckyDexArcadeSession=api;
  if(typeof module!=='undefined'&&module.exports)module.exports=api;
  if(typeof document!=='undefined')wire();
})(typeof window!=='undefined'?window:globalThis);
