(function(root){
  'use strict';
  const core=root.LuckyDexArcadeRecordsCore||(typeof require==='function'?require('./arcade-records-core.js'):null);
  const platform=()=>root.LuckyDexArcadePlatform||(typeof require==='function'?require('./arcade-platform.js'):null);
  const SUPPORTED_GAME_IDS=['berryPicker','tilePuzzle','voltorb','ballDrop','berry','clefairy','fossil','unown','quiz','dash','powerTrial','impactTrial','targetRange','elementalGauntlet','enduranceExpedition','roulette','slotMachine','ekansHoop','digDigDig','magikarpSplash','rockHarden','thunderingDynamo','snoreWar','runRattataRun','sushiGoRound','clearCutChallenge'];
  const GAME_NAMES={berryPicker:'Berry Picker',tilePuzzle:'Tile Puzzle',voltorb:'Voltorb Flip',ballDrop:'Poké Ball Drop',berry:'Berry Blender',clefairy:'Clefairy Match',fossil:'Fossil Dig',unown:'Unown Decoder',quiz:"Who's That Pokémon?",dash:'Pokémon Dash',powerTrial:'Power Trial',impactTrial:'Impact Trial',targetRange:'Target Range',elementalGauntlet:'Elemental Gauntlet',enduranceExpedition:'Endurance Expedition',roulette:'Mauville Roulette',slotMachine:'Mauville Slot Machine',ekansHoop:'Ekans’ Hoop Hurl',digDigDig:'Dig! Dig! Dig!',magikarpSplash:'Magikarp’s Splash',rockHarden:'Rock Harden',thunderingDynamo:'Thundering Dynamo',snoreWar:'Snore War',runRattataRun:'Run, Rattata, Run',sushiGoRound:'Sushi-Go-Round',clearCutChallenge:'Clear Cut Challenge'};
  const s=v=>String(v==null?'':v);
  const fmt=n=>Number(n||0).toLocaleString('en-GB');
  const time=ms=>Number(ms)>0?`${(Number(ms)/1000).toFixed(2)}s`:'—';
  const seconds=value=>Number(value)>0?`${Number(value).toFixed(2)}s`:'—';
  const period=ms=>Number(ms)>0?`${Math.round(Number(ms))} ms / swing`:'—';
  function stateRef(){return root.state||globalThis.state||null;}
  function arcadeState(){const st=stateRef();if(!st)return {};const p=platform();st.arcade=p?.ensureArcadeState?p.ensureArcadeState(st.arcade):(st.arcade||{});return st.arcade;}
  function rows(...pairs){return pairs.filter(x=>x&&x[0]!=null&&x[1]!=null&&x[1]!=='').map(([label,value])=>({label:s(label),value:s(value)}));}
  function section(title,rs){return {title:s(title),rows:rs||[]};}
  function difficultyRows(obj,formatter=v=>fmt(v)){return ['easy','normal','hard'].filter(k=>obj&&obj[k]!=null).map(k=>({label:k[0].toUpperCase()+k.slice(1),value:formatter(obj[k])}));}
  function goldenrodCupSection(a,eventId){
    const e=a.goldenrod?.events?.[eventId]||{},div=e.divisionTrophies||{},types=e.typeTrophies||{};
    const divisionMedals=Object.values(div).filter(Boolean),typeMedals=Object.values(types).flatMap(by=>Object.values(by||{})).filter(Boolean);
    return section('Goldenrod Cups',rows(['Highest Division',String(e.unlockedDivision||'rookie').replace(/\b\w/g,c=>c.toUpperCase())],['Division Trophies',fmt(divisionMedals.length)],['Master Trophy',div.master?String(div.master).toUpperCase():'—'],['Type Cup Trophies',fmt(typeMedals.length)]));
  }
  const adapters={
    berryPicker:a=>[section('Best Scores',difficultyRows(a.bestBerryPicker))],
    tilePuzzle:a=>[section('Best Times',difficultyRows(a.bestTilePuzzle,seconds))],
    voltorb:a=>[section('Career',rows(['Current Level',a.voltorbLevel||1]))],
    ballDrop:a=>[section('Career',rows(['Best Score',fmt(a.bestBallDrop)],['Jackpots',fmt(a.ballDropJackpots)]))],
    berry:(a,st)=>[section('Career',rows(['Perfect Blends',fmt(st?.stats?.perfectBerryRounds)]))],
    clefairy:a=>[section('Career',rows(['Best Round',fmt(a.bestMemory)]))],
    fossil:a=>[section('Career',rows(['Best Dig',fmt(a.bestFossil)],['Finds Recovered',fmt(a.fossilsFound)],['Museum Exhibits',fmt(Object.values(a.museum?.exhibits||{}).filter(x=>x?.discovered).length)]))],
    unown:a=>[section('Career',rows(['Best Score',fmt(a.bestUnown)]))],
    quiz:a=>[section('Career',rows(['Best Score',fmt(a.bestQuiz)],['Best Endless Streak',fmt(a.bestQuizEndless)],['Best Endless Score',fmt(a.bestQuizEndlessScore)]))],
    dash:a=>{const d=a.dash||{};return [section('Career',rows(['Races',fmt(d.races)],['Wins',fmt(d.wins)],['Podiums',fmt(d.podiums)],['Best Time',time(d.bestTimeMs)])),section('Quick Race Bests',['easy','normal','hard','expert'].map(k=>({label:k[0].toUpperCase()+k.slice(1),value:time(d.quickBestTimes?.[k])}))),goldenrodCupSection(a,'dash')];},
    powerTrial:a=>{const r=a.powerTrial||{};return [section('Career',rows(['Games',fmt(r.gamesPlayed)],['Full Clears',fmt(r.fullClears)],['Hard Clears',fmt(r.hardClears)],['Best Score',fmt(r.bestScore)],['Best Hit',r.bestSingleHit?`${Number(r.bestSingleHit).toFixed(1)} power`:'—'],['Perfect Hits',fmt(r.perfectHits)],['Golden Targets',`${fmt(r.goldenTargetsCleared)} / ${fmt(r.goldenTargetsSeen)} cleared`])),section('Best Scores',difficultyRows(r.bestScores)),goldenrodCupSection(a,'powerTrial')];},
    impactTrial:a=>{const r=a.impactTrial||{},accuracy=Number(r.hardenTargetsSeen)>0?Math.round(Number(r.hardenTargetsHit||0)/Number(r.hardenTargetsSeen)*100):0;return [section('Career',rows(['Games',fmt(r.gamesPlayed)],['Full Clears',fmt(r.fullClears)],['Hard Clears',fmt(r.hardClears)],['No-Damage Clears',fmt(r.noDamageClears)],['Best Score',fmt(r.bestScore)],['Best Integrity',`${fmt(r.bestIntegrity)}%`],['Best Harden',`${fmt(r.bestHardenPct)}%`],['Perfect Hardens',fmt(r.perfectDefenses)],['Shield Hits',`${fmt(r.hardenTargetsHit)} / ${fmt(r.hardenTargetsSeen)} (${accuracy}%)`],['Golden Hazards',`${fmt(r.goldenHazardsCleared)} / ${fmt(r.goldenHazardsSeen)} cleared`])),section('Best Scores',difficultyRows(r.bestScores)),goldenrodCupSection(a,'impactTrial')];},
    targetRange:a=>{const r=a.targetRange||{},accuracy=Number(r.totalShots)>0?Math.round(Number(r.totalHits||0)/Number(r.totalShots)*100):0;return [section('Career',rows(['Games',fmt(r.gamesPlayed)],['Best Score',fmt(r.bestScore)],['Best Accuracy',`${fmt(r.bestAccuracy)}%`],['Bullseyes',fmt(r.totalBullseyes)],['Best Bullseyes',fmt(r.bestBullseyes)],['Best Bullseye Streak',fmt(r.bestBullseyeStreak)],['Longest Bullseye',Number(r.longestBullseyeM)>0?`${fmt(r.longestBullseyeM)} m`:'—'],['Career Accuracy',`${accuracy}%`],['Golden Targets',`${fmt(r.goldenTargetsWon)} / ${fmt(r.goldenTargetsSeen)} won`])),section('Best Scores',difficultyRows(r.bestScores)),goldenrodCupSection(a,'targetRange')];},
    elementalGauntlet:a=>{const r=a.elementalGauntlet||{};return [section('Career',rows(['Games',fmt(r.gamesPlayed)],['Full Clears',fmt(r.fullClears)],['Hard Clears',fmt(r.hardClears)],['No-Damage Clears',fmt(r.noDamageClears)],['Best Score',fmt(r.bestScore)],['Best HP Remaining',`${fmt(r.bestHealth)}%`],['Best Perfect Waves',`${fmt(r.bestPerfectWaves)} / 5`],['Dodges',fmt(r.totalDodges)],['Shielded Hits',fmt(r.totalGuards)],['Damage Taken',fmt(r.totalDamageTaken)],['Prismatic Storms',`${fmt(r.prismaticStormsCleared)} / ${fmt(r.prismaticStormsSeen)} cleared`])),section('Best Scores',difficultyRows(r.bestScores)),goldenrodCupSection(a,'elementalGauntlet')];},
    enduranceExpedition:a=>{const r=a.enduranceExpedition||{};return [section('Career',rows(['Games',fmt(r.gamesPlayed)],['Full Clears',fmt(r.fullClears)],['Hard Clears',fmt(r.hardClears)],['Flawless Clears',fmt(r.flawlessClears)],['Low-HP Hard Clears',fmt(r.lowHpHardClears)],['Best Score',fmt(r.bestScore)],['Best Endurance Remaining',`${fmt(r.bestEndurancePct)}%`],['Best Perfect Zones',`${fmt(r.bestPerfectStages)} / 5`],['Obstacles Cleared',fmt(r.totalObstaclesCleared)],['Hits Taken',fmt(r.totalHits)],['Golden Trail Caches',`${fmt(r.goldenCachesCollected)} / ${fmt(r.goldenCachesSeen)} collected`])),section('Best Scores',difficultyRows(r.bestScores)),goldenrodCupSection(a,'enduranceExpedition')];},
    ekansHoop:a=>{const r=a.ekansHoop||{};return [section('Career',rows(['Games',fmt(r.gamesPlayed)],['Wins',fmt(r.wins)],['Best Score',fmt(r.bestScore)],['Best Streak',fmt(r.bestStreak)],['Total Hoops',fmt(r.totalHoops)],['Shiny Hits',fmt(r.shinyHits)]))];},
    digDigDig:a=>{const r=a.digDigDig||{};return [section('Career',rows(['Games',fmt(r.gamesPlayed)],['Wins',fmt(r.wins)],['Podiums',fmt(r.podiums)],['Best Time',time(r.bestTimeMs)])),section('Best Times',difficultyRows(r.bestTimes,time))];},
    magikarpSplash:a=>{const r=a.magikarpSplash||{};return [section('Career',rows(['Games',fmt(r.gamesPlayed)],['Wins',fmt(r.wins)],['Podiums',fmt(r.podiums)],['Best Score',fmt(r.bestScore)],['Best Quick Chain',fmt(r.bestQuickChain)])),section('Best Scores',difficultyRows(r.bestScores))];},
    rockHarden:a=>{const r=a.rockHarden||{};return [section('Career',rows(['Games',fmt(r.gamesPlayed)],['Wins',fmt(r.wins)],['Podiums',fmt(r.podiums)],['Best Score',fmt(r.bestScore)],['Best Perfects',fmt(r.bestPerfects)],['Best HP Remaining',fmt(r.bestHpRemaining)],['Gold Rewards Claimed',fmt(r.goldRewardsClaimed)])),section('Best Scores',difficultyRows(r.bestScores))];},
    thunderingDynamo:a=>{const r=a.thunderingDynamo||{};return [section('Career',rows(['Games',fmt(r.gamesPlayed)],['Wins',fmt(r.wins)],['Podiums',fmt(r.podiums)],['Best Time',time(r.bestTimeMs)],['Best Accuracy',`${fmt(r.bestAccuracy)}%`],['Correct Presses',fmt(r.totalCorrect)],['Wrong Presses',fmt(r.totalWrong)])),section('Best Times',difficultyRows(r.bestTimes,time))];},
    snoreWar:a=>{const r=a.snoreWar||{};return [section('Career',rows(['Games',fmt(r.gamesPlayed)],['Wins',fmt(r.wins)],['Podiums',fmt(r.podiums)],['Best Streak',fmt(r.bestStreak)],['Best Accuracy',`${fmt(r.bestAccuracy)}%`],['Hypnosis Hits',fmt(r.totalHits)],['Misses',fmt(r.totalMisses)])),section('Endless',rows(['Endless Runs',fmt(r.endlessRuns)],['Best Endless Hits',fmt(r.bestEndlessHits)],['Best Endless Streak',fmt(r.bestEndlessStreak)],['Fastest Pendulum',period(r.bestEndlessPeriodMs)])),section('Difficulty Wins',difficultyRows(r.winsByDifficulty))];},
    runRattataRun:a=>{const r=a.runRattataRun||{};return [section('Career',rows(['Games',fmt(r.gamesPlayed)],['Wins',fmt(r.wins)],['Podiums',fmt(r.podiums)],['Best Time',time(r.bestTimeMs)],['Flawless Wins',fmt(r.flawlessWins)],['Hurdles Cleared',fmt(r.totalHurdlesCleared)],['Hurdles Hit',fmt(r.totalHurdlesHit)])),section('Best Times',difficultyRows(r.bestTimes,time)),section('Difficulty Wins',difficultyRows(r.winsByDifficulty))];},
    sushiGoRound:a=>{const r=a.sushiGoRound||{};return [section('Career',rows(['Games',fmt(r.gamesPlayed)],['Wins',fmt(r.wins)],['Podiums',fmt(r.podiums)],['Best Bill',`¥${fmt(r.bestBill)}`],['Best Combo',`x${fmt(r.bestCombo)}`],['Sushi Eaten',fmt(r.totalSushiEaten)],['Hot Tea Hits',fmt(r.hotPenalties)])),section('Best Bills',difficultyRows(r.bestBills,v=>`¥${fmt(v)}`)),section('Difficulty Wins',difficultyRows(r.winsByDifficulty))];},
    clearCutChallenge:a=>{const r=a.clearCutChallenge||{},avg=Number(r.totalCuts)>0?Number(r.totalAbsErrorPct||0)/Number(r.totalCuts):null;return [section('Career',rows(['Games',fmt(r.gamesPlayed)],['Best Score',`${fmt(r.bestScore)}/100`],['Perfect Cuts',fmt(r.totalPerfects)],['Closest Cut',r.closestCutPct==null?'—':`${Number(r.closestCutPct).toFixed(2)}%`],['Average Error',avg==null?'—':`${avg.toFixed(2)}%`],['Mystery Bags',`${fmt(r.bagsPerfect)} perfect · ${fmt(r.bagPrizes)} prizes`])),section('Best Scores',difficultyRows(r.bestScores,v=>`${fmt(v)}/100`))];},
    roulette:a=>{const r=a.roulette||{},net=Number(r.coinsWon||0)-Number(r.coinsWagered||0);return [section('Career',rows(['Tables Completed',fmt(r.tablesCompleted)],['Spins',fmt(r.spins)],['Wins',fmt(r.wins)],['Exact Slot Wins',fmt(r.exactWins)],['Pokémon Wins',fmt(r.pokemonWins)],['Colour Wins',fmt(r.colorWins)],['Best Payout',`${fmt(r.bestPayout)} coins`],['Biggest Multiplier',`×${fmt(r.biggestMultiplier)}`],['Career Net',`${net>=0?'+':''}${fmt(net)} coins`],['Stuck-Ball Rescues',fmt(r.rescueEvents)],['Service Day Spins',fmt(r.serviceDaySpins)],['Golden Balls',fmt(r.goldenBalls)],['Golden Ball Bonus',`${fmt(r.goldenBallCoins)} coins`]))];},
    slotMachine:a=>{const r=a.slotMachine||{},net=Number(r.coinsWon||0)-Number(r.coinsWagered||0);return [section('Career',rows(['Spins',fmt(r.spins)],['Wins',fmt(r.wins)],['Jackpots',fmt(r.jackpots)],['Mixed 7 Wins',fmt(r.mixedSevens)],['Replays',fmt(r.replays)],['Reel Times',fmt(r.reelTimes)],['Best Payout',`${fmt(r.bestPayout)} coins`],['Biggest Multiplier',`×${fmt(r.biggestMultiplier)}`],['Max Pika Power',`${fmt(r.maxPower)} / 16`],['Career Net',`${net>=0?'+':''}${fmt(net)} coins`]))];}
  };
  function adapterFor(gameId){return SUPPORTED_GAME_IDS.includes(String(gameId))?adapters[String(gameId)]||null:null;}
  function getPermanent(gameId){const fn=adapterFor(gameId);if(!fn)return [];try{return fn(arcadeState(),stateRef())||[];}catch(_){return [];}}
  function captureAchievementSnapshot(){
    const api=root.LuckyDexAchievements;let result=[];let available=false;
    try{if(api&&typeof api.snapshotCompletedArcadeIds==='function'){result=api.snapshotCompletedArcadeIds()||[];available=true;}}catch(_){result=[];available=false;}
    result=Array.isArray(result)?result.map(String):[];try{Object.defineProperty(result,'available',{value:available,enumerable:false});}catch(_){}return result;
  }
  function achievementRows(before){
    if(!Array.isArray(before)||before.available===false)return [];
    const api=root.LuckyDexAchievements;if(!api?.snapshotCompletedArcadeIds||!api?.describeAchievementIds)return [];
    try{const after=api.snapshotCompletedArcadeIds()||[], ids=after.map(String).filter(id=>!new Set(before.map(String)).has(id));return api.describeAchievementIds(ids)||[];}catch(_){return [];}
  }
  function commitReview(gameId,review,{achievementBefore=null,historyKey,completedAt=Date.now()}={}){
    let model=core.normalizeReview(gameId,review||{});
    const newRows=achievementRows(achievementBefore);
    if(newRows.length)model=core.normalizeReview(gameId,{...model,achievements:[...(model.achievements||[]),...newRows]});
    const entry=core.historyEntryFromReview(model,{completedAt,entryId:historyKey});
    if(!entry)return model;
    try{
      const a=arcadeState();const next=core.appendHistory(a.records,gameId,entry,10);a.records=next.store;
      if(next.appended){try{root.save?.();}catch(error){try{console.warn('[LuckyDex] arcade records save failed',error);}catch(_){}}}
    }catch(error){try{console.warn('[LuckyDex] arcade records commit failed',error);}catch(_){}}
    return model;
  }
  function getRecent(gameId){try{return (arcadeState().records?.games?.[String(gameId)]?.recent||[]).map(x=>core.normalizeHistoryEntry(gameId,x)).filter(Boolean).slice(0,10);}catch(_){return [];}}

  let opened=false,currentGame=null;
  function el(id){return typeof document!=='undefined'?document.getElementById(id):null;}
  function esc(v){return s(v).replace(/[&<>\"]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]));}
  function permanentSummary(gameId){const sections=getPermanent(gameId),flat=sections.flatMap(x=>x.rows||[]).filter(r=>r&&r.value!==''&&r.value!=='—');return flat.slice(0,2).map(r=>`${r.label}: ${r.value}`).join(' · ')||'No permanent record yet';}
  function renderList(){
    const list=el('arcadeRecordsList'),detail=el('arcadeRecordsDetail'),title=el('arcadeRecordsTitle'),summary=el('arcadeRecordsSummary');if(!list)return false;
    currentGame=null;if(title)title.textContent='ARCADE RECORDS';if(summary)summary.textContent='Permanent records and your 10 most recent completed runs.';if(detail)detail.hidden=true;list.hidden=false;
    list.innerHTML=SUPPORTED_GAME_IDS.map(id=>{const recent=getRecent(id);return `<button type="button" class="arcade-record-card" data-records-game="${esc(id)}"><b>${esc(GAME_NAMES[id]||id)}</b><span>${esc(permanentSummary(id))}</span><small>${recent.length} / 10 RECENT RUNS</small></button>`;}).join('');return true;
  }
  function renderGame(gameId){
    if(!adapterFor(gameId))return false;const list=el('arcadeRecordsList'),detail=el('arcadeRecordsDetail'),title=el('arcadeRecordsTitle'),summary=el('arcadeRecordsSummary');if(!detail)return false;
    currentGame=String(gameId);if(list)list.hidden=true;detail.hidden=false;if(title)title.textContent=GAME_NAMES[gameId]||gameId;const recent=getRecent(gameId);if(summary)summary.textContent=`PERMANENT RECORDS · ${recent.length} RECENT RUN${recent.length===1?'':'S'}`;
    const permanent=getPermanent(gameId).map(sec=>`<section class="arcade-record-section"><h3>${esc(sec.title)}</h3>${(sec.rows||[]).map(r=>`<div class="arcade-record-kv"><span>${esc(r.label)}</span><b>${esc(r.value)}</b></div>`).join('')}</section>`).join('');
    const runs=recent.length?`<section class="arcade-record-section"><h3>RECENT RUNS</h3><div class="arcade-run-list">${recent.map((r,i)=>`<button type="button" class="arcade-run-row" data-records-run="${esc(r.entryId)}"><small>${String(i+1).padStart(2,'0')}</small><span>${esc([r.mode,r.difficulty,r.title].filter(Boolean).join(' · ')||'Completed run')}</span><b>${esc(r.primaryMetric||r.metricValue||'VIEW')}</b></button>`).join('')}</div></section>`:`<div class="arcade-record-empty">Detailed run history starts with v0.39.0. Your older permanent records are still shown above.</div>`;
    detail.innerHTML=permanent+runs;return true;
  }
  function open({gameId=null}={}){if(typeof document==='undefined'){opened=true;currentGame=gameId||null;return true;}root.LuckyDexArcadeSession?.hideResult?.();const view=el('arcadeRecordsView');if(!view)return false;const world=el('arcadeWorldView'),venue=el('arcadeVenueView');if(world)world.hidden=true;if(venue)venue.hidden=true;document.querySelectorAll('.arcade-game').forEach(n=>n.hidden=true);document.body?.classList?.add('arcade-mode');document.body?.classList?.remove('arcade-open','arcade-venue-open');view.hidden=false;opened=true;return gameId?renderGame(gameId):renderList();}
  function openGame(gameId){return open({gameId});}
  function openStoredRun(gameId,entryId){const entry=getRecent(gameId).find(r=>r.entryId===String(entryId));if(!entry)return false;const view=el('arcadeRecordsView');if(view)view.hidden=true;opened=false;return root.LuckyDexArcadeSession?.showStoredReview?.(gameId,entry)||false;}
  function close(){opened=false;currentGame=null;const view=el('arcadeRecordsView');if(view)view.hidden=true;if(root.LuckyDexArcadeWorld?.openWorld)return root.LuckyDexArcadeWorld.openWorld({focusVenueId:root.LuckyDexArcadeWorld.selectedVenue?.(),activateMode:true});return true;}
  function isOpen(){return !!opened;}
  function wire(){if(typeof document==='undefined')return;el('arcadeRecordsBack')?.addEventListener('click',()=>{if(currentGame)renderList();else close();});document.addEventListener('click',e=>{const g=e.target.closest?.('[data-records-game]');if(g){renderGame(g.dataset.recordsGame);return;}const r=e.target.closest?.('[data-records-run]');if(r&&currentGame)openStoredRun(currentGame,r.dataset.recordsRun);});}
  if(typeof document!=='undefined')wire();
  const api={SUPPORTED_GAME_IDS,GAME_NAMES,adapterFor,captureAchievementSnapshot,commitReview,getRecent,getPermanent,open,openGame,openStoredRun,close,isOpen};
  root.LuckyDexArcadeRecords=api;if(typeof module!=='undefined'&&module.exports)module.exports=api;
})(typeof window!=='undefined'?window:globalThis);
