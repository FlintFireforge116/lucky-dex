/* LuckyDex v0.26.3 physical booster artwork.
   Prefer APK-local packshots generated at build time. If the repository's
   outer workflow skips that materialisation, resolve the same exact ptcg-assets
   packshot directory at runtime rather than showing the generic wrapper. */
(function(root,factory){
  const api=factory(root);
  root.LuckyDexBoosterArt=api;
  if(typeof module!=='undefined'&&module.exports)module.exports=api;
})(typeof window!=='undefined'?window:globalThis,function(root){
  'use strict';
  const MANIFEST='booster-art-index-v0260.json';
  const REMOTE_REPO='1niceroli/ptcg-assets';
  let manifestPromise=null,manifestCache=null;
  const remoteCache=new Map();
  function setKey(set){
    const raw=String(set?._libraryKey||set?._libraryCode||set?.id||set||'').trim().replace(/^library:/i,'');
    return raw.replace(/^en[_:-]/i,'');
  }
  function localPath(set){const key=setKey(set);return key?`booster-art-v0260/${key}.webp`:'';}
  function remoteApiUrl(set){
    const key=setKey(set);return key?`https://api.github.com/repos/${REMOTE_REPO}/contents/${encodeURIComponent(key)}/packshots?ref=main`:'';
  }
  async function loadManifest(){
    if(manifestCache)return manifestCache;
    if(manifestPromise)return manifestPromise;
    manifestPromise=(async()=>{
      if(typeof fetch!=='function')return {};
      try{const response=await fetch(MANIFEST,{cache:'no-store'});if(!response.ok)return {};const data=await response.json();manifestCache=data&&typeof data==='object'?data:{};return manifestCache;}catch(_){return {};}finally{manifestPromise=null;}
    })();
    return manifestPromise;
  }
  async function resolveRemote(set){
    const key=setKey(set);if(!key||typeof fetch!=='function')return '';
    if(remoteCache.has(key))return remoteCache.get(key);
    const job=(async()=>{
      try{
        const response=await fetch(remoteApiUrl(set),{cache:'force-cache',headers:{Accept:'application/vnd.github+json'}});
        if(!response.ok)return '';
        const rows=await response.json();
        if(!Array.isArray(rows))return '';
        const files=rows.filter(row=>row?.type==='file'&&row?.download_url&&/\.(?:webp|png|jpe?g)$/i.test(String(row.name||row.download_url))).sort((a,b)=>String(a.name||'').localeCompare(String(b.name||'')));
        return String(files[0]?.download_url||'');
      }catch(_){return '';}
    })();
    remoteCache.set(key,job);
    const value=await job;remoteCache.set(key,Promise.resolve(value));return value;
  }
  async function has(set){return !!(await resolve(set));}
  async function resolve(set){
    const key=setKey(set),manifest=await loadManifest();
    if(key&&manifest[key])return String(manifest[key]);
    return resolveRemote(set);
  }
  async function list(set){const hit=await resolve(set);return hit?[hit]:[];}
  return {MANIFEST,REMOTE_REPO,setKey,localPath,remoteApiUrl,loadManifest,resolveRemote,has,resolve,list};
});
