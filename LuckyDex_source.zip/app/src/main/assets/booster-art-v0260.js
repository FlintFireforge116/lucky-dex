/* LuckyDex v0.26.0 local physical booster artwork.
   GitHub Actions materialises one representative English packshot per real
   booster set into app assets. Runtime never queries GitHub for booster art. */
(function(root,factory){
  const api=factory(root);
  root.LuckyDexBoosterArt=api;
  if(typeof module!=='undefined'&&module.exports)module.exports=api;
})(typeof window!=='undefined'?window:globalThis,function(root){
  'use strict';
  const MANIFEST='booster-art-index-v0260.json';
  let manifestPromise=null,manifestCache=null;
  function setKey(set){
    const raw=String(set?._libraryKey||set?._libraryCode||set?.id||set||'').trim().replace(/^library:/i,'');
    return raw.replace(/^en[_:-]/i,'');
  }
  function localPath(set){const key=setKey(set);return key?`booster-art-v0260/${key}.webp`:'';}
  async function loadManifest(){
    if(manifestCache)return manifestCache;
    if(manifestPromise)return manifestPromise;
    manifestPromise=(async()=>{
      if(typeof fetch!=='function')return {};
      try{const response=await fetch(MANIFEST,{cache:'no-store'});if(!response.ok)return {};const data=await response.json();manifestCache=data&&typeof data==='object'?data:{};return manifestCache;}catch(_){return {};}finally{manifestPromise=null;}
    })();
    return manifestPromise;
  }
  async function has(set){const key=setKey(set),manifest=await loadManifest();return !!(key&&manifest[key]);}
  async function resolve(set){const key=setKey(set),manifest=await loadManifest();return key&&manifest[key]?String(manifest[key]):'';}
  async function list(set){const hit=await resolve(set);return hit?[hit]:[];}
  return {MANIFEST,setKey,localPath,loadManifest,has,resolve,list};
});
