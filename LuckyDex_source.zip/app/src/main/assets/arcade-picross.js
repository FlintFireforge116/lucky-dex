(function(root){
  'use strict';
  const core=root.LuckyDexPicrossCore;
  const data=root.LuckyDexPicrossData;
  if(!core||!data)return;
  const puzzleById=new Map((data.puzzles||[]).map(p=>[p.resource_id,p]));
  const areaById=new Map((data.areas||[]).map(a=>[Number(a.area),a]));
  const $=id=>typeof document!=='undefined'?document.getElementById(id):null;
  let opened=false,selectedArea=0,selectedPuzzleId=null,board=null,tool='fill',timer=null,finished=false;
  let drag={active:false,pointerId:null,mark:null,visited:new Set()};

  function platform(){return root.LuckyDexArcadePlatform||null;}
  function session(){return root.LuckyDexArcadeSession||null;}
  function state(){return root.state||globalThis.state||null;}
  function save(){try{root.save?.();}catch(_){}}
  function arcadeRecord(){
    const s=state();if(!s)return {completed:{},bestTimesMs:{},totalClears:0,noMistakeClears:0};
    s.arcade=platform()?.ensureArcadeState?platform().ensureArcadeState(s.arcade):(s.arcade||{});
    s.arcade.picross=s.arcade.picross||{completed:{},bestTimesMs:{},totalClears:0,noMistakeClears:0};
    return s.arcade.picross;
  }
  const completed=id=>!!arcadeRecord().completed?.[id];
  const sortedSlots=area=>(area?.slots||[]).slice().sort((a,b)=>Number(a.y)-Number(b.y)||Number(a.x)-Number(b.x));
  function stageLabel(area,resourceId){const slots=sortedSlots(area);const index=slots.findIndex(s=>s.resource_id===resourceId);return core.stageNumber(area?.area,index<0?0:index);}
  function progress(){return core.progressSummary(data.areas,arcadeRecord());}
  function setView(which){
    for(const id of ['picrossAreaView','picrossLevelView','picrossPuzzleView']){const n=$(id);if(n)n.hidden=id!==which;}
  }
  function setStatus(text='',complete=false){const n=$('picrossStatus');if(!n)return;n.textContent=String(text||'');n.classList.toggle('picross-complete-note',!!complete);}
  function miniature(puzzle,large=false){
    if(!puzzle)return '';
    const maxW=large?120:40,maxH=large?90:36;
    const cell=Math.max(1,Math.floor(Math.min(maxW/puzzle.width,maxH/puzzle.height)));
    const cells=puzzle.solution_rows.flatMap((row,y)=>[...row].map((v,x)=>`<i class="picross-mini-cell${v==='1'?' on':''}" aria-hidden="true"></i>`)).join('');
    return `<span class="picross-mini-grid" style="grid-template-columns:repeat(${puzzle.width},${cell}px);grid-template-rows:repeat(${puzzle.height},${cell}px);--mini-cell:${cell}px">${cells}</span>`;
  }
  function renderOverview(){
    const p=progress(),host=$('picrossOverview');if(!host)return;
    host.innerHTML=`<div><small>PICTURES</small><b>${p.uniqueClears} / ${p.totalStages}</b></div><div><small>AREAS</small><b>${p.areasCleared} / ${p.totalAreas}</b></div><div><small>ERRORLESS</small><b>${Number(arcadeRecord().noMistakeClears||0)}</b></div>`;
  }
  function showAreas(){
    stopTimer();board=null;selectedPuzzleId=null;finished=false;setView('picrossAreaView');renderOverview();
    const host=$('picrossAreaGrid');if(!host)return;
    const r=arcadeRecord();host.innerHTML=(data.areas||[]).map(area=>{
      const slots=area.slots||[],done=slots.filter(s=>r.completed?.[s.resource_id]).length,full=slots.length>0&&done===slots.length;
      return `<button type="button" class="picross-area-card${full?' is-complete':''}" data-picross-area="${area.area}"><small>${done}/${slots.length}</small><b>AREA ${String(area.area).padStart(2,'0')}</b><span>${full?'COMPLETE':'SELECT AREA'}</span></button>`;
    }).join('');
  }
  function showLevels(areaId=selectedArea){
    stopTimer();board=null;selectedPuzzleId=null;finished=false;selectedArea=Number(areaId)||0;const area=areaById.get(selectedArea);if(!area)return showAreas();setView('picrossLevelView');
    const r=arcadeRecord(),slots=sortedSlots(area),done=slots.filter(s=>r.completed?.[s.resource_id]).length;
    if($('picrossLevelTitle'))$('picrossLevelTitle').textContent=`AREA ${String(selectedArea).padStart(2,'0')}`;
    if($('picrossLevelProgress'))$('picrossLevelProgress').textContent=`${done} / ${slots.length} COMPLETE`;
    const host=$('picrossLevelGrid');if(!host)return;
    const placed=new Map((area.slots||[]).map(slot=>[`${slot.x}:${slot.y}`,slot]));let html='';
    for(let y=0;y<3;y++)for(let x=0;x<5;x++){
      const slot=placed.get(`${x}:${y}`);if(!slot){html+='<div class="picross-empty-slot" aria-hidden="true"></div>';continue;}
      const puzzle=puzzleById.get(slot.resource_id),isDone=!!r.completed?.[slot.resource_id],index=slots.findIndex(s=>s.resource_id===slot.resource_id),label=core.stageNumber(selectedArea,index);
      const preview=isDone?miniature(puzzle):'<span aria-hidden="true">?</span>';
      const name=puzzle?.kind==='tutorial'?String(puzzle.display_name||'Tutorial'):(isDone?'POKÉMON':'HIDDEN');
      html+=`<button type="button" class="picross-level-card${isDone?' is-complete':''}" data-picross-puzzle="${slot.resource_id}"><b>${label}</b><div class="picross-level-preview">${preview}</div><span>${puzzle?.width||slot.width}×${puzzle?.height||slot.height} · ${name}</span></button>`;
    }
    host.innerHTML=html;
  }
  function cellSizeFor(puzzle){const w=Math.max(1,puzzle.width),h=Math.max(1,puzzle.height),vw=Math.max(300,Math.min(760,(typeof window!=='undefined'?window.innerWidth:480)-36));return Math.max(15,Math.min(27,Math.floor((vw-88)/w),Math.floor(480/h)));}
  function renderBoard(){
    if(!board)return;const puzzle=board.puzzle,host=$('picrossBoard');if(!host)return;
    const cell=cellSizeFor(puzzle),rowClue=Math.max(48,Math.min(84,Math.max(...puzzle.row_clues.map(c=>c.length),1)*14+10));
    host.style.setProperty('--picross-cell',`${cell}px`);host.style.setProperty('--picross-row-clue',`${rowClue}px`);
    host.style.gridTemplateColumns=`${rowClue}px repeat(${puzzle.width},${cell}px)`;
    host.style.gridTemplateRows=`${Math.max(44,Math.max(...puzzle.column_clues.map(c=>c.length),1)*12+8)}px repeat(${puzzle.height},${cell}px)`;
    let html='<div class="picross-corner"></div>';
    for(let x=0;x<puzzle.width;x++)html+=`<div class="picross-column-clue" data-picross-col-clue="${x}" style="grid-column:${x+2};grid-row:1">${puzzle.column_clues[x].map(n=>`<span>${n}</span>`).join('')}</div>`;
    for(let y=0;y<puzzle.height;y++){
      html+=`<div class="picross-row-clue" data-picross-row-clue="${y}" style="grid-column:1;grid-row:${y+2}">${puzzle.row_clues[y].map(n=>`<span>${n}</span>`).join('')}</div>`;
      for(let x=0;x<puzzle.width;x++)html+=`<button type="button" class="picross-cell" aria-label="Row ${y+1}, column ${x+1}" data-picross-cell data-x="${x}" data-y="${y}" data-x5="${(x+1)%5===0&&x<puzzle.width-1}" data-y5="${(y+1)%5===0&&y<puzzle.height-1}" style="grid-column:${x+2};grid-row:${y+2}"></button>`;
    }
    host.innerHTML=html;renderBoardState();
  }
  function renderBoardState(){
    if(!board)return;
    document.querySelectorAll('#picrossBoard [data-picross-cell]').forEach(node=>{const x=Number(node.dataset.x),y=Number(node.dataset.y),mark=board.cells[y][x];node.classList.toggle('is-fill',mark==='fill');node.classList.toggle('is-x',mark==='x');});
    document.querySelectorAll('#picrossBoard [data-picross-row-clue]').forEach(node=>node.classList.toggle('is-complete',core.rowSolved(board,Number(node.dataset.picrossRowClue))));
    document.querySelectorAll('#picrossBoard [data-picross-col-clue]').forEach(node=>node.classList.toggle('is-complete',core.columnSolved(board,Number(node.dataset.picrossColClue))));
    if($('picrossMistakes'))$('picrossMistakes').textContent=String(board.mistakes||0);
    const undo=$('picrossUndo');if(undo)undo.disabled=!board.history.length||finished;
  }
  function updateTimer(){if(board&&$('picrossTimer'))$('picrossTimer').textContent=core.formatTime(core.elapsedMs(board));}
  function startTimer(){stopTimer();updateTimer();timer=setInterval(updateTimer,250);}
  function stopTimer(){if(timer){clearInterval(timer);timer=null;}}
  function setTool(next){tool=next==='x'?'x':'fill';document.querySelectorAll('[data-picross-tool]').forEach(b=>b.classList.toggle('active',b.dataset.picrossTool===tool));}
  function startPuzzle(resourceId,{beginRun=true}={}){
    const puzzle=puzzleById.get(String(resourceId));if(!puzzle)return false;const area=(data.areas||[]).find(a=>(a.slots||[]).some(s=>s.resource_id===puzzle.resource_id));if(area)selectedArea=Number(area.area)||0;
    selectedPuzzleId=puzzle.resource_id;board=core.createBoard(puzzle);finished=false;setTool('fill');setView('picrossPuzzleView');setStatus('Drag across cells to mark them.');
    const label=stageLabel(area,puzzle.resource_id);if($('picrossStageLabel'))$('picrossStageLabel').textContent=label;if($('picrossPuzzleSize'))$('picrossPuzzleSize').textContent=`${puzzle.width}×${puzzle.height}`;
    const previous=arcadeRecord().completed?.[puzzle.resource_id];if($('picrossBest'))$('picrossBest').textContent=previous?.timeMs?core.formatTime(previous.timeMs):'—';
    $('picrossSolvedReveal')?.remove();renderBoard();if(beginRun)session()?.beginRun?.('picross');startTimer();return true;
  }
  function flashMistake(node){if(!node)return;node.classList.remove('is-mistake');void node.offsetWidth;node.classList.add('is-mistake');setTimeout(()=>node.classList.remove('is-mistake'),320);try{navigator.vibrate?.(25);}catch(_){}setStatus('That square is empty — marked X instead.');}
  function markCell(node,mark){
    if(!board||finished||!node)return false;const x=Number(node.dataset.x),y=Number(node.dataset.y),result=core.setMark(board,x,y,mark);if(!result.accepted)return false;if(result.mistake)flashMistake(node);renderBoardState();if(result.solved)completePuzzle();return true;
  }
  function beginDrag(e,node){
    if(!board||finished||!node)return;e.preventDefault();const x=Number(node.dataset.x),y=Number(node.dataset.y),current=board.cells[y][x];drag={active:true,pointerId:e.pointerId,mark:current===tool?'blank':tool,visited:new Set()};try{node.setPointerCapture?.(e.pointerId);}catch(_){}const key=`${x}:${y}`;drag.visited.add(key);markCell(node,drag.mark);
  }
  function moveDrag(e){
    if(!drag.active||e.pointerId!==drag.pointerId||!board||finished)return;e.preventDefault();const raw=document.elementFromPoint(e.clientX,e.clientY),node=raw?.closest?.('[data-picross-cell]');if(!node||!$('picrossBoard')?.contains(node))return;const key=`${node.dataset.x}:${node.dataset.y}`;if(drag.visited.has(key))return;drag.visited.add(key);markCell(node,drag.mark);
  }
  function endDrag(e){if(drag.active&&(e.pointerId==null||e.pointerId===drag.pointerId))drag={active:false,pointerId:null,mark:null,visited:new Set()};}
  function undo(){if(!board||finished)return;core.undo(board);renderBoardState();setStatus('Last mark undone.');}
  function reset(){if(!board||finished)return;core.reset(board);renderBoardState();updateTimer();setStatus('Puzzle reset.');}
  function revealSolved(){
    const puzzle=board?.puzzle;if(!puzzle)return;let n=$('picrossSolvedReveal');if(!n){n=document.createElement('div');n.id='picrossSolvedReveal';n.className='picross-solved-reveal';$('picrossBoardWrap')?.after(n);}n.innerHTML=`<b>PICTURE COMPLETE</b>${miniature(puzzle,true)}`;
  }
  function completePuzzle(){
    if(!board||finished)return false;finished=true;stopTimer();renderBoardState();revealSolved();setStatus('Picture complete!',true);
    const puzzle=board.puzzle,r=arcadeRecord(),id=puzzle.resource_id,previous=r.completed?.[id]||null,elapsed=core.elapsedMs(board),firstClear=!previous,errorlessFirst=!previous||Number(previous.bestMistakes??Infinity)>0;
    r.completed=r.completed||{};r.bestTimesMs=r.bestTimesMs||{};r.completed[id]={area:selectedArea,timeMs:previous?.timeMs?Math.min(Number(previous.timeMs),elapsed):elapsed,bestMistakes:previous?.bestMistakes==null?board.mistakes:Math.min(Number(previous.bestMistakes),Number(board.mistakes||0)),completedAt:previous?.completedAt||Date.now()};
    r.bestTimesMs[id]=r.bestTimesMs[id]?Math.min(Number(r.bestTimesMs[id]),elapsed):elapsed;r.totalClears=Math.max(0,Number(r.totalClears)||0)+1;if(board.mistakes===0&&errorlessFirst)r.noMistakeClears=Math.max(0,Number(r.noMistakeClears)||0)+1;
    let award={coinsAwarded:0,itemAwarded:null};if(firstClear){const coins=core.firstClearCoins(puzzle);award=platform()?.awardRun?platform().awardRun({gameId:'picross',label:'Pokémon Picross',score:1,coins,dailyEligible:false}):{coinsAwarded:coins,itemAwarded:null};}
    save();const p=progress(),label=stageLabel(areaById.get(selectedArea),id),best=r.completed[id].timeMs;
    const review={title:'PUZZLE COMPLETE',mode:label,difficulty:`${puzzle.width}×${puzzle.height}`,metricLabel:'TIME',metricValue:core.formatTime(elapsed),stats:[{label:'Mistakes',value:String(board.mistakes)},{label:'Unique pictures',value:`${p.uniqueClears} / ${p.totalStages}`},{label:'Areas complete',value:`${p.areasCleared} / ${p.totalAreas}`}],pbs:[{label:'Best time',value:core.formatTime(best),isNew:firstClear||elapsed<=best}],rewards:[{label:'Lucky Coins',value:firstClear?String(award.coinsAwarded||0):'First clear already claimed'}]};
    setTimeout(()=>session()?.showResult?.('picross',{title:'PUZZLE COMPLETE',metricLabel:'TIME',metricValue:core.formatTime(elapsed),coinsAwarded:award.coinsAwarded||0,bestText:firstClear?'FIRST CLEAR':`BEST ${core.formatTime(best)}`,review,replayLabel:'REPLAY PUZZLE',onReplay:()=>startPuzzle(id,{beginRun:false}),changeLabel:'LEVEL SELECT',onChange:()=>showLevels(selectedArea),onBack:()=>root.LuckyDexArcadeWorld?.backFromGame?.(true)}),280);
    return true;
  }
  function open(){opened=true;session()?.mount?.('picross',$('picrossGame'));showAreas();return true;}
  function close(){opened=false;stopTimer();endDrag({pointerId:null});board=null;finished=false;return true;}
  function wire(){
    if(typeof document==='undefined')return;
    document.addEventListener('click',e=>{const area=e.target.closest?.('[data-picross-area]');if(area){showLevels(area.dataset.picrossArea);return;}const level=e.target.closest?.('[data-picross-puzzle]');if(level){startPuzzle(level.dataset.picrossPuzzle);return;}const t=e.target.closest?.('[data-picross-tool]');if(t){setTool(t.dataset.picrossTool);}});
    $('picrossBackAreas')?.addEventListener('click',showAreas);$('picrossBackLevels')?.addEventListener('click',()=>showLevels(selectedArea));$('picrossUndo')?.addEventListener('click',undo);$('picrossReset')?.addEventListener('click',reset);
    $('picrossBoard')?.addEventListener('pointerdown',e=>{const node=e.target.closest?.('[data-picross-cell]');if(node)beginDrag(e,node);});
    document.addEventListener('pointermove',moveDrag,{passive:false});document.addEventListener('pointerup',endDrag);document.addEventListener('pointercancel',endDrag);
  }
  if(typeof document!=='undefined')wire();
  root.LuckyDexPicross={open,close,showAreas,showLevels,startPuzzle,progress,isOpen:()=>opened};
})(typeof window!=='undefined'?window:globalThis);
