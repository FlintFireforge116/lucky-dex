(function(root){
'use strict';
const VOLTORB_MEMO_OPTIONS=['bomb','1','2','3'];
const MEMO_BIT={bomb:1,'1':2,'2':4,'3':8};
const CLEFAIRY_RULES={maxHits:5,maxRounds:5,directions:['up','right','down','left']};
let active=null,voltorb=null,clefairy=null,clefairyTimer=null;
const $=id=>typeof document!=='undefined'?document.getElementById(id):null;
const platform=()=>root.LuckyDexArcadePlatform||globalThis.LuckyDexArcadePlatform;
const session=()=>root.LuckyDexArcadeSession||globalThis.LuckyDexArcadeSession;
const clamp=(n,a,b)=>Math.max(a,Math.min(b,n));
const timers=new Set();const setTimeout=(fn,ms)=>{const id=window.setTimeout(()=>{timers.delete(id);fn();},ms);timers.add(id);return id;};const wait=ms=>new Promise(r=>setTimeout(r,ms));
function memoToggle(mask,opt){const bit=MEMO_BIT[opt]||0;return bit?mask^bit:mask;}
function shuffle(a){a=[...a];for(let i=a.length-1;i>0;i--){const j=Math.floor(Math.random()*(i+1));[a[i],a[j]]=[a[j],a[i]];}return a;}
function award(gameId,label,score,coins){return platform()?.awardRun?.({gameId,label,score,coins,dailyEligible:false,dailyReward:null})||{coinsAwarded:coins,itemAwarded:null};}
function stateArcade(){const s=root.state||globalThis.state;if(!s)return null;s.arcade=s.arcade||{};return s.arcade;}
function persist(){try{root.save?.();}catch(_){}}
function sprite(id){return `arcade/sprites/actors/pokemon/${id}.png`;}
function escapeHtml(s){return String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#039;'}[c]));}

/* Voltorb Flip */
function buildVoltorb(){const a=stateArcade(),level=clamp(Number(a?.voltorbLevel||1),1,5),bombs=5+level,threes=2+Math.floor(level/2),twos=5+Math.floor(level/2);let vals=[...Array(bombs).fill(0),...Array(threes).fill(3),...Array(twos).fill(2)];while(vals.length<25)vals.push(1);vals=shuffle(vals);voltorb={level,bank:1,revealed:0,busted:false,cleared:false,memoMode:false,selectedMemo:'bomb',tiles:vals.map(value=>({value,revealed:false,memo:0}))};renderVoltorb();}
function clue(indices){return {sum:indices.reduce((n,i)=>n+voltorb.tiles[i].value,0),bombs:indices.reduce((n,i)=>n+(voltorb.tiles[i].value===0),0)};}
function memoSymbols(mask){return VOLTORB_MEMO_OPTIONS.filter(x=>mask&MEMO_BIT[x]).map(x=>x==='bomb'?'●':x).join('');}
function renderVoltorb(){if(!voltorb)return;const board=$('voltorbBoard');if(!board)return;let html='<div class="vf-grid-v019">';for(let r=0;r<5;r++){for(let c=0;c<5;c++){const i=r*5+c,t=voltorb.tiles[i],face=t.revealed?(t.value===0?`<img src="${sprite(100)}" alt="Voltorb">`:`<b>${t.value}</b>`):(t.memo?`<small>${memoSymbols(t.memo)}</small>`:'');html+=`<button class="vf-card-v019 ${t.revealed?'revealed':''} ${t.value===0&&t.revealed?'bomb':''}" data-vf-card="${i}" data-vf-value="${t.value}" ${voltorb.busted||voltorb.cleared?'disabled':''}>${face}</button>`;}const cl=clue([0,1,2,3,4].map(c=>r*5+c));html+=`<div class="vf-clue-v019"><b>${cl.sum}</b><span><img src="${sprite(100)}" alt="">${cl.bombs}</span></div>`;}for(let c=0;c<5;c++){const cl=clue([0,1,2,3,4].map(r=>r*5+c));html+=`<div class="vf-clue-v019 bottom"><b>${cl.sum}</b><span><img src="${sprite(100)}" alt="">${cl.bombs}</span></div>`;}html+='<div class="vf-corner-v019">↗</div></div>';board.innerHTML=html;board.querySelectorAll('[data-vf-card]').forEach(b=>b.addEventListener('click',()=>voltorbTap(Number(b.dataset.vfCard))));
 if($('voltorbLevel'))$('voltorbLevel').textContent=voltorb.level;if($('voltorbBank'))$('voltorbBank').textContent=Math.max(0,voltorb.bank*20);if($('voltorbCashBtn'))$('voltorbCashBtn').disabled=!voltorb.revealed||voltorb.busted||voltorb.cleared;document.querySelectorAll('[data-vf-memo]').forEach(b=>b.classList.toggle('active',b.dataset.vfMemo===voltorb.selectedMemo));$('voltorbMemoToggle')?.classList.toggle('active',voltorb.memoMode);}
function voltorbTap(i){if(!voltorb||voltorb.busted||voltorb.cleared)return;const t=voltorb.tiles[i];if(t.revealed)return;if(voltorb.memoMode){t.memo=memoToggle(t.memo,voltorb.selectedMemo);renderVoltorb();return;}t.revealed=true;t.memo=0;voltorb.revealed++;if(t.value===0){voltorb.busted=true;voltorb.bank=0;renderVoltorb();finishVoltorb('VOLTORB!','BANK LOST',0,'');return;}if(t.value>1)voltorb.bank*=t.value;const left=voltorb.tiles.some(x=>!x.revealed&&x.value>1);if(!left){voltorb.cleared=true;const coins=Math.min(2400,voltorb.bank*20+voltorb.level*120),res=award('voltorb','Voltorb Flip',voltorb.bank,coins),a=stateArcade();if(a)a.voltorbLevel=Math.min(5,voltorb.level+1);persist();renderVoltorb();finishVoltorb(`LEVEL ${voltorb.level} CLEAR`,`×${voltorb.bank}`,res.coinsAwarded,'BOARD CLEARED');return;}renderVoltorb();}
function finishVoltorb(title,metric,coins,best){session()?.showResult?.('voltorb',{title,metricLabel:'BANK',metricValue:metric,coinsAwarded:coins,itemAwarded:null,bestText:best,onReplay:buildVoltorb,onBack:()=>root.LuckyDexArcadeWorld?.backFromGame?.(true)});}
function cashVoltorb(){if(!voltorb||!voltorb.revealed||voltorb.busted||voltorb.cleared)return;voltorb.cleared=true;renderVoltorb();const coins=Math.min(1800,voltorb.bank*20+voltorb.revealed*8),res=award('voltorb','Voltorb Flip',voltorb.bank,coins);finishVoltorb('CASHED OUT',`×${voltorb.bank} · ${voltorb.revealed} flipped`,res.coinsAwarded,'');}
function installVoltorb(){const game=$('voltorbGame');if(!game)return;const oldSign=game.querySelector('.vf-gamecorner-sign');if(oldSign)oldSign.outerHTML='<div class="vf-top-v019"><div><span>COINS</span><b id="voltorbBank">0</b></div><div><span>LEVEL</span><b id="voltorbLevel">1</b></div><button id="voltorbMemoToggle" type="button">MEMO</button></div><div class="vf-memo-panel-v019"><span>MARK</span><button data-vf-memo="bomb">●</button><button data-vf-memo="1">1</button><button data-vf-memo="2">2</button><button data-vf-memo="3">3</button></div>';game.querySelector('p.muted')?.remove();game.querySelector('.section-head')?.remove();const toggle=$('voltorbMemoToggle');if(toggle)toggle.onclick=()=>{if(voltorb){voltorb.memoMode=!voltorb.memoMode;renderVoltorb();}};document.querySelectorAll('[data-vf-memo]').forEach(b=>b.onclick=()=>{if(voltorb){voltorb.selectedMemo=b.dataset.vfMemo;voltorb.memoMode=true;renderVoltorb();}});const nb=$('voltorbNewBtn');if(nb)nb.onclick=buildVoltorb;const cb=$('voltorbCashBtn');if(cb)cb.onclick=cashVoltorb;}

/* Berry Blender visual adapter — the v0.16.4 engine remains authoritative */
function openBerry(){const engine=root.LuckyDexBerryBlender;engine?.reset?.();const game=$('berryGame');if(game){game.hidden=false;game.classList.add('berry-authentic-v019');}return true;}

/* Clefairy Match is owned by clefairy-memory.js. */

/* Fossil Dig moved to arcade-fossil-museum.js in v0.25.0. */
function hideClassics(){['voltorb','berry'].forEach(g=>{const n=$(`${g}Game`);if(n)n.hidden=true;});}
function open(gameId){if(!['voltorb','berry'].includes(gameId))return false;active=gameId;hideClassics();const n=$(`${gameId}Game`);if(n)n.hidden=false;document.body?.classList.add('arcade-open','arcade-mode');if(gameId==='voltorb')buildVoltorb();if(gameId==='berry')openBerry();return true;}
function close(gameId){if(gameId==='berry')root.LuckyDexBerryBlender?.stop();for(const id of timers)window.clearTimeout(id);timers.clear();active=null;hideClassics();return true;}
function install(){if(typeof document==='undefined')return;installVoltorb();const berry=$('berryGame');berry?.classList.add('berry-authentic-v019');}
const api={VOLTORB_MEMO_OPTIONS,memoToggle,open,close,buildVoltorb};root.LuckyDexArcadeClassicsV0190=api;if(typeof module!=='undefined'&&module.exports)module.exports=api;if(typeof document!=='undefined')install();
})(typeof window!=='undefined'?window:globalThis);
