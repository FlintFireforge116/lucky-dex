(function(root,factory){
  const api=factory();
  if(typeof module!=='undefined'&&module.exports)module.exports=api;
  root.LuckyDexElementalGauntletCore=api;
})(typeof window!=='undefined'?window:globalThis,function(){
  'use strict';

  const clamp=(n,a,b)=>Math.max(a,Math.min(b,Number(n)||0));
  const round1=n=>Math.round(Number(n||0)*10)/10;
  const COUNTDOWN_STEP_MS=650;
  const COUNTDOWN_END_MS=COUNTDOWN_STEP_MS*4;
  const WAVES=Object.freeze([
    Object.freeze({id:'fire',type:'fire',name:'FIRESTORM',move:'Flamethrower',baseDamage:24,pattern:'firestorm'}),
    Object.freeze({id:'water',type:'water',name:'RIPTIDE',move:'Water Pulse',baseDamage:22,pattern:'riptide'}),
    Object.freeze({id:'electric',type:'electric',name:'THUNDER FIELD',move:'Thunderbolt',baseDamage:25,pattern:'thunder'}),
    Object.freeze({id:'ice',type:'ice',name:'ICE SHARDS',move:'Ice Beam',baseDamage:23,pattern:'ice'}),
    Object.freeze({id:'psychic',type:'psychic',name:'PSYCHIC PRESSURE',move:'Psybeam',baseDamage:27,pattern:'psychic'}),
  ]);
  const DIFFICULTIES=Object.freeze({
    easy:Object.freeze({id:'easy',label:'EASY',telegraphMs:1080,groupGapMs:640,clusterSize:1,clusterGapMs:0,hazardScale:.90,damageScale:.88,guardDrain:0,guardRegen:24,countScale:.78,rewardMultiplier:.82}),
    normal:Object.freeze({id:'normal',label:'NORMAL',telegraphMs:820,groupGapMs:520,clusterSize:2,clusterGapMs:145,hazardScale:1,damageScale:1,guardDrain:0,guardRegen:18,countScale:1,rewardMultiplier:1}),
    hard:Object.freeze({id:'hard',label:'HARD',telegraphMs:535,groupGapMs:390,clusterSize:3,clusterGapMs:65,hazardScale:1.04,damageScale:1.28,guardDrain:0,guardRegen:11,countScale:1.68,rewardMultiplier:1.38}),
  });
  const DIVISION_BASE=Object.freeze({
    rookie:{telegraphMs:1010,groupGapMs:610,clusterSize:1,clusterGapMs:0,hazardScale:.92,damageScale:.92,guardDrain:0,guardRegen:23,countScale:.82},
    poke:{telegraphMs:900,groupGapMs:560,clusterSize:2,clusterGapMs:175,hazardScale:.96,damageScale:.96,guardDrain:0,guardRegen:21,countScale:.90},
    great:{telegraphMs:785,groupGapMs:510,clusterSize:2,clusterGapMs:145,hazardScale:1,damageScale:1.03,guardDrain:0,guardRegen:18,countScale:1},
    ultra:{telegraphMs:650,groupGapMs:445,clusterSize:2,clusterGapMs:105,hazardScale:1.04,damageScale:1.14,guardDrain:0,guardRegen:14,countScale:1.24},
    master:{telegraphMs:535,groupGapMs:395,clusterSize:3,clusterGapMs:70,hazardScale:1.07,damageScale:1.27,guardDrain:0,guardRegen:11,countScale:1.60},
  });

  function hashSeed(seed){if(Number.isFinite(Number(seed)))return (Number(seed)>>>0)||0x6d2b79f5;let h=2166136261;for(const ch of String(seed??'elemental-gauntlet')){h^=ch.charCodeAt(0);h=Math.imul(h,16777619);}return h>>>0||0x6d2b79f5;}
  function createSeededRng(seed){let a=hashSeed(seed);return()=>{a|=0;a=(a+0x6D2B79F5)|0;let t=Math.imul(a^(a>>>15),1|a);t=(t+Math.imul(t^(t>>>7),61|t))^t;return((t^(t>>>14))>>>0)/4294967296;};}
  function difficultyProfile(id='normal'){return {...(DIFFICULTIES[id]||DIFFICULTIES.normal),mode:'exhibition'};}
  function divisionProfile(id='rookie',roundIndex=0){const key=DIVISION_BASE[id]?id:'rookie',r=clamp(Math.trunc(roundIndex),0,2),b=DIVISION_BASE[key];return {...b,id:key,label:key.toUpperCase(),mode:'cup',divisionId:key,roundIndex:r,telegraphMs:Math.max(455,Math.round(b.telegraphMs-r*45)),groupGapMs:Math.max(350,Math.round(b.groupGapMs-r*20)),hazardScale:b.hazardScale+r*.025,damageScale:b.damageScale+r*.04,countScale:b.countScale+r*.08,rewardMultiplier:1};}
  function countdownLabel(elapsedMs){const t=Math.max(0,Number(elapsedMs)||0);if(t<COUNTDOWN_STEP_MS)return '3';if(t<COUNTDOWN_STEP_MS*2)return '2';if(t<COUNTDOWN_STEP_MS*3)return '1';if(t<COUNTDOWN_END_MS)return 'GO!';return '';}

  // Sp. Def changes both the punishment for an unshielded mistake and the strength of the emergency shield.
  function spDefDamageMultiplier(spDef){const n=clamp(Number(spDef)||60,5,180);if(n<60)return 1.15+((60-n)/55)*.55;return clamp(1.15-((n-60)/120)*.65,.50,1.15);}
  function spDefPerformance(spDef){const m=spDefDamageMultiplier(spDef);return clamp(1.62-m*.62,.52,1.31);}
  function shieldCapacityForSpDef(spDef){const n=clamp(Number(spDef)||60,5,180);return Math.round(42+n*.95);}
  function shieldRegenPerSecond(spDef,profile={}){const max=shieldCapacityForSpDef(spDef);return Math.max(5,round1(max*clamp(Number(profile.guardRegen)||18,4,35)/100));}
  function guardMultiplier(guardStrength=1){return clamp(.58-clamp(guardStrength,0,1)*.28,.30,.58);}
  function resolveImpact({spDef=60,baseDamage=24,damageScale=1,hit=true,guarding=false,guardStrength=1}={}){
    if(!hit)return {hit:false,guarding:false,damage:0,multiplier:0,grade:'DODGED'};
    const statMultiplier=spDefDamageMultiplier(spDef),guard=guarding?guardMultiplier(guardStrength):1;
    const damage=Math.max(1,Math.round(Math.max(1,Number(baseDamage)||1)*Math.max(.25,Number(damageScale)||1)*statMultiplier*guard));
    return {hit:true,guarding:!!guarding,damage,statMultiplier:round1(statMultiplier),guardMultiplier:round1(guard),multiplier:round1(statMultiplier*guard),grade:guarding?'GUARDED':'HIT'};
  }

  function rollPrismaticStorm(rng=Math.random,rate=.02){return clamp(Number((rng||Math.random)())||0,0,.999999)<clamp(rate,0,1);}
  function rand(rng,a,b){return a+clamp(rng(),0,.999999)*(b-a);}
  function signatureFor(type,index){
    const odd=index%2===1;
    if(type==='fire')return odd?{shape:index%4===1?'lane-v':'lane-h',visual:'fire-wall'}:{shape:'circle',visual:'flame'};
    if(type==='water')return odd?{shape:'circle',visual:'water-orb'}:{shape:'lane-h',visual:'water-wave'};
    if(type==='electric')return odd?{shape:'circle',visual:'electric-field'}:{shape:'lane-v',visual:'lightning-bolt'};
    if(type==='ice')return odd?{shape:index%4===1?'lane-v':'lane-h',visual:'ice-beam'}:{shape:'circle',visual:'ice-shard'};
    return odd?{shape:'circle',visual:'psychic-orb'}:{shape:'ring',visual:'psychic-wave'};
  }
  function createWavePlan({wave=WAVES[0],profile=difficultyProfile('normal'),rng=Math.random,prismatic=false,waveIndex=0}={}){
    const p=profile||difficultyProfile('normal'),random=typeof rng==='function'?rng:Math.random;
    const wi=clamp(Math.trunc(waveIndex),0,4),baseCounts=[7,8,9,10,11];
    const count=Math.max(5,Math.round(baseCounts[wi]*(Number(p.countScale)||1)+(prismatic?2:0)));
    const clusterSize=Math.max(1,Math.round(Number(p.clusterSize)||1));
    const clusterGap=Math.max(0,Number(p.clusterGapMs)||0),groupGap=Math.max(300,Number(p.groupGapMs)||520);
    const telegraph=Math.max(430,Number(p.telegraphMs)||820),hazards=[];
    const firstImpact=Math.max(760,telegraph+220);
    for(let i=0;i<count;i++){
      const group=Math.floor(i/clusterSize),slot=i%clusterSize;
      const impactAt=Math.round(firstImpact+group*groupGap+slot*clusterGap+rand(random,-18,18));
      const baseType=prismatic?WAVES[(wi+i)%WAVES.length].type:wave.type;
      const sig=signatureFor(baseType,i);
      const shape=sig.shape,visual=sig.visual;
      const scale=Number(p.hazardScale)||1;
      let size;
      if(shape==='circle')size=rand(random,.105,.155)*scale;
      else if(shape==='ring')size=rand(random,.19,.265)*scale;
      else size=rand(random,.12,.18)*scale;
      const x=shape==='lane-v'?rand(random,.10,.90):rand(random,.12,.88);
      const y=shape==='lane-h'?rand(random,.13,.87):rand(random,.14,.88);
      const ringWidth=shape==='ring'?rand(random,.045,.072):0;
      const late=i>=Math.ceil(count*.62),damageBoost=late?3:0;
      hazards.push({id:`${wave.id}-${i+1}`,index:i,waveIndex:wi,type:baseType,shape,visual,x:round1(x*100)/100,y:round1(y*100)/100,size:round1(size*1000)/1000,ringWidth:round1(ringWidth*1000)/1000,telegraphAt:impactAt-telegraph,impactAt,lingerMs:visual==='psychic-wave'?330:visual==='water-wave'?280:230,baseDamage:wave.baseDamage+damageBoost+(p.id==='hard'?2:0),resolved:false});
    }
    hazards.sort((a,b)=>a.impactAt-b.impactAt||a.index-b.index);
    const durationMs=(hazards.at(-1)?.impactAt||firstImpact)+520;
    return {wave:{...wave},profile:{...p},prismatic:!!prismatic,hazards,durationMs};
  }
  function hazardHitsPlayer(hazard,player={x:.5,y:.72}){
    const x=clamp(player.x,.04,.96),y=clamp(player.y,.08,.92),hx=Number(hazard?.x)||.5,hy=Number(hazard?.y)||.5,size=Math.max(.03,Number(hazard?.size)||.15),shape=hazard?.shape||'circle';
    if(shape==='lane-v')return Math.abs(x-hx)<=size/2;
    if(shape==='lane-h')return Math.abs(y-hy)<=size/2;
    const d=Math.hypot(x-hx,y-hy);
    if(shape==='ring'){const w=Math.max(.035,Number(hazard?.ringWidth)||.08);return d>=Math.max(0,size-w)&&d<=size+w;}
    return d<=size;
  }

  function createRun({difficulty='normal',profile=null,participant=null,rng=Math.random,goldenRate=.02,seed=null}={}){
    const p=profile?{...profile}:difficultyProfile(difficulty),random=seed==null?(typeof rng==='function'?rng:Math.random):createSeededRng(seed),prismatic=rollPrismaticStorm(random,goldenRate);
    const spDef=Number(participant?.baseStat)||60,shieldMax=shieldCapacityForSpDef(spDef);
    return {difficulty:p.id||difficulty,profile:p,participant:participant?{...participant}:null,prismatic,waveIndex:0,waves:[],health:100,shieldMax,shield:shieldMax,guard:100,score:0,damageTaken:0,shieldDamageTaken:0,shieldBreaks:0,hits:0,guards:0,dodges:0,perfectWaves:0,finished:false,fullClear:false,prismaticCleared:false};
  }
  function syncGuardAlias(run){if(run)run.guard=run.shieldMax>0?clamp(run.shield/run.shieldMax*100,0,100):0;}
  function applyImpact(run,{hazard,hit,guarding=false,guardStrength=1}={}){
    if(!run||run.finished)return null;
    const spDef=Number(run.participant?.baseStat)||60;
    if(!hit){run.dodges++;run.score+=28;return {hit:false,guarding:false,damage:0,shieldDamage:0,shieldBroken:false,multiplier:0,grade:'DODGED',health:run.health,shield:run.shield,score:run.score};}

    const unguarded=resolveImpact({spDef,baseDamage:hazard?.baseDamage||24,damageScale:run.profile?.damageScale||1,hit:true,guarding:false,guardStrength});
    let hpDamage=unguarded.damage,shieldDamage=0,shieldBroken=false,grade='HIT';
    const shieldBefore=Math.max(0,Number(run.shield)||0);
    if(guarding&&shieldBefore>0){
      const requested=Math.max(1,Math.round(unguarded.damage*.92));
      shieldDamage=Math.min(shieldBefore,requested);
      run.shield=clamp(shieldBefore-shieldDamage,0,run.shieldMax||shieldBefore);
      const overflow=Math.max(0,requested-shieldDamage);
      hpDamage=overflow>0?Math.max(1,Math.round(unguarded.damage*(overflow/requested)*.86)):0;
      shieldBroken=run.shield<=0&&shieldBefore>0;
      grade=shieldBroken?'SHIELD BREAK':'SHIELDED';
      run.guards++;
      run.shieldDamageTaken+=shieldDamage;
      if(shieldBroken)run.shieldBreaks++;
    }
    if(hpDamage>0){run.health=clamp(run.health-hpDamage,0,100);run.damageTaken+=hpDamage;run.hits++;}
    syncGuardAlias(run);
    const points=hpDamage===0&&guarding?18:hpDamage===0?28:guarding?Math.max(6,18-hpDamage*.18):Math.max(2,12-hpDamage*.18);
    run.score+=Math.round(points);
    if(run.health<=0){run.finished=true;run.fullClear=false;}
    return {hit:true,guarding:!!guarding,damage:hpDamage,shieldDamage,shieldBroken,shield:run.shield,shieldMax:run.shieldMax,statMultiplier:unguarded.statMultiplier,multiplier:unguarded.multiplier,grade,health:run.health,score:run.score};
  }
  function regenShield(run,dtMs){
    if(!run||run.finished||run.shield>=run.shieldMax)return run?.shield||0;
    const spDef=Number(run.participant?.baseStat)||60,perSecond=shieldRegenPerSecond(spDef,run.profile||{});
    run.shield=clamp(run.shield+perSecond*Math.max(0,Number(dtMs)||0)/1000,0,run.shieldMax);
    syncGuardAlias(run);
    return run.shield;
  }
  function finishWave(run,{damageBefore=0}={}){
    if(!run||run.finished&&run.health<=0)return null;const clean=run.damageTaken<=Number(damageBefore||0);if(clean){run.perfectWaves++;run.score+=45;}else run.score+=Math.max(8,Math.round(run.health*.12));run.waves.push({index:run.waveIndex,clean,health:run.health,shield:run.shield,score:run.score});run.waveIndex++;
    if(run.waveIndex>=WAVES.length||run.health<=0){run.finished=true;run.fullClear=run.waveIndex>=WAVES.length&&run.health>0;run.prismaticCleared=!!run.prismatic&&run.fullClear;run.score+=run.fullClear?Math.round(run.health*.7)+70:0;}
    return {clean,waveIndex:run.waveIndex,finished:run.finished,fullClear:run.fullClear,score:run.score};
  }
  function roundMetric(run){return Math.round((Number(run?.score)||0)*10)/10;}
  function rewardForRun(run){const p=run?.profile||difficultyProfile(run?.difficulty),score=Math.max(0,Number(run?.score)||0),health=Math.max(0,Number(run?.health)||0),full=!!run?.fullClear;return Math.max(30,Math.round((35+score*.18+health*.25+(full?55:0)+(run?.prismaticCleared?35:0))*(Number(p.rewardMultiplier)||1)));}

  return Object.freeze({WAVES,DIFFICULTIES,DIVISION_BASE,COUNTDOWN_STEP_MS,COUNTDOWN_END_MS,createSeededRng,difficultyProfile,divisionProfile,countdownLabel,spDefDamageMultiplier,spDefPerformance,shieldCapacityForSpDef,shieldRegenPerSecond,guardMultiplier,resolveImpact,rollPrismaticStorm,createWavePlan,hazardHitsPlayer,createRun,applyImpact,regenShield,finishWave,roundMetric,rewardForRun});
});
