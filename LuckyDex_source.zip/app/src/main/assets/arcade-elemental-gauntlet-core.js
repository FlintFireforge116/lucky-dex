(function(root,factory){
  const api=factory();
  if(typeof module!=='undefined'&&module.exports)module.exports=api;
  root.LuckyDexElementalGauntletCore=api;
})(typeof window!=='undefined'?window:globalThis,function(){
  'use strict';

  const clamp=(n,a,b)=>Math.max(a,Math.min(b,Number(n)||0));
  const round1=n=>Math.round(Number(n||0)*10)/10;
  const COUNTDOWN_STEP_MS=650;
  const COUNTDOWN_END_MS=COUNTDOWN_STEP_MS*4;
  const WAVES=Object.freeze([
    Object.freeze({id:'fire',type:'fire',name:'FIRESTORM',move:'Flamethrower',baseDamage:24,pattern:'sweep'}),
    Object.freeze({id:'water',type:'water',name:'RIPTIDE',move:'Water Pulse',baseDamage:22,pattern:'lanes'}),
    Object.freeze({id:'electric',type:'electric',name:'THUNDER FIELD',move:'Thunderbolt',baseDamage:25,pattern:'bursts'}),
    Object.freeze({id:'ice',type:'ice',name:'ICE SHARDS',move:'Ice Beam',baseDamage:23,pattern:'shards'}),
    Object.freeze({id:'psychic',type:'psychic',name:'PSYCHIC PRESSURE',move:'Psybeam',baseDamage:27,pattern:'rings'})
  ]);
  const DIFFICULTIES=Object.freeze({
    easy:Object.freeze({id:'easy',label:'EASY',telegraphMs:1180,gapMs:560,hazardScale:.88,damageScale:.88,guardDrain:18,guardRegen:23,countScale:.86,rewardMultiplier:.82}),
    normal:Object.freeze({id:'normal',label:'NORMAL',telegraphMs:930,gapMs:450,hazardScale:1,damageScale:1,guardDrain:23,guardRegen:20,countScale:1,rewardMultiplier:1}),
    hard:Object.freeze({id:'hard',label:'HARD',telegraphMs:720,gapMs:350,hazardScale:1.08,damageScale:1.13,guardDrain:29,guardRegen:18,countScale:1.18,rewardMultiplier:1.28})
  });
  const DIVISION_BASE=Object.freeze({
    rookie:{telegraphMs:1120,gapMs:520,hazardScale:.90,damageScale:.90,guardDrain:19,guardRegen:23,countScale:.88},
    poke:{telegraphMs:1010,gapMs:475,hazardScale:.95,damageScale:.95,guardDrain:21,guardRegen:22,countScale:.94},
    great:{telegraphMs:900,gapMs:425,hazardScale:1,damageScale:1,guardDrain:23,guardRegen:20,countScale:1},
    ultra:{telegraphMs:790,gapMs:385,hazardScale:1.05,damageScale:1.08,guardDrain:26,guardRegen:19,countScale:1.10},
    master:{telegraphMs:690,gapMs:340,hazardScale:1.10,damageScale:1.16,guardDrain:29,guardRegen:18,countScale:1.20}
  });

  function hashSeed(seed){if(Number.isFinite(Number(seed)))return (Number(seed)>>>0)||0x6d2b79f5;let h=2166136261;for(const ch of String(seed??'elemental-gauntlet')){h^=ch.charCodeAt(0);h=Math.imul(h,16777619);}return h>>>0||0x6d2b79f5;}
  function createSeededRng(seed){let a=hashSeed(seed);return()=>{a|=0;a=(a+0x6D2B79F5)|0;let t=Math.imul(a^(a>>>15),1|a);t=(t+Math.imul(t^(t>>>7),61|t))^t;return((t^(t>>>14))>>>0)/4294967296;};}
  function difficultyProfile(id='normal'){return {...(DIFFICULTIES[id]||DIFFICULTIES.normal),mode:'exhibition'};}
  function divisionProfile(id='rookie',roundIndex=0){const key=DIVISION_BASE[id]?id:'rookie',r=clamp(Math.trunc(roundIndex),0,2),b=DIVISION_BASE[key];return {...b,id:key,label:key.toUpperCase(),mode:'cup',divisionId:key,roundIndex:r,telegraphMs:Math.max(560,Math.round(b.telegraphMs-r*55)),gapMs:Math.max(285,Math.round(b.gapMs-r*25)),hazardScale:b.hazardScale+r*.025,damageScale:b.damageScale+r*.035,countScale:b.countScale+r*.07,rewardMultiplier:1};}
  function countdownLabel(elapsedMs){const t=Math.max(0,Number(elapsedMs)||0);if(t<COUNTDOWN_STEP_MS)return '3';if(t<COUNTDOWN_STEP_MS*2)return '2';if(t<COUNTDOWN_STEP_MS*3)return '1';if(t<COUNTDOWN_END_MS)return 'GO!';return '';}

  // Sp. Def only changes the price of a mistake. A clean dodge is always perfect defense.
  function spDefDamageMultiplier(spDef){const n=clamp(Number(spDef)||60,5,180);if(n<60)return 1.15+((60-n)/55)*.55;return clamp(1.15-((n-60)/120)*.65,.50,1.15);}
  function spDefPerformance(spDef){const m=spDefDamageMultiplier(spDef);return clamp(1.62-m*.62,.52,1.31);}
  function guardMultiplier(guardStrength=1){return clamp(.58-clamp(guardStrength,0,1)*.28,.30,.58);}
  function resolveImpact({spDef=60,baseDamage=24,damageScale=1,hit=true,guarding=false,guardStrength=1}={}){
    if(!hit)return {hit:false,guarding:false,damage:0,multiplier:0,grade:'DODGED'};
    const statMultiplier=spDefDamageMultiplier(spDef),guard=guarding?guardMultiplier(guardStrength):1;
    const damage=Math.max(1,Math.round(Math.max(1,Number(baseDamage)||1)*Math.max(.25,Number(damageScale)||1)*statMultiplier*guard));
    return {hit:true,guarding:!!guarding,damage,statMultiplier:round1(statMultiplier),guardMultiplier:round1(guard),multiplier:round1(statMultiplier*guard),grade:guarding?'GUARDED':'HIT'};
  }

  function rollPrismaticStorm(rng=Math.random,rate=.02){return clamp(Number((rng||Math.random)())||0,0,.999999)<clamp(rate,0,1);}
  function rand(rng,a,b){return a+clamp(rng(),0,.999999)*(b-a);}
  function hazardShapeFor(wave,index){
    if(wave.pattern==='sweep')return index%2?'lane-h':'lane-v';
    if(wave.pattern==='lanes')return 'lane-v';
    if(wave.pattern==='rings')return 'ring';
    return 'circle';
  }
  function createWavePlan({wave=WAVES[0],profile=difficultyProfile('normal'),rng=Math.random,prismatic=false,waveIndex=0}={}){
    const p=profile||difficultyProfile('normal'),random=typeof rng==='function'?rng:Math.random,baseCounts=[5,6,6,7,7],count=Math.max(4,Math.round(baseCounts[clamp(waveIndex,0,4)]*(Number(p.countScale)||1)+(prismatic?1:0)));
    const hazards=[];let impactAt=Math.max(900,Number(p.telegraphMs)||930);
    for(let i=0;i<count;i++){
      const shape=hazardShapeFor(wave,i),type=prismatic?WAVES[(waveIndex+i)%WAVES.length].type:wave.type;
      const size=(shape==='circle'?rand(random,.13,.18):shape==='ring'?rand(random,.22,.30):rand(random,.18,.25))*(Number(p.hazardScale)||1);
      const x=shape==='lane-v'?rand(random,.16,.84):rand(random,.18,.82),y=shape==='lane-h'?rand(random,.22,.78):rand(random,.22,.78);
      const ringWidth=shape==='ring'?rand(random,.07,.10):0;
      hazards.push({id:`${wave.id}-${i+1}`,index:i,waveIndex,type,shape,x:round1(x*100)/100,y:round1(y*100)/100,size:round1(size*1000)/1000,ringWidth:round1(ringWidth*1000)/1000,telegraphAt:impactAt-Math.max(500,Number(p.telegraphMs)||930),impactAt,lingerMs:210,baseDamage:wave.baseDamage+(i>=Math.ceil(count*.7)?2:0),resolved:false});
      impactAt+=Math.max(300,Number(p.gapMs)||450)+Math.round(rand(random,-55,90));
    }
    const durationMs=impactAt+420;
    return {wave:{...wave},profile:{...p},prismatic:!!prismatic,hazards,durationMs};
  }
  function hazardHitsPlayer(hazard,player={x:.5,y:.72}){
    const x=clamp(player.x,.04,.96),y=clamp(player.y,.08,.92),hx=Number(hazard?.x)||.5,hy=Number(hazard?.y)||.5,size=Math.max(.03,Number(hazard?.size)||.15),shape=hazard?.shape||'circle';
    if(shape==='lane-v')return Math.abs(x-hx)<=size/2;
    if(shape==='lane-h')return Math.abs(y-hy)<=size/2;
    const d=Math.hypot(x-hx,y-hy);
    if(shape==='ring'){const w=Math.max(.035,Number(hazard?.ringWidth)||.08);return d>=Math.max(0,size-w)&&d<=size+w;}
    return d<=size;
  }

  function createRun({difficulty='normal',profile=null,participant=null,rng=Math.random,goldenRate=.02,seed=null}={}){
    const p=profile?{...profile}:difficultyProfile(difficulty),random=seed==null?(typeof rng==='function'?rng:Math.random):createSeededRng(seed),prismatic=rollPrismaticStorm(random,goldenRate);
    return {difficulty:p.id||difficulty,profile:p,participant:participant?{...participant}:null,prismatic,waveIndex:0,waves:[],health:100,guard:100,score:0,damageTaken:0,hits:0,guards:0,dodges:0,perfectWaves:0,finished:false,fullClear:false,prismaticCleared:false};
  }
  function applyImpact(run,{hazard,hit,guarding=false,guardStrength=1}={}){
    if(!run||run.finished)return null;const spDef=Number(run.participant?.baseStat)||60,out=resolveImpact({spDef,baseDamage:hazard?.baseDamage||24,damageScale:run.profile?.damageScale||1,hit,guarding,guardStrength});
    if(out.damage){run.health=clamp(run.health-out.damage,0,100);run.damageTaken+=out.damage;run.hits++;if(guarding)run.guards++;}
    else run.dodges++;
    const points=out.damage===0?28:guarding?Math.max(8,20-out.damage*.22):Math.max(2,12-out.damage*.18);run.score+=Math.round(points);
    if(run.health<=0){run.finished=true;run.fullClear=false;}
    return {...out,health:run.health,score:run.score};
  }
  function finishWave(run,{damageBefore=0}={}){
    if(!run||run.finished&&run.health<=0)return null;const clean=run.damageTaken<=Number(damageBefore||0);if(clean){run.perfectWaves++;run.score+=45;}else run.score+=Math.max(8,Math.round(run.health*.12));run.waves.push({index:run.waveIndex,clean,health:run.health,score:run.score});run.waveIndex++;
    if(run.waveIndex>=WAVES.length||run.health<=0){run.finished=true;run.fullClear=run.waveIndex>=WAVES.length&&run.health>0;run.prismaticCleared=!!run.prismatic&&run.fullClear;run.score+=run.fullClear?Math.round(run.health*.7)+70:0;}
    return {clean,waveIndex:run.waveIndex,finished:run.finished,fullClear:run.fullClear,score:run.score};
  }
  function roundMetric(run){return Math.round((Number(run?.score)||0)*10)/10;}
  function rewardForRun(run){const p=run?.profile||difficultyProfile(run?.difficulty),score=Math.max(0,Number(run?.score)||0),health=Math.max(0,Number(run?.health)||0),full=!!run?.fullClear;return Math.max(30,Math.round((35+score*.18+health*.25+(full?55:0)+(run?.prismaticCleared?35:0))*(Number(p.rewardMultiplier)||1)));}

  return Object.freeze({WAVES,DIFFICULTIES,DIVISION_BASE,COUNTDOWN_STEP_MS,COUNTDOWN_END_MS,createSeededRng,difficultyProfile,divisionProfile,countdownLabel,spDefDamageMultiplier,spDefPerformance,guardMultiplier,resolveImpact,rollPrismaticStorm,createWavePlan,hazardHitsPlayer,createRun,applyImpact,finishWave,roundMetric,rewardForRun});
});
