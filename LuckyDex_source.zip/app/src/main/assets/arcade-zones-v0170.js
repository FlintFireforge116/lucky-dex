(function(root){
  'use strict';

  const FALLBACK_ZONES={
    amie:{id:'amie',name:'Kalos Amie Garden',icon:'🌸',games:['berryPicker','headIt','tilePuzzle']},
    gameCorner:{id:'gameCorner',name:'Game Corner',icon:'🎰',games:['voltorb','ballDrop']},
    discovery:{id:'discovery',name:'Discovery District',icon:'🔬',games:['fossil','ditto','unown','quiz']},
    performance:{id:'performance',name:'Performance Stage',icon:'🎭',games:['berry','clefairy']}
  };
  const GAME_META={
    berryPicker:{icon:'🍓',name:'Berry Picker',copy:'Serve the Berry each Pokémon wants before its patience runs out.',daily:true},
    headIt:{icon:'🧶',name:'Head It',copy:'Time your taps as falling yarn reaches your Pokémon.',daily:true},
    tilePuzzle:{icon:'🧩',name:'Tile Puzzle',copy:'Rebuild a Pokémon picture as a sliding tile puzzle.',daily:true},
    voltorb:{icon:'⚡',name:'Voltorb Flip',copy:'Read the clues, find the multipliers and avoid every Voltorb.'},
    ballDrop:{icon:'🔴',name:'Poké Ball Drop',copy:'Drop three balls through the Celadon prize machine.'},
    fossil:{icon:'🦴',name:'Fossil Excavation',copy:'Dig carefully, conserve tools and restore an ancient Pokémon.'},
    ditto:{icon:'🧬',name:'Ditto Transform',copy:'Watch Ditto Transform, then spot the imperfect copy in the Mansion research lab.'},
    unown:{icon:'🔤',name:'Unown Decoder',copy:'Decode messages from the Ruins of Alph before time expires.'},
    quiz:{icon:'❓',name:"Who's That Pokémon?",copy:'Identify silhouettes, build a streak and beat the clock.'},
    berry:{icon:'🍓',name:'Berry Blender',copy:'Hit the timing window and push the blender to maximum speed.'},
    clefairy:{icon:'🌙',name:'Clefairy Match',copy:'Watch the sequence, repeat it and decide when to bank.'}
  };

  const sourceZones=root.LuckyDexArcadePlatform?.ZONES||globalThis.LuckyDexArcadePlatform?.ZONES||FALLBACK_ZONES;
  const ZONE_MAP=Object.fromEntries(Object.entries(sourceZones).map(([id,z])=>[id,{...z,id,games:[...(z.games||[])]}]));
  let activeZone='amie';
  let activeGame=null;
  let legacyOpen=null;
  let legacyClose=null;
  let legacyBack=null;

  function zoneForGame(gameId){
    for(const zone of Object.values(ZONE_MAP))if(zone.games.includes(gameId))return zone.id;
    return null;
  }
  function el(id){return typeof document!=='undefined'?document.getElementById(id):null;}
  function platform(){return root.LuckyDexArcadePlatform||globalThis.LuckyDexArcadePlatform;}
  function zoneDailyReady(zone){
    const p=platform();if(!p?.dailyClaimAvailable)return 0;
    return zone.games.filter(id=>GAME_META[id]?.daily&&p.dailyClaimAvailable(id)).length;
  }
  function renderMap(){
    const host=el('arcadeMap');if(!host)return;
    host.innerHTML=Object.values(ZONE_MAP).map(zone=>{
      const ready=zoneDailyReady(zone);
      return `<button type="button" class="arcade-zone-card zone-${zone.id}" data-zone-id="${zone.id}"><span class="zone-icon">${zone.icon}</span><span class="zone-copy"><b>${zone.name}</b><small data-zone-count>${zone.games.length} games</small><em data-zone-daily>${ready?`${ready} daily item${ready===1?'':'s'} ready`:'Explore zone'}</em></span><span class="zone-arrow">›</span></button>`;
    }).join('');
    host.querySelectorAll('[data-zone-id]').forEach(btn=>btn.addEventListener('click',()=>openZone(btn.dataset.zoneId)));
  }
  function renderZone(zoneId){
    const zone=ZONE_MAP[zoneId];if(!zone)return;
    const title=el('arcadeZoneTitle');if(title)title.textContent=`${zone.icon} ${zone.name}`;
    const games=el('arcadeZoneGames');if(!games)return;
    games.innerHTML=zone.games.map(id=>{
      const meta=GAME_META[id]||{icon:'🎮',name:id,copy:'Arcade game'};
      const daily=meta.daily&&platform()?.dailyClaimAvailable?.(id);
      return `<button type="button" class="zone-game-card" data-zone-game="${id}"><span>${meta.icon}</span><div><b>${meta.name}</b><small>${meta.copy}</small>${meta.daily?`<em class="zone-daily ${daily?'ready':'claimed'}">${daily?'DAILY ITEM READY':'DAILY ITEM CLAIMED'}</em>`:''}</div><i>›</i></button>`;
    }).join('');
    games.querySelectorAll('[data-zone-game]').forEach(btn=>btn.addEventListener('click',()=>openGame(btn.dataset.zoneGame)));
  }
  function showMapOnly(){const map=el('arcadeMap'),view=el('arcadeZoneView');if(map)map.hidden=false;if(view)view.hidden=true;}
  function showZoneOnly(){const map=el('arcadeMap'),view=el('arcadeZoneView');if(map)map.hidden=true;if(view)view.hidden=false;}
  function arcadePageActive(){return !!document?.querySelector?.('.page[data-page="arcade"].active');}
  function openMap(){
    if(typeof document==='undefined')return;
    if(document.body.classList.contains('arcade-open')){const closed=backFromGame(false);if(!closed)return;}
    activeGame=null;renderMap();showMapOnly();
  }
  function openZone(zoneId){
    const zone=ZONE_MAP[zoneId];if(!zone){openMap();return false;}
    activeZone=zoneId;activeGame=null;
    const s=root.state||globalThis.state;if(s?.arcade){s.arcade.lastArcadeZone=zoneId;if(typeof root.save==='function')root.save();}
    renderZone(zoneId);showZoneOnly();return true;
  }
  function setExitLabels(zoneId){
    const zone=ZONE_MAP[zoneId];if(!zone||typeof document==='undefined')return;
    document.querySelectorAll('.arcade-game:not([hidden]) [data-exit-game]').forEach(btn=>btn.textContent=`‹ ${zone.name.toUpperCase()}`);
  }
  function openGame(gameId){
    const zoneId=zoneForGame(gameId);if(!zoneId)return false;
    activeZone=zoneId;activeGame=gameId;showMapOnly();const map=el('arcadeMap');if(map)map.hidden=true;
    const view=el('arcadeZoneView');if(view)view.hidden=true;
    if(['berryPicker','headIt','tilePuzzle'].includes(gameId)){
      root.LuckyDexAmie?.open?.(gameId);
    }else{
      const hook=document?.querySelector?.(`#arcadeLegacyHooks [data-game="${gameId}"]`);
      if(hook&&typeof hook.click==='function')hook.click();else if(typeof legacyOpen==='function')legacyOpen(gameId);
    }
    setTimeout(()=>setExitLabels(zoneId),0);return true;
  }
  function backFromGame(force=false){
    if(typeof document==='undefined')return false;
    const amie=root.LuckyDexAmie;
    if(amie?.activeGame?.()){
      const zoneId=zoneForGame(amie.activeGame())||activeZone;
      const closed=amie.close(force)!==false;if(!closed)return false;
      activeGame=null;openZone(zoneId);return true;
    }
    const wasOpen=document.body.classList.contains('arcade-open');
    if(wasOpen&&typeof legacyClose==='function')legacyClose(force);
    const stillOpen=document.body.classList.contains('arcade-open');
    if(wasOpen&&stillOpen)return false;
    if(wasOpen||activeGame){const zoneId=zoneForGame(activeGame)||activeZone;activeGame=null;openZone(zoneId);return true;}
    return false;
  }
  function wire(){
    legacyOpen=typeof root.openArcadeGame==='function'?root.openArcadeGame:null;
    legacyClose=typeof root.closeArcadeGame==='function'?root.closeArcadeGame:null;
    legacyBack=typeof root.handleLuckyBack==='function'?root.handleLuckyBack:null;
    const s=root.state||globalThis.state;if(s?.arcade&&ZONE_MAP[s.arcade.lastArcadeZone])activeZone=s.arcade.lastArcadeZone;
    el('arcadeMapBack')?.addEventListener('click',openMap);
    document.querySelectorAll('[data-exit-game]').forEach(btn=>{btn.onclick=ev=>{ev.preventDefault();backFromGame(false);};});
    root.closeArcadeGame=(force=false)=>backFromGame(force);
    root.handleLuckyBack=function(){
      if(document.body.classList.contains('arcade-open')){backFromGame(false);return true;}
      const zoneView=el('arcadeZoneView');if(arcadePageActive()&&zoneView&&!zoneView.hidden){openMap();return true;}
      return typeof legacyBack==='function'?legacyBack():false;
    };
    document.querySelector('[data-nav="arcade"]')?.addEventListener('click',()=>setTimeout(openMap,0));
    renderMap();showMapOnly();
  }

  const api={ZONE_MAP,GAME_META,openMap,openZone,openGame,backFromGame,zoneForGame};
  root.LuckyDexArcadeZones=api;
  if(typeof module!=='undefined'&&module.exports)module.exports=api;
  if(typeof document!=='undefined')wire();
})(typeof window!=='undefined'?window:globalThis);
