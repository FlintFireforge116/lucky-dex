const API = {
  pokeSpecies: 'https://pokeapi.co/api/v2/pokemon-species?limit=2000',
  pokeType: type => `https://pokeapi.co/api/v2/type/${type}`,
  tcgSets: 'https://api.tcgdex.net/v2/en/sets',
  tcgSeries: id => `https://api.tcgdex.net/v2/en/series/${id}`,
  tcgSet: id => `https://api.tcgdex.net/v2/en/sets/${id}`,
  card: id => `https://api.tcgdex.net/v2/en/cards/${id}`,
  sprite: (id, shiny=false) => `https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/${shiny ? 'shiny/' : ''}${id}.png`
};

const MAX_DEX_ID = 1025;
const LEGENDARY_RATE = 1 / 400;
const RARE_WILD_RATE = 1 / 20;
const LEGENDARIES = new Set([144,145,146,150,151,243,244,245,249,250,251,377,378,379,380,381,382,383,384,385,386,480,481,482,483,484,485,486,487,488,489,490,491,492,493,494,638,639,640,641,642,643,644,645,646,647,648,649,716,717,718,719,720,721,772,773,785,786,787,788,789,790,791,792,800,801,802,807,808,809,888,889,890,891,892,893,894,895,896,897,898,905,1001,1002,1003,1004,1007,1008,1009,1010,1024,1025]);
const MYTHICAL = new Set([151,251,385,386,489,490,491,492,493,494,647,648,649,719,720,721,801,802,807,808,809,893]);
const RARE_WILD = new Set([
  1,2,3,4,5,6,7,8,9,138,139,140,141,142,147,148,149,
  152,153,154,155,156,157,158,159,160,246,247,248,
  252,253,254,255,256,257,258,259,260,345,346,347,348,371,372,373,374,375,376,
  387,388,389,390,391,392,393,394,395,408,409,410,411,443,444,445,
  495,496,497,498,499,500,501,502,503,564,565,566,567,633,634,635,
  650,651,652,653,654,655,656,657,658,696,697,698,699,704,705,706,
  722,723,724,725,726,727,728,729,730,782,783,784,
  810,811,812,813,814,815,816,817,818,880,881,882,883,885,886,887,
  906,907,908,909,910,911,912,913,914,996,997,998
]);

const GENERATIONS = [
  {id:1,name:'Kanto',min:1,max:151},
  {id:2,name:'Johto',min:152,max:251},
  {id:3,name:'Hoenn',min:252,max:386},
  {id:4,name:'Sinnoh',min:387,max:493},
  {id:5,name:'Unova',min:494,max:649},
  {id:6,name:'Kalos',min:650,max:721},
  {id:7,name:'Alola',min:722,max:809},
  {id:8,name:'Galar/Hisui',min:810,max:905},
  {id:9,name:'Paldea',min:906,max:1025}
];

const ZONES = {
  meadow:{name:'Meadow',emoji:'🌿',types:['grass','normal','bug','fairy']},
  cave:{name:'Cave',emoji:'🪨',types:['rock','ground','dark','poison','steel']},
  coast:{name:'Coast',emoji:'🌊',types:['water','ice','flying']},
  volcano:{name:'Volcano',emoji:'🌋',types:['fire','rock','ground','dragon']}
};

const defaultState = {
  saveVersion: 2,
  settings:{shinyOdds:2048,vibration:true,zone:'meadow'},
  stats:{encounters:0,catches:0,shinies:0,packs:0,cardsPulled:0,zonesExplored:{}},
  pokemon:{}, cards:{}, recentPokemon:[], rareHits:[]
};

let state = loadState();
let species = [];
let zonePools = {};
let setCache = {tcg:[],tcgp:[]};
let collectionMode = 'pokemon';
let currentZone = state.settings.zone in ZONES ? state.settings.zone : 'meadow';
let huntPhase = 'idle';
let pendingEncounter = null;
let preparedPack = null;
let cardDetailCache = new Map();
let toastTimer = null;

function loadState(){
  try{
    const raw=JSON.parse(localStorage.getItem('luckyDexSave')||'{}');
    const migrated={
      ...defaultState,
      ...raw,
      settings:{...defaultState.settings,...(raw.settings||{})},
      stats:{...defaultState.stats,...(raw.stats||{}),zonesExplored:{...(raw.stats?.zonesExplored||{})}},
      pokemon:{...(raw.pokemon||{})},
      cards:{...(raw.cards||{})},
      recentPokemon:[...(raw.recentPokemon||[])],
      rareHits:[...(raw.rareHits||[])]
    };
    if(!raw.saveVersion){
      if(Number(migrated.settings.shinyOdds)===512) migrated.settings.shinyOdds=2048;
      if(!Number.isFinite(Number(migrated.stats.catches)) || Number(migrated.stats.catches)===0){
        migrated.stats.catches=Object.values(migrated.pokemon).reduce((n,p)=>n+Number(p.count||0),0);
      }
      Object.values(migrated.cards).forEach(c=>{
        if(!c.setName && c.set) c.setName=c.set;
        if(!c.setId && c.id?.includes('-')) c.setId=c.id.split('-').slice(0,-1).join('-');
      });
    }
    migrated.saveVersion=2;
    return migrated;
  }catch(e){ return structuredClone(defaultState); }
}

function save(){
  state.saveVersion=2;
  localStorage.setItem('luckyDexSave', JSON.stringify(state));
  updateStats();
}
function fmt(n){ return Number(n||0).toLocaleString(); }
function titleCase(s=''){ return String(s).replaceAll('-',' ').replace(/\b\w/g,c=>c.toUpperCase()); }
function delay(ms){ return new Promise(r=>setTimeout(r,ms)); }
function vibrate(ms=30){ if(state.settings.vibration && navigator.vibrate) navigator.vibrate(ms); }
async function fetchJson(url){ const r=await fetch(url); if(!r.ok) throw new Error(`${r.status}`); return r.json(); }
function cardImage(base){ return base ? `${base}/high.webp` : ''; }
function assetImage(base){ return base ? `${base}.webp` : ''; }
function clamp(n,a,b){ return Math.max(a,Math.min(b,n)); }
function escapeHtml(s=''){ return String(s).replace(/[&<>'"]/g,ch=>({'&':'&amp;','<':'&lt;','>':'&gt;',"'":'&#39;','"':'&quot;'}[ch])); }
function showToast(text){
  const el=document.getElementById('toast'); el.textContent=text; el.classList.add('show'); clearTimeout(toastTimer); toastTimer=setTimeout(()=>el.classList.remove('show'),1800);
}
function generationForId(id){ return GENERATIONS.find(g=>id>=g.min&&id<=g.max) || GENERATIONS[GENERATIONS.length-1]; }
function numericLocalId(v){ const m=String(v||'').match(/\d+/); return m?Number(m[0]):99999; }

function rarityTier(rarity=''){
  const x=String(rarity).toLowerCase().replace(/[★☆◇◆]/g,' ').replace(/\s+/g,' ').trim();
  if(!x || x==='unknown') return 1;
  if(x.includes('crown')||x.includes('three star')||x.includes('3 star')||x.includes('immersive')) return 6;
  if(x.includes('special illustration')||x.includes('hyper rare')||x.includes('secret rare')||x.includes('two star')||x.includes('2 star')||x.includes('two shiny')||x.includes('2 shiny')||x.includes('shiny ultra')) return 5;
  if(x.includes('illustration rare')||x.includes('ultra rare')||x.includes('one star')||x.includes('1 star')||x.includes('one shiny')||x.includes('1 shiny')||x.includes('ace spec')||x.includes('radiant')||x.includes('amazing')) return 4;
  if(x.includes('double rare')||x.includes('four diamond')||x.includes('4 diamond')) return 3;
  if(x.includes('three diamond')||x.includes('3 diamond')||x==='rare'||x.includes('rare holo')||x.includes('holo rare')) return 2;
  if(x.includes('uncommon')||x.includes('two diamond')||x.includes('2 diamond')) return 1;
  if(x.includes('common')||x.includes('one diamond')||x.includes('1 diamond')) return 0;
  if(x.includes('rare')) return 2;
  return 1;
}
function looksRare(r=''){ return rarityTier(r)>=3; }
function tierLabel(t){ return ['Common','Uncommon','Rare','Double rare','Illustration/ultra','Special rare','Jackpot'][clamp(t,0,6)]; }
function rollWeighted(entries){
  const r=Math.random(); let acc=0;
  for(const [value,p] of entries){ acc+=p; if(r<acc) return value; }
  return entries[entries.length-1][0];
}
function hitTierForSource(source){
  const table=source==='tcgp'
    ? [[2,.60],[3,.28],[4,.09],[5,.025],[6,.005]]
    : [[2,.62],[3,.25],[4,.09],[5,.035],[6,.005]];
  return rollWeighted(table);
}

function navigate(page){
  document.querySelectorAll('.page').forEach(x=>x.classList.toggle('active',x.dataset.page===page));
  document.querySelectorAll('[data-nav]').forEach(x=>x.classList.toggle('active',x.dataset.nav===page));
  if(page==='collection'){ rebuildCollectionControls(); renderCollection(); }
  if(page==='stats') renderStats();
}
document.querySelectorAll('[data-nav]').forEach(b=>b.addEventListener('click',()=>navigate(b.dataset.nav)));

async function initSpecies(){
  try{
    const data=await fetchJson(API.pokeSpecies);
    species=data.results.map(x=>({name:x.name,id:Number(x.url.split('/').filter(Boolean).pop())})).filter(x=>Number.isFinite(x.id)&&x.id<=MAX_DEX_ID);
    localStorage.setItem('luckyDexSpecies',JSON.stringify(species));
  }catch(e){
    species=(JSON.parse(localStorage.getItem('luckyDexSpecies')||'null')||[]).filter(x=>x.id<=MAX_DEX_ID);
    if(!species.length) species=Array.from({length:151},(_,i)=>({id:i+1,name:`pokemon-${i+1}`}));
  }
}

async function loadZonePool(zoneKey){
  if(zonePools[zoneKey]?.length) return zonePools[zoneKey];
  const cacheKey=`luckyDexZonePool:${zoneKey}:v2`;
  try{
    const cached=JSON.parse(localStorage.getItem(cacheKey)||'null');
    if(Array.isArray(cached)&&cached.length>20){ zonePools[zoneKey]=cached; return cached; }
  }catch(e){}
  const zone=ZONES[zoneKey];
  try{
    const lists=await Promise.all(zone.types.map(t=>fetchJson(API.pokeType(t))));
    const map=new Map();
    lists.forEach(data=>(data.pokemon||[]).forEach(row=>{
      const p=row.pokemon||{}; const id=Number((p.url||'').split('/').filter(Boolean).pop());
      if(Number.isFinite(id)&&id<=MAX_DEX_ID) map.set(id,{id,name:p.name});
    }));
    const pool=[...map.values()];
    if(pool.length<20) throw new Error('small pool');
    zonePools[zoneKey]=pool; localStorage.setItem(cacheKey,JSON.stringify(pool)); return pool;
  }catch(e){
    zonePools[zoneKey]=species.length?species:Array.from({length:151},(_,i)=>({id:i+1,name:`pokemon-${i+1}`}));
    return zonePools[zoneKey];
  }
}

async function chooseSpeciesForZone(){
  const pool=await loadZonePool(currentZone);
  const legendaryGate=Math.random()<LEGENDARY_RATE;
  const rareWildGate=!legendaryGate && Math.random()<RARE_WILD_RATE;
  let candidates;
  if(legendaryGate) candidates=pool.filter(p=>LEGENDARIES.has(p.id));
  else if(rareWildGate) candidates=pool.filter(p=>RARE_WILD.has(p.id)&&!LEGENDARIES.has(p.id));
  else candidates=pool.filter(p=>!LEGENDARIES.has(p.id)&&!RARE_WILD.has(p.id));
  if(!candidates.length){
    if(legendaryGate) candidates=species.filter(p=>LEGENDARIES.has(p.id));
    else if(rareWildGate) candidates=species.filter(p=>RARE_WILD.has(p.id)&&!LEGENDARIES.has(p.id));
    else candidates=pool.filter(p=>!LEGENDARIES.has(p.id));
  }
  const chosen=candidates[Math.floor(Math.random()*candidates.length)] || {id:25,name:'pikachu'};
  return {pokemon:chosen,legendaryGate,rareWildGate};
}

function setHuntControlsLocked(locked){ document.querySelectorAll('[data-zone]').forEach(b=>b.disabled=locked); }
function resetEncounterUI(){
  pendingEncounter=null; huntPhase='idle'; setHuntControlsLocked(false);
  const zone=ZONES[currentZone];
  document.getElementById('pokemonSprite').hidden=true;
  document.getElementById('encounterPlaceholder').hidden=false;
  document.getElementById('encounterPlaceholder').textContent=zone.emoji;
  document.getElementById('encounterName').textContent=`${zone.name} ready`;
  document.getElementById('encounterSub').textContent='Search the habitat to start an encounter.';
  document.getElementById('encounterTier').textContent='Ready';
  const btn=document.getElementById('encounterBtn'); btn.disabled=false; btn.textContent=`SEARCH ${zone.name.toUpperCase()}`;
  document.getElementById('runBtn').hidden=true;
  document.getElementById('spriteStage').classList.remove('searching','catching','caught');
}

async function startEncounter(){
  if(huntPhase==='found') return catchEncounter();
  if(huntPhase==='caught') return resetEncounterUI();
  if(huntPhase!=='idle') return;
  huntPhase='searching'; setHuntControlsLocked(true);
  const btn=document.getElementById('encounterBtn'); btn.disabled=true; btn.textContent='SEARCHING…';
  document.getElementById('runBtn').hidden=true;
  document.getElementById('encounterName').textContent='Something is moving…';
  document.getElementById('encounterSub').textContent=`Searching the ${ZONES[currentZone].name.toLowerCase()}…`;
  const stage=document.getElementById('spriteStage'); stage.classList.add('searching');
  document.getElementById('pokemonSprite').hidden=true; document.getElementById('encounterPlaceholder').hidden=true;
  await Promise.all([delay(850),loadZonePool(currentZone)]);
  const {pokemon:p,rareWildGate}=await chooseSpeciesForZone();
  const shiny=Math.floor(Math.random()*state.settings.shinyOdds)===0;
  const legendary=LEGENDARIES.has(p.id), mythical=MYTHICAL.has(p.id);
  const rareWild=rareWildGate&&RARE_WILD.has(p.id)&&!legendary;
  const eventOdds=(legendary?1/LEGENDARY_RATE:rareWild?1/RARE_WILD_RATE:1)*(shiny?state.settings.shinyOdds:1);
  state.stats.encounters++;
  state.stats.zonesExplored[currentZone]=(state.stats.zonesExplored[currentZone]||0)+1;
  save();
  pendingEncounter={...p,shiny,legendary,mythical,rareWild,eventOdds,zone:currentZone};
  huntPhase='found'; stage.classList.remove('searching');
  renderPendingEncounter();
}

function renderPendingEncounter(){
  const p=pendingEncounter; if(!p)return;
  const img=document.getElementById('pokemonSprite'); img.src=API.sprite(p.id,p.shiny); img.hidden=false;
  document.getElementById('encounterPlaceholder').hidden=true;
  document.getElementById('encounterName').textContent=`${p.shiny?'★ ':''}${titleCase(p.name)}`;
  const tier=p.shiny&&p.legendary?'SHINY LEGENDARY':p.shiny&&p.rareWild?'SHINY RARE':p.shiny?'SHINY':p.mythical?'MYTHICAL':p.legendary?'LEGENDARY':p.rareWild?'RARE WILD':'WILD POKÉMON';
  document.getElementById('encounterTier').textContent=tier;
  const rare=p.shiny||p.legendary||p.rareWild;
  document.getElementById('encounterSub').textContent=rare?`Rare encounter · event chance roughly 1 in ${fmt(Math.round(p.eventOdds))}`:`Found in the ${ZONES[p.zone].name}. Catch it to add it to your Pokédex.`;
  const btn=document.getElementById('encounterBtn'); btn.disabled=false; btn.textContent='THROW POKÉ BALL';
  document.getElementById('runBtn').hidden=false;
  if(p.shiny){ triggerSparkles(); vibrate([40,40,80]); } else if(p.legendary) vibrate(60);
}

async function catchEncounter(){
  if(!pendingEncounter||huntPhase!=='found')return;
  huntPhase='catching';
  const p=pendingEncounter,btn=document.getElementById('encounterBtn'); btn.disabled=true; btn.textContent='CATCHING…'; document.getElementById('runBtn').hidden=true;
  const stage=document.getElementById('spriteStage'); stage.classList.add('catching');
  await delay(1450);
  stage.classList.remove('catching'); stage.classList.add('caught');
  state.stats.catches++; if(p.shiny) state.stats.shinies++;
  const key=`${p.id}:${p.shiny?'s':'n'}`;
  const old=state.pokemon[key]||{id:p.id,name:p.name,shiny:p.shiny,count:0,firstSeen:Date.now(),bestOdds:p.eventOdds,generation:generationForId(p.id).id};
  old.count++; old.bestOdds=Math.max(old.bestOdds||1,p.eventOdds); old.lastZone=p.zone; state.pokemon[key]=old;
  state.recentPokemon.unshift({id:p.id,name:p.name,shiny:p.shiny,zone:p.zone,ts:Date.now()}); state.recentPokemon=state.recentPokemon.slice(0,12);
  if(p.shiny||p.legendary){ state.rareHits.unshift({type:'pokemon',name:`${p.shiny?'Shiny ':''}${titleCase(p.name)}`,odds:p.eventOdds,ts:Date.now()}); state.rareHits=state.rareHits.slice(0,40); }
  save(); renderRecent();
  document.getElementById('encounterTier').textContent='CAUGHT';
  document.getElementById('encounterSub').textContent=`${titleCase(p.name)} was added to your Pokédex${old.count>1?` · ×${old.count}`:''}.`;
  btn.disabled=false; btn.textContent='SEARCH AGAIN'; huntPhase='caught';
  vibrate([25,45,25]);
}

function runFromEncounter(){
  if(huntPhase!=='found')return;
  showToast(`Got away from ${titleCase(pendingEncounter.name)}.`); resetEncounterUI();
}
function triggerSparkles(){ const s=document.getElementById('sparkles'); s.classList.remove('active'); requestAnimationFrame(()=>s.classList.add('active')); }

function renderRecent(){
  const el=document.getElementById('recentPokemon');
  if(!state.recentPokemon.length){ el.innerHTML='<div class="muted small">Your recent catches will appear here.</div>'; return; }
  el.innerHTML=state.recentPokemon.map(p=>`<div class="recent-card ${p.shiny?'shiny-glow':''}"><img src="${API.sprite(p.id,p.shiny)}"><b>${p.shiny?'★ ':''}${escapeHtml(titleCase(p.name))}</b><small>${p.zone&&ZONES[p.zone]?ZONES[p.zone].emoji:''}</small></div>`).join('');
}

function selectZone(zoneKey){
  if(!(zoneKey in ZONES)||huntPhase==='searching'||huntPhase==='catching'||huntPhase==='found') return;
  currentZone=zoneKey; state.settings.zone=zoneKey; save();
  document.querySelectorAll('[data-zone]').forEach(b=>b.classList.toggle('active',b.dataset.zone===zoneKey));
  document.getElementById('huntCard').dataset.zone=zoneKey;
  resetEncounterUI(); loadZonePool(zoneKey);
}

async function loadSets(source){
  const select=document.getElementById('setSelect'); select.innerHTML='<option>Loading…</option>';
  try{
    if(source==='tcgp' && !setCache.tcgp.length){ setCache.tcgp=(await fetchJson(API.tcgSeries('tcgp'))).sets||[]; }
    if(source==='tcg' && !setCache.tcg.length){
      const [all,pocketSeries]=await Promise.all([fetchJson(API.tcgSets), setCache.tcgp.length?Promise.resolve({sets:setCache.tcgp}):fetchJson(API.tcgSeries('tcgp'))]);
      if(!setCache.tcgp.length) setCache.tcgp=pocketSeries.sets||[];
      const pocketIds=new Set(setCache.tcgp.map(s=>s.id));
      setCache.tcg=(all||[]).filter(s=>!pocketIds.has(s.id));
    }
    const sets=setCache[source].filter(s=>s.cardCount?.total>0).sort((a,b)=>String(b.releaseDate||'').localeCompare(String(a.releaseDate||''))||a.name.localeCompare(b.name));
    select.innerHTML=sets.map(s=>`<option value="${escapeHtml(s.id)}">${escapeHtml(s.name)} (${s.cardCount.total})</option>`).join('');
  }catch(e){ select.innerHTML='<option value="">Could not load sets</option>'; }
}

async function getCardDetail(brief){
  if(cardDetailCache.has(brief.id)) return cardDetailCache.get(brief.id);
  let card;
  try{ card=await fetchJson(API.card(brief.id)); }
  catch(e){ card={...brief,rarity:'Unknown'}; }
  cardDetailCache.set(brief.id,card); return card;
}

async function pickCardForTier(briefs,targetTier,used){
  const pool=briefs.filter(c=>!used.has(c.id));
  if(!pool.length) return getCardDetail(briefs[Math.floor(Math.random()*briefs.length)]);
  const maxAttempts=targetTier>=5?18:targetTier>=4?12:8;
  const tried=new Set(); let best=null,bestDistance=999;
  for(let i=0;i<maxAttempts&&tried.size<pool.length;i++){
    let brief;
    do{ brief=pool[Math.floor(Math.random()*pool.length)]; }while(tried.has(brief.id)&&tried.size<pool.length);
    tried.add(brief.id);
    const card=await getCardDetail(brief); const tier=rarityTier(card.rarity);
    const distance=Math.abs(tier-targetTier);
    if(distance<bestDistance || (distance===bestDistance&&tier<=(best?rarityTier(best.rarity):99))){ best=card; bestDistance=distance; }
    if(tier===targetTier) return card;
  }
  return best || getCardDetail(pool[0]);
}

async function buildBalancedPack(set,source,luckyPack=false){
  const briefs=set.cards||[]; if(!briefs.length) throw new Error('No cards');
  const hitTier=hitTierForSource(source);
  const plan=luckyPack ? [4,4,4,5,6] : (source==='tcgp'
    ? [0,0,1,rollWeighted([[1,.72],[2,.25],[3,.03]]),hitTier]
    : [0,1,1,rollWeighted([[1,.55],[2,.38],[3,.07]]),hitTier]);
  const cards=[],used=new Set();
  for(let i=0;i<plan.length;i++){
    const card=await pickCardForTier(briefs,plan[i],used); cards.push(card); used.add(card.id);
  }
  return cards;
}

async function preparePack(){
  const btn=document.getElementById('openPackBtn'),setId=document.getElementById('setSelect').value,source=document.getElementById('cardSource').value;
  if(!setId)return;
  btn.disabled=true; btn.textContent='BUILDING PACK…';
  document.getElementById('packStage').innerHTML='<div class="loading pack-loading"><div class="spinner"></div><b>Sorting rarity slots…</b><span>This first pack from a set may take a moment.</span></div>';
  try{
    const set=await fetchJson(API.tcgSet(setId));
    const luckyPack=Math.random()<1/2000;
    const cards=await buildBalancedPack(set,source,luckyPack);
    preparedPack={set,source,cards,luckyPack,revealed:new Set(),committed:false};
    renderSealedPack();
  }catch(e){
    document.getElementById('packStage').innerHTML='<div class="empty">Could not prepare this set. Check your connection and try again.</div>';
  }
  btn.disabled=false; btn.textContent='PREPARE PACK';
}

function renderSealedPack(){
  const {set,source}=preparedPack;
  const logo=set.logo?`<img class="pack-logo" src="${assetImage(set.logo)}" alt="">`:'';
  document.getElementById('packStage').innerHTML=`
    <div class="pack-instruction">Tap the pack to tear it open</div>
    <button class="sealed-pack" id="sealedPack" aria-label="Open ${escapeHtml(set.name)} pack">
      <div class="pack-foil"></div>
      <div class="pack-notch"></div>
      ${logo}
      <div class="pack-title"><small>${source==='tcgp'?'TCG POCKET':'POKÉMON TCG'}</small><b>${escapeHtml(set.name)}</b><span>5 cards</span></div>
      <div class="tear-line"></div>
    </button>`;
  document.getElementById('sealedPack').onclick=tearPack;
}

async function tearPack(){
  if(!preparedPack)return;
  const pack=document.getElementById('sealedPack'); if(pack){pack.disabled=true;pack.classList.add('tearing');}
  vibrate([15,20,25]); await delay(720);
  commitPreparedPack(); renderFaceDownPack();
}

function commitPreparedPack(){
  if(!preparedPack||preparedPack.committed)return;
  const {cards,set,source}=preparedPack;
  state.stats.packs++; state.stats.cardsPulled+=cards.length;
  if(preparedPack.luckyPack){ state.rareHits.unshift({type:'pack',name:'✦ Lucky Pack',rarity:'~1/2,000 event',ts:Date.now()}); }
  cards.forEach(c=>{
    const existing=state.cards[c.id]; c._wasNew=!existing;
    const old=existing||{id:c.id,name:c.name,image:c.image,localId:c.localId,setId:c.set?.id||set.id,setName:c.set?.name||set.name,setTotal:c.set?.cardCount?.total||set.cardCount?.total||0,source,rarity:c.rarity||'Unknown',count:0,firstPulled:Date.now()};
    old.count++; old.image=c.image||old.image; old.localId=c.localId||old.localId; old.rarity=c.rarity||old.rarity; old.setId=c.set?.id||old.setId||set.id; old.setName=c.set?.name||old.setName||set.name; old.setTotal=c.set?.cardCount?.total||old.setTotal||set.cardCount?.total||0; old.source=source||old.source;
    state.cards[c.id]=old;
    if(looksRare(c.rarity||'')){ state.rareHits.unshift({type:'card',name:c.name,rarity:c.rarity,set:old.setName,tier:rarityTier(c.rarity),ts:Date.now()}); }
  });
  state.rareHits=state.rareHits.slice(0,40); preparedPack.committed=true; save();
}

function renderFaceDownPack(){
  const {cards,set}=preparedPack;
  document.getElementById('packStage').innerHTML=`
    ${preparedPack.luckyPack?'<div class="lucky-pack-banner">✦ LUCKY PACK · ~1 IN 2,000 ✦</div>':''}
    <div class="pack-reveal-head"><div><b>${escapeHtml(set.name)}</b><span id="revealCounter">0 / ${cards.length} revealed</span></div><small>Tap a card to flip it. Tap it again for full screen.</small></div>
    <div class="pack-reveal-grid">${cards.map((c,i)=>`
      <button class="flip-card" data-pack-index="${i}" aria-label="Reveal card ${i+1}">
        <div class="flip-inner">
          <div class="flip-face card-back"><div class="ball-mark">●</div><b>LUCKY DEX</b><span>${i+1}</span></div>
          <div class="flip-face card-front ${looksRare(c.rarity)?'rare-card':''}"><img src="${cardImage(c.image)}" alt="${escapeHtml(c.name)}"><div class="card-front-copy"><b>${escapeHtml(c.name)}</b><span>${escapeHtml(c.rarity||'Unknown')}</span></div>${c._wasNew?'<i class="new-badge">NEW</i>':''}</div>
        </div>
      </button>`).join('')}</div>
    <div id="packComplete"></div>`;
  document.querySelectorAll('[data-pack-index]').forEach(b=>b.onclick=()=>handlePackCardTap(Number(b.dataset.packIndex),b));
  if(preparedPack.luckyPack){ vibrate([40,35,40,35,90]); }
}

function handlePackCardTap(index,button){
  if(!preparedPack)return; const card=preparedPack.cards[index];
  if(!preparedPack.revealed.has(index)){
    preparedPack.revealed.add(index); button.classList.add('revealed');
    const tier=rarityTier(card.rarity); if(tier>=4) vibrate([25,25,60]); else vibrate(18);
    document.getElementById('revealCounter').textContent=`${preparedPack.revealed.size} / ${preparedPack.cards.length} revealed`;
    if(tier>=5) setTimeout(()=>triggerPackShine(button),260);
    if(preparedPack.revealed.size===preparedPack.cards.length){
      document.getElementById('packComplete').innerHTML='<div class="pack-complete"><b>Pack complete</b><span>Everything has been added to your binder.</span><button class="secondary" id="anotherPackBtn">OPEN ANOTHER</button></div>';
      document.getElementById('anotherPackBtn').onclick=preparePack;
    }
  }else openCardModal(card);
}
function triggerPackShine(button){ button.classList.add('big-hit'); setTimeout(()=>button.classList.remove('big-hit'),1100); }

function cardSetKey(c){ return c.setId||c.setName||c.set||'Unknown set'; }
function cardSetName(c){ return c.setName||c.set||c.setId||'Unknown set'; }

function rebuildCollectionControls(){
  const filter=document.getElementById('collectionFilter'),group=document.getElementById('collectionGroupFilter');
  const oldFilter=filter.value,oldGroup=group.value;
  if(collectionMode==='pokemon'){
    filter.innerHTML='<option value="all">All caught</option><option value="shiny">Shiny only</option><option value="duplicates">Duplicates</option>';
    const ids=new Set(Object.values(state.pokemon).map(x=>x.id));
    const ownedGens=GENERATIONS.filter(g=>[...ids].some(id=>id>=g.min&&id<=g.max));
    group.innerHTML='<option value="all">All generations</option>'+ownedGens.map(g=>{const n=[...ids].filter(id=>id>=g.min&&id<=g.max).length;return `<option value="gen:${g.id}">Gen ${g.id} · ${escapeHtml(g.name)} · ${n}/${g.max-g.min+1}</option>`;}).join('');
  }else{
    filter.innerHTML='<option value="all">All cards</option><option value="rare">Rare hits</option><option value="duplicates">Duplicates</option>';
    const map=new Map();
    Object.values(state.cards).forEach(c=>{const k=cardSetKey(c); const row=map.get(k)||{key:k,name:cardSetName(c),ids:new Set(),total:Number(c.setTotal||0)};row.ids.add(c.id);row.total=Math.max(row.total,Number(c.setTotal||0));map.set(k,row);});
    group.innerHTML='<option value="all">All owned sets</option>'+[...map.values()].sort((a,b)=>a.name.localeCompare(b.name)).map(s=>`<option value="set:${escapeHtml(s.key)}">${escapeHtml(s.name)} · ${s.ids.size}${s.total?`/${s.total}`:''}</option>`).join('');
  }
  if([...filter.options].some(o=>o.value===oldFilter)) filter.value=oldFilter;
  if([...group.options].some(o=>o.value===oldGroup)) group.value=oldGroup;
}

function renderCollectionProgress(items,allItems){
  const el=document.getElementById('collectionProgress'),group=document.getElementById('collectionGroupFilter').value;
  let title=collectionMode==='pokemon'?'Pokédex':'Card binder',owned=0,total=0,sub='';
  if(collectionMode==='pokemon'){
    const unique=new Set(items.map(x=>x.id)); owned=unique.size;
    if(group.startsWith('gen:')){ const g=GENERATIONS.find(x=>x.id===Number(group.split(':')[1])); total=g.max-g.min+1; title=`Gen ${g.id} · ${g.name}`; sub=`${owned} of ${total} species caught`; }
    else{ const uniqueAll=new Set(allItems.map(x=>x.id)); owned=uniqueAll.size; total=MAX_DEX_ID; sub=`${owned} species caught across all generations`; }
  }else{
    const unique=new Set(items.map(x=>x.id)); owned=unique.size;
    if(group.startsWith('set:')){ const first=items[0]; total=Number(first?.setTotal||0); title=first?cardSetName(first):'Set'; sub=total?`${owned} of ${total} cards collected`:`${owned} unique cards collected`; }
    else{ owned=new Set(allItems.map(x=>x.id)).size; total=0; sub=`${owned} unique cards across ${new Set(allItems.map(cardSetKey)).size} sets`; }
  }
  const pct=total?clamp((owned/total)*100,0,100):0;
  el.innerHTML=`<div><b>${escapeHtml(title)}</b><span>${escapeHtml(sub)}</span></div>${total?`<div class="progress-track"><i style="width:${pct}%"></i></div>`:''}`;
}

function renderCollection(){
  const q=document.getElementById('collectionSearch').value.toLowerCase(),filter=document.getElementById('collectionFilter').value,group=document.getElementById('collectionGroupFilter').value,grid=document.getElementById('collectionGrid');
  const allItems=Object.values(collectionMode==='pokemon'?state.pokemon:state.cards);
  let items=allItems.filter(x=>(x.name||'').toLowerCase().includes(q));
  if(collectionMode==='pokemon'){
    if(group.startsWith('gen:')){const g=GENERATIONS.find(x=>x.id===Number(group.split(':')[1]));items=items.filter(x=>x.id>=g.min&&x.id<=g.max);}
    if(filter==='shiny')items=items.filter(x=>x.shiny); if(filter==='duplicates')items=items.filter(x=>x.count>1);
    if(group!=='all') items.sort((a,b)=>a.id-b.id||Number(b.shiny)-Number(a.shiny)); else items.sort((a,b)=>(b.firstSeen||0)-(a.firstSeen||0));
  }else{
    if(group.startsWith('set:')){const key=group.slice(4);items=items.filter(x=>cardSetKey(x)===key);}
    if(filter==='rare')items=items.filter(x=>looksRare(x.rarity)); if(filter==='duplicates')items=items.filter(x=>x.count>1);
    if(group!=='all') items.sort((a,b)=>numericLocalId(a.localId)-numericLocalId(b.localId)||a.name.localeCompare(b.name)); else items.sort((a,b)=>(b.firstPulled||0)-(a.firstPulled||0));
  }
  renderCollectionProgress(items,allItems);
  if(!items.length){ grid.innerHTML='<div class="empty">Nothing here yet.</div>'; return; }
  grid.innerHTML=items.map(x=>collectionMode==='pokemon'
    ?`<div class="collection-item ${x.shiny?'shiny-glow':''}"><span class="count-badge">×${x.count}</span><img src="${API.sprite(x.id,x.shiny)}"><b>${x.shiny?'★ ':''}${escapeHtml(titleCase(x.name))}</b><span>#${x.id} · Gen ${generationForId(x.id).id}</span></div>`
    :`<button class="collection-item card ${looksRare(x.rarity||'')?'rare-card':''}" data-card-id="${escapeHtml(x.id)}"><span class="count-badge">×${x.count}</span><img src="${cardImage(x.image)}"><b>${escapeHtml(x.name)}</b><span>${escapeHtml(x.rarity||cardSetName(x))}</span></button>`).join('');
  grid.querySelectorAll('[data-card-id]').forEach(b=>b.onclick=()=>openCardModal(state.cards[b.dataset.cardId]));
}

function openCardModal(card){
  if(!card)return;
  const stored=state.cards[card.id]||card;
  document.getElementById('cardDialogImage').src=cardImage(card.image||stored.image);
  document.getElementById('cardDialogName').textContent=card.name||stored.name;
  document.getElementById('cardDialogMeta').textContent=`${card.rarity||stored.rarity||'Unknown rarity'} · ${card.set?.name||stored.setName||stored.set||'Unknown set'}`;
  const badges=[];
  if(stored.count) badges.push(`Owned ×${stored.count}`);
  if(card.localId||stored.localId) badges.push(`#${card.localId||stored.localId}`);
  const t=rarityTier(card.rarity||stored.rarity); if(t>=3)badges.push(tierLabel(t));
  document.getElementById('cardDialogBadges').innerHTML=badges.map(x=>`<span>${escapeHtml(x)}</span>`).join('');
  document.getElementById('cardDialog').showModal();
}

function updateStats(){
  document.getElementById('seenStat').textContent=fmt(state.stats.encounters);
  document.getElementById('caughtStat').textContent=fmt(state.stats.catches);
  document.getElementById('shinyStat').textContent=fmt(state.stats.shinies);
  const ids=new Set(Object.values(state.pokemon).map(x=>x.id)); document.getElementById('uniqueStat').textContent=fmt(ids.size);
  document.getElementById('encounterOdds').textContent=`Shiny 1/${state.settings.shinyOdds} · Legends ~1/${Math.round(1/LEGENDARY_RATE)}`;
}

function renderStats(){
  const uniquePokemon=new Set(Object.values(state.pokemon).map(x=>x.id)).size,uniqueCards=Object.keys(state.cards).length,setsStarted=new Set(Object.values(state.cards).map(cardSetKey)).size;
  document.getElementById('statsGrid').innerHTML=[['Encounters',state.stats.encounters],['Caught',state.stats.catches],['Shinies',state.stats.shinies],['Species',uniquePokemon],['Packs',state.stats.packs],['Cards pulled',state.stats.cardsPulled],['Unique cards',uniqueCards],['Sets started',setsStarted]].map(([k,v])=>`<div class="stat-card"><strong>${fmt(v)}</strong><span>${k}</span></div>`).join('');
  const rare=state.rareHits.slice(0,16);
  document.getElementById('rarestList').innerHTML=rare.length?rare.map(x=>`<div class="rare-row"><b>${escapeHtml(x.name)}</b><span>${x.type==='pokemon'&&x.odds?`~1/${fmt(Math.round(x.odds))}`:escapeHtml(x.rarity||x.set||'Rare')}</span></div>`).join(''):'<div class="empty">Your shiny, legendary and high-rarity pulls will appear here.</div>';
}

function exportSave(){
  const data=JSON.stringify(state,null,2); if(window.Android?.shareText){window.Android.shareText(data);return;}
  const blob=new Blob([data],{type:'application/json'}),a=document.createElement('a');a.href=URL.createObjectURL(blob);a.download='lucky-dex-save.json';a.click();URL.revokeObjectURL(a.href);
}

// events
document.getElementById('encounterBtn').onclick=startEncounter;
document.getElementById('runBtn').onclick=runFromEncounter;
document.querySelectorAll('[data-zone]').forEach(b=>b.onclick=()=>selectZone(b.dataset.zone));
document.getElementById('cardSource').onchange=e=>{preparedPack=null;document.getElementById('packStage').innerHTML='<div class="empty compact-empty">Pick a set and prepare a pack.</div>';loadSets(e.target.value);};
document.getElementById('openPackBtn').onclick=preparePack;
document.querySelectorAll('[data-collection]').forEach(b=>b.onclick=()=>{collectionMode=b.dataset.collection;document.querySelectorAll('[data-collection]').forEach(x=>x.classList.toggle('active',x===b));rebuildCollectionControls();renderCollection();});
document.getElementById('collectionSearch').oninput=renderCollection;
document.getElementById('collectionFilter').onchange=renderCollection;
document.getElementById('collectionGroupFilter').onchange=renderCollection;
document.getElementById('settingsBtn').onclick=()=>document.getElementById('settingsDialog').showModal();
document.getElementById('closeSettings').onclick=()=>document.getElementById('settingsDialog').close();
document.getElementById('closeCardDialog').onclick=()=>document.getElementById('cardDialog').close();
document.getElementById('cardDialog').addEventListener('click',e=>{if(e.target===e.currentTarget)e.currentTarget.close();});
document.getElementById('shinyOddsSelect').value=String(state.settings.shinyOdds);
document.getElementById('vibrationToggle').checked=state.settings.vibration;
document.getElementById('shinyOddsSelect').onchange=e=>{state.settings.shinyOdds=Number(e.target.value);save();};
document.getElementById('vibrationToggle').onchange=e=>{state.settings.vibration=e.target.checked;save();};
document.getElementById('exportBtn').onclick=exportSave;
document.getElementById('resetBtn').onclick=()=>{if(confirm('Delete the entire Lucky Dex collection?')){state=structuredClone(defaultState);currentZone='meadow';save();renderRecent();renderStats();rebuildCollectionControls();renderCollection();selectZone('meadow');}};

(async function boot(){
  updateStats(); renderRecent(); rebuildCollectionControls();
  document.querySelectorAll('[data-zone]').forEach(b=>b.classList.toggle('active',b.dataset.zone===currentZone)); document.getElementById('huntCard').dataset.zone=currentZone; resetEncounterUI();
  await initSpecies();
  await Promise.allSettled([loadZonePool(currentZone),loadSets('tcg')]);
})();
