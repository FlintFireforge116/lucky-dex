const API = {
  pokeSpecies: 'https://pokeapi.co/api/v2/pokemon-species?limit=2000',
  tcgSets: 'https://api.tcgdex.net/v2/en/sets',
  tcgSeries: id => `https://api.tcgdex.net/v2/en/series/${id}`,
  tcgSet: id => `https://api.tcgdex.net/v2/en/sets/${id}`,
  card: id => `https://api.tcgdex.net/v2/en/cards/${id}`,
  sprite: (id, shiny=false) => `https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/${shiny ? 'shiny/' : ''}${id}.png`
};

const LEGENDARIES = new Set([144,145,146,150,151,243,244,245,249,250,251,377,378,379,380,381,382,383,384,385,386,480,481,482,483,484,485,486,487,488,489,490,491,492,493,494,638,639,640,641,642,643,644,645,646,647,648,649,716,717,718,719,720,721,772,773,785,786,787,788,789,790,791,792,800,801,802,807,808,809,888,889,890,891,892,893,894,895,896,897,898,905,1001,1002,1003,1004,1007,1008,1009,1010,1024,1025]);
const MYTHICAL = new Set([151,251,385,386,489,490,491,492,493,494,647,648,649,719,720,721,801,802,807,808,809,893]);
const RARE_WORDS = ['rare','ultra','secret','hyper','illustration','special','shiny','gold','double rare','ace spec','crown','immersive','star'];

const defaultState = {
  settings:{shinyOdds:512,vibration:true},
  stats:{encounters:0,shinies:0,packs:0,cardsPulled:0},
  pokemon:{}, cards:{}, recentPokemon:[], rareHits:[]
};
let state = loadState();
let species = [];
let setCache = {tcg:[],tcgp:[]};
let collectionMode = 'pokemon';
let currentSetCards = [];

function loadState(){
  try { return {...structuredClone(defaultState), ...JSON.parse(localStorage.getItem('luckyDexSave')||'{}')}; }
  catch { return structuredClone(defaultState); }
}
function save(){ localStorage.setItem('luckyDexSave', JSON.stringify(state)); updateStats(); }
function fmt(n){ return Number(n||0).toLocaleString(); }
function titleCase(s=''){ return s.replaceAll('-',' ').replace(/\b\w/g,c=>c.toUpperCase()); }
function vibrate(ms=30){ if(state.settings.vibration && navigator.vibrate) navigator.vibrate(ms); }
async function fetchJson(url){ const r=await fetch(url); if(!r.ok) throw new Error(`${r.status}`); return r.json(); }
function imageUrl(base){ return base ? `${base}/high.webp` : ''; }
function rarityScore(r=''){ const x=r.toLowerCase(); let s=1; if(x.includes('uncommon'))s=1.2; if(x.includes('rare'))s=2; if(x.includes('double'))s=3; if(x.includes('ultra'))s=4; if(x.includes('secret')||x.includes('hyper')||x.includes('special illustration')||x.includes('immersive'))s=6; return s; }
function looksRare(r=''){ const x=r.toLowerCase(); return RARE_WORDS.some(w=>x.includes(w)) && !x.includes('common'); }

function navigate(page){
  document.querySelectorAll('.page').forEach(x=>x.classList.toggle('active',x.dataset.page===page));
  document.querySelectorAll('[data-nav]').forEach(x=>x.classList.toggle('active',x.dataset.nav===page));
  if(page==='collection') renderCollection(); if(page==='stats') renderStats();
}
document.querySelectorAll('[data-nav]').forEach(b=>b.addEventListener('click',()=>navigate(b.dataset.nav)));

async function initSpecies(){
  try{
    const data=await fetchJson(API.pokeSpecies);
    species=data.results.map(x=>({name:x.name,id:Number(x.url.split('/').filter(Boolean).pop())})).filter(x=>Number.isFinite(x.id));
    localStorage.setItem('luckyDexSpecies',JSON.stringify(species));
  }catch(e){
    species=JSON.parse(localStorage.getItem('luckyDexSpecies')||'null') || Array.from({length:151},(_,i)=>({id:i+1,name:`pokemon-${i+1}`}));
  }
}

function weightedSpecies(){
  if(!species.length) return {id:25,name:'pikachu'};
  // Most rolls come from the broad dex. A small explicit legendary gate makes those hits feel special.
  const legendaryGate=Math.random()<0.012;
  let pool=legendaryGate ? species.filter(p=>LEGENDARIES.has(p.id)) : species.filter(p=>!LEGENDARIES.has(p.id));
  if(!pool.length) pool=species;
  return pool[Math.floor(Math.random()*pool.length)];
}

async function encounter(){
  const btn=document.getElementById('encounterBtn'); btn.disabled=true;
  const p=weightedSpecies();
  const shiny=Math.floor(Math.random()*state.settings.shinyOdds)===0;
  const legendary=LEGENDARIES.has(p.id), mythical=MYTHICAL.has(p.id);
  const comboOdds=(legendary?Math.round(species.length/Math.max(1,species.filter(x=>LEGENDARIES.has(x.id)).length)/0.012):1) * (shiny?state.settings.shinyOdds:1);
  state.stats.encounters++; if(shiny)state.stats.shinies++;
  const key=`${p.id}:${shiny?'s':'n'}`;
  const old=state.pokemon[key]||{id:p.id,name:p.name,shiny,count:0,firstSeen:Date.now(),bestOdds:comboOdds}; old.count++; old.bestOdds=Math.max(old.bestOdds||1,comboOdds); state.pokemon[key]=old;
  state.recentPokemon.unshift({id:p.id,name:p.name,shiny,ts:Date.now()}); state.recentPokemon=state.recentPokemon.slice(0,12);
  if(shiny||legendary){ state.rareHits.unshift({type:'pokemon',name:`${shiny?'Shiny ':''}${titleCase(p.name)}`,odds:comboOdds,ts:Date.now()}); state.rareHits=state.rareHits.slice(0,30); }
  save(); renderEncounter(p,shiny,legendary,mythical,comboOdds); renderRecent(); btn.disabled=false;
}
function renderEncounter(p,shiny,legendary,mythical,odds){
  const img=document.getElementById('pokemonSprite'); img.src=API.sprite(p.id,shiny); img.hidden=false; document.getElementById('encounterPlaceholder').hidden=true;
  document.getElementById('encounterName').textContent=`${shiny?'★ ':''}${titleCase(p.name)}`;
  const tier=shiny&&legendary?'SHINY LEGENDARY':shiny?'SHINY':mythical?'MYTHICAL':legendary?'LEGENDARY':'ENCOUNTER';
  document.getElementById('encounterTier').textContent=tier;
  document.getElementById('encounterSub').textContent=(shiny||legendary)?`Rare hit · approximate combined roll 1 in ${fmt(Math.max(1,Math.round(odds)))}`:'Added to your collection.';
  if(shiny){ const s=document.getElementById('sparkles'); s.classList.remove('active'); requestAnimationFrame(()=>s.classList.add('active')); vibrate([40,40,80]); }
  else if(legendary) vibrate(55);
}
function renderRecent(){
  const el=document.getElementById('recentPokemon');
  if(!state.recentPokemon.length){ el.innerHTML='<div class="muted small">Your recent encounters will appear here.</div>'; return; }
  el.innerHTML=state.recentPokemon.map(p=>`<div class="recent-card ${p.shiny?'shiny-glow':''}"><img src="${API.sprite(p.id,p.shiny)}"><b>${p.shiny?'★ ':''}${titleCase(p.name)}</b></div>`).join('');
}

async function loadSets(source){
  const select=document.getElementById('setSelect'); select.innerHTML='<option>Loading…</option>';
  try{
    if(!setCache[source].length){
      setCache[source]=source==='tcgp' ? (await fetchJson(API.tcgSeries('tcgp'))).sets : await fetchJson(API.tcgSets);
    }
    const sets=setCache[source].filter(s=>s.cardCount?.total>0).sort((a,b)=>a.name.localeCompare(b.name));
    select.innerHTML=sets.map(s=>`<option value="${s.id}">${s.name} (${s.cardCount.total})</option>`).join('');
  }catch(e){ select.innerHTML='<option value="">Could not load sets</option>'; }
}

async function openPack(){
  const btn=document.getElementById('openPackBtn'), setId=document.getElementById('setSelect').value; if(!setId)return;
  btn.disabled=true; document.getElementById('packStage').innerHTML='<div class="loading">Opening pack…</div>';
  try{
    const set=await fetchJson(API.tcgSet(setId)); currentSetCards=set.cards||[];
    if(!currentSetCards.length) throw new Error('No cards');
    const chosen=[];
    for(let i=0;i<5;i++) chosen.push(currentSetCards[Math.floor(Math.random()*currentSetCards.length)]);
    // Detail only the five pulls; fast enough and gives us real rarity/variant metadata.
    const cards=await Promise.all(chosen.map(c=>fetchJson(API.card(c.id)).catch(()=>({...c,rarity:'Unknown',set:{name:set.name,id:setId}}))));
    state.stats.packs++; state.stats.cardsPulled+=cards.length;
    cards.forEach(c=>{
      const key=c.id; const old=state.cards[key]||{id:c.id,name:c.name,image:c.image,set:c.set?.name||set.name,rarity:c.rarity||'Unknown',count:0,firstPulled:Date.now()}; old.count++; old.rarity=c.rarity||old.rarity; state.cards[key]=old;
      if(looksRare(c.rarity||'')){ state.rareHits.unshift({type:'card',name:c.name,rarity:c.rarity,set:c.set?.name||set.name,ts:Date.now()}); state.rareHits=state.rareHits.slice(0,30); }
    });
    save(); renderPack(cards); if(cards.some(c=>looksRare(c.rarity||''))) vibrate([35,35,70]);
  }catch(e){ document.getElementById('packStage').innerHTML='<div class="empty">Could not open this set. Check your connection and try another set.</div>'; }
  btn.disabled=false;
}
function renderPack(cards){
  document.getElementById('packStage').innerHTML=cards.map((c,i)=>`<div class="card-tile ${looksRare(c.rarity||'')?'rare-card':''}" style="animation-delay:${i*80}ms"><img src="${imageUrl(c.image)}" alt="${c.name}"><b>${c.name}</b><span>${c.rarity||'Unknown'}</span></div>`).join('');
}

function renderCollection(){
  const q=document.getElementById('collectionSearch').value.toLowerCase(), filter=document.getElementById('collectionFilter').value, grid=document.getElementById('collectionGrid');
  let items=Object.values(collectionMode==='pokemon'?state.pokemon:state.cards);
  items=items.filter(x=>(x.name||'').toLowerCase().includes(q));
  if(filter==='shiny') items=items.filter(x=>x.shiny); if(filter==='duplicates')items=items.filter(x=>x.count>1);
  items.sort((a,b)=>(b.firstSeen||b.firstPulled||0)-(a.firstSeen||a.firstPulled||0));
  if(!items.length){ grid.innerHTML='<div class="empty">Nothing here yet.</div>'; return; }
  grid.innerHTML=items.map(x=>collectionMode==='pokemon'
    ?`<div class="collection-item ${x.shiny?'shiny-glow':''}"><span class="count-badge">×${x.count}</span><img src="${API.sprite(x.id,x.shiny)}"><b>${x.shiny?'★ ':''}${titleCase(x.name)}</b><span>#${x.id}</span></div>`
    :`<div class="collection-item card ${looksRare(x.rarity||'')?'rare-card':''}"><span class="count-badge">×${x.count}</span><img src="${imageUrl(x.image)}"><b>${x.name}</b><span>${x.rarity||x.set}</span></div>`).join('');
}

function updateStats(){
  document.getElementById('seenStat').textContent=fmt(state.stats.encounters); document.getElementById('shinyStat').textContent=fmt(state.stats.shinies);
  const ids=new Set(Object.values(state.pokemon).map(x=>x.id)); document.getElementById('uniqueStat').textContent=fmt(ids.size);
  document.getElementById('encounterOdds').textContent=`Shiny odds 1/${state.settings.shinyOdds}`;
}
function renderStats(){
  const uniquePokemon=new Set(Object.values(state.pokemon).map(x=>x.id)).size, uniqueCards=Object.keys(state.cards).length;
  document.getElementById('statsGrid').innerHTML=[['Encounters',state.stats.encounters],['Shinies',state.stats.shinies],['Species',uniquePokemon],['Packs',state.stats.packs],['Cards pulled',state.stats.cardsPulled],['Unique cards',uniqueCards]].map(([k,v])=>`<div class="stat-card"><strong>${fmt(v)}</strong><span>${k}</span></div>`).join('');
  const rare=state.rareHits.slice(0,12); document.getElementById('rarestList').innerHTML=rare.length?rare.map(x=>`<div class="rare-row"><b>${x.name}</b><span>${x.type==='pokemon'&&x.odds?`~1/${fmt(Math.round(x.odds))}`:(x.rarity||x.set||'Rare')}</span></div>`).join(''):'<div class="empty">Your shiny, legendary and high-rarity pulls will appear here.</div>';
}

function exportSave(){
  const data=JSON.stringify(state,null,2); if(window.Android?.shareText){window.Android.shareText(data);return;}
  const blob=new Blob([data],{type:'application/json'}),a=document.createElement('a');a.href=URL.createObjectURL(blob);a.download='lucky-dex-save.json';a.click();URL.revokeObjectURL(a.href);
}

// events
document.getElementById('encounterBtn').onclick=encounter;
document.getElementById('cardSource').onchange=e=>loadSets(e.target.value);
document.getElementById('openPackBtn').onclick=openPack;
document.querySelectorAll('[data-collection]').forEach(b=>b.onclick=()=>{collectionMode=b.dataset.collection;document.querySelectorAll('[data-collection]').forEach(x=>x.classList.toggle('active',x===b));renderCollection();});
document.getElementById('collectionSearch').oninput=renderCollection; document.getElementById('collectionFilter').onchange=renderCollection;
document.getElementById('settingsBtn').onclick=()=>document.getElementById('settingsDialog').showModal(); document.getElementById('closeSettings').onclick=()=>document.getElementById('settingsDialog').close();
document.getElementById('shinyOddsSelect').value=state.settings.shinyOdds; document.getElementById('vibrationToggle').checked=state.settings.vibration;
document.getElementById('shinyOddsSelect').onchange=e=>{state.settings.shinyOdds=Number(e.target.value);save();}; document.getElementById('vibrationToggle').onchange=e=>{state.settings.vibration=e.target.checked;save();};
document.getElementById('exportBtn').onclick=exportSave; document.getElementById('resetBtn').onclick=()=>{if(confirm('Delete the entire Lucky Dex collection?')){state=structuredClone(defaultState);save();renderRecent();renderStats();renderCollection();}};

(async function boot(){ updateStats(); renderRecent(); await Promise.allSettled([initSpecies(),loadSets('tcg')]); })();
