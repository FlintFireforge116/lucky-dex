(function(root,factory){
  const core=root.LuckyDexPokemonSeekCore||(typeof require==='function'?require('./arcade-pokemon-seek-core.js'):null);
  const api=factory(root,core);root.LuckyDexPokemonSeek=api;if(typeof module!=='undefined'&&module.exports)module.exports=api;
})(typeof window!=='undefined'?window:globalThis,function(root,core){
  'use strict';
  if(!core)throw new Error('LuckyDexPokemonSeekCore required');
  const $=id=>typeof document!=='undefined'?document.getElementById(id):null;
  const now=()=>typeof performance!=='undefined'&&performance.now?performance.now():Date.now();
  const raf=fn=>(root.requestAnimationFrame||((f)=>setTimeout(()=>f(now()),16)))(fn);
  const caf=id=>(root.cancelAnimationFrame||clearTimeout)(id);
  const clamp=(n,a,b)=>Math.max(a,Math.min(b,Number(n)||0));
  const session=()=>root.LuckyDexArcadeSession||globalThis.LuckyDexArcadeSession;
  const platform=()=>root.LuckyDexArcadePlatform||globalThis.LuckyDexArcadePlatform;
  const rareRewards=()=>root.LuckyDexArcadeRareRewards||globalThis.LuckyDexArcadeRareRewards;
  const rareBridge=()=>root.LuckyDexRareRewardBridge||globalThis.LuckyDexRareRewardBridge;
  const giftCore=()=>root.LuckyDexVoltorbGiftCore||globalThis.LuckyDexVoltorbGiftCore;
  let opened=false,phase='closed',difficulty='normal',run=null,rafId=0,lastFrame=0,revealTimer=0,completionHandled=false,finalResult=null,rng=Math.random,flash='',flashUntil=0;

  function profile(){return core.difficultyProfile(difficulty);}
  function rareRate(){return clamp(root.state?.settings?.rareOdds?.pokemonSeekDreamSparkle??core.CONFIG.dreamRate,0,1);}
  function stopLoop(){if(rafId){caf(rafId);rafId=0;}}
  function schedule(){if(!rafId&&phase==='running')rafId=raf(frame);}
  function clearRevealTimer(){if(revealTimer){clearTimeout(revealTimer);revealTimer=0;}}
  function showReady(next=difficulty){
    difficulty=core.DIFFICULTIES[next]?next:'normal';phase='ready';run=null;stopLoop();clearRevealTimer();completionHandled=false;finalResult=null;flash='';
    const ready=$('pokemonSeekReady');if(ready)ready.hidden=false;const pause=$('pokemonSeekPauseOverlay');if(pause)pause.hidden=true;const reveal=$('pokemonSeekReveal');if(reveal)reveal.hidden=true;
    document.querySelectorAll?.('[data-pokemonseek-difficulty]')?.forEach(btn=>{const on=btn.dataset.pokemonseekDifficulty===difficulty;btn.classList.toggle('active',on);btn.setAttribute('aria-pressed',on?'true':'false');});
    const meta=$('pokemonSeekReadyMeta');if(meta)meta.textContent=`${profile().label.toUpperCase()} · 90 SECONDS · FIND THE LOST POKÉMON`;renderAll();return true;
  }
  function selectDifficulty(key){if(phase!=='ready'||!core.DIFFICULTIES[key])return false;return showReady(key);}
  function startRun(){
    if(!opened||phase!=='ready')return false;session()?.hideResult?.();run=core.createRun({difficulty,rng,dreamRate:rareRate()});phase='running';lastFrame=now();completionHandled=false;finalResult=null;flash='';const ready=$('pokemonSeekReady');if(ready)ready.hidden=true;
    session()?.update?.('pokemonSeek',{runText:'90 seconds · search the manor',rewardText:'Lucky Coins · lost item · rare Dream Sparkle',liveLabel:'TARGET',liveValue:run.target.label});renderAll();schedule();return true;
  }
  function frame(t){
    rafId=0;if(phase!=='running'||!run)return;const dt=Math.min(.05,Math.max(0,(t-lastFrame)/1000||0));lastFrame=t;run.elapsedMs=Math.min(core.CONFIG.durationMs,run.elapsedMs+dt*1000);if(run.elapsedMs>=core.CONFIG.durationMs){run.complete=true;void finishRun();return;}renderHud();renderStatus();schedule();
  }
  function move(direction){if(phase!=='running'||!run)return false;const changed=core.move(run,direction);if(!changed){flash='THAT WAY IS BLOCKED';flashUntil=now()+550;renderStatus();return false;}flash=`ROOM ${core.roomLabel(run.currentRoom)}`;flashUntil=now()+450;renderAll();return true;}
  function listen(){if(phase!=='running'||!run)return false;const hint=core.listenHint(run);flash=hint.message;flashUntil=now()+2200;renderHud();renderStatus();return hint;}
  function showReveal(result){
    const host=$('pokemonSeekReveal'),img=$('pokemonSeekRevealSprite'),title=$('pokemonSeekRevealTitle'),copy=$('pokemonSeekRevealCopy');if(!host)return;
    if(result?.pokemon&&img){img.src=`arcade/sprites/pokemon/${result.pokemon.dex}.png`;img.alt=result.pokemon.label;img.hidden=false;}else if(img){img.hidden=true;img.removeAttribute('src');}
    if(title)title.textContent=result?.foundTarget?'FOUND!':result?.kind==='pokemon'?`${result.pokemon.label.toUpperCase()}!`:'NOTHING HERE';
    if(copy)copy.textContent=result?.foundTarget?`You found ${run.target.label}!`:result?.kind==='pokemon'?`Not the lost Pokémon. The clock pauses while ${result.pokemon.label} slips away.`:'This hiding place is empty.';
    host.hidden=false;
  }
  function hideReveal(){const host=$('pokemonSeekReveal');if(host)host.hidden=true;}
  function searchSpot(spotId){
    if(phase!=='running'||!run)return {accepted:false};const result=core.search(run,spotId);if(!result.accepted)return result;renderSpots();
    if(result.foundTarget){phase='reveal';stopLoop();showReveal(result);revealTimer=setTimeout(()=>{revealTimer=0;hideReveal();void finishRun();},650);return result;}
    if(result.kind==='pokemon'){phase='reveal';stopLoop();showReveal(result);revealTimer=setTimeout(()=>{revealTimer=0;hideReveal();if(opened&&run&&!run.complete){phase='running';lastFrame=now();renderAll();schedule();}},780);return result;}
    flash='NOTHING HERE';flashUntil=now()+650;renderAll();return result;
  }
  function collectLostItem(){if(phase!=='running'||!run)return false;const result=core.collectLostItem(run);if(!result.collected)return false;flash=`LOST ITEM FOUND · +${core.CONFIG.lostItemScore.toLocaleString('en-GB')}`;flashUntil=now()+1500;renderAll();return true;}
  function collectDreamSparkle(){if(phase!=='running'||!run)return false;const result=core.collectDreamSparkle(run);if(!result.collected)return false;flash='✦ DREAM SPARKLE FOUND · PRIZE RESERVED ✦';flashUntil=now()+1700;renderAll();return true;}
  function renderHud(){
    const remaining=core.remainingMs(run),secs=Math.ceil(remaining/1000);if($('pokemonSeekTimer'))$('pokemonSeekTimer').textContent=`${Math.floor(secs/60)}:${String(secs%60).padStart(2,'0')}`;
    if($('pokemonSeekScore'))$('pokemonSeekScore').textContent=Number(core.finalScore(run)).toLocaleString('en-GB');if($('pokemonSeekRoom'))$('pokemonSeekRoom').textContent=run?core.roomLabel(run.currentRoom):'B2';if($('pokemonSeekWrong'))$('pokemonSeekWrong').textContent=String(run?.wrongFinds||0);
    const rec=root.state?.arcade?.pokemonSeek;if($('pokemonSeekBest'))$('pokemonSeekBest').textContent=`BEST ${Number(rec?.bestScores?.[difficulty]||0).toLocaleString('en-GB')}`;
  }
  function renderTarget(){const img=$('pokemonSeekTargetSprite'),name=$('pokemonSeekTargetName');if(!run){if(img)img.hidden=true;if(name)name.textContent='LOST POKÉMON';return;}if(img){img.hidden=false;img.src=`arcade/sprites/pokemon/${run.target.dex}.png`;img.alt=run.target.label;}if(name)name.textContent=`FIND ${run.target.label.toUpperCase()}`;}
  function renderMap(){const host=$('pokemonSeekMap');if(!host)return;host.innerHTML=Array.from({length:9},(_,i)=>`<i class="${run?.currentRoom===i?'current ':''}${run?.visitedRooms?.includes(i)?'visited':''}" aria-label="Room ${core.roomLabel(i)}"></i>`).join('');}
  function renderSpots(){
    const host=$('pokemonSeekSpots');if(!host)return;if(!run){host.innerHTML='';return;}const room=core.currentRoom(run);host.innerHTML=room.spots.map(spot=>{
      const state=spot.searched?'is-searched':spot.rustle?'is-rustling':'';const status=spot.searched?(spot.kind==='empty'?'EMPTY':'CHECKED'):'SEARCH';
      return `<button type="button" class="pokemonseek-spot ${state}" data-pokemonseek-spot="${spot.id}" ${spot.searched?'disabled':''}><small>${spot.label}</small><b>${status}</b><span>${spot.rustle&&!spot.searched?'RUSTLE…':'LOOK CLOSELY'}</span></button>`;
    }).join('');
  }
  function renderExtras(){
    const item=$('pokemonSeekLostItem'),dream=$('pokemonSeekDreamSparkle');if(!run){if(item)item.hidden=true;if(dream)dream.hidden=true;return;}
    if(item)item.hidden=run.itemFound||run.currentRoom!==run.itemRoom;
    const showDream=run.dreamEvent&&!run.dreamFound&&run.currentRoom===run.dreamRoom;if(dream)dream.hidden=!showDream;if(showDream)core.markDreamSeen(run);
  }
  function renderNav(){if(!run)return;const {x,y}=core.roomXY(run.currentRoom);const set=(id,disabled)=>{const n=$(id);if(n)n.disabled=phase!=='running'||disabled;};set('pokemonSeekNorth',y===0);set('pokemonSeekSouth',y===2);set('pokemonSeekWest',x===0);set('pokemonSeekEast',x===2);const listenBtn=$('pokemonSeekListen');if(listenBtn)listenBtn.disabled=phase!=='running';}
  function renderStatus(){const s=$('pokemonSeekStatus');if(!s)return;if(flash&&now()<flashUntil)s.textContent=flash;else if(phase==='running')s.textContent='SEARCH BOTH HIDING PLACES OR LISTEN CAREFULLY';else if(phase==='paused')s.textContent='SEARCH PAUSED';else s.textContent='FIND THE LOST POKÉMON BEFORE TIME RUNS OUT';}
  function renderAll(){renderHud();renderTarget();renderMap();renderSpots();renderExtras();renderNav();renderStatus();}
  function pause(){if(phase!=='running')return false;phase='paused';stopLoop();const p=$('pokemonSeekPauseOverlay');if(p)p.hidden=false;renderNav();renderStatus();return true;}
  function resume(){if(phase!=='paused')return false;phase='running';lastFrame=now();const p=$('pokemonSeekPauseOverlay');if(p)p.hidden=true;renderAll();schedule();return true;}
  async function claimDreamPrize(){
    if(!run?.dreamFound)return {label:'',reveal:null,pending:false};const rr=rareRewards(),bridge=rareBridge(),gift=giftCore();if(!root.state||!rr||!bridge||!gift)return {label:'Dream Prize Reserved',reveal:null,pending:true};
    let attempt=rr.getOrCreateAttempt(root.state,'pokemonSeekDreamSparkle',()=>{const pick=gift.rewardForRoll(rng());return {kind:pick.kind,reward:pick.reward,source:'pokemon-seek-dream-sparkle'};});
    try{if(!attempt.reward&&['card','pack'].includes(attempt.kind)){const reward=await bridge.resolveArcadeReward?.(attempt.kind);if(!reward)throw new Error('Dream Sparkle reward could not be resolved');attempt=rr.patchAttempt(root.state,'pokemonSeekDreamSparkle',attempt.id,{reward})||attempt;bridge.save?.();}if(!attempt.reward)throw new Error('Dream Sparkle reward missing');const claim=await rr.claimAttempt(root.state,'pokemonSeekDreamSparkle',attempt.id,r=>bridge.grantReward?.(r));bridge.save?.();return {label:claim?.result?.label||attempt.reward.label||'Dream Prize',reveal:bridge.rewardReveal?.(attempt.reward,claim?.result,'DREAM SPARKLE PRIZE')||null,pending:false};}
    catch(error){console.warn?.('[LuckyDex] Pokémon Seek Dream Sparkle prize remains reserved',error);bridge.save?.();return {label:'Dream Prize Reserved',reveal:null,pending:true};}
  }
  async function finishRun(){
    if(finalResult)return finalResult;if(!run)return null;phase='finishing';stopLoop();clearRevealTimer();const p=platform();if(!root.state||!p?.ensureArcadeState)return null;root.state.arcade=p.ensureArcadeState(root.state.arcade);const rec=root.state.arcade.pokemonSeek,prevScore=Number(rec.bestScores?.[difficulty]||0),prevRemain=Number(rec.bestRemainingMs||0),prevWrong=Number(rec.bestCleanScore||0),prize=await claimDreamPrize();
    const found=!!run.foundTarget,remainingMs=core.remainingMs(run),score=core.finalScore(run),clean=found&&run.wrongFinds===0,reward=core.rewardForRun(run);
    rec.gamesPlayed=Number(rec.gamesPlayed||0)+1;if(found)rec.clears=Number(rec.clears||0)+1;if(found&&difficulty==='hard')rec.hardClears=Number(rec.hardClears||0)+1;if(clean)rec.cleanFinds=Number(rec.cleanFinds||0)+1;if(run.itemFound)rec.lostItemsFound=Number(rec.lostItemsFound||0)+1;rec.bestScore=Math.max(Number(rec.bestScore||0),score);rec.bestScores[difficulty]=Math.max(Number(rec.bestScores?.[difficulty]||0),score);if(found)rec.bestRemainingMs=Math.max(Number(rec.bestRemainingMs||0),remainingMs);if(clean)rec.bestCleanScore=Math.max(Number(rec.bestCleanScore||0),score);rec.totalWrongFinds=Number(rec.totalWrongFinds||0)+run.wrongFinds;rec.totalListens=Number(rec.totalListens||0)+run.listens;rec.totalRoomsVisited=Number(rec.totalRoomsVisited||0)+run.visitedRooms.length;if(run.dreamEvent)rec.dreamSparklesSeen=Number(rec.dreamSparklesSeen||0)+1;if(run.dreamFound)rec.dreamSparklesFound=Number(rec.dreamSparklesFound||0)+1;if(run.dreamFound&&!prize.pending)rec.dreamPrizes=Number(rec.dreamPrizes||0)+1;
    const award=p.awardRun?.({gameId:'pokemonSeek',label:'Pokémon Seek',score,coins:reward})||{coinsAwarded:reward};root.save?.();finalResult={found,score,remainingMs,itemFound:run.itemFound,dreamFound:run.dreamFound,wrongFinds:run.wrongFinds,listens:run.listens,reward:award.coinsAwarded||0,prize:prize.label||''};phase='finished';if(completionHandled)return finalResult;completionHandled=true;
    const title=found?(clean?'FOUND WITHOUT A WRONG TURN!':'POKÉMON FOUND!'):'TIME UP!';const stats=[{label:'Pokémon',value:run.target.label},{label:'Time Left',value:found?`${(remainingMs/1000).toFixed(1)}s`:'0.0s'},{label:'Rooms Visited',value:String(run.visitedRooms.length)},{label:'Wrong Pokémon',value:String(run.wrongFinds)},{label:'Listen Uses',value:String(run.listens)},{label:'Lost Item',value:run.itemFound?'FOUND · +5,000':'MISSED'},{label:'Dream Sparkle',value:run.dreamFound?(prize.pending?'FOUND · PRIZE RESERVED':`FOUND · ${prize.label}`):run.dreamEvent?'MISSED':'—'}];
    const review={title,mode:'Dream World · Pokémon Seek',difficulty:profile().label,metricLabel:'SCORE',metricValue:score.toLocaleString('en-GB'),stats,pbs:[{label:`${profile().label} Score`,value:Number(rec.bestScores[difficulty]||0).toLocaleString('en-GB'),isNew:score>prevScore},{label:'Best Time Left',value:`${(Number(rec.bestRemainingMs||0)/1000).toFixed(1)}s`,isNew:found&&remainingMs>prevRemain},{label:'Clean Find Score',value:Number(rec.bestCleanScore||0).toLocaleString('en-GB'),isNew:clean&&score>prevWrong}],rewards:[{label:'Lucky Coins',value:String(award.coinsAwarded||0)},...(prize.label?[{label:'Dream Sparkle',value:prize.label}]:[])]};
    session()?.showResult?.('pokemonSeek',{title,metricLabel:'SCORE',metricValue:score.toLocaleString('en-GB'),coinsAwarded:award.coinsAwarded,bestText:prize.pending?'DREAM PRIZE RESERVED':prize.label?`DREAM SPARKLE · ${prize.label}`:`BEST ${rec.bestScore.toLocaleString('en-GB')}`,rewardReveals:prize.reveal?[prize.reveal]:[],review,replayLabel:'SEARCH AGAIN',onReplay:()=>showReady(difficulty),onBack:()=>root.LuckyDexArcadeWorld?.backFromGame?.()});return finalResult;
  }
  function open(){opened=true;session()?.mount?.('pokemonSeek',$('pokemonSeekGame'));showReady(difficulty);return true;}
  function close(){opened=false;stopLoop();clearRevealTimer();phase='closed';run=null;completionHandled=false;finalResult=null;const pause=$('pokemonSeekPauseOverlay');if(pause)pause.hidden=true;hideReveal();return true;}
  function keydown(e){if(phase!=='running')return;const key=String(e?.key||'').toLowerCase(),map={arrowleft:'left',arrowright:'right',arrowup:'up',arrowdown:'down'};if(map[key]){e.preventDefault?.();move(map[key]);}else if(key==='l'){e.preventDefault?.();listen();}}
  function wire(){if(typeof document==='undefined')return;$('pokemonSeekStart')?.addEventListener?.('click',startRun);$('pokemonSeekResume')?.addEventListener?.('click',resume);$('pokemonSeekListen')?.addEventListener?.('click',listen);$('pokemonSeekNorth')?.addEventListener?.('click',()=>move('up'));$('pokemonSeekSouth')?.addEventListener?.('click',()=>move('down'));$('pokemonSeekWest')?.addEventListener?.('click',()=>move('left'));$('pokemonSeekEast')?.addEventListener?.('click',()=>move('right'));$('pokemonSeekLostItem')?.addEventListener?.('click',collectLostItem);$('pokemonSeekDreamSparkle')?.addEventListener?.('click',collectDreamSparkle);for(const btn of document.querySelectorAll?.('[data-pokemonseek-difficulty]')||[])btn.addEventListener?.('click',()=>selectDifficulty(btn.dataset.pokemonseekDifficulty));document.addEventListener?.('click',e=>{const spot=e.target.closest?.('[data-pokemonseek-spot]');if(spot)searchSpot(spot.dataset.pokemonseekSpot);});document.addEventListener?.('keydown',keydown,{capture:true});document.addEventListener?.('visibilitychange',()=>{if(document.hidden&&opened)pause();});root.addEventListener?.('pagehide',()=>{if(opened)pause();});}
  function snapshot(){return {phase,difficulty,run:core.snapshot(run),finalResult:finalResult?JSON.parse(JSON.stringify(finalResult)):null};}
  wire();return {open,close,showReady,startRun,selectDifficulty,move,listen,searchSpot,collectLostItem,collectDreamSparkle,pause,resume,finishRun,snapshot,_setRng:fn=>{if(typeof fn==='function')rng=fn;}};
});
