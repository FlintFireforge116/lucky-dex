/* LuckyDex v0.16.6 — Fossil Excavation, Ditto Shuffle, Who's That Pokémon? */
let fossilGameV166=null,dittoGameV166=null,quizGameV166=null,quizTimerV166=null,quizDifficultyV166='normal';

const FOSSILS_V166=[
 {fossil:'Helix Fossil',pokemon:'Omanyte',id:138,shape:[[0,1],[0,2],[1,0],[1,1],[1,2],[2,0],[2,1],[3,1]]},
 {fossil:'Dome Fossil',pokemon:'Kabuto',id:140,shape:[[0,1],[0,2],[1,0],[1,1],[1,2],[1,3],[2,0],[2,1],[2,2],[2,3]]},
 {fossil:'Old Amber',pokemon:'Aerodactyl',id:142,shape:[[0,0],[0,2],[1,0],[1,1],[1,2],[2,1],[3,0],[3,2]]},
 {fossil:'Root Fossil',pokemon:'Lileep',id:345,shape:[[0,1],[1,0],[1,1],[1,2],[2,1],[3,0],[3,1],[3,2]]},
 {fossil:'Claw Fossil',pokemon:'Anorith',id:347,shape:[[0,0],[0,2],[1,0],[1,2],[2,0],[2,1],[2,2],[3,1]]},
 {fossil:'Skull Fossil',pokemon:'Cranidos',id:408,shape:[[0,1],[0,2],[1,0],[1,1],[1,2],[2,0],[2,1],[3,1]]},
 {fossil:'Armor Fossil',pokemon:'Shieldon',id:410,shape:[[0,1],[0,2],[1,0],[1,1],[1,2],[1,3],[2,0],[2,1],[2,2],[2,3],[3,1],[3,2]]},
 {fossil:'Cover Fossil',pokemon:'Tirtouga',id:564,shape:[[0,1],[0,2],[1,0],[1,1],[1,2],[1,3],[2,0],[2,1],[2,2],[2,3]]},
 {fossil:'Plume Fossil',pokemon:'Archen',id:566,shape:[[0,0],[0,3],[1,1],[1,2],[2,1],[2,2],[3,0],[3,3]]},
 {fossil:'Jaw Fossil',pokemon:'Tyrunt',id:696,shape:[[0,0],[0,1],[0,2],[1,0],[1,2],[2,0],[2,1],[3,1]]},
 {fossil:'Sail Fossil',pokemon:'Amaura',id:698,shape:[[0,1],[1,0],[1,1],[2,0],[2,1],[2,2],[3,1],[3,2]]}
];

const QUIZ_FALLBACK_V166=[
 [1,'bulbasaur'],[4,'charmander'],[7,'squirtle'],[12,'butterfree'],[25,'pikachu'],[26,'raichu'],[35,'clefairy'],[37,'vulpix'],[39,'jigglypuff'],[52,'meowth'],
 [54,'psyduck'],[58,'growlithe'],[63,'abra'],[66,'machop'],[74,'geodude'],[77,'ponyta'],[81,'magnemite'],[92,'gastly'],[94,'gengar'],[95,'onix'],
 [100,'voltorb'],[104,'cubone'],[113,'chansey'],[122,'mr-mime'],[129,'magikarp'],[130,'gyarados'],[131,'lapras'],[132,'ditto'],[133,'eevee'],[137,'porygon'],
 [138,'omanyte'],[140,'kabuto'],[142,'aerodactyl'],[143,'snorlax'],[147,'dratini'],[149,'dragonite'],[150,'mewtwo'],[151,'mew'],[155,'cyndaquil'],[158,'totodile'],
 [172,'pichu'],[175,'togepi'],[196,'espeon'],[197,'umbreon'],[202,'wobbuffet'],[212,'scizor'],[214,'heracross'],[225,'delibird'],[246,'larvitar'],[248,'tyranitar'],
 [252,'treecko'],[255,'torchic'],[258,'mudkip'],[280,'ralts'],[282,'gardevoir'],[302,'sableye'],[303,'mawile'],[304,'aron'],[328,'trapinch'],[333,'swablu'],
 [359,'absol'],[371,'bagon'],[374,'beldum'],[376,'metagross'],[387,'turtwig'],[390,'chimchar'],[393,'piplup'],[403,'shinx'],[408,'cranidos'],[410,'shieldon'],
 [425,'drifloon'],[443,'gible'],[447,'riolu'],[448,'lucario'],[479,'rotom'],[495,'snivy'],[498,'tepig'],[501,'oshawott'],[570,'zorua'],[571,'zoroark'],
 [607,'litwick'],[610,'axew'],[633,'deino'],[650,'chespin'],[653,'fennekin'],[656,'froakie'],[700,'sylveon'],[704,'goomy'],[722,'rowlet'],[725,'litten'],
 [728,'popplio'],[778,'mimikyu'],[810,'grookey'],[813,'scorbunny'],[816,'sobble'],[848,'toxel'],[906,'sprigatito'],[909,'fuecoco'],[912,'quaxly'],[926,'fidough'],
 [957,'tinkatink'],[996,'frigibax']
].map(([id,name])=>({id,name}));

const sleepV166=ms=>new Promise(r=>setTimeout(r,ms));
function shuffleV166(arr){const out=[...arr];for(let i=out.length-1;i>0;i--){const j=Math.floor(Math.random()*(i+1));[out[i],out[j]]=[out[j],out[i]];}return out;}
function titlePokemonV166(name){return titleCase(String(name||'').replace(/-/g,' '));}
function resultV166(label,icon,title,copy,button,action){
  const el=ensureArcadeResultV5();const eyebrow=el.querySelector('.eyebrow');if(eyebrow)eyebrow.textContent=label;
  showArcadeResultV5(icon,title,copy,button,action);
}
function ensureArcadeProgressV166(){
  state.arcade ||= {};
  const defaults={bestFossil:0,fossilsFound:0,bestDitto:0,bestQuiz:0,quizPerfect:0};
  let changed=false;for(const [k,v] of Object.entries(defaults)){if(state.arcade[k]==null){state.arcade[k]=v;changed=true;}}
  if(changed)save();
  if(!ACHIEVEMENTS.some(a=>a.id==='fossil_five'))ACHIEVEMENTS.push(
    {id:'fossil_five',icon:'🦴',name:'Underground Archaeologist',desc:'Restore 5 fossils in Fossil Excavation.',reward:{coins:900,tickets:1},progress:()=>[Number(state.arcade.fossilsFound||0),5]},
    {id:'ditto_six',icon:'🧬',name:'No Fooling Me',desc:'Reach Round 6 in Ditto Transform.',reward:{coins:850},progress:()=>[Number(state.arcade.bestDitto||0),6]},
    {id:'quiz_perfect',icon:'❓',name:'Pokédex Savant',desc:"Score a perfect 10/10 in Who's That Pokémon?",reward:{coins:1200,tickets:1},progress:()=>[Number(state.arcade.quizPerfect||0),1]}
  );
}
function stopFossilV166(){if(fossilGameV166)fossilGameV166.closed=true;}
function stopDittoV166(){if(dittoGameV166)dittoGameV166.token=(dittoGameV166.token||0)+1;}
function stopQuizV166(){if(quizTimerV166){clearInterval(quizTimerV166);quizTimerV166=null;}if(quizGameV166)quizGameV166.token=(quizGameV166.token||0)+1;}

openArcadeGame=function(name){
  if(name!=='clefairy'&&typeof stopClefairyGame==='function')stopClefairyGame();stopFossilV166();stopDittoV166();stopQuizV166();
  ['voltorb','clefairy','berry','fossil','ditto','quiz'].forEach(g=>{const el=document.getElementById(`${g}Game`);if(el)el.hidden=g!==name;});
  document.body.classList.add('arcade-open');window.Android?.setImmersive?.(true);
  if(name==='voltorb')newVoltorbBoard();if(name==='clefairy')resetMemoryGame();if(name==='berry')resetBerryGame();
  if(name==='fossil')resetFossilGameV166();if(name==='ditto')resetDittoGameV166();if(name==='quiz')resetQuizGameV166();renderArcadeHelper();
};
closeArcadeGame=function(force=false){
  const atRisk=(voltorb&&!voltorb.busted&&voltorb.revealed>0&&voltorb.bank>1)||(memoryGame&&memoryGame.bank>0)||(dittoGameV166&&dittoGameV166.bank>0&&!dittoGameV166.failed);
  if(atRisk&&!force&&!confirm('Leave the minigame? Any unbanked reward will be lost.'))return;
  stopClefairyGame();if(berryRaf)cancelAnimationFrame(berryRaf);if(berryGame)berryGame.running=false;stopFossilV166();stopDittoV166();stopQuizV166();
  ['voltorb','clefairy','berry','fossil','ditto','quiz'].forEach(g=>{const el=document.getElementById(`${g}Game`);if(el)el.hidden=true;});
  document.body.classList.remove('arcade-open');window.Android?.setImmersive?.(false);voltorb=null;memoryGame=null;fossilGameV166=null;dittoGameV166=null;quizGameV166=null;renderArcadeHelper();
};

/* Fossil Excavation */
function fossilBoundsV166(shape){return{w:Math.max(...shape.map(p=>p[1]))+1,h:Math.max(...shape.map(p=>p[0]))+1};}
function resetFossilGameV166(){
  const rows=6,cols=7,fossil=FOSSILS_V166[Math.floor(Math.random()*FOSSILS_V166.length)],b=fossilBoundsV166(fossil.shape);
  const ox=Math.floor(Math.random()*(cols-b.w+1)),oy=Math.floor(Math.random()*(rows-b.h+1));
  const fossilCells=new Set(fossil.shape.map(([r,c])=>(oy+r)*cols+(ox+c))),free=shuffleV166(Array.from({length:rows*cols},(_,i)=>i).filter(i=>!fossilCells.has(i)));
  fossilGameV166={rows,cols,fossil,fossilCells,treasureCells:new Set(free.slice(0,3)),hardness:Array.from({length:rows*cols},(_,i)=>fossilCells.has(i)?1+Math.floor(Math.random()*2):1+Math.floor(Math.random()*3)),revealed:new Set(),tool:'chisel',tools:24,treasures:0,complete:false,closed:false};
  document.getElementById('fossilStatus').textContent='Fresh dig site';document.getElementById('fossilRevealName').textContent='Unknown Fossil';document.getElementById('fossilRevealCopy').textContent='Excavate every fossil fragment before your tools run out.';
  document.getElementById('fossilReveal').classList.remove('complete');document.getElementById('fossilRevealSprite').src=API.sprite(fossil.id);document.getElementById('fossilRevealSprite').alt=fossil.pokemon;
  document.getElementById('fossilFoundCount').textContent=fmt(state.arcade.fossilsFound||0);document.getElementById('fossilBest').textContent=fmt(state.arcade.bestFossil||0);setFossilToolV166('chisel');renderFossilV166();
}
function setFossilToolV166(tool){if(!fossilGameV166)return;fossilGameV166.tool=tool;document.getElementById('fossilChiselBtn').classList.toggle('active',tool==='chisel');document.getElementById('fossilHammerBtn').classList.toggle('active',tool==='hammer');}
function fossilNearV166(index){const g=fossilGameV166,r=Math.floor(index/g.cols),c=index%g.cols;for(const fi of g.fossilCells){const fr=Math.floor(fi/g.cols),fc=fi%g.cols;if(Math.abs(fr-r)+Math.abs(fc-c)<=1)return true;}return false;}
function renderFossilV166(){
  const g=fossilGameV166;if(!g)return;document.getElementById('fossilTools').textContent=g.tools;
  const grid=document.getElementById('fossilGrid');grid.innerHTML=Array.from({length:g.rows*g.cols},(_,i)=>{const open=g.revealed.has(i),hard=g.hardness[i],fossil=g.fossilCells.has(i),treasure=g.treasureCells.has(i);const cls=['fossil-cell',open?'open':'',!open&&hard===1?'cracked':'',!open&&fossilNearV166(i)?'warm':'',open&&fossil?'fossil':'',open&&treasure?'treasure':''].filter(Boolean).join(' ');return`<button class="${cls}" data-fossil-cell="${i}" ${g.complete||g.tools<=0?'disabled':''} aria-label="Excavate rock"></button>`;}).join('');
  grid.querySelectorAll('[data-fossil-cell]').forEach(b=>b.onclick=()=>digFossilV166(Number(b.dataset.fossilCell)));
}
function digFossilV166(index){
  const g=fossilGameV166;if(!g||g.complete||g.tools<=0||g.closed)return;const cost=g.tool==='hammer'?2:1;if(g.tools<cost){showToast('Not enough tools for the hammer.');return;}
  const r=Math.floor(index/g.cols),c=index%g.cols,offsets=g.tool==='hammer'?[[0,0],[-1,0],[1,0],[0,-1],[0,1]]:[[0,0]];g.tools-=cost;let newly=0;
  for(const [dr,dc] of offsets){const rr=r+dr,cc=c+dc;if(rr<0||rr>=g.rows||cc<0||cc>=g.cols)continue;const i=rr*g.cols+cc;if(g.revealed.has(i))continue;g.hardness[i]-=g.tool==='hammer'?1:2;if(g.hardness[i]<=0){g.revealed.add(i);newly++;if(g.treasureCells.has(i)){g.treasures++;vibrate([8,18,22]);}}}
  if(newly)vibrate(g.tool==='hammer'?[12,20,16]:8);const found=[...g.fossilCells].filter(i=>g.revealed.has(i)).length;document.getElementById('fossilStatus').textContent=`Fossil fragments ${found}/${g.fossilCells.size}`;renderFossilV166();
  if(found===g.fossilCells.size)completeFossilV166();else if(g.tools<=0)failFossilV166();
}
function completeFossilV166(){
  const g=fossilGameV166;if(!g||g.complete)return;g.complete=true;const payout=420+g.fossilCells.size*32+g.tools*18+g.treasures*75;
  state.arcade.fossilsFound=Number(state.arcade.fossilsFound||0)+1;state.arcade.bestFossil=Math.max(Number(state.arcade.bestFossil||0),payout);save();
  document.getElementById('fossilReveal').classList.add('complete');document.getElementById('fossilRevealName').textContent=`${g.fossil.fossil} · ${g.fossil.pokemon}`;document.getElementById('fossilRevealCopy').textContent=`Restoration complete! ${g.treasures} mineral sparkles recovered.`;document.getElementById('fossilFoundCount').textContent=fmt(state.arcade.fossilsFound);document.getElementById('fossilBest').textContent=fmt(state.arcade.bestFossil);renderFossilV166();
  const awarded=awardArcadeCoins(payout,`${g.fossil.fossil} restored`,'fossil');window.LuckyDexArcadeSession?.showResult?.('fossil',{title:'FOSSIL RESTORED!',metricLabel:'RESTORED',metricValue:`${g.fossil.fossil} · ${g.fossil.pokemon}`,coinsAwarded:awarded,itemAwarded:null,bestText:g.treasures?`${g.treasures} mineral find${g.treasures===1?'':'s'}`:'',onReplay:resetFossilGameV166,onBack:()=>window.LuckyDexArcadeWorld?.backFromGame?.(true)});
}
function failFossilV166(){const g=fossilGameV166;if(!g||g.complete)return;g.complete=true;const salvage=Math.max(40,g.treasures*45);renderFossilV166();const awarded=awardArcadeCoins(salvage,'Dig-site salvage','fossil');window.LuckyDexArcadeSession?.showResult?.('fossil',{title:'TOOLS DEPLETED',metricLabel:'SALVAGE',metricValue:`${g.treasures} mineral find${g.treasures===1?'':'s'}`,coinsAwarded:awarded,itemAwarded:null,bestText:'',onReplay:resetFossilGameV166,onBack:()=>window.LuckyDexArcadeWorld?.backFromGame?.(true)});}

/* Ditto Shuffle */
const DITTO_DECOYS_V166=[{id:137,name:'Porygon'},{id:81,name:'Magnemite'},{id:88,name:'Grimer'},{id:109,name:'Koffing'},{id:100,name:'Voltorb'},{id:133,name:'Eevee'},{id:35,name:'Clefairy'},{id:479,name:'Rotom'}];
function resetDittoGameV166(){stopDittoV166();dittoGameV166={round:0,bank:0,selecting:false,failed:false,pods:[],token:1};document.getElementById('dittoRound').textContent='0';document.getElementById('dittoBank').textContent='0';document.getElementById('dittoBest').textContent=fmt(state.arcade.bestDitto||0);document.getElementById('dittoMessage').textContent="Press START TEST when you're ready.";document.getElementById('dittoTrack').innerHTML='<div class="ditto-idle-mark">🧬</div>';const s=document.getElementById('dittoStartBtn');s.disabled=false;s.textContent='START TEST';document.getElementById('dittoCashBtn').disabled=true;}
function renderDittoPodsV166(reveal=true){const g=dittoGameV166,track=document.getElementById('dittoTrack');if(!g)return;track.innerHTML=g.pods.map(p=>`<button class="ditto-pod ${reveal?'':'covered'}" data-ditto-pod="${p.id}" aria-label="Research capsule"><div class="pod-shell"><img src="${API.sprite(p.pokemon.id)}" alt="${escapeHtml(p.pokemon.name)}"><div class="pod-shutter"></div></div></button>`).join('');track.querySelectorAll('[data-ditto-pod]').forEach(b=>b.onclick=()=>chooseDittoPodV166(Number(b.dataset.dittoPod)));requestAnimationFrame(layoutDittoPodsV166);}
function layoutDittoPodsV166(){const g=dittoGameV166,track=document.getElementById('dittoTrack');if(!g||!track)return;const gap=7,n=g.pods.length,total=Math.max(240,track.clientWidth),w=Math.min(88,Math.max(52,(total-gap*(n-1)-8)/n)),used=n*w+(n-1)*gap,start=Math.max(4,(total-used)/2);track.querySelectorAll('.ditto-pod').forEach(el=>{const p=g.pods.find(x=>x.id===Number(el.dataset.dittoPod));if(p){el.style.width=`${w}px`;el.style.transform=`translateX(${start+p.pos*(w+gap)}px)`;}});}
async function startDittoRoundV166(){
 const g=dittoGameV166;if(!g||g.selecting)return;const token=++g.token;g.round++;g.failed=false;const count=g.round<=2?3:g.round<=4?4:5,swaps=Math.min(12,3+g.round*2),speed=Math.max(150,390-g.round*28),mixed=shuffleV166([{id:132,name:'Ditto'},...shuffleV166(DITTO_DECOYS_V166).slice(0,count-1)]);
 g.pods=mixed.map((p,i)=>({id:i+1,pos:i,pokemon:p,target:p.id===132}));g.selecting=false;document.getElementById('dittoRound').textContent=g.round;document.getElementById('dittoMessage').textContent='Memorise Ditto!';document.getElementById('dittoStartBtn').disabled=true;document.getElementById('dittoCashBtn').disabled=true;renderDittoPodsV166(true);await sleepV166(1250);if(!dittoGameV166||token!==g.token)return;
 document.querySelectorAll('#dittoTrack .ditto-pod').forEach(el=>el.classList.add('covered'));document.getElementById('dittoMessage').textContent='Tracking capsules…';await sleepV166(380);let last='';
 for(let s=0;s<swaps;s++){if(!dittoGameV166||token!==g.token)return;let a,b,pair;do{a=Math.floor(Math.random()*count);b=Math.floor(Math.random()*count);pair=[Math.min(a,b),Math.max(a,b)].join('-');}while(a===b||pair===last);last=pair;const pa=g.pods.find(p=>p.pos===a),pb=g.pods.find(p=>p.pos===b);pa.pos=b;pb.pos=a;const ea=document.querySelector(`[data-ditto-pod="${pa.id}"]`),eb=document.querySelector(`[data-ditto-pod="${pb.id}"]`);ea?.classList.add('swapping');eb?.classList.add('swapping');layoutDittoPodsV166();await sleepV166(speed);ea?.classList.remove('swapping');eb?.classList.remove('swapping');}
 if(!dittoGameV166||token!==g.token)return;g.selecting=true;document.getElementById('dittoMessage').textContent='Which capsule is hiding Ditto?';
}
function chooseDittoPodV166(id){
 const g=dittoGameV166;if(!g||!g.selecting)return;g.selecting=false;const chosen=g.pods.find(p=>p.id===id),target=g.pods.find(p=>p.target);document.querySelectorAll('#dittoTrack .ditto-pod').forEach(el=>{el.classList.remove('covered');const p=g.pods.find(x=>x.id===Number(el.dataset.dittoPod));if(p?.target)el.classList.add('correct');else if(Number(el.dataset.dittoPod)===id)el.classList.add('wrong');});
 if(chosen?.target){const gain=110+g.round*90+g.pods.length*25;g.bank+=gain;state.arcade.bestDitto=Math.max(Number(state.arcade.bestDitto||0),g.round);save();document.getElementById('dittoBank').textContent=fmt(g.bank);document.getElementById('dittoBest').textContent=fmt(state.arcade.bestDitto);document.getElementById('dittoMessage').textContent=`Correct! Ditto found · +${fmt(gain)} added to the run bank.`;const s=document.getElementById('dittoStartBtn');s.disabled=false;s.textContent='NEXT ROUND';document.getElementById('dittoCashBtn').disabled=false;vibrate([14,18,30]);}
 else{const lost=g.bank;g.bank=0;g.failed=true;state.stats.arcadeGames=Number(state.stats.arcadeGames||0)+1;save();vibrate([28,28,55]);document.getElementById('dittoBank').textContent='0';document.getElementById('dittoMessage').textContent=`Wrong capsule — Ditto was in position ${target.pos+1}.`;resultV166('DITTO SHUFFLE','🧬','DITTO GOT AWAY!',lost?`The lab fooled you and your ${fmt(lost)}-coin run bank was lost.`:'The Transform Pokémon slipped away.','NEW TEST',resetDittoGameV166);}
}
function cashDittoV166(){const g=dittoGameV166;if(!g||g.bank<=0||g.selecting)return;const payout=g.bank;g.bank=0;awardArcadeCoins(payout,'Ditto Shuffle','ditto');resultV166('DITTO SHUFFLE','🧬','RESEARCH COMPLETE',`You safely banked ${fmt(payout)} Lucky Coins after reaching Round ${g.round}.`,'NEW TEST',resetDittoGameV166);}

/* Who's That Pokémon? */
function quizPoolV166(){const live=(species||[]).filter(s=>Number(s.id)>0&&Number(s.id)<=MAX_DEX_ID&&s.name&&!/^pokemon-\d+$/i.test(s.name)),map=new Map(QUIZ_FALLBACK_V166.map(x=>[x.id,x]));for(const x of live)map.set(Number(x.id),{id:Number(x.id),name:x.name});let pool=[...map.values()];if(quizDifficultyV166==='easy')pool=pool.filter(x=>x.id<=251);return pool;}
function generationForIdV166(id){return GENERATIONS.find(g=>id>=g.min&&id<=g.max)||GENERATIONS[GENERATIONS.length-1];}
function resetQuizGameV166(){stopQuizV166();quizGameV166={round:0,score:0,streak:0,correct:0,active:false,token:1,current:null};document.getElementById('quizRound').textContent='0';document.getElementById('quizScore').textContent='0';document.getElementById('quizStreak').textContent='0';document.getElementById('quizBest').textContent=fmt(state.arcade.bestQuiz||0);document.getElementById('quizPrompt').textContent="WHO'S THAT POKÉMON?";document.getElementById('quizHint').textContent='Choose a difficulty, then start the quiz.';document.getElementById('quizSprite').removeAttribute('src');document.querySelector('.quiz-silhouette-wrap')?.classList.remove('reveal','hard');document.getElementById('quizAnswers').innerHTML='';document.getElementById('quizTimerFill').style.width='0%';const b=document.getElementById('quizStartBtn');b.hidden=false;b.disabled=false;b.textContent='START QUIZ';}
function setQuizDifficultyV166(mode){if(quizGameV166?.active)return;quizDifficultyV166=mode;document.querySelectorAll('[data-quiz-difficulty]').forEach(b=>b.classList.toggle('active',b.dataset.quizDifficulty===mode));const h=document.getElementById('quizHint');if(h)h.textContent={easy:'Kanto + Johto · 12 seconds',normal:'All regions · 9 seconds',hard:'All regions · mirrored silhouette · 6 seconds'}[mode];}
function startQuizV166(){stopQuizV166();quizGameV166={round:0,score:0,streak:0,correct:0,active:true,token:2,current:null};document.getElementById('quizStartBtn').hidden=true;nextQuizQuestionV166();}
function quizOptionsV166(correct,pool,count){const gen=generationForIdV166(correct.id),same=shuffleV166(pool.filter(x=>x.id!==correct.id&&generationForIdV166(x.id).id===gen.id)),rest=shuffleV166(pool.filter(x=>x.id!==correct.id&&!same.some(s=>s.id===x.id)));return shuffleV166([correct,...same,...rest].slice(0,count));}
function nextQuizQuestionV166(){
 const g=quizGameV166;if(!g||!g.active)return;if(g.round>=10){finishQuizV166();return;}const pool=quizPoolV166();if(pool.length<10){showToast('Pokédex data is still loading. Try again in a moment.');resetQuizGameV166();return;}
 g.round++;const correct=pool[Math.floor(Math.random()*pool.length)],count=quizDifficultyV166==='hard'?5:4,opts=quizOptionsV166(correct,pool,count),duration={easy:12000,normal:9000,hard:6000}[quizDifficultyV166];g.current={correct,answered:false,duration,started:performance.now()};const token=g.token;
 document.getElementById('quizRound').textContent=g.round;document.getElementById('quizPrompt').textContent="WHO'S THAT POKÉMON?";const gen=generationForIdV166(correct.id);document.getElementById('quizHint').textContent=quizDifficultyV166==='hard'?'No hints · trust your Pokédex instincts':quizDifficultyV166==='easy'?`${gen.name} Pokémon`:`Generation ${gen.id} · ${gen.name}`;
 const wrap=document.querySelector('.quiz-silhouette-wrap');wrap.classList.remove('reveal','hard');if(quizDifficultyV166==='hard')wrap.classList.add('hard');const img=document.getElementById('quizSprite');img.src=API.sprite(correct.id);img.alt='Mystery Pokémon';
 const answers=document.getElementById('quizAnswers');answers.innerHTML=opts.map(x=>`<button data-quiz-answer="${x.id}">${escapeHtml(titlePokemonV166(x.name))}</button>`).join('');answers.querySelectorAll('[data-quiz-answer]').forEach(b=>b.onclick=()=>answerQuizV166(Number(b.dataset.quizAnswer)));
 if(quizTimerV166)clearInterval(quizTimerV166);const fill=document.getElementById('quizTimerFill');fill.style.width='100%';quizTimerV166=setInterval(()=>{if(!quizGameV166||token!==quizGameV166.token||!g.current||g.current.answered){clearInterval(quizTimerV166);quizTimerV166=null;return;}const remaining=Math.max(0,1-(performance.now()-g.current.started)/duration);fill.style.width=`${remaining*100}%`;if(remaining<=0)answerQuizV166(null);},100);
}
function answerQuizV166(id){
 const g=quizGameV166,q=g?.current;if(!g||!q||q.answered)return;q.answered=true;if(quizTimerV166){clearInterval(quizTimerV166);quizTimerV166=null;}const correct=id===q.correct.id,remaining=Math.max(0,1-(performance.now()-q.started)/q.duration),wrap=document.querySelector('.quiz-silhouette-wrap');wrap.classList.add('reveal');wrap.classList.remove('hard');
 document.getElementById('quizPrompt').textContent=correct?`${titlePokemonV166(q.correct.name)}!`:`It's ${titlePokemonV166(q.correct.name)}!`;document.getElementById('quizHint').textContent=correct?'Correct!':'That one caught you out.';document.querySelectorAll('[data-quiz-answer]').forEach(b=>{b.disabled=true;if(Number(b.dataset.quizAnswer)===q.correct.id)b.classList.add('correct');else if(id!=null&&Number(b.dataset.quizAnswer)===id)b.classList.add('wrong');});
 if(correct){g.correct++;g.streak++;g.score+=Math.round(100+remaining*100+Math.min(100,g.streak*12));vibrate([10,14,20]);}else{g.streak=0;vibrate(22);}document.getElementById('quizScore').textContent=fmt(g.score);document.getElementById('quizStreak').textContent=g.streak;document.getElementById('quizTimerFill').style.width='0%';setTimeout(()=>{if(quizGameV166===g&&g.active)nextQuizQuestionV166();},900);
}
function finishQuizV166(){const g=quizGameV166;if(!g||!g.active)return;g.active=false;if(quizTimerV166){clearInterval(quizTimerV166);quizTimerV166=null;}const payout=Math.max(100,Math.round(g.score*({easy:.42,normal:.52,hard:.62}[quizDifficultyV166])+g.correct*20));state.arcade.bestQuiz=Math.max(Number(state.arcade.bestQuiz||0),g.score);if(g.correct===10)state.arcade.quizPerfect=1;save();document.getElementById('quizBest').textContent=fmt(state.arcade.bestQuiz);const awarded=awardArcadeCoins(payout,"Who's That Pokémon?",'quiz');window.LuckyDexArcadeSession?.showResult?.('quiz',{title:g.correct===10?'PERFECT 10/10!':`${g.correct}/10 CORRECT`,metricLabel:'SCORE',metricValue:fmt(g.score),coinsAwarded:awarded,itemAwarded:null,bestText:g.correct===10?'PERFECT RUN':'',onReplay:resetQuizGameV166,onBack:()=>window.LuckyDexArcadeWorld?.backFromGame?.(true)});}

function wireArcadeExpansionV166(){
 ensureArcadeProgressV166();document.querySelectorAll('[data-exit-game]').forEach(b=>b.onclick=()=>closeArcadeGame());
 document.getElementById('fossilChiselBtn').onclick=()=>setFossilToolV166('chisel');document.getElementById('fossilHammerBtn').onclick=()=>setFossilToolV166('hammer');document.getElementById('fossilNewBtn').onclick=resetFossilGameV166;
 document.getElementById('dittoStartBtn').onclick=startDittoRoundV166;document.getElementById('dittoCashBtn').onclick=cashDittoV166;
 document.querySelectorAll('[data-quiz-difficulty]').forEach(b=>b.onclick=()=>setQuizDifficultyV166(b.dataset.quizDifficulty));document.getElementById('quizStartBtn').onclick=startQuizV166;
 window.addEventListener('resize',()=>{if(dittoGameV166?.pods?.length)layoutDittoPodsV166();});setQuizDifficultyV166('normal');
}
wireArcadeExpansionV166();
