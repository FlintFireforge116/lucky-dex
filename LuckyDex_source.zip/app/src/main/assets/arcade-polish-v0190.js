(function(root){
'use strict';
function install(){if(typeof document==='undefined')return;
 const machine=document.querySelector('.ball-drop-machine');machine?.classList.add('cabinet-v019');
 const landing=document.getElementById('ballDropLanding');if(landing&&machine){const sync=()=>{const live=!landing.hidden;machine.classList.toggle('landing-live-v019',live);const txt=(document.getElementById('ballDropLandingTitle')?.textContent||'').toUpperCase();machine.classList.toggle('jackpot-live-v019',live&&txt.includes('JACKPOT'));};new MutationObserver(sync).observe(landing,{attributes:true,attributeFilter:['hidden']});new MutationObserver(sync).observe(document.getElementById('ballDropLandingTitle')||landing,{childList:true,subtree:true,characterData:true});sync();}
 const wrap=document.querySelector('.quiz-silhouette-wrap'),stage=document.querySelector('.quiz-stage');if(wrap&&stage){const syncQuiz=()=>{if(wrap.classList.contains('reveal')){stage.classList.remove('quiz-reveal-v019');void stage.offsetWidth;stage.classList.add('quiz-reveal-v019');}else stage.classList.remove('quiz-reveal-v019');};new MutationObserver(syncQuiz).observe(wrap,{attributes:true,attributeFilter:['class']});}
 document.querySelector('.unown-chamber')?.classList.add('ruins-chamber-v019');
}
if(typeof document!=='undefined')install();
const api={install};root.LuckyDexArcadePolishV0190=api;if(typeof module!=='undefined'&&module.exports)module.exports=api;
})(typeof window!=='undefined'?window:globalThis);
