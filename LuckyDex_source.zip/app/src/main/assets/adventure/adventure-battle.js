(function (root, factory) {
  'use strict';
  const api = factory();
  if (typeof module === 'object' && module.exports) module.exports = api;
  if (root) root.LuckyDexAdventureBattle = api;
})(typeof window !== 'undefined' ? window : null, function () {
  'use strict';
  const D=(typeof window!=='undefined'&&window.LuckyDexMoveData)||(typeof require==='function'?require('./adventure-move-data.js'):null);
  const P=(typeof window!=='undefined'&&window.LuckyDexProgression)||(typeof require==='function'?require('./adventure-progression.js'):null);
  const MOVES={normal:'Body Slam',fire:'Flame Burst',water:'Water Pulse',electric:'Spark',grass:'Razor Leaf',ice:'Icy Wind',fighting:'Brick Break',poison:'Poison Jab',ground:'Mud Shot',flying:'Air Slash',psychic:'Psybeam',bug:'Bug Bite',rock:'Rock Throw',ghost:'Shadow Sneak',dragon:'Dragon Breath',dark:'Bite',steel:'Metal Claw',fairy:'Draining Kiss'};
  const SUPER={fire:['grass','ice','bug','steel'],water:['fire','ground','rock'],electric:['water','flying'],grass:['water','ground','rock'],ice:['grass','ground','flying','dragon'],fighting:['normal','ice','rock','dark','steel'],poison:['grass','fairy'],ground:['fire','electric','poison','rock','steel'],flying:['grass','fighting','bug'],psychic:['fighting','poison'],bug:['grass','psychic','dark'],rock:['fire','ice','flying','bug'],ghost:['psychic','ghost'],dragon:['dragon'],dark:['psychic','ghost'],steel:['ice','rock','fairy'],fairy:['fighting','dragon','dark']};
  const WEAK={fire:['fire','water','rock','dragon'],water:['water','grass','dragon'],electric:['electric','grass','dragon'],grass:['fire','grass','poison','flying','bug','dragon','steel'],ice:['fire','water','ice','steel'],fighting:['poison','flying','psychic','bug','fairy'],poison:['poison','ground','rock','ghost'],ground:['grass','bug'],flying:['electric','rock','steel'],psychic:['psychic','steel'],bug:['fire','fighting','poison','flying','ghost','steel','fairy'],rock:['fighting','ground','steel'],ghost:['dark'],dragon:['steel'],dark:['fighting','dark','fairy'],steel:['fire','water','electric','steel'],fairy:['fire','poison','steel']};
  const IMMUNE={normal:['ghost'],electric:['ground'],fighting:['ghost'],poison:['steel'],ground:['flying'],psychic:['dark'],ghost:['normal'],dragon:['fairy']};
  const BALLS={pokeball:{name:'Poké Ball',mod:1},greatball:{name:'Great Ball',mod:1.5},ultraball:{name:'Ultra Ball',mod:2}};
  const ENEMY_TURN_DELAY=420, HIT_HOLD=260;
  const MYTHICAL=[151,251,385,386,489,490,491,492,493,494,647,648,649,719,720,721,801,802,807,808,809,893];
  const LEGENDARY=[144,145,146,150,151,243,244,245,249,250,251,377,378,379,380,381,382,383,384,385,386,480,481,482,483,484,485,486,487,488,489,490,491,492,493,494,638,639,640,641,642,643,644,645,646,647,648,649,716,717,718,719,720,721,772,773,785,786,787,788,789,790,791,792,800,801,802,807,808,809,888,889,890,891,892,893,894,895,896,897,898,905,1001,1002,1003,1004,1007,1008,1009,1010,1024,1025];
  const BOSSES={127:{id:'enrage',name:'Enrage',text:'Below 40% HP, Pinsir attacks 20% harder.'},142:{id:'swift',name:'Ancient speed',text:'Aerodactyl acts first on the opening turn.'},94:{id:'veil',name:'Ghostly veil',text:'The first incoming hit deals 40% less damage.'},131:{id:'tide',name:'Restorative tide',text:'Below half HP, Lapras restores 20% HP once.'},6:{id:'blaze',name:'Blazing field',text:'Fire attacks from either side deal 20% more damage.'}};
  const clone=value=>JSON.parse(JSON.stringify(value));
  const clamp=(n,min,max)=>Math.max(min,Math.min(max,n));
  const number=(n,fallback)=>Number.isFinite(Number(n))?Number(n):fallback;
  const esc=value=>String(value==null?'':value).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
  function seedValue(seed) { if(typeof seed==='number') return (seed>>>0)||0x9e3779b9;let h=2166136261;for(const c of String(seed==null?'adventure':seed)){h^=c.charCodeAt(0);h=Math.imul(h,16777619);}return h>>>0||1; }
  function random(fight) { let x=fight.rng>>>0;x^=x<<13;x^=x>>>17;x^=x<<5;fight.rng=x>>>0;return fight.rng/4294967296; }
  function stats(row) {
    const base=row.baseStats||{}, L=clamp(number(row.level,5),1,50);
    return {hp:Math.round(number(base.hp,60)*.55+L*4+18),attack:Math.round(number(base.attack,60)*.28+L*2.1+8),defense:Math.round(number(base.defense,60)*.28+L*2+8),speed:Math.round(number(base.speed,60)*.22+L*1.6+6)};
  }
  function build(row,index,full) {
    const p=clone(row), computed=stats(p);P.ensureOwned(p);p.pp=p.pp||Object.fromEntries(p.moves.map(id=>[id,D.moves[id].pp||10]));p.status=p.status||null;p.statusTurns=p.statusTurns||0;p.guard=Number(p.guard)||1;p.attackBoost=Number(p.attackBoost)||1;p.level=clamp(number(p.level,5),1,50);p.types=Array.isArray(p.types)&&p.types.length?p.types:['normal'];
    p.stats=computed;p.maxHp=Math.max(1,Math.round(number(p.maxHp,computed.hp)));p.hp=full?p.maxHp:clamp(number(p.hp,p.maxHp),0,p.maxHp);
    if(index!=null)p.key=p.key||`${p.id}:${p.shiny?'s':'n'}`;return p;
  }
  function create(party,enemy,opts) {
    opts=opts||{};const context=['expedition','regional'].includes(opts.context)?opts.context:'roam', members=(party||[]).map((p,i)=>build(p,i,context==='roam'));
    const foe=build(enemy,null,true), kind=opts.kind||'wild', modifier=kind==='boss'?BOSSES[opts.bossId||foe.id]:null;
    if(kind==='boss') {foe.maxHp=Math.round(foe.maxHp*1.3);foe.hp=foe.maxHp;}
    const rng=seedValue(opts.seed), lead=members.find(p=>p.key===opts.leadKey&&p.hp>0)||members.find(p=>p.hp>0);
    const fight={id:`fight-${context}-${opts.destination||'meadow'}-${rng}-${foe.id}`,context,kind,destination:opts.destination||'meadow',enemy:foe,party:members,leadKey:lead?lead.key:null,berryBoost:1,rng,turns:0,actionSeq:0,phase:'active',flags:{},bossModifier:modifier?clone(modifier):null,perks:Array.isArray(opts.perks)?opts.perks.slice():[],trainer:opts.trainer?clone(opts.trainer):null,result:null,lastAction:null};
    fight.realMoves=context==='regional'||(party||[]).some(p=>Array.isArray(p.moves));fight.enemyTeam=(opts.enemyTeam||[enemy]).map(p=>build(p,null,true));fight.enemyIndex=0;fight.strategy=opts.strategy||opts.trainer?.strategy||'pressure';if(!lead) terminal(fight,'loss');return fight;
  }
  function lead(fight) {return fight.party.find(p=>p.key===fight.leadKey);}
  function terminal(fight,kind,extra) {
    fight.phase='terminal';fight.result={kind,enemy:clone(fight.enemy),leadKey:fight.leadKey,...extra};return fight.result;
  }
  function effectiveness(type,types) {return types.reduce((v,t)=>v*((IMMUNE[type]||[]).includes(t)?0:(SUPER[type]||[]).includes(t)?2:(WEAK[type]||[]).includes(t)?.5:1),1);}
  function modifierEvent(action,text) {action.events.push({kind:'modifier',text,target:'enemy'});}
  function hit(fight,action,attacker,defender,type,power,target,multiplier) {
    if(fight.context==='regional'&&target==='player')multiplier=(multiplier||1)*.60;
    const eff=effectiveness(type,defender.types), variance=.86+random(fight)*.22;
    let mod=multiplier||1;
    if(fight.bossModifier?.id==='blaze'&&type==='fire')mod*=1.2;
    if(target==='enemy'&&fight.bossModifier?.id==='veil'&&!fight.flags.veilUsed) {mod*=.6;fight.flags.veilUsed=true;modifierEvent(action,'Gengar’s veil softens the first hit.');}
    const damage=eff===0?0:Math.max(1,Math.round(power*(attacker.stats.attack/Math.max(1,defender.stats.defense))*.44*variance*eff*mod*(attacker.attackBoost||1)/Math.max(.75,defender.guard||1)));
    const before=defender.hp;defender.hp=Math.max(0,defender.hp-damage);
    const text=eff===0?'It has no effect.':eff>1?'Super effective!':eff<1?'Not very effective.':`${defender.name} takes ${damage} damage.`;
    const event={kind:'hit',target,source:target==='enemy'?'player':'enemy',key:defender.key||null,name:defender.name,type,damage,eff,beforeHp:before,hp:defender.hp,maxHp:defender.maxHp,fainted:defender.hp===0,text};
    action.events.push(event);return event;
  }
  function readyMoves(p){return p.moves.filter(id=>(Number(p.pp?.[id])||0)>0&&D.moves[id]);}
  function canStruggle(p){return !readyMoves(p).some(id=>D.moves[id].damageClass!=='status');}
  function resolveMove(fight,p,command,args){if(args?.moveId)return Number(args.moveId);if(command==='quick')return p.moves[0];const damage=readyMoves(p).filter(id=>D.moves[id].damageClass!=='status');return damage.sort((a,b)=>(D.moves[b].power||40)-(D.moves[a].power||40))[0]||p.moves[0];}
  function migrateFight(fight){if(!fight)return fight;for(const p of [...fight.party,fight.enemy]){P.ensureOwned(p);p.pp=p.pp||Object.fromEntries(p.moves.map(id=>[id,D.moves[id].pp||10]));p.guard=p.guard||1;p.attackBoost=p.attackBoost||1}fight.enemyTeam=fight.enemyTeam||[clone(fight.enemy)];fight.enemyIndex=fight.enemyIndex||0;fight.realMoves=true;return fight;}
  function useMove(fight,action,attacker,defender,id,target,multiplier=1){
    const move=D.moves[id],own=target==='enemy'?'player':'enemy';if(id!==165)attacker.pp[id]=Math.max(0,attacker.pp[id]-1);
    if(attacker.status==='paralysis'&&random(fight)<.18){action.events.push({kind:'miss',target:own,text:`${attacker.name} is paralyzed.`});return {damage:0,eff:1};}
    if(attacker.status==='sleep'&&attacker.statusTurns>0){attacker.statusTurns--;if(!attacker.statusTurns)attacker.status=null;action.events.push({kind:'miss',target:own,text:`${attacker.name} is drowsy.`});return {damage:0,eff:1};}
    if(move.accuracy!=null&&random(fight)>move.accuracy/100){action.events.push({kind:'miss',target,text:move.name+' missed!'});return {damage:0,eff:1};}
    let event={damage:0,eff:1};
    if(move.damageClass!=='status'){
      const type=id===165?'typeless':move.type,power=Math.min(95,move.power||40),stab=attacker.types.includes(move.type)?1.1:1;
      event=hit(fight,action,attacker,defender,type,power,target,multiplier*stab);event.moveName=move.name;
      if(move.effect?.drain>0){const before=attacker.hp;attacker.hp=Math.min(attacker.maxHp,attacker.hp+Math.round(event.damage*move.effect.drain/100));action.events.push({kind:'heal',target:own,hp:attacker.hp,maxHp:attacker.maxHp,heal:attacker.hp-before,text:move.name+' restores HP.'});}
      if(id===165)attacker.hp=Math.max(1,attacker.hp-Math.max(1,Math.round(attacker.maxHp*.08)));
    }else if(move.role==='heal'){const before=attacker.hp;attacker.hp=Math.min(attacker.maxHp,attacker.hp+Math.round(attacker.maxHp*Math.max(.2,(move.effect?.healing||40)/100)));action.events.push({kind:'heal',target:own,hp:attacker.hp,maxHp:attacker.maxHp,heal:attacker.hp-before,text:move.name+' restores HP.'});}
    else if(move.role==='buff'){attacker.guard=Math.min(1.6,(attacker.guard||1)+.15);attacker.attackBoost=Math.min(1.3,(attacker.attackBoost||1)+.08);action.events.push({kind:'modifier',target:own,text:move.name+' strengthens your stance.'});}
    else if(move.role==='debuff'){defender.guard=Math.max(.75,(defender.guard||1)-.12);defender.attackBoost=Math.max(.75,(defender.attackBoost||1)-.08);action.events.push({kind:'modifier',target,text:move.name+' weakens the opposing stance.'});}
    else if(move.role==='no-op')action.events.push({kind:'modifier',target:own,text:move.name+' is a non-damaging field move. Struggle is available.'});
    const ailment=move.effect?.ailment;if(['burn','poison','paralysis','sleep','freeze'].includes(ailment)&&!defender.status&&defender.hp>0&&effectiveness(move.type,defender.types)>0&&random(fight)<((move.effect.ailmentChance||100)/100)){const immune=ailment==='burn'&&defender.types.includes('fire')||ailment==='poison'&&defender.types.some(t=>['poison','steel'].includes(t))||ailment==='paralysis'&&defender.types.includes('electric');if(!immune){defender.status=ailment==='freeze'?'sleep':ailment;defender.statusTurns=2;action.events.push({kind:'modifier',target,text:`${defender.name}: ${defender.status}.`});}}
    return event;
  }
  function nextEnemy(fight,action){if(fight.enemy.hp>0)return false;if(fight.enemyIndex+1>=fight.enemyTeam.length){terminal(fight,'victory');return true}fight.enemyIndex++;fight.enemy=build(fight.enemyTeam[fight.enemyIndex],null,true);fight.flags={};action.events.push({kind:'modifier',target:'enemy',text:`${fight.trainer?.name||'The trainer'} sent out ${fight.enemy.name}!`});return true;}
  function enemyMove(fight,player){const e=fight.enemy,ids=readyMoves(e);if(!ids.length||canStruggle(e))return 165;const healing=ids.find(id=>D.moves[id].role==='heal');if(healing&&e.hp<e.maxHp*.4&&!fight.flags.healUsed){fight.flags.healUsed=true;return healing;}const support=ids.find(id=>['buff','status','debuff'].includes(D.moves[id].role));if(support&&fight.strategy!=='pressure'&&!fight.flags.supportUsed){fight.flags.supportUsed=true;return support}return ids.filter(id=>D.moves[id].damageClass!=='status').sort((a,b)=>(D.moves[b].power||40)*effectiveness(D.moves[b].type,player.types)-(D.moves[a].power||40)*effectiveness(D.moves[a].type,player.types))[0]||ids[0];}
  function residual(fight,action,p,target){if(!['burn','poison'].includes(p.status)||p.hp<=0)return;const before=p.hp,damage=Math.max(1,Math.round(p.maxHp*.04));p.hp=Math.max(0,p.hp-damage);action.events.push({kind:'hit',source:'status',target,type:p.status,key:p.key,name:p.name,damage,beforeHp:before,hp:p.hp,maxHp:p.maxHp,fainted:p.hp===0,eff:1,text:`${p.name} takes ${p.status} damage.`});}
  function enemyTurn(fight,action) {
    if(fight.phase!=='active')return;const player=lead(fight);if(!player)return;
    let mod=1;
    if(fight.bossModifier?.id==='enrage'&&fight.enemy.hp/fight.enemy.maxHp<.4) {mod=1.2;if(!fight.flags.enraged){fight.flags.enraged=true;modifierEvent(action,'Pinsir is enraged! Attacks are 20% stronger.');}}
    if(fight.realMoves)useMove(fight,action,fight.enemy,player,enemyMove(fight,player),'player',mod);else hit(fight,action,fight.enemy,player,fight.enemy.types[0],26,'player',mod);residual(fight,action,player,'player');residual(fight,action,fight.enemy,'enemy');
    if(player.hp===0) {
      const next=fight.party.find(p=>p.hp>0);
      if(next) {fight.leadKey=next.key;action.events.push({kind:'switch',target:'player',key:next.key,name:next.name,text:`Go, ${next.name}!`});}
      else terminal(fight,'loss');
    }
    if(fight.phase==='active'&&fight.enemy.hp===0)nextEnemy(fight,action);
  }
  function captureChance(fight,key) {
    const e=fight.enemy, legendary=e.legendary||e.tier==='legendary'||LEGENDARY.includes(Number(e.id)), mythical=e.mythical||MYTHICAL.includes(Number(e.id));
    return clamp((.12+(1-e.hp/e.maxHp)*.62)*(e.tier==='rare'?.72:1)*(legendary?.28:1)*(mythical?.75:1)*BALLS[key].mod*fight.berryBoost,.025,.95);
  }
  function act(fight,command,args,inventory) {
    args=args||{};inventory=inventory||{};
    const reject=reason=>({applied:false,reason,action:null,result:null});
    if(!fight||fight.phase!=='active')return reject('This encounter has ended.');
    if(!['move','quick','type','berry','potion','ball','switch','flee'].includes(command))return reject('Unknown command.');
    const current=lead(fight);
    if(!current||current.hp<=0)return reject('Choose a living party member.');
    const chosen=['move','quick','type'].includes(command)&&fight.realMoves?resolveMove(fight,current,command,args):null;
    if(chosen&&(!D.moves[chosen]||(chosen===165?!canStruggle(current):!current.moves.includes(chosen)||!(current.pp[chosen]>0))))return reject('Choose a known move with PP.');
    let item;
    if(command==='ball') {if(['trainer','elite'].includes(fight.kind))return reject('Trainer Pokémon cannot be caught.');if(!BALLS[args.key])return reject('Choose a Poké Ball.');item=args.key;}
    if(command==='berry'||command==='potion')item=command;
    if(item&&!(number(inventory[item],0)>=1))return reject('No supplies left.');
    if(command==='potion'&&current.hp>=current.maxHp)return reject('HP is already full.');
    if(command==='switch'&&(!fight.party.some(p=>p.key===args.key&&p.hp>0)||args.key===fight.leadKey))return reject('Choose another living Pokémon.');
    const action={seq:++fight.actionSeq,kind:command,target:command==='quick'||command==='type'||command==='ball'?'enemy':'player',text:'',events:[],beforeLead:{key:current.key,name:current.name,hp:current.hp,maxHp:current.maxHp}};
    if(item)inventory[item]=number(inventory[item],0)-1;
    if(command==='berry') {
      const satchel=fight.perks.includes('berrySatchel');fight.berryBoost=Math.min(satchel?2.2:2,fight.berryBoost*(satchel?1.55:1.4));
      action.text=`A Berry makes ${fight.enemy.name} easier to catch.`;action.events.push({kind:'berry',target:'enemy',text:action.text});
    } else if(command==='flee') {action.text=fight.context==='expedition'?'You retreated from the expedition.':'You slipped back into the habitat.';terminal(fight,'fled');}
    else {
      fight.turns++;
      const first=fight.bossModifier?.id==='swift'&&!fight.flags.swiftUsed;
      if(first) {fight.flags.swiftUsed=true;enemyTurn(fight,action);modifierEvent(action,'Aerodactyl’s ancient speed gave it the opening move.');}
      if(fight.phase==='active') {
        const player=lead(fight);
        if(command==='move'||command==='quick'||command==='type') {
          const type=chosen?D.moves[chosen].type:command==='quick'?'normal':player.types[0], name=chosen?D.moves[chosen].name:D.moves[player.moves[0]]?.name||'Struggle';
          action.text=`${player.name} used ${name}!`;
          let mod=1;
          if(fight.perks.includes('quickClaw')&&!fight.flags.quickClawUsed){mod=1.15;fight.flags.quickClawUsed=true;}
          if(chosen){const event=useMove(fight,action,player,fight.enemy,chosen,'enemy',mod);action.damage=event.damage;action.eff=event.eff;}
          else if(command==='type'&&random(fight)>=.9) {action.events.push({kind:'miss',target:'enemy',text:'The attack missed!'});action.damage=0;action.eff=1;}
          else {const event=hit(fight,action,player,fight.enemy,type,command==='quick'?24:38,'enemy',mod);action.damage=event.damage;action.eff=event.eff;}
          if(fight.enemy.hp===0)nextEnemy(fight,action);
          else if(fight.bossModifier?.id==='tide'&&!fight.flags.tideUsed&&fight.enemy.hp/fight.enemy.maxHp<.5) {
            fight.flags.tideUsed=true;const heal=Math.round(fight.enemy.maxHp*.2), before=fight.enemy.hp;fight.enemy.hp=Math.min(fight.enemy.maxHp,before+heal);
            action.events.push({kind:'heal',target:'enemy',heal: fight.enemy.hp-before,beforeHp:before,hp:fight.enemy.hp,maxHp:fight.enemy.maxHp,text:'Lapras restores HP with a restorative tide.'});
          }
        } else if(command==='potion') {
          const before=player.hp, amount=Math.round(Math.max(10,Math.round(player.maxHp*(fight.context==='regional'?.62:.38)))*(fight.perks.includes('potionBelt')?1.15:1));
          player.hp=Math.min(player.maxHp,before+amount);action.text=`${player.name} recovered HP.`;
          action.events.push({kind:'heal',target:'player',key:player.key,heal:player.hp-before,beforeHp:before,hp:player.hp,maxHp:player.maxHp,text:action.text});
        } else if(command==='switch') {fight.leadKey=args.key;action.text=`Go, ${lead(fight).name}!`;action.events.push({kind:'switch',target:'player',key:args.key,name:lead(fight).name,text:action.text});}
        else if(command==='ball') {
          const chance=captureChance(fight,args.key), roll=random(fight);action.ball=args.key;action.captureChance=chance;action.captureSuccess=roll<chance;
          action.shakes=action.captureSuccess?3:Math.min(2,Math.floor((roll-chance)/Math.max(.0001,1-chance)*3));
          action.text=action.captureSuccess?`Gotcha! ${fight.enemy.name} was caught!`:`${fight.enemy.name} broke free!`;
          action.events.push({kind:'capture',target:'enemy',success:action.captureSuccess,shakes:action.shakes,text:action.text});
          if(action.captureSuccess)terminal(fight,'capture',{captureChance:chance,ball:args.key});else fight.berryBoost=1;
        }
        if(!first&&!action.events.some(e=>e.kind==='modifier'&&e.text.includes('sent out')))enemyTurn(fight,action);
      }
    }
    if(fight.result?.kind==='loss')action.text='Your party is out of HP. Return to safety.';
    fight.lastAction=action;return {applied:true,action,result:fight.result};
  }
  function actorAsset(assets,p,back) {
    return typeof assets.pokemon==='function'?assets.pokemon(p.id,!!p.shiny,!!back):`arcade/sprites/actors/pokemon/${p.shiny?'shiny/':''}${p.id}.png`;
  }
  function hpHud(p,side) {return `<div class="adv-battle-hud adv-battle-hud--${side}" data-battle-hud="${side}"><div><strong data-hud-name>${esc(p.name)}</strong><span data-hud-level>Lv.${p.level}</span></div><div class="adv-battle-hp"><b>HP</b><span role="progressbar" aria-label="${esc(p.name)} HP" aria-valuemin="0" aria-valuemax="${p.maxHp}" aria-valuenow="${p.hp}" data-hp-track><i data-hp-fill style="width:${p.hp/p.maxHp*100}%"></i></span></div><small data-hp-text>${Math.ceil(p.hp)} / ${p.maxHp}</small><small data-hud-status>${esc(p.status||'')}</small></div>`;}
  function moveButtons(p){const ids=[...p.moves];if(canStruggle(p)&&!ids.includes(165))ids.push(165);return ids.map((id,i)=>{const m=D.moves[id];return `<button type="button" data-adv-battle="${i===0?'quick':i===1?'type':'move'}" data-move-id="${id}"${id!==165&&!(p.pp[id]>0)?' disabled':''}><b${i===1?' data-type-move':''}>${esc(m.name)}</b><small${i===1?' data-type-label':''}>${esc(m.type)} · ${m.damageClass==='status'?m.role:'PWR '+(m.power||'var')} · PP ${id===165?'∞':p.pp[id]}</small></button>`}).join('');}
  function markup(fight,assets) {
    assets=assets||{};const p=lead(fight)||fight.party[0]||fight.enemy, e=fight.enemy, dest=(assets.destinations||{})[fight.destination]||{}, boss=fight.kind==='boss';
    const backdrop=(boss&&dest.boss)||dest.battle||`adventure/art/${fight.destination}-battle.png`, inv=fight.inventory||assets.inventory||{}, trainer=fight.trainer;
    const trainerName=trainer&&(trainer.name||trainer.class)||'Trainer';
    const trainerKey=trainer&&(trainer.sprite||trainer.classKey||trainer.class), trainerAsset=['trainer','elite'].includes(fight.kind)&&!(fight.context==='regional'&&trainer?.city)?((assets.trainers||{})[trainerKey]||trainer?.image||dest.trainer):null;
    const banner=boss?`${e.name} · Area guardian`:['trainer','elite'].includes(fight.kind)?`${trainerName} challenges you!${fight.enemyTeam.length>1?' · '+(fight.enemyIndex+1)+'/'+fight.enemyTeam.length+' Pokémon':''}`:`A wild ${e.name} appeared!`;
    const btn=(cmd,label,key)=>`<button type="button" data-adv-battle="${cmd}"${key?` data-key="${esc(key)}"`:''}>${label}</button>`;
    const balls=Object.keys(BALLS).map(key=>`<button type="button" data-adv-battle="ball" data-key="${key}" data-item="${key}"${(['trainer','elite'].includes(fight.kind)||!inv[key])?' disabled':''}><span class="adv-battle-item adv-battle-item--${key}" aria-hidden="true"></span>${BALLS[key].name}<small data-item-count="${key}">×${Number(inv[key]||0)}</small></button>`).join('');
    const switches=fight.party.map(member=>`<button type="button" data-adv-battle="switch" data-key="${esc(member.key)}"${member.hp<=0||member.key===fight.leadKey?' disabled':''}><img src="${esc(actorAsset(assets,member,false))}" data-back-src="${esc(actorAsset(assets,member,true))}" alt=""><span>${esc(member.name)}<small data-party-hp="${esc(member.key)}">${Math.ceil(member.hp)} / ${member.maxHp} HP</small></span></button>`).join('');
    return `<section class="adventure-battle${boss?' adventure-battle--boss':''}${e.shiny?' adventure-battle--shiny':''}" data-fight-id="${esc(fight.id)}" style="--adv-battle-backdrop:url('${esc(backdrop)}')"><div class="adv-battle-scene"><p class="adv-battle-banner">${esc(banner)}</p>${fight.bossModifier?`<p class="adv-battle-modifier">${esc(fight.bossModifier.name)} · ${esc(fight.bossModifier.text)}</p>`:''}${trainerAsset?`<img class="adv-battle-trainer" src="${esc(trainerAsset)}" alt="${esc(trainerName)}">`:''}${hpHud(e,'enemy')}${hpHud(p,'player')}<div class="adv-battle-actor adv-battle-actor--enemy" data-battle-actor="enemy"><img data-actor-image src="${esc(actorAsset(assets,e,false))}" alt="${esc(e.name)}"><span class="adv-battle-sparkles" aria-hidden="true"></span></div><div class="adv-battle-actor adv-battle-actor--player" data-battle-actor="player"><img data-actor-image src="${esc(actorAsset(assets,p,true))}" alt="${esc(p.name)}"></div><div class="adv-battle-effect" data-battle-effect aria-hidden="true"></div><div class="adv-battle-ball" data-battle-ball aria-hidden="true"></div></div><div class="adv-battle-console"><p class="adv-battle-message" data-battle-message role="status" aria-live="polite">${esc(fight.lastAction?.text||banner)}</p><div class="adv-battle-command-panel"><p data-battle-prompt>What will ${esc(p.name)} do?</p><div class="adv-battle-command-grid">${moveButtons(p)}<button type="button" data-adv-command="battle-bag" aria-expanded="false"><b>BAG</b><small>Supplies &amp; capture</small></button><button type="button" data-adv-command="battle-switch" aria-expanded="false"><b>SWITCH</b><small>Choose your lead</small></button></div></div><div class="adv-battle-drawer" data-battle-drawer="bag" hidden><div class="adv-battle-drawer-title"><strong>FIELD BAG</strong><button type="button" data-adv-command="battle-close" aria-label="Close bag">×</button></div><div class="adv-battle-supplies"><button type="button" data-adv-battle="berry" data-item="berry"${inv.berry?'':' disabled'}>Berry<small data-item-count="berry">×${Number(inv.berry||0)}</small></button><button type="button" data-adv-battle="potion" data-item="potion"${inv.potion&&p.hp<p.maxHp?'':' disabled'}>Potion<small data-item-count="potion">×${Number(inv.potion||0)}</small></button>${balls}</div><p data-catch-hint>${['trainer','elite'].includes(fight.kind)?'Trainer Pokémon cannot be caught.':`Weaken your opponent to improve the catch. Berry boost ×${fight.berryBoost.toFixed(1)}.`}</p></div><div class="adv-battle-drawer" data-battle-drawer="switch" hidden><div class="adv-battle-drawer-title"><strong>YOUR PARTY</strong><button type="button" data-adv-command="battle-close" aria-label="Close party">×</button></div><div class="adv-battle-party">${switches}</div></div><button type="button" class="adv-battle-flee" data-adv-battle="flee">${fight.context==='regional'?'RETREAT FROM REGION':fight.context==='expedition'?'RETREAT FROM EXPEDITION':'RETURN TO HABITAT'}</button></div></section>`;
  }
  function update(host,fight) {
    const scene=host.matches?.('.adventure-battle')?host:host.querySelector('.adventure-battle');if(!scene)return;
    const p=lead(fight)||fight.party[0], e=fight.enemy;
    for(const [side,row] of [['enemy',e],['player',p]]) {
      if(!row)continue;const hud=scene.querySelector(`[data-battle-hud="${side}"]`);if(!hud)continue;
      hud.querySelector('[data-hud-name]').textContent=row.name;hud.querySelector('[data-hud-level]').textContent=`Lv.${row.level}`;
      const fill=hud.querySelector('[data-hp-fill]');fill.style.width=`${row.hp/row.maxHp*100}%`;fill.dataset.tone=row.hp/row.maxHp<=.2?'low':row.hp/row.maxHp<=.5?'mid':'high';
      hud.querySelector('[data-hp-text]').textContent=`${Math.ceil(row.hp)} / ${row.maxHp}`;
      const status=hud.querySelector('[data-hud-status]');if(status)status.textContent=row.status||'';
      const track=hud.querySelector('[data-hp-track]');track.setAttribute('aria-valuenow',row.hp);track.setAttribute('aria-valuemax',row.maxHp);track.setAttribute('aria-label',`${row.name} HP`);
      const actor=scene.querySelector(`[data-battle-actor="${side}"]`);if(side==='enemy'){const img=actor.querySelector('img');img.src=actorAsset((typeof window!=='undefined'&&window.LuckyDexAdventureAssets)||{},e,false);img.alt=e.name;}actor.classList.toggle('is-fainted',row.hp<=0);actor.classList.toggle('is-caught',side==='enemy'&&fight.result?.kind==='capture');
      if(side==='player') {
        const button=Array.from(scene.querySelectorAll('[data-adv-battle="switch"]')).find(b=>b.dataset.key===row.key), image=actor.querySelector('img');
        if(button) {const thumbnail=button.querySelector('img'),src=thumbnail.dataset.backSrc||thumbnail.getAttribute('src');if(image.getAttribute('src')!==src)image.src=src;image.alt=row.name;}
      }
    }
    const prompt=scene.querySelector('[data-battle-prompt]');prompt.textContent=fight.phase==='terminal'?(fight.result?.kind==='capture'?'A new travel companion!':fight.result?.kind==='victory'?'Victory!':'Encounter complete'):`What will ${p.name} do?`;
    const grid=scene.querySelector('.adv-battle-command-grid');grid.querySelectorAll('[data-move-id]').forEach(b=>b.remove());grid.insertAdjacentHTML('afterbegin',moveButtons(p));
    if(fight.trainer&&fight.enemyTeam.length>1)scene.querySelector('.adv-battle-banner').textContent=`${fight.trainer.name} · Pokémon ${fight.enemyIndex+1}/${fight.enemyTeam.length}`;
    if(fight.lastAction)scene.querySelector('[data-battle-message]').textContent=fight.lastAction.text;
    for(const button of scene.querySelectorAll('[data-adv-battle]')) {
      const cmd=button.dataset.advBattle;button.disabled=fight.phase!=='active';if(button.dataset.moveId&&Number(button.dataset.moveId)!==165)button.disabled ||= !(p.pp[button.dataset.moveId]>0);
      if(cmd==='switch') {const member=fight.party.find(m=>m.key===button.dataset.key);button.disabled ||= !member||member.hp<=0||member.key===fight.leadKey;if(member)button.querySelector('[data-party-hp]').textContent=`${Math.ceil(member.hp)} / ${member.maxHp} HP`;}
      const item=button.dataset.item;
      if(item) {const count=fight.inventory?.[item];if(count!=null) {button.querySelector('[data-item-count]').textContent=`×${count}`;button.disabled ||= count<1;}else button.disabled ||= Number((button.querySelector('[data-item-count]').textContent||'').replace('×',''))<1;
        if(item==='potion')button.disabled ||= p.hp>=p.maxHp;if(cmd==='ball')button.disabled ||= ['trainer','elite'].includes(fight.kind);
      }
    }
    for(const b of scene.querySelectorAll('.adv-battle-command-grid [data-adv-command]'))b.disabled=fight.phase!=='active';
    const hint=scene.querySelector('[data-catch-hint]');if(!['trainer','elite'].includes(fight.kind))hint.textContent=`Weaken your opponent to improve the catch. Berry boost ×${fight.berryBoost.toFixed(1)}.`;
  }
  function updateEventHud(scene,event) {
    if(!event||!['hit','heal'].includes(event.kind)||!event.target)return;
    const hud=scene.querySelector(`[data-battle-hud="${event.target}"]`);if(!hud)return;
    const hp=Math.max(0,Number(event.hp)||0),max=Math.max(1,Number(event.maxHp)||1),ratio=hp/max;
    const fill=hud.querySelector('[data-hp-fill]');if(fill){fill.style.width=`${ratio*100}%`;fill.dataset.tone=ratio<=.2?'low':ratio<=.5?'mid':'high';}
    const text=hud.querySelector('[data-hp-text]');if(text)text.textContent=`${Math.ceil(hp)} / ${max}`;
    const track=hud.querySelector('[data-hp-track]');if(track){track.setAttribute('aria-valuenow',hp);track.setAttribute('aria-valuemax',max);}
  }
  async function animate(host,action,scope,reduced) {
    if(!host||!action||!scope||typeof scope.wait!=='function')return;
    const scene=host.matches?.('.adventure-battle')?host:host.querySelector('.adventure-battle');if(!scene)return;
    const active=()=>!scope.disposed&&(typeof scope.isActive!=='function'||scope.isActive());
    const wait=async ms=>{await scope.wait(ms);return active();};
    const classes=[], actorStates=[];const add=(node,name)=>{if(node){node.classList.add(name);classes.push([node,name]);}};
    const playerActor=scene.querySelector('[data-battle-actor="player"]'), playerImage=playerActor?.querySelector('img');
    const finalImage=playerImage?{src:playerImage.getAttribute('src'),alt:playerImage.alt}:null;
    const showPlayer=key=>{const button=Array.from(scene.querySelectorAll?.('[data-adv-battle="switch"]')||[]).find(b=>b.dataset.key===key), thumbnail=button?.querySelector('img');if(playerImage&&thumbnail){playerImage.src=thumbnail.dataset.backSrc||thumbnail.getAttribute('src');playerImage.alt=button.querySelector('span')?.firstChild?.textContent||'';}};
    try {
      if(!active())return;
      if(reduced) {scene.querySelector('[data-battle-message]').textContent=action.text;return;}
      if(action.kind==='intro') {add(scene,'is-entering');await wait(320);return;}
      for(const side of ['player','enemy']) {const actor=scene.querySelector(`[data-battle-actor="${side}"]`);if(actor){actorStates.push({actor,fainted:actor.classList.contains('is-fainted'),caught:actor.classList.contains('is-caught')});actor.classList.remove('is-fainted');actor.classList.remove('is-caught');}}
      if(action.beforeLead)showPlayer(action.beforeLead.key);
      if(action.kind==='ball') {
        const ball=scene.querySelector('[data-battle-ball]'),enemy=scene.querySelector('[data-battle-actor="enemy"]');
        ball.dataset.ball=action.ball;add(ball,'is-thrown');if(!await wait(170))return;add(enemy,'is-capturing');add(ball,'is-landed');
        if(!await wait(80))return;
        for(let i=0;i<action.shakes;i++) {ball.classList.remove('is-shaking');void ball.offsetWidth;ball.classList.add('is-shaking');if(!await wait(100))return;}
        ball.classList.remove('is-shaking');
        if(action.captureSuccess){add(ball,'is-caught');add(scene,'is-capture-success');await wait(100);}else {add(enemy,'is-breakout');await wait(120);}
      }
      for(const event of action.events||[]) {
        if(!active())return;
        if(event.kind==='hit') {
          if(event.source==='enemy') {
            scene.querySelector('[data-battle-message]').textContent=`${scene.querySelector('[data-battle-actor="enemy"] img')?.alt||'The opponent'} used ${event.moveName||MOVES[event.type]||'Attack'}!`;
            if(!await wait(ENEMY_TURN_DELAY))return;
          }
          const source=scene.querySelector(`[data-battle-actor="${event.source}"]`), target=scene.querySelector(`[data-battle-actor="${event.target}"]`);
          add(source,'is-attacking');add(target,'is-hit');if(event.eff>1)add(scene,'is-super-effective');
          const effect=scene.querySelector('[data-battle-effect]');effect.dataset.type=event.type;effect.dataset.target=event.target;add(effect,'is-active');
          if(!await wait(190))return;updateEventHud(scene,event);scene.querySelector('[data-battle-message]').textContent=event.text;
          source?.classList.remove('is-attacking');target?.classList.remove('is-hit');effect.classList.remove('is-active');scene.classList.remove('is-super-effective');
          if(event.fainted) {add(target,'is-fainting');if(!await wait(170))return;}
          if(!await wait(HIT_HOLD))return;
        } else if(event.kind==='heal') {const actor=scene.querySelector(`[data-battle-actor="${event.target}"]`);add(actor,'is-healing');if(!await wait(170))return;updateEventHud(scene,event);scene.querySelector('[data-battle-message]').textContent=event.text;actor?.classList.remove('is-healing');if(!await wait(180))return;}
        else if(event.kind==='berry') {const actor=scene.querySelector(`[data-battle-actor="${event.target}"]`);add(actor,'is-healing');if(!await wait(170))return;actor?.classList.remove('is-healing');}
        else if(event.kind==='miss') {scene.querySelector('[data-battle-message]').textContent=event.text;if(!await wait(320))return;}
        else if(event.kind==='modifier') {scene.querySelector('[data-battle-message]').textContent=event.text;if(!await wait(280))return;}
        else if(event.kind==='switch') {showPlayer(event.key);playerActor?.classList.remove('is-fainting');if(!await wait(220))return;}
      }
      if(active())scene.querySelector('[data-battle-message]').textContent=action.text;
    } finally {
      for(const [node,name] of classes)node.classList.remove(name);scene.querySelector('[data-battle-ball]')?.classList.remove('is-shaking');
      for(const state of actorStates){if(state.fainted)state.actor.classList.add('is-fainted');if(state.caught)state.actor.classList.add('is-caught');}
      if(finalImage){playerImage.src=finalImage.src;playerImage.alt=finalImage.alt;}
    }
  }
  return Object.freeze({create,act,markup,update,animate,migrateFight,stats,effectiveness});
});
