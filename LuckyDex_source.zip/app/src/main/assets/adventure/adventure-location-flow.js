/* Place presentation and optional services; authored battle/reward IDs stay in the engine. */
(function(root){'use strict';
const E=root.LuckyDexRegionalEngine||(typeof require==='function'?require('./adventure-regional-engine.js'):null);
const slug=s=>String(s).normalize('NFD').replace(/[\u0300-\u036f]/g,'').toLowerCase().replace(/[^a-z0-9]+/g,'-').replace(/^-|-$/g,'');
const towns={
 kanto:['Pallet Town','Viridian City','Pewter City','Cerulean City','Vermilion City','Lavender Town','Celadon City','Fuchsia City','Saffron City','Cinnabar Island','Indigo Plateau'],
 johto:['New Bark Town','Cherrygrove City','Violet City','Azalea Town','Goldenrod City','Ecruteak City','Cianwood City','Olivine City','Mahogany Town','Blackthorn City','Indigo Plateau'],
 hoenn:['Littleroot Town','Petalburg City','Rustboro City','Dewford Town','Slateport City','Mauville City','Lavaridge Town','Fortree City','Lilycove City','Mossdeep City','Sootopolis City','Ever Grande City']
};
const homes=new Set(['Pallet Town','New Bark Town','Littleroot Town']);
const noMart=new Set(['Pallet Town','New Bark Town','Littleroot Town','Cianwood City','Dewford Town','Ever Grande City']);
const kinds={'Viridian Forest':'forest','Ilex Forest':'forest','Petalburg Woods':'forest','Mt. Moon':'cave','Rock Tunnel':'cave','Seafoam Islands':'cave','Union Cave':'cave','Whirl Islands':'cave','Mt. Mortar':'cave','Ice Path':'cave','Granite Cave':'cave','Fiery Path':'cave','Rusturf Tunnel':'cave','Victory Road':'cave','Slowpoke Well':'cave','Dragon’s Den':'cave','Sprout Tower':'tower','Burned Tower':'tower','Pokémon Tower':'tower','Olivine Lighthouse':'tower','Pokémon Mansion':'tower','Weather Institute':'tower','Mt. Chimney':'mountain','Mt. Pyre':'mountain','Indigo Plateau':'league','Ever Grande City':'league','Cianwood shore':'coast','Lake of Rage':'coast','Sootopolis waters':'coast','Ever Grande waterfall':'coast'};
const waterRoutes={kanto:new Set(['Route 19','Route 21']),johto:new Set(['Route 40']),hoenn:new Set(['Route 106','Route 124','Route 126'])};
const hints={
 'New Bark Town':'Route 29 leads west to Cherrygrove City.',
 'Pallet Town':'Route 1 leads north towards Viridian City.',
 'Littleroot Town':'Route 101 leads towards Petalburg and its woods.',
 'Cherrygrove City':'The northern road reaches Routes 30 and 31.',
 'Route 30':'Follow the path north to Route 31.',
 'Route 31':'Sprout Tower is the next training stop.',
 'Sprout Tower':'The tower’s trainer stands between you and Violet City.',
 'Violet City':'Falkner awaits at Violet Gym. Heal first if you need to.',
 'Cianwood City':'Chuck trains at Cianwood Gym; the pharmacy stands nearby.',
 'Dewford Town':'Brawly awaits at Dewford Gym.'
};
const milestone=n=>['gym','trial','elite-four','league-round','champion'].includes(n?.type);
function mainNode(j){const c=E.current(j);return c&&!c.optional?c:j?.nodes.find(n=>!n.optional&&n.depth===(c?.depth??j.depth));}
function path(j,n){if(j.region==='johto'&&n?.id==='johto-c0-s3')return ['Route 30','Route 31','Sprout Tower'];if(j.region==='johto'&&n?.id==='johto-c0-s4')return ['Violet City','Violet Gym'];if(n?.type==='gym'&&!/Gym$/.test(n.name))return [`${n.name.replace(/ (City|Town|Island)$/,'')} Gym`];return [n?.name||j.checkpoint?.name||j.location];}
function stepFor(j,n){const names=path(j,n);if(E.current(j)?.id===n?.id&&['node','battle','result'].includes(j.phase))return names.length-1;const f=j.locationFlow;return f?.nodeId===n?.id&&f.traversal===(j.traversal||0)?Math.max(0,Math.min(names.length-1,Number(f.step)||0)):0;}
function category(j,name,n){if(/Gym$/.test(name)||['gym','trial'].includes(n?.type)&&name===n.name)return 'gym';if(['elite-four','league-round','champion'].includes(n?.type))return 'league';if(kinds[name])return kinds[name];if(waterRoutes[j.region]?.has(name))return 'coast';if(/City$/.test(name))return 'city';if(/Town$/.test(name))return 'town';if(/Island$/.test(name))return 'city';if(/^Route\s|Road|Bridge|approach|Cycling/.test(name))return 'route';return {cave:'cave',haunted:'tower',coast:'coast',volcano:'mountain'}[n?.habitat]||'route';}
function servicesFor(j,name){const settlement=towns[j.region]?.includes(name)||false;return {center:settlement&&!homes.has(name),home:homes.has(name),mart:settlement&&!noMart.has(name),martLabel:name==='Mahogany Town'?'SOUVENIR SHOP':'POKÉ MART',talk:settlement};}
function describe(j){if(!j)return null;const n=mainNode(j),names=path(j,n),step=stepFor(j,n),name=names[step],services=servicesFor(j,name),last=step===names.length-1,nextNode=j.nodes.find(v=>!v.optional&&v.depth===(n?.depth??j.depth)+1),nextLabel=!last?names[step+1]:nextNode?path(j,nextNode)[0]:'Pokémon League';
 const completed=j.phase==='result'&&E.current(j)?.id===n?.id,travel=['event','camp'].includes(n?.type),canContinue=!j.recovery&&j.phase!=='battle'&&j.phase!=='complete'&&(!last||completed||travel),blockedText=canContinue?'':milestone(n)?`Challenge ${name} to travel onward.`:['trainer','victory-road'].includes(n?.type)?'Defeat the trainer to travel onward.':'Clear the local encounter to travel onward.';
 return {id:`${j.region}-${slug(name)}`,name,exploreText:`Look around ${name}. Watch your footing; supplies may turn up.`,kind:category(j,name,n),region:j.region,habitat:n?.habitat||'meadow',nodeId:n?.id,services,nextLabel,continueLabel:`${['town','city','league'].includes(category(j,name,n))?'LEAVE FOR':'CONTINUE TO'} ${nextLabel.toUpperCase()}`,canContinue,blockedText,segment:step+1,segments:names.length,chapterIndex:n?.chapterIndex??j.chapterIndex,sectionIndex:n?.sectionIndex??j.sectionIndex};
}
function local(j){const n=mainNode(j),old=j.locationFlow;if(old?.nodeId===n?.id&&old.traversal===(j.traversal||0))return old;j.locationFlow={nodeId:n?.id,step:stepFor(j,n),traversal:j.traversal||0,feedback:null};return j.locationFlow;}
function notice(j,text){const p=describe(j),f=local(j);f.feedback={placeId:p.id,text};return text;}
function feedbackFor(j){const f=j?.locationFlow,p=describe(j);return f?.nodeId===p?.nodeId&&f.traversal===(j.traversal||0)&&f.feedback?.placeId===p?.id?f.feedback.text:'';}
function dismiss(j){if(!j?.locationFlow?.feedback)return false;j.locationFlow.feedback=null;return true;}
function actionsFor(save,j=save?.adventureRegional?.active){const p=describe(j),current=E.current(j);if(!p||j.recovery||['node','battle','complete'].includes(j.phase)||j.phase==='result'&&(current?.optional||milestone(current)))return [];const n=mainNode(j),last=stepFor(j,n)===path(j,n).length-1,done=j.phase==='result'&&current?.id===n.id,available=E.available(j),out=[],add=(key,label,extra={})=>out.push({key,label,...extra});
 if(p.services.talk)add('talk','TALK TO LOCALS');
 if(p.services.center)add('center','POKÉMON CENTER');
 if(p.services.home&&last&&n.type==='event'&&!j.claims[n.id]&&j.phase==='map')add('heal','REST AT HOME',{nodeId:n.id});
 if(p.services.home&&last&&n.type==='camp'&&!done&&j.phase==='map')add('heal','REST AT HOME',{nodeId:n.id});
 if(p.services.mart)add('mart',p.services.martLabel,{screen:'mart'});
 if(last&&!done&&['wild','rare','trainer','victory-road','gym','trial','elite-four','league-round','champion'].includes(n.type))add('battle',['gym','trial'].includes(n.type)?`CHALLENGE ${p.name.toUpperCase()}`:['elite-four','league-round','champion'].includes(n.type)?'LEAGUE CHALLENGE':['trainer','victory-road'].includes(n.type)?'TRAINER':p.kind==='route'?'SEARCH GRASS':'SEARCH POKÉMON',{nodeId:n.id});
 const cache=last&&available.find(v=>v.optional&&v.type==='cache');
 if(!done&&(!milestone(n)||!last))add('explore','EXPLORE',cache?{nodeId:cache.id}:{});
 if(!last&&path(j,n)[stepFor(j,n)+1]===n.name&&milestone(n))add('gym',`ENTER ${n.name.toUpperCase()}`,{nodeId:n.id});
 const next=j.nodes.find(v=>!v.optional&&v.depth===n.depth+1);if(last&&n.type==='camp'&&next?.type==='gym')add('gym',`ENTER ${next.name.toUpperCase()}`,{nodeId:next.id});
 for(const d of available.filter(v=>v.optional&&v.type!=='cache')){if(d.type==='wild-hunt')add('hunt','WILD HUNT',{nodeId:d.id,habitat:d.habitat});else if(d.type==='rare')add('rare','RARE POKÉMON',{nodeId:d.id});else if(d.type==='shop'&&!p.services.mart)add('merchant','TRAVELLING MERCHANT',{nodeId:d.id,screen:'mart',context:'merchant'});}
 return out.slice(0,6);
}
function outcome(applied,extra={}){return {applied:!!applied,...extra};}
function perform(save,key){const j=E.ensureSave(save).active;if(!j)return outcome(false);const action=actionsFor(save,j).find(a=>a.key===key);if(!action)return outcome(false);const p=describe(j),n=mainNode(j);local(j);dismiss(j);
 if(key==='talk')return outcome(true,{text:notice(j,hints[p.name]||`${p.nextLabel} is the next stop. Take care of your partners on the road.`)});
 if(key==='center'){if(!E.restoreAtCenter(save))return outcome(false);return outcome(true,{text:notice(j,'Party restored. HP, PP and status recovered.')});}
 if(key==='mart'||key==='merchant')return outcome(true,{screen:'mart',context:action.context});
 if(key==='hunt')return outcome(true,{habitat:action.habitat});
 if(key==='gym'){const moved=continueTravel(save);return outcome(moved.applied,{destination:describe(j)?.name});}
 if(key==='heal'){if(j.phase==='result'||j.phase==='node')return outcome(false);if(E.enter(save,n.id)&&E.resolveNode(save,'safe')){notice(j,n.type==='camp'?'Party restored at home.':'Your party recovered a little at home.');return outcome(true)}return outcome(false);}
 if(key==='explore'){if(action.nodeId)return outcome(E.enter(save,action.nodeId)&&E.resolveNode(save,'safe'));if(n.type==='event'&&!j.claims[n.id]&&!n.detours?.some(d=>d.type==='cache')&&j.phase==='map')return outcome(E.enter(save,n.id));return outcome(true,{text:notice(j,hints[p.name]||`The path onward leads to ${p.nextLabel}.`)});}
 if(['battle','rare'].includes(key)){dismiss(j);return outcome(E.enter(save,action.nodeId));}return outcome(false);
}
function routineText(j,n){const text=j.resolutions[j.current]?.text||'';if(n.type==='camp')return describe(j).services.home?'Party restored at home.':'Party restored.';if(n.type==='shop')return 'Purchases saved.';if(n.type==='wild-hunt')return 'Wild Hunt ready.';if(n.type==='tm')return text;if(/already claimed|already explored/.test(text))return 'Already explored. Supplies kept.';if(n.type==='cache')return 'Found Lucky Coins, 1 Potion and 2 Poké Balls.';if(j.battle?.result?.kind==='capture')return 'Companion caught.';if(['trainer','victory-road'].includes(n.type))return 'Trainer defeated.';if(['wild','rare'].includes(n.type))return 'Encounter cleared.';if(/12%/.test(text))return 'Rough ground: party lost 12% HP.';if(/supply purse/.test(text))return 'Found a supply purse.';return 'Your party recovered a little.';}
function settleRoutine(save){const j=E.ensureSave(save).active,n=E.current(j);if(j?.phase!=='result'||!n||milestone(n))return outcome(false);const p=describe(j),text=feedbackFor(j)||routineText(j,n);if(n.optional){if(!E.advance(save))return outcome(false);j.location=p.name;notice(j,text);return outcome(true)}const f=local(j);if(f.routineSettledId===n.id)return outcome(false);f.routineSettledId=n.id;notice(j,text);return outcome(true);}
function continueTravel(save){const j=E.ensureSave(save).active;if(!j)return outcome(false);const p=describe(j),n=mainNode(j);if(!p.canContinue)return outcome(false,{reason:p.blockedText});const f=local(j),names=path(j,n),step=stepFor(j,n);dismiss(j);
 if(step<names.length-1){f.step=step+1;j.location=names[f.step];return outcome(true)}
 const moved=j.phase==='result'?E.advance(save):E.skipTravel(save,n.id);if(!moved)return outcome(false);j.locationFlow=null;if(j.phase!=='complete')j.location=describe(j).name;return outcome(true);
}
function sceneFor(place,assets={},habitatAssets=assets){if(!place)return habitatAssets.destinations?.meadow?.scene||null;if(place.scene)return place.scene;const named=assets.named?.[place.region]?.[place.name],exact=assets.places?.[place.id]||named,category=assets.categories?.[place.region]?.[place.kind]||assets.categories?.[place.kind],resolve=key=>typeof key==='object'&&key?key.path:key&&assets.scenes?.[key]?.path||(/\.(png|webp|jpe?g)$/i.test(key||'')?key:null);return resolve(exact)||resolve(category)||habitatAssets.destinations?.[place.habitat]?.scene||habitatAssets.destinations?.meadow?.scene||null;}
const api={describe,actionsFor,perform,continue:continueTravel,settleRoutine,feedbackFor,dismiss,sceneFor};root.LuckyDexLocationFlow=api;if(typeof module==='object'&&module.exports)module.exports=api;
})(typeof window!=='undefined'?window:globalThis);
