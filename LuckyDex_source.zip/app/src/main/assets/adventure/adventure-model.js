(function (root, factory) {
  'use strict';
  const api = factory();
  if (typeof module === 'object' && module.exports) module.exports = api;
  if (root) root.LuckyDexAdventureModel = api;
})(typeof globalThis !== 'undefined' ? globalThis : this, function () {
  'use strict';

  const DESTINATIONS = {
    meadow: {id:'meadow',name:'Viridian Wilds',expeditionName:'Viridian Trail',rank:1,minLevel:2,maxLevel:8,levels:[2,8],clearCoins:500,clearXp:300,bossId:127,bossName:'Pinsir'},
    cave: {id:'cave',name:'Mt. Moon',expeditionName:'Mt. Moon Caverns',rank:3,minLevel:6,maxLevel:14,levels:[6,14],clearCoins:750,clearXp:450,bossId:142,bossName:'Aerodactyl'},
    haunted: {id:'haunted',name:'Lavender',expeditionName:'Lavender Haunted House',rank:5,minLevel:10,maxLevel:20,levels:[10,20],clearCoins:950,clearXp:600,bossId:94,bossName:'Gengar'},
    coast: {id:'coast',name:'Seafoam Islands',expeditionName:'Seafoam Shore',rank:6,minLevel:10,maxLevel:20,levels:[10,20],clearCoins:1100,clearXp:700,bossId:131,bossName:'Lapras'},
    volcano: {id:'volcano',name:'Cinnabar Crater',expeditionName:'Cinnabar Crater',rank:10,minLevel:16,maxLevel:28,levels:[16,28],clearCoins:1500,clearXp:900,bossId:6,bossName:'Charizard'}
  };
  const HOTSPOT_BLUEPRINTS = {
    meadow: [
      {clue:'Fresh tracks',x:18,y:15,effect:'sand_footprints'},
      {clue:'Shaking tree',x:80,y:13,effect:'ground_impact_dust'},
      {clue:'Falling leaves',x:67,y:38,effect:'ground_impact_dust'},
      {clue:'Rustling grass',x:28,y:64,effect:'short_grass'},
      {clue:'Rustling grass',x:69,y:78,effect:'short_grass'}
    ],
    cave: [
      {clue:'Loose stones',x:20,y:10,effect:'ground_impact_dust'},
      {clue:'Drifting dust',x:73,y:20,effect:'ground_impact_dust'},
      {clue:'Glinting stone',x:38,y:43,effect:'small_sparkle'},
      {clue:'Fresh tracks',x:77,y:59,effect:'sand_footprints'},
      {clue:'Cave shadow',x:18,y:80,effect:'shadow_medium'}
    ],
    haunted: [
      {clue:'Rattling grave',x:22,y:33,effect:'ground_impact_dust'},
      {clue:'Purple glow',x:50,y:46,effect:'small_sparkle'},
      {clue:'Drifting wisp',x:75,y:31,effect:'small_sparkle'},
      {clue:'Cold spot',x:28,y:70,effect:'ripple'},
      {clue:'Strange shadow',x:76,y:76,effect:'shadow_medium'}
    ],
    coast: [
      {clue:'Water ripple',x:38,y:15,effect:'ripple'},
      {clue:'Rising bubbles',x:35,y:28,effect:'ripple'},
      {clue:'Cracked ice',x:77,y:20,effect:'ground_impact_dust'},
      {clue:'Moving shadow',x:80,y:56,effect:'shadow_medium'},
      {clue:'Quiet splash',x:44,y:75,effect:'jump_small_splash'}
    ],
    volcano: [
      {clue:'Heat shimmer',x:50,y:20,effect:'small_sparkle'},
      {clue:'Shifting rocks',x:30,y:39,effect:'ground_impact_dust'},
      {clue:'Ember trail',x:62,y:47,effect:'small_sparkle'},
      {clue:'Ash plume',x:80,y:66,effect:'ground_impact_dust'},
      {clue:'Fresh tracks',x:34,y:76,effect:'sand_footprints'}
    ]
  };
  const ENCOUNTER_POOLS = {
    meadow: {
      normal:[10,13,16,19,21,25,29,32,35,39,43,46,48,52,69,102,133],
      rare:[113,123],
      legendary:[]
    },
    cave: {
      normal:[41,50,66,74,95,111,246,304,524,529,703,744],
      rare:[51,67,75,443],
      legendary:[]
    },
    haunted: {
      normal:[41,42,63,92,93,96,200,302,353,355,425,607,708],
      rare:[64,97,442,778],
      legendary:[]
    },
    coast: {
      normal:[54,60,72,79,86,90,98,116,118,120,129,170,194,223,278,320,363],
      rare:[87,91,121,130,226,350],
      legendary:[144]
    },
    volcano: {
      normal:[37,58,74,77,95,111,126,218,228,240,322,324,390,636,757],
      rare:[38,59,78,110,112,136,219,323],
      legendary:[146,485]
    }
  };
  const NODE_TYPES = ['start','wild','rare','trainer','elite','cache','mystery','event','camp','hazard','discovery','boss'];
  const PERKS = {
    compass: {id:'compass',name:"Explorer's Compass",description:'Reveal one extra future node.',item:'pokeball',revealExtra:1},
    potionBelt: {id:'potionBelt',name:'Potion Belt',description:'Potions restore 15% more HP.',item:'potion',potionMultiplier:1.15},
    luckyCharm: {id:'luckyCharm',name:'Lucky Charm',description:'Rare encounter chance +2 percentage points.',item:'pokeball',rareBoost:0.02},
    berrySatchel: {id:'berrySatchel',name:'Berry Satchel',description:'Berries add a stronger catch boost.',item:'berry',berryBoost:0.05},
    quickClaw: {id:'quickClaw',name:'Quick Claw',description:'First attack deals 15% more damage.',item:'pokeball',firstAttackMultiplier:1.15},
    fieldMedic: {id:'fieldMedic',name:'Field Medic',description:'Camp rest restores 15% more maximum HP.',item:'potion',campHealBonus:0.15},
    collectorsEye: {id:'collectorsEye',name:"Collector's Eye",description:'Caches hold one extra supply.',item:'pokeball',cacheExtra:1}
  };

  // Concise location-specific encounters. Each has a guaranteed safe path;
  // the capability path costs an item only when explicitly declared.
  function event(id,title,text,safeLabel,safe,riskLabel,success,failure,capLabel,requires,cap) {
    return {id,title,text,choices:[
      {id:'safe',label:safeLabel,outcome:safe},
      {id:'risk',label:riskLabel,risk:{chance:0.62,success,failure}},
      {id:'capability',label:capLabel,requires,outcome:cap}
    ]};
  }
  const EVENTS = {
    meadow: [
      event('meadow-fallen-tree','Fallen tree','A fallen trunk covers the trail.','Follow the stream',{xp:12},'Climb over',{items:{berry:1}},{damageFraction:0.06},'Send a Flying Pokémon',{types:['flying']},{xp:18,revealExtra:1}),
      event('meadow-lost-catcher','Lost Bug Catcher','A young catcher has lost the trail.','Point out the sign',{coins:18},'Search the thicket',{coins:36,xp:10},{battle:{enemyId:13,levelBonus:0}},'Scout from above',{types:['flying']},{coins:28,revealExtra:1}),
      event('meadow-berry-grove','Berry grove','Sweet berries grow beyond tangled roots.','Pick the low berries',{items:{berry:1}},'Reach into the roots',{items:{berry:2}},{damageFraction:0.05},'Ask a Grass Pokémon',{types:['grass']},{items:{berry:2},healFraction:0.05}),
      event('meadow-beedrill-nest','Buzzing hollow','A guarded nest hangs over a supply pouch.','Give it space',{xp:14},'Reach for the pouch',{items:{pokeball:1},coins:24},{battle:{enemyId:15,levelBonus:1}},'Leave a Berry',{item:'berry',amount:1},{items:{berry:-1,pokeball:1},xp:20}),
      event('meadow-strange-tracks','Strange tracks','Deep tracks lead away from the path.','Mark the trail',{revealExtra:1},'Follow the tracks',{rareBoost:0.02,xp:18},{damageFraction:0.06},'Read the roots',{types:['grass']},{rareBoost:0.02,revealExtra:1}),
      event('meadow-old-ball-cache','Old Ball cache','A weathered box sits in a shallow pond.','Gather loose coins',{coins:20},'Wade to the box',{items:{pokeball:2}},{damageFraction:0.07},'Send a Water Pokémon',{types:['water']},{items:{pokeball:1},coins:20})
    ],
    cave: [
      event('cave-fossil-wall','Fossil wall','A fossil shape is caught in loose stone.','Sketch the outline',{xp:18},'Free a fragment',{coins:42,xp:12},{damageFraction:0.08},'Steady it with Rock',{types:['rock','ground']},{coins:30,xp:16}),
      event('cave-collapsing-passage','Shifting passage','Dust falls from a narrow shortcut.','Use the marked tunnel',{xp:14},'Cross quickly',{coins:30,revealExtra:1},{damageFraction:0.08},'Brace the tunnel',{types:['rock','ground']},{revealExtra:1,xp:22}),
      event('cave-clefairy-gathering','Moonlit gathering','Clefairy circle a pale stone.','Watch quietly',{xp:20},'Join their dance',{rareBoost:0.02,items:{berry:1}},{battle:{enemyId:35,levelBonus:0}},'Offer a Berry',{item:'berry',amount:1},{items:{berry:-1},rareBoost:0.02,xp:26}),
      event('cave-underground-spring','Hidden spring','Clear water bubbles beneath a ledge.','Rest by the water',{healFraction:0.08},'Climb down',{healFraction:0.15,coins:20},{damageFraction:0.06},'Let Water guide you',{types:['water']},{healFraction:0.18}),
      event('cave-trainer-camp','Hiker camp','A hiker needs a supply for a bruised partner.','Share directions',{coins:22},'Search nearby',{items:{potion:1}},{battle:{enemyId:74,levelBonus:1}},'Share a Potion',{item:'potion',amount:1},{items:{potion:-1,pokeball:2},coins:20}),
      event('cave-mineral-deposit','Glittering seam','A bright seam hides behind dark rock.','Pocket a loose shard',{coins:24},'Dig into the seam',{coins:48},{damageFraction:0.07},'Lift the rock safely',{types:['rock','ground']},{coins:38,xp:18})
    ],
    haunted: [
      event('haunted-flickering-corridor','Flickering corridor','Lamps blink along a deserted hall.','Follow the steady lamp',{xp:18},'Follow the flicker',{revealExtra:1,coins:30},{damageFraction:0.06},'Read the presence',{types:['psychic','ghost']},{revealExtra:1,xp:24}),
      event('haunted-possessed-object','Rattling cabinet','A cabinet shakes around a medicine tin.','Leave it closed',{xp:14},'Open the doors',{items:{potion:1}},{battle:{enemyId:92,levelBonus:1}},'Calm the spirit',{types:['ghost','psychic']},{items:{potion:1},xp:18}),
      event('haunted-lost-spirit','Lost spirit','A faint light circles an old portrait.','Wait beside it',{healFraction:0.07},'Touch the frame',{xp:36,rareBoost:0.02},{damageFraction:0.07},'Guide it home',{types:['ghost','psychic']},{xp:30,healFraction:0.08}),
      event('haunted-sealed-room','Sealed room','A warped door guards a dusty supply shelf.','Search the doorstep',{coins:22},'Force the door',{items:{pokeball:2},coins:20},{damageFraction:0.08},'Slip past the seal',{types:['ghost']},{items:{pokeball:1,potion:1}}),
      event('haunted-strange-mirror','Strange mirror','A mirror reflects another corridor.','Turn it to the wall',{xp:16},'Look closer',{rareBoost:0.02,revealExtra:1},{battle:{enemyId:93,levelBonus:0}},'Read the illusion',{types:['psychic']},{revealExtra:1,nextBattleBonus:0.08}),
      event('haunted-medicine-cabinet','Medicine cabinet','A cracked tin still holds clean bandages.','Use a clean strip',{healFraction:0.08},'Sort the entire tin',{items:{potion:1}},{damageFraction:0.05},'Treat the party',{item:'potion',amount:1},{items:{potion:-1},healFraction:0.23})
    ],
    coast: [
      event('coast-strong-current','Strong current','A swift channel separates two shores.','Follow the shoreline',{xp:18},'Leap between rocks',{coins:34,revealExtra:1},{damageFraction:0.08},'Ride with Water',{types:['water']},{revealExtra:1,xp:24}),
      event('coast-cracked-ice','Cracked ice','A glint rests beyond a web of ice cracks.','Collect near the edge',{coins:24},'Cross the cracks',{coins:48,items:{berry:1}},{damageFraction:0.09},'Fly over the ice',{types:['flying']},{coins:36,items:{berry:1}}),
      event('coast-frozen-supplies','Frozen supply cache','An ice-coated box is wedged under a ledge.','Gather loose supplies',{items:{pokeball:1}},'Chip the box free',{items:{pokeball:2,potion:1}},{damageFraction:0.08},'Thaw it with Fire',{types:['fire']},{items:{pokeball:1,potion:1}}),
      event('coast-submerged-passage','Submerged passage','Bubbles rise from a tunnel under the pool.','Mark the pool',{xp:20},'Explore the shallows',{rareBoost:0.02,coins:24},{battle:{enemyId:90,levelBonus:0}},'Ask Water to scout',{types:['water']},{rareBoost:0.02,revealExtra:1}),
      event('coast-resting-lapras','Quiet lagoon','A distant Lapras rests near a calm cove.','Rest on the shore',{healFraction:0.09},'Approach quietly',{xp:34,rareBoost:0.02},{damageFraction:0.05},'Offer a Berry',{item:'berry',amount:1},{items:{berry:-1},healFraction:0.19,xp:20}),
      event('coast-ice-bridge','Ice bridge','A narrow bridge groans above the surf.','Use the rocky path',{xp:18},'Cross before it shifts',{coins:38,revealExtra:1},{damageFraction:0.08},'Brace it with Rock',{types:['rock','ground']},{revealExtra:1,nextBattleBonus:0.08})
    ],
    volcano: [
      event('volcano-lava-vent','Lava vent','A hot vent blocks the crater path.','Take the upper path',{xp:20},'Dash past the vent',{coins:44},{damageFraction:0.09},'Cool it with Water',{types:['water']},{coins:32,revealExtra:1}),
      event('volcano-unstable-rock','Unstable rock','A slab rocks over a buried supply bag.','Check around the slab',{coins:24},'Lift the edge',{items:{potion:1},coins:24},{damageFraction:0.09},'Hold it with Ground',{types:['ground','rock']},{items:{potion:1},xp:20}),
      event('volcano-research-equipment','Research station','A dusty instrument clicks beside a ruined desk.','Read the notebook',{xp:22},'Restart the instrument',{coins:46,rareBoost:0.02},{battle:{enemyId:81,levelBonus:1}},'Read the signal',{types:['psychic']},{rareBoost:0.02,xp:28}),
      event('volcano-heat-exhaustion','Shaded ledge','The hot climb has worn the party down.','Rest in the shade',{healFraction:0.09},'Reach the higher shade',{healFraction:0.17,coins:20},{damageFraction:0.06},'Share a Potion',{item:'potion',amount:1},{items:{potion:-1},healFraction:0.25}),
      event('volcano-fire-nest','Warm hollow','A sleeping Fire Pokémon guards a scorched pouch.','Keep your distance',{xp:18},'Retrieve the pouch',{items:{pokeball:2}},{battle:{enemyId:58,levelBonus:1}},'Let Fire approach',{types:['fire']},{items:{pokeball:1},nextBattleBonus:0.08}),
      event('volcano-volcanic-cache','Ash-covered cache','Old supplies lie beneath fresh ash.','Brush off the surface',{items:{berry:1}},'Dig into the ash',{items:{potion:1,pokeball:1}},{damageFraction:0.07},'Blow the ash away',{types:['flying']},{items:{potion:1,pokeball:1},xp:16})
    ]
  };

  const isObject = x => !!x && typeof x === 'object' && !Array.isArray(x);
  const owns = (obj,key) => !!obj && Object.prototype.hasOwnProperty.call(obj,key);
  const finite = (x,fallback) => Number.isFinite(x) ? x : fallback;
  const count = x => Math.max(0,Math.floor(finite(x,0)));
  const clone = x => JSON.parse(JSON.stringify(x));
  function destinationFor(id) {
    const key = typeof id === 'string' ? id : id && id.id;
    return owns(DESTINATIONS,key) ? DESTINATIONS[key] : DESTINATIONS.meadow;
  }
  function seedValue(seed) {
    // FNV-1a handles numeric and string seeds consistently, including zero.
    const source = typeof seed === 'number' && Number.isFinite(seed) ? String(seed) : typeof seed === 'string' ? seed : '0';
    let value=2166136261;
    for(let i=0;i<source.length;i++) value=Math.imul(value^source.charCodeAt(i),16777619)>>>0;
    return value || 0x9e3779b9;
  }
  function seeded(seed) {
    let state=seedValue(seed);
    return {next:function(){state^=state<<13;state^=state>>>17;state^=state<<5;state>>>=0;return state/4294967296;},state:function(){return state;}};
  }
  function pick(rng,rows) { return rows[Math.floor(rng.next()*rows.length)]; }
  function shuffle(rng,rows) {
    const out=rows.slice();
    for(let i=out.length-1;i>0;i--){const j=Math.floor(rng.next()*(i+1));const value=out[i];out[i]=out[j];out[j]=value;}
    return out;
  }
  function nodeContent(type,seed,dest) {
    const rng=seeded(seed+':content');
    if(['event','hazard','discovery','mystery'].includes(type)) return {eventId:pick(rng,EVENTS[dest.id]).id};
    if(type==='boss') return {enemyId:dest.bossId,levelBonus:3,boss:true};
    if(type==='cache') return {coins:18+Math.floor(rng.next()*19),xp:8,items:{[pick(rng,['berry','pokeball','potion'])]:1},perkIds:shuffle(rng,Object.keys(PERKS)).slice(0,2)};
    if(type==='camp') return {healFraction:0.35};
    if(type==='rare') return {rareBoost:0.16,levelBonus:1};
    if(type==='trainer') return {levelBonus:1,coins:35,xp:22};
    if(type==='elite') return {levelBonus:2,coins:55,xp:34};
    if(type==='wild') return {levelBonus:0};
    return {};
  }
  function generateRoute(seed,destination) {
    const dest=destinationFor(destination), source=typeof seed==='string'||typeof seed==='number'&&Number.isFinite(seed)?seed:0;
    const rng=seeded(String(source)+':'+dest.id), rare=rng.next()<0.38, rareDepth=rng.next()<0.5?3:5;
    const layers=[['start'],['wild'],shuffle(rng,['cache','event',pick(rng,['wild','trainer'])]),
      shuffle(rng,['trainer',rare&&rareDepth===3?'rare':'hazard','discovery']).slice(0,rng.next()<0.5?2:3),
      ['camp'],shuffle(rng,['wild','cache',rare&&rareDepth===5?'rare':'event']),
      shuffle(rng,['trainer','elite',pick(rng,['mystery','discovery'])]).slice(0,rng.next()<0.5?2:3),['boss']];
    // A rare is optional even when the generator considers one: it may be in
    // an omitted lane. The camp cut layer is crossed by every complete path.
    const nodes=[];
    layers.forEach((types,depth)=>types.forEach((type,lane)=>{
      const nodeSeed=Math.floor(rng.next()*4294967296)>>>0;
      nodes.push({id:depth===0?'start':depth===7?'boss':'d'+depth+'l'+lane,depth,lane,type,seed:nodeSeed,links:[],content:nodeContent(type,nodeSeed,dest)});
    }));
    for(const node of nodes) node.links=nodes.filter(n=>n.depth===node.depth+1).map(n=>n.id);
    return {seed:source,nodes};
  }

  function createRun(destination,seed,party) {
    const dest=destinationFor(destination), route=generateRoute(seed,dest.id), source=route.seed;
    const rows=[], keys=new Set();
    for(const row of Array.isArray(party)?party:[]) {
      if(!isObject(row)||row.key==null)continue;
      const key=String(row.key);if(!key||keys.has(key))continue;keys.add(key);
      rows.push(Object.assign({},row,{key,id:count(row.id),name:typeof row.name==='string'?row.name:'Pokémon',level:Math.max(1,count(row.level)),types:Array.isArray(row.types)?row.types.filter(t=>typeof t==='string').map(t=>t.toLowerCase()):[],maxHp:Math.max(1,count(row.maxHp))}));
    }
    const rngSeed=seedValue(String(source)+':'+dest.id+':run');
    return {id:dest.id+'-'+seedValue(String(source)+':run').toString(36),destination:dest.id,seed:source,rng:{algorithm:'xorshift32',seed:rngSeed,state:rngSeed},route,
      currentNode:'start',completed:[],revealed:['start','d1l0','boss'],phase:'route',party:rows,partyKeys:rows.map(row=>row.key),hpByKey:Object.fromEntries(rows.map(row=>[row.key,row.maxHp])),leadKey:rows.length?rows[0].key:null,
      loot:{coins:0,xp:0,catches:[],items:{},rare:0,rooms:0,battles:0},perks:[],pending:null,battle:null,claimed:false,resolutions:{},perkOffer:null,perkOfferSequence:0};
  }
  function validRoute(route) {
    if(!isObject(route)||!Array.isArray(route.nodes)||route.nodes.length<3)return false;
    const byId=new Map();
    for(const n of route.nodes) {
      if(!isObject(n)||typeof n.id!=='string'||byId.has(n.id)||!NODE_TYPES.includes(n.type)||!Number.isInteger(n.depth)||n.depth<0||n.depth>7||!Array.isArray(n.links))return false;
      byId.set(n.id,n);
    }
    if(!byId.has('start')||!byId.has('boss')||byId.get('start').depth!==0||byId.get('boss').depth!==7)return false;
    for(const n of route.nodes) if(n.links.some(id=>!byId.has(id)||byId.get(id).depth!==n.depth+1)||n.id!=='boss'&&!n.links.length)return false;
    const reached=new Set();const visit=id=>{if(reached.has(id))return;reached.add(id);byId.get(id).links.forEach(visit);};visit('start');
    return reached.size===byId.size;
  }
  function normalizeRun(run) {
    if(!isObject(run)||!owns(DESTINATIONS,run.destination))return null;
    if(!validRoute(run.route))return null;
    const defaults=createRun(run.destination,run.seed,Array.isArray(run.party)?run.party:[]);
    for(const key of Object.keys(defaults)) if(!owns(run,key))run[key]=defaults[key];
    run.party=defaults.party;
    const nodeIds=new Set(run.route.nodes.map(n=>n.id));
    for(const key of ['completed','revealed'])run[key]=Array.isArray(run[key])?Array.from(new Set(run[key].filter(id=>nodeIds.has(id)))):[];
    run.partyKeys=Array.isArray(run.partyKeys)?Array.from(new Set(run.partyKeys.filter(key=>typeof key==='string'))):defaults.partyKeys;
    if(!isObject(run.hpByKey))run.hpByKey={};
    for(const key of run.partyKeys) {
      const row=run.party.find(p=>p.key===key),max=row?Math.max(1,count(row.maxHp)):Math.max(1,count(run.hpByKey[key]));
      run.hpByKey[key]=Math.min(max,count(run.hpByKey[key]));
    }
    if(!run.partyKeys.includes(run.leadKey))run.leadKey=run.partyKeys[0]||null;
    if(!nodeIds.has(run.currentNode)) {run.currentNode='start';run.pending=null;run.phase='route';}
    if(run.pending!==null&&(!isObject(run.pending)||run.pending.nodeId!==run.currentNode||run.completed.includes(run.currentNode))) {run.pending=null;run.battle=null;run.phase=run.currentNode==='boss'?'complete':'route';}
    if(!isObject(run.loot))run.loot=defaults.loot;
    for(const key of ['coins','xp','rare','rooms','battles'])run.loot[key]=count(run.loot[key]);
    if(!Array.isArray(run.loot.catches))run.loot.catches=[];
    if(!isObject(run.loot.items))run.loot.items={};
    run.perks=Array.isArray(run.perks)?Array.from(new Set(run.perks.filter(id=>owns(PERKS,id)))).slice(0,3):[];
    if(!isObject(run.resolutions))run.resolutions={};
    if(!isObject(run.rng))run.rng=defaults.rng;
    else {
      run.rng.state=Number.isInteger(run.rng.state)?run.rng.state>>>0:defaults.rng.state;
      if(!run.rng.state)run.rng.state=defaults.rng.state;
      if(!owns(run.rng,'seed'))run.rng.seed=defaults.rng.seed;
      if(!owns(run.rng,'algorithm'))run.rng.algorithm=defaults.rng.algorithm;
    }
    if(run.battle!==null&&!isObject(run.battle))run.battle=null;
    run.claimed=run.claimed===true;
    if(!['route','battle','event','camp','cache','complete','retreated','defeated'].includes(run.phase))run.phase=run.pending?'event':'route';
    if(run.perkOffer!==null&&(!isObject(run.perkOffer)||!Array.isArray(run.perkOffer.ids)))run.perkOffer=null;
    return run;
  }
  function normalizeRecord(record) {
    if(!isObject(record))record={};
    for(const key of ['encounters','shiny','clears'])record[key]=count(record[key]);
    for(const key of ['seen','caught','rare'])if(!isObject(record[key]))record[key]={};
    if(!owns(record,'boss'))record.boss=false;
    return record;
  }
  function ensureState(save) {
    if(!isObject(save))throw new TypeError('Adventure state requires a save object.');
    if(!isObject(save.adventureV2))save.adventureV2={};
    const v2=save.adventureV2;
    if(!owns(v2,'schema'))v2.schema=1;
    if(!isObject(v2.destinations))v2.destinations={};
    for(const id of Object.keys(DESTINATIONS))v2.destinations[id]=normalizeRecord(v2.destinations[id]);
    if(!owns(DESTINATIONS,v2.lastDestination))v2.lastDestination='meadow';
    if(!isObject(v2.activeRoam)||!owns(DESTINATIONS,v2.activeRoam.destination))v2.activeRoam=null;
    else {
      v2.activeRoam.chain=count(v2.activeRoam.chain);
      if(!Array.isArray(v2.activeRoam.hotspots))v2.activeRoam.hotspots=[];
    }
    v2.activeExpedition=normalizeRun(v2.activeExpedition);
    return v2;
  }
  function availableNodes(run) {
    if(!isObject(run)||!isObject(run.route)||!Array.isArray(run.route.nodes)||run.pending||run.claimed||run.phase!=='route')return [];
    const node=run.route.nodes.find(n=>n.id===run.currentNode);
    if(!node)return [];
    return run.route.nodes.filter(n=>node.links.includes(n.id)&&!run.completed.includes(n.id));
  }
  function enterNode(run,id) {
    const node=availableNodes(run).find(n=>n.id===id);if(!node)return false;
    run.currentNode=id;run.pending={nodeId:id,type:node.type};
    run.phase=['wild','rare','trainer','elite','boss'].includes(node.type)?'battle':node.type==='camp'?'camp':node.type==='cache'?'cache':'event';
    if(!run.revealed.includes(id))run.revealed.push(id);
    for(const next of node.links)if(!run.revealed.includes(next))run.revealed.push(next);
    return true;
  }
  function completeNode(run,id) {
    if(!isObject(run)||!run.pending||run.pending.nodeId!==id||run.currentNode!==id||run.completed.includes(id)||run.claimed)return false;
    const node=run.route.nodes.find(n=>n.id===id);if(!node)return false;
    run.completed.push(id);run.loot.rooms=count(run.loot.rooms)+1;run.pending=null;run.battle=null;run.phase=node.type==='boss'?'complete':'route';
    return true;
  }
  function eventFor(run,node) {
    if(!run||!node)return null;
    const events=EVENTS[destinationFor(run.destination).id];
    const stored=node.content&&node.content.eventId;
    if(stored)return events.find(e=>e.id===stored)||null;
    return events[Math.floor(seeded(String(node.seed)+':event').next()*events.length)];
  }
  function choiceAvailable(choice,ctx) {
    if(!choice)return false;
    const required=choice.requires;if(!required)return true;ctx=ctx||{};
    if(required.types) {
      const rows=Array.isArray(ctx.party)?ctx.party:[];
      if(!rows.some(row=>Array.isArray(row.types)&&row.types.some(t=>required.types.includes(typeof t==='string'?t.toLowerCase():t&&t.type&&t.type.name))))return false;
    }
    if(required.item&&count(ctx.inventory&&ctx.inventory[required.item])<Math.max(1,count(required.amount)))return false;
    if(required.hpFraction&&finite(ctx.hpFraction,0)<required.hpFraction)return false;
    return true;
  }
  function resolveEvent(run,nodeId,choiceId,ctx) {
    const no={applied:false,outcome:null};
    if(!run||!run.pending||run.pending.nodeId!==nodeId||run.currentNode!==nodeId||run.completed.includes(nodeId)||run.claimed||owns(run.resolutions,nodeId))return no;
    const node=run.route.nodes.find(n=>n.id===nodeId);
    if(!node||!['event','mystery','hazard','discovery'].includes(node.type))return no;
    const definition=eventFor(run,node),choice=definition&&definition.choices.find(c=>c.id===choiceId);
    if(!choiceAvailable(choice,ctx))return no;
    const rng=seeded(String(node.seed)+':'+definition.id+':'+choice.id);
    const outcome=clone(choice.risk?rng.next()<choice.risk.chance?choice.risk.success:choice.risk.failure:choice.outcome);
    if(!isObject(run.resolutions))run.resolutions={};
    // Root applies these effects and saves the flag together, synchronously.
    run.resolutions[nodeId]={eventId:definition.id,choiceId:choice.id,outcome:clone(outcome)};
    return {applied:true,outcome};
  }
  function offerPerk(run,ids) {
    if(!run||run.claimed||run.perkOffer&&!run.perkOffer.resolved)return {applied:false,reason:'offer-pending'};
    const offered=Array.from(new Set((Array.isArray(ids)?ids:[]).filter(id=>owns(PERKS,id)&&!run.perks.includes(id))));
    if(!offered.length)return {applied:false,reason:'no-new-perks'};
    run.perkOfferSequence=count(run.perkOfferSequence)+1;
    run.perkOffer={id:run.id+':perk:'+run.perkOfferSequence,ids:offered,resolved:false};
    return {applied:true,offer:run.perkOffer};
  }
  function keepPerk(run,id,replaceId) {
    const offer=run&&run.perkOffer;
    if(!offer||offer.resolved||run.claimed||!offer.ids.includes(id)||!owns(PERKS,id)||run.perks.includes(id))return {applied:false,reason:'invalid-offer'};
    if(run.perks.length>=3) {
      if(!replaceId)return {applied:false,requiresReplacement:true,reason:'capacity'};
      const index=run.perks.indexOf(replaceId);if(index<0)return {applied:false,reason:'invalid-replacement'};
      run.perks[index]=id;
    } else run.perks.push(id);
    offer.resolved=true;offer.kept=id;if(replaceId)offer.replaced=replaceId;
    return {applied:true,perk:PERKS[id]};
  }
  function fieldRecord(v2,destination) {
    if(!isObject(v2.destinations))v2.destinations={};const id=destinationFor(destination).id;
    return v2.destinations[id]=normalizeRecord(v2.destinations[id]);
  }
  function speciesId(encounter) {
    const id=isObject(encounter)?encounter.id:encounter;
    return Number.isInteger(Number(id))&&Number(id)>0?String(Number(id)):null;
  }
  function recordEncounter(v2,dest,encounter) {
    const id=speciesId(encounter);if(!id)return false;
    const record=fieldRecord(v2,dest);record.encounters++;record.seen[id]=count(record.seen[id])+1;
    if(encounter&&encounter.rare)record.rare[id]=count(record.rare[id])+1;
    if(encounter&&(encounter.shiny||encounter.isShiny))record.shiny++;
    return record;
  }
  function recordCatch(v2,dest,encounter) {
    const id=speciesId(encounter);if(!id)return false;
    const record=fieldRecord(v2,dest);record.caught[id]=count(record.caught[id])+1;
    return record;
  }
  function mastery(record) {
    if(!isObject(record))return 0;
    const unique=key=>isObject(record[key])?Object.keys(record[key]).filter(id=>record[key][id]>0).length:0;
    return Math.min(5,(count(record.encounters)>0?1:0)+(unique('seen')>=5?1:0)+(unique('caught')>=3?1:0)+(unique('rare')>0||count(record.shiny)>0?1:0)+(count(record.clears)>0||record.boss?1:0));
  }
  return {DESTINATIONS,HOTSPOT_BLUEPRINTS,ENCOUNTER_POOLS,EVENTS,PERKS,NODE_TYPES,ensureState,generateRoute,createRun,availableNodes,enterNode,completeNode,eventFor,choiceAvailable,resolveEvent,mastery,recordEncounter,recordCatch,offerPerk,keepPerk};
});
