(function(root,factory){'use strict';const api=factory();if(typeof module==='object'&&module.exports)module.exports=api;if(root)root.LuckyDexMoveView=api;})(typeof window!=='undefined'?window:null,function(){
  'use strict';
  const D=(typeof window!=='undefined'&&window.LuckyDexMoveData)||(typeof require==='function'?require('./adventure-move-data.js'):null);
  const cap=value=>String(value||'').replace(/(^|[ -])([a-z])/g,(_,space,c)=>space+c.toUpperCase());
  const esc=value=>String(value==null?'':value).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
  function describe(value,opts){
    opts=opts||{};const m=typeof value==='object'?value:D.moves[value];if(!m)return null;
    const damaging=m.damageClass!=='status',effect=m.effect||{},sentences=[];
    if(damaging)sentences.push('Deals '+m.damageClass+' damage.');
    else if(m.role==='heal')sentences.push('Restores the user’s HP.');
    else if(m.role==='buff')sentences.push('Raises the user’s offensive and defensive stance.');
    else if(m.role==='debuff')sentences.push('Lowers the target’s offensive and defensive stance.');
    if(damaging&&effect.drain>0)sentences.push('Restores HP based on damage dealt.');
    const ailments={burn:'burn the target',poison:'poison the target',paralysis:'paralyze the target',sleep:'put the target to sleep',freeze:'put the target to sleep in LuckyDex'};
    if(ailments[effect.ailment])sentences.push((effect.ailmentChance>0&&effect.ailmentChance<100?'May ':'Can ')+ailments[effect.ailment]+'.');
    if(!sentences.length)sentences.push('No battle effect is currently implemented in LuckyDex.');
    if(m.id===165)sentences.push('Available without PP when no damaging move has PP; costs a little HP.');
    const max=m.pp==null?'—':String(m.pp),current=opts.currentPP;
    return {id:m.id,name:m.name,type:cap(m.type),category:cap(m.damageClass),power:damaging?(m.power==null?'Variable':String(m.power)):'—',accuracy:m.accuracy==null?'Always hits':m.accuracy+'%',pp:current==null?max:String(Math.max(0,Number(current)||0))+' / '+max,maxPP:m.pp,priority:Number(m.priority)||0,description:sentences.join(' ')};
  }
  function markup(value,opts){const m=describe(value,opts);if(!m)return '';return `<article class="adv-move-card" data-move-card="${esc(m.id)}"><div class="adv-move-card-heading"><strong>${esc(m.name)}</strong><span class="adv-move-type">${esc(m.type)}</span></div><p class="adv-move-category">${esc(m.category)}</p><dl class="adv-move-values"><div><dt>Power</dt><dd>${esc(m.power)}</dd></div><div><dt>Accuracy</dt><dd>${esc(m.accuracy)}</dd></div><div><dt>PP</dt><dd>${esc(m.pp)}</dd></div></dl><p class="adv-move-description">${esc(m.description)}</p></article>`;}
  return Object.freeze({describe,markup});
});
