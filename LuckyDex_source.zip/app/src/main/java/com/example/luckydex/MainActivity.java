package com.example.luckydex;

import android.app.Activity;
import android.os.Bundle;
import android.os.Build;
import android.os.VibrationEffect;
import android.os.Vibrator;
import android.content.Context;
import android.content.Intent;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.view.View;
import android.graphics.Color;

import org.json.JSONArray;

public class MainActivity extends Activity {
    private WebView webView;

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        webView = new WebView(this);
        webView.setOverScrollMode(View.OVER_SCROLL_NEVER);
        webView.setVerticalScrollBarEnabled(false);
        getWindow().setStatusBarColor(Color.rgb(5, 12, 24));
        getWindow().setNavigationBarColor(Color.rgb(5, 12, 24));
        setContentView(webView);
        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setCacheMode(WebSettings.LOAD_NO_CACHE);
        s.setAllowFileAccess(true);
        // Lucky Dex is a packaged, non-navigable local app. Keep the existing
        // file:// origin so upgrades retain the user's localStorage save, while
        // allowing its bundled JavaScript to reach the HTTPS card-data/image
        // fallbacks used by the pack cache. Never load untrusted file:// pages.
        @SuppressWarnings("deprecation")
        boolean legacyFileOrigin = true;
        s.setAllowFileAccessFromFileURLs(legacyFileOrigin);
        s.setAllowUniversalAccessFromFileURLs(legacyFileOrigin);
        s.setBlockNetworkLoads(false);
        s.setBlockNetworkImage(false);
        s.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        webView.clearCache(true);
        webView.setWebViewClient(new WebViewClient());
        webView.setWebChromeClient(new WebChromeClient());
        webView.addJavascriptInterface(new AndroidBridge(), "Android");
        webView.loadUrl("file:///android_asset/index.html");
    }

    public class AndroidBridge {
        @JavascriptInterface public void setImmersive(boolean enabled) {
            runOnUiThread(() -> {
                int flags = enabled
                    ? (View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY | View.SYSTEM_UI_FLAG_FULLSCREEN | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_LAYOUT_STABLE)
                    : View.SYSTEM_UI_FLAG_VISIBLE;
                getWindow().getDecorView().setSystemUiVisibility(flags);
            });
        }

        @JavascriptInterface public void shareText(String text) {
            Intent i = new Intent(Intent.ACTION_SEND);
            i.setType("text/plain");
            i.putExtra(Intent.EXTRA_TEXT, text);
            startActivity(Intent.createChooser(i, "Export Lucky Dex save"));
        }

        @JavascriptInterface public void packHaptic(String jsonPattern) {
            try {
                JSONArray values = new JSONArray(jsonPattern == null ? "[]" : jsonPattern);
                if (values.length() == 0) return;
                long[] waveform = new long[values.length() + 1];
                waveform[0] = 0;
                for (int i = 0; i < values.length(); i++) {
                    waveform[i + 1] = Math.max(0L, values.optLong(i, 0L));
                }
                Vibrator vibrator = (Vibrator) getSystemService(Context.VIBRATOR_SERVICE);
                if (vibrator == null || !vibrator.hasVibrator()) return;
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    vibrator.vibrate(VibrationEffect.createWaveform(waveform, -1));
                } else {
                    vibrator.vibrate(waveform, -1);
                }
            } catch (Exception ignored) {
                // Haptics are enhancement-only; never interrupt a pack reveal.
            }
        }
    }

    @Override public void onBackPressed() {
        if (webView == null) { finish(); return; }
        webView.evaluateJavascript("(function(){return window.handleLuckyBack ? window.handleLuckyBack() : false;})()", value -> {
            if ("true".equals(value)) return;
            if (webView.canGoBack()) webView.goBack(); else finish();
        });
    }
}
