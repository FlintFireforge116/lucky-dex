
## LuckyDex v0.30.0 handover

- Pokémon Dash v2: top-down 540×720 Gen 3-inspired racer with larger 96–112 px sprites.
- Modes: Quick Race and 18 Type Leagues; leagues are three-race cups with 10/6/4/3/2/1 scoring and time tie-breaks.
- Difficulty Speed bands: Easy 20–65, Normal 55–100, Hard 90–135, Expert 125–180.
- Quick rewards: Easy 120/80/55/35/25/20; Normal 150/100/70/45/30/25; Hard 180/120/85/55/40/30; Expert 240/160/110/70/50/40. League final rewards are 3× the corresponding Quick reward and are paid only after race 3.
- Dash save migration is additive and preserves v0.29 career totals.
- Android identity remains `com.example.luckydex`; permanent dev keystore config is unchanged.
# CURRENT HANDOVER — v0.29.2 GOD PACK PRODUCTION POLISH

- Release identity: **v0.29.2 / versionCode 293**, unchanged `com.example.luckydex` application ID and permanent signer.
- God Pack production denominator remains **1000** and `FORCE_TEST_GOD_PACK=false`.
- Lucky Pack is now **1/500** and only rolls when God Pack does not trigger.
- God Pack intro copy is reduced to **GOD PACK** only; GOD PACK COMPLETE remains on the summary.
- Pack generation, spectacle, persistence and lifetime stats otherwise remain unchanged from v0.29.1.
- See `TEST_REPORT_v0.29.2.md`.
