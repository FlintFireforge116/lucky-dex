# Lucky Dex — Codex Handover

## Current build
- Version in UI: **v0.13**
- Android app is a lightweight **WebView app**.
- Runtime UI is HTML/CSS/JavaScript under `app/src/main/assets/`.
- Active files are:
  - `app/src/main/assets/index.html`
  - `app/src/main/assets/app-v013.js`
  - `app/src/main/assets/styles-v013.css`
- Android shell:
  - `app/src/main/java/com/example/luckydex/MainActivity.java`
  - Gradle files at project root / `app/`
- GitHub Actions workflow: `.github/workflows/build-apk.yml`

This handoff copy intentionally removes old inactive versioned JS/CSS files so Codex is not distracted by append-only legacy overrides.

## Reference target
`reference/TARGET_CLEFAIRY_AND_PACK_OPENING.png` is the target visual direction. Treat it as a **motion/art direction reference**, not as something to reproduce as static screenshots.

## Current functionality that must be preserved
- Pokémon collection / Pokédex
- zones, hunting, battles and catching
- expeditions
- arcade games including Voltorb Flip / Clefairy Match / Berry Blender
- pack economy, coins, tickets, card dust
- physical TCG and TCG Pocket support
- collection persistence / save migration
- rarity-aware pack generation
- local/offline card cache introduced in v0.13
- current Android APK build workflow

## Known issues / reason for handoff
The app is functional, but high-impact visual moments still feel like styled HTML rather than a game.

### Pack opening
Current implementation uses layered CSS effects, but it still feels like a PowerPoint transition. We want a **real cinematic card reveal** with continuous 3D motion, camera-depth feel, particles, rarity-specific timing and an actual gold ribbon/swirl for top hits.

### Clefairy Match
Current scene is much better than early versions, but animation should be treated as a proper game scene. The background should remain stable. Clefairy should be its own character layer with smooth pose/state transitions and real motion, with the reflection derived from the same motion.

## Important technical notes
- Prefer **Web Animations API + requestAnimationFrame** for timelines and continuous motion.
- Canvas/SVG is encouraged for particles, glow ribbons and trails.
- Avoid heavy external frameworks unless there is a strong reason; the app is intended to stay light.
- Animation must not depend on the network.
- Preload all local assets needed for animation.
- Cancel animation loops / RAF handles when leaving a screen.
- Avoid append-only patches. Refactor the active code cleanly and remove obsolete animation code rather than stacking overrides.
- Keep Android WebView compatibility in mind.
- Do not regress save data or pack caching.

## Build / verification expectations
Before completion:
1. Run JS syntax checks.
2. Exercise the two animation systems with mocked/local data and with the network disabled.
3. Test at mobile viewports around 360x800 and 412x915.
4. Build the debug APK with Gradle / existing workflow.
5. Verify the app opens, pack reveal completes, swipe navigation works, Clefairy actions replay, and screen exit cancels animations.
6. Bump the visible version to **v0.14** only once the work is actually integrated and tested.

Do not stop at a plan. Implement, test, and leave the project buildable.
