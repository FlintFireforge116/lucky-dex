#!/usr/bin/env python3
"""Chromium geometry smoke for the exact shipped Arcade source.

The harness blocks browser navigation, so this script inlines the local CSS/JS
into one document before using page.set_content(). It is still the real app
DOM and production scripts; only network-loaded imagery is allowed to fail.
"""
from __future__ import annotations
import argparse, json, re, sys
from pathlib import Path
from playwright.sync_api import sync_playwright, TimeoutError as PlaywrightTimeout

ROOT=Path(__file__).resolve().parents[1]
ASSET_DIR=ROOT/'app/src/main/assets'
VIEWPORTS=[(360,800),(412,915)]
PRIMARY={
 'berryPicker':'berryPickerStartBtn','headIt':'headItStartBtn','tilePuzzle':'tilePuzzleStartBtn',
 'voltorb':'voltorbNewBtn','ballDrop':'ballDropBtn','berry':'berryStartBtn','clefairy':'clefairyStartV019',
 'fossil':'fossilNewBtn','unown':'unownStartBtn','quiz':'quizStartBtn'
}

def inline_app()->str:
    html=(ASSET_DIR/'index.html').read_text(encoding='utf-8')
    def css(m):
        p=ASSET_DIR/m.group(1)
        return '<style>\n'+p.read_text(encoding='utf-8')+'\n</style>' if p.exists() else ''
    def js(m):
        p=ASSET_DIR/m.group(1)
        return '<script>\n'+p.read_text(encoding='utf-8')+'\n</script>' if p.exists() else ''
    html=re.sub(r'<link rel="stylesheet" href="([^"]+)"\s*/?>',css,html)
    html=re.sub(r'<script src="([^"]+)"></script>',js,html)
    shim="""<script>try{Object.defineProperty(window,'localStorage',{value:{_d:{},getItem(k){return this._d[k]??null},setItem(k,v){this._d[k]=String(v)},removeItem(k){delete this._d[k]},clear(){this._d={}}},configurable:true})}catch(e){}</script>"""
    return html.replace('<head>','<head>'+shim,1)

def visible_control(page,bid):
    return page.evaluate("""id=>{
      const b=document.getElementById(id);if(!b)return {ok:false,why:'missing'};
      const r=b.getBoundingClientRect(),cs=getComputedStyle(b);
      if(b.hidden||cs.display==='none'||cs.visibility==='hidden'||Number(cs.opacity)===0)return {ok:false,why:'hidden'};
      const x=Math.max(0,Math.min(innerWidth-1,r.left+r.width/2)),y=Math.max(0,Math.min(innerHeight-1,r.top+r.height/2));
      const hit=document.elementFromPoint(x,y),within=r.bottom>0&&r.top<innerHeight&&r.right>0&&r.left<innerWidth;
      const hittable=!!hit&&(hit===b||b.contains(hit));
      return {ok:within&&hittable,fully:r.top>=0&&r.bottom<=innerHeight,hittable,r:{top:r.top,bottom:r.bottom,left:r.left,right:r.right,width:r.width,height:r.height},hit:hit?.id||hit?.className||hit?.tagName};
    }""",bid)

def run(browser_executable=None):
    failures=[];rows=[];html=inline_app()
    with sync_playwright() as p:
        kw={'headless':True}
        if browser_executable:kw['executable_path']=browser_executable
        browser=p.chromium.launch(**kw)
        for w,h in VIEWPORTS:
            page=browser.new_page(viewport={'width':w,'height':h});runtime=[]
            page.on('pageerror',lambda exc:runtime.append(str(exc)))
            try:page.set_content(html,wait_until='domcontentloaded',timeout=5000)
            except PlaywrightTimeout:pass
            page.wait_for_timeout(160)
            page.evaluate("""()=>{document.getElementById('titleScreen')?.classList.add('hidden-title');document.querySelectorAll('.page').forEach(p=>p.classList.remove('active'));document.querySelector('.page[data-page="arcade"]')?.classList.add('active');window.LuckyDexArcadeWorld?.openWorld?.();}""")
            world=page.evaluate("""()=>{const n=document.getElementById('arcadeWorldRoute'),cs=getComputedStyle(n);return {overflowX:cs.overflowX,scrollWidth:n.scrollWidth,clientWidth:n.clientWidth,documentOverflow:document.documentElement.scrollWidth-innerWidth};}""")
            ok=world['overflowX'] in ('hidden','clip') and world['documentOverflow']<=1
            rows.append({'viewport':f'{w}x{h}','world':world,'ok':ok})
            if not ok:failures.append(f'{w}x{h}: world {world}')
            for game,bid in PRIMARY.items():
                page.evaluate("id=>window.LuckyDexArcadeWorld.openGame(id)",game);page.wait_for_timeout(30)
                info=visible_control(page,bid);rows.append({'viewport':f'{w}x{h}','game':game,'control':bid,**info})
                if not info.get('ok'):failures.append(f'{w}x{h} {game}/{bid}: {info}')
                page.evaluate("()=>window.LuckyDexArcadeWorld.backFromGame(true)")
            if runtime:failures.append(f'{w}x{h}: runtime errors {runtime[:5]}')
            page.close()
        browser.close()
    print(json.dumps(rows,indent=2))
    if failures:
        print('\nFAILURES:',file=sys.stderr)
        for f in failures:print('-',f,file=sys.stderr)
        return 1
    print(f'PASS v0.20 Chromium geometry: {len(VIEWPORTS)} viewports × {len(PRIMARY)} game controls; world has no native scrollbar')
    return 0

if __name__=='__main__':
    ap=argparse.ArgumentParser();ap.add_argument('--browser',default='/usr/bin/chromium');ns=ap.parse_args()
    raise SystemExit(run(ns.browser if Path(ns.browser).exists() else None))
