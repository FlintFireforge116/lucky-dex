#!/usr/bin/env python3
"""Materialise one real English physical booster packshot per set into APK assets.

This runs in GitHub Actions before Gradle. Runtime booster art is therefore
fully local: no GitHub/API lookups occur on the phone. Sets without a packshot
folder are treated as non-booster products and are not entered in the manifest.
"""
from __future__ import annotations
import json, os, re, shutil, tempfile, urllib.error, urllib.parse, urllib.request
from concurrent.futures import ThreadPoolExecutor, as_completed
from pathlib import Path

REPO='1niceroli/ptcg-assets'; BRANCH='main'
ROOT=Path(__file__).resolve().parents[1]
ASSET_DIR=ROOT/'app/src/main/assets/booster-art-v0260'
MANIFEST=ROOT/'app/src/main/assets/booster-art-index-v0260.json'
README=f'https://raw.githubusercontent.com/{REPO}/{BRANCH}/README.md'
API=f'https://api.github.com/repos/{REPO}/contents'
TOKEN=os.environ.get('GH_TOKEN') or os.environ.get('GITHUB_TOKEN') or ''

def request(url:str, *, accept='application/vnd.github+json'):
    headers={'Accept':accept,'User-Agent':'LuckyDex-booster-assets-v0260'}
    if TOKEN and 'api.github.com' in url: headers['Authorization']=f'Bearer {TOKEN}'
    return urllib.request.urlopen(urllib.request.Request(url,headers=headers),timeout=45)

def request_json(url:str):
    with request(url) as response:return json.load(response)

def request_text(url:str):
    with request(url,accept='text/plain') as response:return response.read().decode('utf-8')

def english_set_ids(readme:str):
    english=readme.split('## English',1)
    if len(english)<2:return []
    block=re.split(r'(?m)^##\s+',english[1],maxsplit=1)[0]
    out=[]
    for line in block.splitlines():
        m=re.match(r'^\|\s*([A-Za-z0-9][A-Za-z0-9._-]*)\s*\|\s*en\s*\|',line)
        if m:out.append(m.group(1))
    return out

def choose_packshot(set_id:str):
    url=f'{API}/{urllib.parse.quote(set_id)}/packshots?ref={BRANCH}'
    try:rows=request_json(url)
    except urllib.error.HTTPError as exc:
        if exc.code == 404:return set_id,None
        raise
    files=[r for r in rows if isinstance(r,dict) and r.get('type')=='file' and r.get('download_url')]
    priority={'.webp':0,'.png':1,'.jpg':2,'.jpeg':3}
    supported=[]
    for row in files:
        ext=Path(str(row.get('name',''))).suffix.lower()
        if ext in priority:supported.append((priority[ext],str(row.get('name','')).lower(),row,ext))
    supported.sort(key=lambda item:(item[0],item[1]))
    if not supported:return set_id,None
    _,_,row,ext=supported[0]
    return set_id,{'url':row['download_url'],'ext':ext}

def download(url:str,dest:Path):
    dest.parent.mkdir(parents=True,exist_ok=True)
    fd,tmp=tempfile.mkstemp(prefix=dest.name+'.',dir=str(dest.parent));os.close(fd)
    try:
        with request(url,accept='image/webp,image/png,image/jpeg,*/*') as response, open(tmp,'wb') as out:shutil.copyfileobj(response,out)
        if Path(tmp).stat().st_size<4096:raise RuntimeError(f'booster asset too small: {url}')
        Path(tmp).replace(dest)
    finally:
        try:Path(tmp).unlink()
        except FileNotFoundError:pass

def main():
    ids=english_set_ids(request_text(README))
    if not ids:raise SystemExit('No English set IDs found in booster artwork source')
    selected={}
    with ThreadPoolExecutor(max_workers=12) as pool:
        futures=[pool.submit(choose_packshot,set_id) for set_id in ids]
        for future in as_completed(futures):
            set_id,asset=future.result()
            if asset:selected[set_id]=asset
    required_smoke={'base1':'Base Set','base2':'Jungle','ecard3':'Skyridge','sm35':'Shining Legends','me3':'Perfect Order'}
    missing_smoke=[name for set_id,name in required_smoke.items() if set_id not in selected]
    if missing_smoke:raise SystemExit(f'Known booster artwork missing; refusing an incomplete LuckyDex build: {missing_smoke}')
    ASSET_DIR.mkdir(parents=True,exist_ok=True)
    expected={f"{set_id}{asset['ext']}" for set_id,asset in selected.items()}
    for stale in ASSET_DIR.iterdir():
        if stale.is_file() and stale.name not in expected:stale.unlink()
    with ThreadPoolExecutor(max_workers=8) as pool:
        jobs={pool.submit(download,asset['url'],ASSET_DIR/f"{set_id}{asset['ext']}"):set_id for set_id,asset in selected.items()}
        for future in as_completed(jobs):future.result()
    missing=[set_id for set_id,asset in selected.items() if not (ASSET_DIR/f"{set_id}{asset['ext']}").exists()]
    if missing:raise SystemExit(f'Missing materialised booster art: {missing[:12]}')
    manifest={set_id:f"booster-art-v0260/{set_id}{selected[set_id]['ext']}" for set_id in sorted(selected)}
    MANIFEST.write_text(json.dumps(manifest,indent=2)+'\n',encoding='utf-8')
    base=ASSET_DIR/f"base1{selected['base1']['ext']}"
    if base.stat().st_size<4096:raise SystemExit('Base Set booster artwork failed integrity check')
    print(f'PASS local booster artwork: {len(manifest)} physical booster sets materialised into APK assets')

if __name__=='__main__':main()
