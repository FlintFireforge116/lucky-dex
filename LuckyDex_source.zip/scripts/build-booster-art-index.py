#!/usr/bin/env python3
"""Materialise one real English physical booster packshot per set into APK assets.

The build deliberately avoids GitHub's REST Contents API. GitHub-hosted runners
can share an unauthenticated REST rate limit, which previously caused APK builds
to fail with HTTP 403 while enumerating many set folders. Instead we fetch only
Git tree metadata with a blobless Git fetch, enumerate packshot paths locally,
then download the selected images from raw.githubusercontent.com.
"""
from __future__ import annotations

import json
import re
import shutil
import subprocess
import tempfile
import time
import urllib.error
import urllib.parse
import urllib.request
from concurrent.futures import ThreadPoolExecutor, as_completed
from pathlib import Path

REPO = '1niceroli/ptcg-assets'
BRANCH = 'main'
ROOT = Path(__file__).resolve().parents[1]
ASSET_DIR = ROOT / 'app/src/main/assets/booster-art-v0260'
MANIFEST = ROOT / 'app/src/main/assets/booster-art-index-v0260.json'
README = f'https://raw.githubusercontent.com/{REPO}/{BRANCH}/README.md'
RAW_BASE = f'https://raw.githubusercontent.com/{REPO}/{BRANCH}/'


def request(url: str, *, accept: str = '*/*', attempts: int = 4):
    last_error = None
    for attempt in range(1, attempts + 1):
        try:
            headers = {
                'Accept': accept,
                'User-Agent': 'LuckyDex-booster-assets-v0263',
            }
            return urllib.request.urlopen(
                urllib.request.Request(url, headers=headers), timeout=60
            )
        except (urllib.error.HTTPError, urllib.error.URLError, TimeoutError) as exc:
            last_error = exc
            status = getattr(exc, 'code', None)
            retryable = status in (None, 408, 429, 500, 502, 503, 504)
            if not retryable or attempt >= attempts:
                raise
            time.sleep(min(2 ** (attempt - 1), 8))
    raise last_error  # pragma: no cover


def request_text(url: str) -> str:
    with request(url, accept='text/plain') as response:
        return response.read().decode('utf-8')


def english_set_ids(readme: str):
    english = readme.split('## English', 1)
    if len(english) < 2:
        return []
    block = re.split(r'(?m)^##\s+', english[1], maxsplit=1)[0]
    out = []
    for line in block.splitlines():
        match = re.match(
            r'^\|\s*([A-Za-z0-9][A-Za-z0-9._-]*)\s*\|\s*en\s*\|', line
        )
        if match:
            out.append(match.group(1))
    return out


def repository_paths():
    """Return repository paths without downloading the 2+ GB asset blobs."""
    with tempfile.TemporaryDirectory(prefix='luckydex-packtree-') as temp_dir:
        subprocess.run(['git', 'init', '-q', temp_dir], check=True)
        subprocess.run(
            [
                'git', '-C', temp_dir, 'remote', 'add', 'origin',
                f'https://github.com/{REPO}.git',
            ],
            check=True,
        )
        # GitHub supports partial clone filtering. This fetches commit/tree metadata
        # only; the large image blobs are downloaded later only for selected packs.
        subprocess.run(
            [
                'git', '-C', temp_dir, 'fetch', '--quiet', '--depth=1',
                '--filter=blob:none', 'origin', BRANCH,
            ],
            check=True,
            timeout=180,
        )
        result = subprocess.run(
            [
                'git', '-C', temp_dir, 'ls-tree', '-r', '--name-only', '-z',
                'FETCH_HEAD',
            ],
            check=True,
            stdout=subprocess.PIPE,
            timeout=60,
        )
        return [
            item.decode('utf-8')
            for item in result.stdout.split(b'\0')
            if item
        ]


def choose_packshots(set_ids, paths):
    priority = {'.webp': 0, '.png': 1, '.jpg': 2, '.jpeg': 3}
    candidates = {set_id: [] for set_id in set_ids}
    allowed = set(set_ids)

    for path in paths:
        parts = path.split('/', 2)
        if len(parts) < 3:
            continue
        set_id, folder, _ = parts
        if set_id not in allowed or folder != 'packshots':
            continue
        ext = Path(path).suffix.lower()
        if ext not in priority:
            continue
        candidates[set_id].append((priority[ext], path.casefold(), path, ext))

    selected = {}
    for set_id, rows in candidates.items():
        if not rows:
            continue
        rows.sort(key=lambda item: (item[0], item[1]))
        _, _, path, ext = rows[0]
        selected[set_id] = {
            'url': RAW_BASE + urllib.parse.quote(path, safe='/'),
            'ext': ext,
            'source_path': path,
        }
    return selected


def download(url: str, dest: Path):
    dest.parent.mkdir(parents=True, exist_ok=True)
    if dest.is_file() and dest.stat().st_size >= 4096:
        return
    temp_path = dest.with_name(dest.name + '.part')
    try:
        with request(
            url, accept='image/webp,image/png,image/jpeg,*/*', attempts=4
        ) as response, open(temp_path, 'wb') as output:
            shutil.copyfileobj(response, output)
        if temp_path.stat().st_size < 4096:
            raise RuntimeError(f'booster asset too small: {url}')
        temp_path.replace(dest)
    finally:
        try:
            temp_path.unlink()
        except FileNotFoundError:
            pass


def main():
    ids = english_set_ids(request_text(README))
    if not ids:
        raise SystemExit('No English set IDs found in booster artwork source')

    selected = choose_packshots(ids, repository_paths())
    required_smoke = {
        'base1': 'Base Set',
        'base2': 'Jungle',
        'ecard3': 'Skyridge',
        'sm35': 'Shining Legends',
        'me3': 'Perfect Order',
    }
    missing_smoke = [
        name for set_id, name in required_smoke.items() if set_id not in selected
    ]
    if missing_smoke:
        raise SystemExit(
            'Known booster artwork missing; refusing an incomplete LuckyDex build: '
            f'{missing_smoke}'
        )

    ASSET_DIR.mkdir(parents=True, exist_ok=True)
    expected = {
        f"{set_id}{asset['ext']}" for set_id, asset in selected.items()
    }
    for stale in ASSET_DIR.iterdir():
        if stale.is_file() and stale.name not in expected:
            stale.unlink()

    with ThreadPoolExecutor(max_workers=6) as pool:
        jobs = {
            pool.submit(
                download, asset['url'], ASSET_DIR / f"{set_id}{asset['ext']}"
            ): set_id
            for set_id, asset in selected.items()
        }
        for future in as_completed(jobs):
            future.result()

    missing = [
        set_id
        for set_id, asset in selected.items()
        if not (ASSET_DIR / f"{set_id}{asset['ext']}").exists()
    ]
    if missing:
        raise SystemExit(f'Missing materialised booster art: {missing[:12]}')

    manifest = {
        set_id: f"booster-art-v0260/{set_id}{selected[set_id]['ext']}"
        for set_id in sorted(selected)
    }
    MANIFEST.write_text(json.dumps(manifest, indent=2) + '\n', encoding='utf-8')

    base = ASSET_DIR / f"base1{selected['base1']['ext']}"
    if base.stat().st_size < 4096:
        raise SystemExit('Base Set booster artwork failed integrity check')

    print(
        'PASS local booster artwork: '
        f'{len(manifest)} physical booster sets materialised into APK assets '
        'without GitHub REST API enumeration'
    )


if __name__ == '__main__':
    main()
