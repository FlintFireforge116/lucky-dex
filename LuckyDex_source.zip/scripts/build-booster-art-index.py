#!/usr/bin/env python3
"""Materialise one real English physical booster packshot per set into APK assets.

This runs in GitHub Actions before Gradle. Runtime booster art is therefore
fully local: no GitHub/API lookups occur on the phone. Sets without a packshot
folder are treated as non-booster products and are not entered in the manifest.
"""
from __future__ import annotations
import json, os, re, shutil, tempfile, urllib.error, urllib.parse, urllib.request
from concurrent.futures import ThreadPoolExecutor, as_completed
from pathlib import Path

REPO='1niceroli/ptcg-assets'; BRANCH='main'
ROOT=Path(__file__).resolve().parents[1]
ASSET_DIR=ROOT/'app/src/main/assets/booster-art-v0260'
MANIFEST=ROOT/'app/src/main/assets/booster-art-index-v0260.json'
README=f'https://raw.githubusercontent.com/{REPO}/{BRANCH}/README.md'
API=f'https://api.github.com/repos/{REPO}/contents'
TOKEN=os.environ.get('GH_TOKEN') or os.environ.get('GITHUB_TOKEN') or ''

def request(url:str, *, accept='application/vnd.github+json'):
    headers={'Accept':accept,'User-Agent':'LuckyDex-booster-assets-v0260'}
    if TOKEN and 'api.github.com' in url: headers['Authorization']=f'Bearer {TOKEN}'
    return urllib.request.urlopen(urllib.request.Request(url,headers=headers),timeout=45)

def request_json(url:str):
    with request(url) as response:return json.load(response)

def request_text(url:str):
    with request(url,accept='text/plain') as response:return response.read().decode('utf-8')

def english_set_ids(readme:str):
    block=readme.split('## English',1)[1].split('## Japanese',1)[0]
    out=[]
    for line in block.splitlines():
        m=re.match(r'^\|\s*([A-Za-z0-9][A-Za-z0-9._-]*)\s*\|\s*en\s*\|',line)
        if m:out.append(m.group(1))
    return out

def choose_packshot(set_id:str):
    url=f'{API}/{urllib.parse.quote(set_id)}/packshots?ref={BRANCH}'
    try:rows=request_json(url)
    except urllib.error.HTTPError as exc:
        if exc.code == 404:return set_id,None
        raise
    files=[r for r in rows if isinstance(r,dict) and r.get('type')=='file' and r.get('download_url')]
    webp=sorted((r for r in files if str(r.get('name','')).lower().endswith('.webp')),key=lambda r:str(r.get('name','')).lower())
    return set_id,(webp[0]['download_url'] if webp else None)

def download(url:str,dest:Path):
    dest.parent.mkdir(parents=True,exist_ok=True)
    fd,tmp=tempfile.mkstemp(prefix=dest.name+'.',dir=str(dest.parent));os.close(fd)
    try:
        with request(url,accept='image/webp,*/*') as response, open(tmp,'wb') as out:shutil.copyfileobj(response,out)
        if Path(tmp).stat().st_size<4096:raise RuntimeError(f'booster asset too small: {url}')
        Path(tmp).replace(dest)
    finally:
        try:Path(tmp).unlink()
        except FileNotFoundError:pass

def main():
    ids=english_set_ids(request_text(README))
    if not ids:raise SystemExit('No English set IDs found in booster artwork source')
    selected={}
    with ThreadPoolExecutor(max_workers=12) as pool:
        futures=[pool.submit(choose_packshot,set_id) for set_id in ids]
        for future in as_completed(futures):
            set_id,url=future.result()
            if url:selected[set_id]=url
    if 'base1' not in selected:raise SystemExit('Base Set packshot missing; refusing an incomplete LuckyDex build')
    ASSET_DIR.mkdir(parents=True,exist_ok=True)
    expected={f'{set_id}.webp' for set_id in selected}
    for stale in ASSET_DIR.glob('*.webp'):
        if stale.name not in expected:stale.unlink()
    with ThreadPoolExecutor(max_workers=8) as pool:
        jobs={pool.submit(download,url,ASSET_DIR/f'{set_id}.webp'):set_id for set_id,url in selected.items()}
        for future in as_completed(jobs):future.result()
    missing=[set_id for set_id in selected if not (ASSET_DIR/f'{set_id}.webp').exists()]
    if missing:raise SystemExit(f'Missing materialised booster art: {missing[:12]}')
    manifest={set_id:f'booster-art-v0260/{set_id}.webp' for set_id in sorted(selected)}
    MANIFEST.write_text(json.dumps(manifest,indent=2)+'\n',encoding='utf-8')
    base=ASSET_DIR/'base1.webp'
    if base.stat().st_size<4096:raise SystemExit('Base Set booster artwork failed integrity check')
    print(f'PASS local booster artwork: {len(manifest)} physical booster sets materialised into APK assets')

if __name__=='__main__':main()
