#!/usr/bin/env python3
"""Build LuckyDex's English physical-booster packshot URL index.

The source repository is intentionally not vendored (it is multi-GB). This
script indexes only packshot URLs during GitHub Actions so every booster set can
show its real wrapper without inflating the APK by hundreds of MB.
"""
from __future__ import annotations
import json, os, re, sys, urllib.request
from concurrent.futures import ThreadPoolExecutor, as_completed
from pathlib import Path

REPO='1niceroli/ptcg-assets'
BRANCH='main'
ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT/'app/src/main/assets/booster-art-index-v0259.json'
README=f'https://raw.githubusercontent.com/{REPO}/{BRANCH}/README.md'
API=f'https://api.github.com/repos/{REPO}/contents'
TOKEN=os.environ.get('GH_TOKEN') or os.environ.get('GITHUB_TOKEN') or ''
IMAGE_RE=re.compile(r'\.(?:png|jpe?g|webp)$',re.I)

def request_json(url:str):
    headers={'Accept':'application/vnd.github+json','User-Agent':'LuckyDex-booster-index-v0259'}
    if TOKEN: headers['Authorization']=f'Bearer {TOKEN}'
    with urllib.request.urlopen(urllib.request.Request(url,headers=headers),timeout=30) as response:
        return json.load(response)

def request_text(url:str):
    headers={'User-Agent':'LuckyDex-booster-index-v0259'}
    if TOKEN: headers['Authorization']=f'Bearer {TOKEN}'
    with urllib.request.urlopen(urllib.request.Request(url,headers=headers),timeout=30) as response:
        return response.read().decode('utf-8')

def english_set_ids(readme:str):
    block=readme.split('## English',1)[1].split('## Japanese',1)[0]
    ids=[]
    for line in block.splitlines():
        m=re.match(r'^\|\s*([A-Za-z0-9][A-Za-z0-9._-]*)\s*\|\s*en\s*\|',line)
        if m: ids.append(m.group(1))
    return ids

def packshots(set_id:str):
    url=f'{API}/{urllib.parse.quote(set_id)}/packshots?ref={BRANCH}'
    try: rows=request_json(url)
    except Exception as exc:
        # Sets without booster products legitimately have no packshots folder.
        return set_id,[],str(exc)
    urls=[]
    for row in rows if isinstance(rows,list) else []:
        name=str(row.get('name') or '')
        raw=row.get('download_url')
        if row.get('type')=='file' and raw and IMAGE_RE.search(name): urls.append(raw)
    return set_id,sorted(set(urls)),''

def main():
    # urllib.parse is referenced in worker after import here to keep imports tidy.
    global urllib
    import urllib.parse  # noqa: PLC0415
    ids=english_set_ids(request_text(README))
    if not ids: raise SystemExit('No English set IDs found in ptcg-assets README')
    result={}; errors=[]
    with ThreadPoolExecutor(max_workers=12) as pool:
        futures=[pool.submit(packshots,set_id) for set_id in ids]
        for future in as_completed(futures):
            set_id,urls,error=future.result()
            if urls: result[set_id]=urls
            elif error: errors.append((set_id,error))
    if 'base1' not in result or len(result['base1'])<3:
        raise SystemExit('Packshot index sanity check failed: Base Set artwork missing')
    OUT.write_text(json.dumps(dict(sorted(result.items())),indent=2,ensure_ascii=False)+'\n',encoding='utf-8')
    total=sum(map(len,result.values()))
    print(f'Wrote {OUT.relative_to(ROOT)}: {len(result)} sets / {total} packshots ({len(errors)} sets without indexed packshots)')

if __name__=='__main__': main()
