// Optional live audit against the same documented TCGdex set-detail endpoint.
const fs=require('node:fs'),path=require('node:path');
const {enrichSets}=require('../app/src/main/assets/pack-opening.js');
async function json(url){const r=await fetch(url,{signal:AbortSignal.timeout(10000)});if(!r.ok)throw Error(String(r.status));return r.json();}
(async()=>{
  const pocket=await json('https://api.tcgdex.net/v2/en/series/tcgp');
  const ids=new Set(pocket.sets.map(s=>s.id));
  const physical=(await json('https://api.tcgdex.net/v2/en/sets?sort:field=releaseDate&sort:order=DESC')).filter(s=>!ids.has(s.id)&&s.cardCount?.total>0);
  const audit={at:new Date().toISOString()};
  for(const [source,sets] of [['tcgp',pocket.sets],['tcg',physical.slice(0,12)]]){
    const ordered=await enrichSets(sets,{online:true,cached:()=>null,detail:id=>json('https://api.tcgdex.net/v2/en/sets/'+encodeURIComponent(id))});
    audit[source]=ordered.map(s=>({id:s.id,name:s.name,releaseDate:s.releaseDate||null}));
  }
  fs.mkdirSync(path.resolve(__dirname,'../artifacts'),{recursive:true});fs.writeFileSync(path.resolve(__dirname,'../artifacts/chronology-audit.json'),JSON.stringify(audit,null,2));
  console.log(JSON.stringify(audit,null,2));
})().catch(error=>{console.error(error.message);process.exitCode=1;});
