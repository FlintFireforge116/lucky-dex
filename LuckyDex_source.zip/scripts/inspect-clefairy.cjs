// Local visual/performance inspection; no external service dependencies.
const fs=require('node:fs'),http=require('node:http'),path=require('node:path');
let pw;try{pw=require('playwright');}catch(_){pw=require(require.resolve('playwright',{paths:['C:/Users/sjwal/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/node_modules']}));}
(async()=>{
  const assets=path.resolve(__dirname,'../app/src/main/assets'),out=path.resolve(__dirname,'../artifacts');fs.mkdirSync(out,{recursive:true});
  const server=http.createServer((req,res)=>{const file=path.join(assets,new URL(req.url,'http://local').pathname==='/'?'index.html':new URL(req.url,'http://local').pathname);fs.readFile(file,(err,data)=>{if(err){res.writeHead(404).end();return;}res.setHeader('Content-Type',file.endsWith('.js')?'application/javascript':file.endsWith('.css')?'text/css':file.endsWith('.png')?'image/png':'text/html');res.end(data);});});
  await new Promise(r=>server.listen(0,'127.0.0.1',r));const origin=`http://127.0.0.1:${server.address().port}`;
  const browser=await pw.chromium.launch({executablePath:process.env.CHROME_PATH||'C:/Program Files/Google/Chrome/Application/chrome.exe',headless:true}),context=await browser.newContext({viewport:{width:360,height:800},isMobile:true,hasTouch:true}),page=await context.newPage();
  await context.route('**/*',r=>r.request().url().startsWith(origin)?r.continue():r.fulfill({headers:{'access-control-allow-origin':'*'},json:{sets:[],results:[],pokemon:[]}}));
  try{
    await page.goto(origin);await page.evaluate(()=>{document.getElementById('titleScreen').classList.add('hidden-title');navigate('arcade');openArcadeGame('clefairy');});await page.evaluate(()=>clefairyScene.ready);
    const cdp=await context.newCDPSession(page);await cdp.send('Profiler.enable');await cdp.send('Profiler.start');
    const timings=await page.evaluate(async()=>{
      const times=[],start=performance.now();let running=true;
      function tick(t){times.push(t-start);if(running)requestAnimationFrame(tick);}requestAnimationFrame(tick);
      await LuckyDexDebug.playClefairyAction('star');running=false;return times;
    });
    const {profile}=await cdp.send('Profiler.stop'),counts=new Map();for(const id of profile.samples||[])counts.set(id,(counts.get(id)||0)+1);
    console.log('First STAR RAF timings:',timings.map(t=>t.toFixed(1)).join(','));
    console.log('CPU samples:',profile.nodes.map(n=>({function:n.callFrame.functionName,url:n.callFrame.url.split('/').at(-1),samples:counts.get(n.id)||0})).sort((a,b)=>b.samples-a.samples).slice(0,12));
    await page.screenshot({path:path.join(out,'clefairy-idle-360.png')});
    for(const [action,time] of [['star',540],['song',820],['moon',780],['spin',550]]){
      await page.evaluate(action=>{LuckyDexDebug.playClefairyAction(action);},action);await page.waitForTimeout(time);await page.screenshot({path:path.join(out,`clefairy-${action}-360.png`)});await page.evaluate(()=>LuckyDexDebug.playClefairyAction('idle'));
    }
    const bounds=await page.evaluate(()=>[...document.querySelectorAll('.clefairy-character,.clefairy-reflection,.clefairy-mirror,.clefairy-reflection .clefairy-motion')].map(e=>({class:e.className,style:getComputedStyle(e).cssText,rect:e.getBoundingClientRect().toJSON()})));console.log(JSON.stringify(bounds));
  }finally{await browser.close();await new Promise(r=>server.close(r));}
})();
