// Read-only verification against the extracted accepted v0.14 release.
const fs=require('node:fs'),path=require('node:path'),assert=require('node:assert/strict'),crypto=require('node:crypto');
let acorn;try{acorn=require('acorn');}catch(_){acorn=require('../.tools/acorn/package/dist/acorn.js');}
const baseline=process.argv[2];if(!baseline)throw Error('Pass the extracted v0.14 source directory.');
const relative='app/src/main/assets/',read=(root,file)=>fs.readFileSync(path.join(root,file),'utf8');
const oldJs=read(baseline,relative+'app-v013.js'),newJs=read('.',relative+'app-v013.js');
const legacy=name=>/^(?:resetMemoryGame|nextMemoryRound|flashMemorySequence|memoryTap|replayMemory|renderMemoryTrackV5|playClefairy|setClefairy|preloadClefairy|CLEFAIRY_|__memoryFlash)/.test(name||'');
function nonSceneNodes(source){return acorn.parse(source,{ecmaVersion:'latest'}).body.filter(n=>{
  if(n.type==='FunctionDeclaration')return !legacy(n.id.name)&&!['openArcadeGame','closeArcadeGame','navigate'].includes(n.id.name);
  if(n.type==='VariableDeclaration')return !n.declarations.every(d=>legacy(d.id.name));
  if(n.type==='ExpressionStatement'){
    const e=n.expression;if(e.type==='AssignmentExpression'&&legacy(e.left.name))return false;
    if(e.type==='CallExpression'&&(legacy(e.callee.name)||e.callee.name==='setTimeout'&&/setClefairy|resetBerryGame/.test(source.slice(n.start,n.end))))return false;
  }return true;
}).map(n=>source.slice(n.start,n.end));}
assert.deepEqual(nonSceneNodes(newJs),nonSceneNodes(oldJs),'A non-Clefairy application node changed');
// Every non-Clefairy markup section stays literal; new script/style includes and
// the next release version are the only changes outside the Clefairy panel.
const html=s=>s.replace(/<div id="clefairyGame"[\s\S]*?(?=<div id="berryGame")/,'CLEFAIRY_PANEL')
  .replace(/^.*(?:href="clefairy-scene.css"|src="clefairy-(?:scene|flow).js").*\r?\n/gm,'').replace(/v0\.15/g,'v0.14');
assert.equal(html(read('.',relative+'index.html')),html(read(baseline,relative+'index.html')));
const oldCss=read(baseline,relative+'styles-v013.css'),newCss=read('.',relative+'styles-v013.css');let rules=0;
for(const match of oldCss.matchAll(/[^{}]+\{[^{}]*\}/g)){
  const block=match[0],header=block.slice(0,block.indexOf('{')).replace(/\/\*[\s\S]*?\*\//g,'').trim();
  if(/(?:pack|card-art|card-dialog|sealed|lucky-pack|rare-card|tearPack)/i.test(header)){assert.ok(newCss.includes(header+block.slice(block.indexOf('{'))),'Pack CSS changed: '+header);rules++;}
}
const hash=p=>crypto.createHash('sha256').update(fs.readFileSync(p)).digest('hex');let files=0;
for(const file of ['pack-opening.js','pack-flow.js','pack-opening.css',...fs.readdirSync(path.join(baseline,relative)).filter(f=>/^clefairy_|^moon_stage_/.test(f))]){
  assert.equal(hash(path.join(baseline,relative,file)),hash(path.resolve(relative,file)),file);files++;
}
for(const file of ['tests/pack-opening.test.cjs','tests/browser-smoke.test.cjs'])assert.equal(hash(path.join(baseline,file)),hash(path.resolve(file)),file);
console.log(`Pack preservation verified: ${nonSceneNodes(newJs).length} non-Clefairy JS nodes, ${rules} pack CSS rules, markup, ${files} runtime/scene files, and both original test files.`);
