"""Offline native Emerald pixel vignettes, not canonical map screenshots.

Reuses the pinned, paired-bank Dash decoder without running its asset builder.
Only the Adventure catalog and its QA contact sheet are written.
"""
from pathlib import Path
import hashlib
import json
import struct
from PIL import Image, ImageDraw
from build_dash_gen3_assets import Decoder, SRC, PIN, layouts

ROOT = Path(__file__).resolve().parents[1]
ASSETS = ROOT / 'app/src/main/assets'
OUT = ASSETS / 'adventure/location-scenes'
QA = ROOT / 'artifacts/adventure-location-scenes'
DASH = json.loads((ASSETS / 'arcade/dash/gen3/manifest.json').read_text())
USED = set()
MAPS = {}


def digest(bytes_):
    return hashlib.sha256(bytes_).hexdigest()


def map_component(layout_name, rect, semantic):
    """Extract exactly the stated complete map rectangle, retaining both layers."""
    if layout_name not in MAPS:
        layout = next(l for l in layouts if l['name'] == layout_name + '_Layout')
        primary = layout['primary_tileset'].removeprefix('gTileset_')
        secondary = layout['secondary_tileset'].removeprefix('gTileset_')
        decoder = Decoder(primary, secondary)
        path = SRC / layout['blockdata_filepath']
        raw = path.read_bytes()
        ids = [v & 1023 for v in struct.unpack('<' + 'H' * (len(raw)//2), raw)]
        for p in decoder.paths:
            USED.update([p/'tiles.png', p/'metatiles.bin', p/'metatile_attributes.bin'])
        for i in range(16):
            USED.add(decoder.paths[0 if i < 6 else 1]/'palettes'/f'{i:02d}.pal')
        USED.add(path)
        MAPS[layout_name] = layout, decoder, ids
    layout, decoder, ids = MAPS[layout_name]
    x, y, w, h = rect
    assert x >= 0 and y >= 0 and x+w <= layout['width'] and y+h <= layout['height']
    rows = [ids[(y+j)*layout['width']+x:(y+j)*layout['width']+x+w] for j in range(h)]
    image = decoder.assemble(rows)
    return image, {'semantic': semantic, 'layout': layout_name, 'mapRect': list(rect),
                   'primaryTileset': decoder.primary, 'secondaryTileset': decoder.secondary,
                   'metatiles': rows, 'nativeSize': list(image.size), 'pixelSha256': digest(image.tobytes())}


def packaged(key, semantic=None):
    entry = DASH['sprites'][key]
    image = Image.open(ASSETS/entry['path']).convert('RGBA')
    assert digest(image.tobytes()) == entry['pixelSha256']
    # Carry the packaged sprite's original source evidence into this catalog.
    for relative in DASH['sources']['pret-pokeemerald']['sha256']:
        USED.add(SRC/relative)
    return image, {'semantic': semantic or key, 'packagedPath': entry['path'],
                   'nativeSize': list(image.size), 'pixelSha256': entry['pixelSha256']}


class Scene:
    def __init__(self, region, kind, name=None):
        self.id = name or region+'-'+kind
        self.region, self.kind = region, kind
        self.image = Image.new('RGBA', (384,160))
        self.components = []

    def place(self, component, x, y, columns=1, rows=1):
        image, evidence = component
        w, h = image.size
        assert x >= 0 and y >= 0 and x+w*columns <= 384 and y+h*rows <= 160, (self.id, evidence)
        for row in range(rows):
            for column in range(columns):
                self.image.alpha_composite(image, (x+column*w, y+row*h))
        self.components.append({**evidence, 'position': [x,y], 'repeat': [columns,rows],
                                'destinationSize': [w*columns,h*rows]})
        return self

    def tile(self, key, x=0, y=0, columns=24, rows=10):
        return self.place(packaged(key), x, y, columns, rows)

    def trees(self, key, coordinates):
        for x,y in coordinates:
            self.place(packaged(key, 'complete-tree'), x,y)
        return self

    def descriptor(self):
        return {'id': self.id, 'region': self.region, 'kind': self.kind,
                'path': 'adventure/location-scenes/'+self.id+'.png', 'width':384, 'height':160,
                'classification':'native-pixel-composition', 'canonicalMapScreenshot':False,
                'interpretation':'Gen III native-pixel place vignette; not an exact canonical map reconstruction',
                'pixelSha256':digest(self.image.tobytes()), 'components':self.components}


def house(): return map_component('PetalburgCity',(5,2,5,4),'complete-house')
def center(): return map_component('PetalburgCity',(19,13,4,4),'complete-center')
def mart(): return map_component('FortreeCity',(3,11,4,4),'complete-mart')
def facade(): return map_component('PetalburgCity',(12,4,6,5),'complete-gym-facade')
def treehouse(): return map_component('FortreeCity',(8,1,5,6),'complete-treehouse')
def stairway(): return map_component('MtPyre_1F',(9,0,5,2),'stairway')
def wall(): return map_component('MtPyre_1F',(14,0,1,2),'tower-wall')
def podium(): return map_component('MauvilleCity_Gym',(2,0,6,6),'complete-challenge-podium')
def shoreline(): return map_component('Route104',(14,67,1,1),'native-sand-shoreline')
def beach(): return map_component('Route104',(15,67,1,1),'native-beach-sand')
def ridge(): return map_component('GraniteCave_1F',(8,0,1,2),'rock-ridge')


def settlement(region, kind, name=None):
    s = Scene(region,kind,name).tile('route-grass')
    pine = 'pine' if region == 'johto' else 'tree'
    s.tile('shore-sand',0,112,24,1)
    if kind == 'town':
        if region == 'hoenn' and name is None:
            s.place(treehouse(),64,0).place(house(),240,32)
            s.tile('long-grass',304,128,3,2)
        else:
            s.place(house(),48,16).place(house(),256,32)
            s.tile('shore-sand',80,80,2,2).tile('shore-sand',288,96,2,1)
        s.trees(pine, [(0,0),(0,64),(352,0),(352,80),(160,0),(192,128)])
        s.place(packaged('sign'),144,96)
        if name:
            s.tile('flowers',32,128,3,1).tile('flowers',288,128,3,1)
    else:
        s.place(center(),32,32).place(facade(),144,16).place(mart(),288,48)
        s.tile('shore-sand',48,96,2,1).tile('shore-sand',176,96,2,1)
        s.place(packaged('sign'),256,112)
        s.trees(pine,[(0,0),(352,0),(0,128),(352,128)])
        if region == 'johto':
            s.tile('flowers',112,128,3,1)
        elif region == 'hoenn':
            s.tile('shore-water',0,144,24,1)
            s.tile('long-grass',112,128,3,1)
        else:
            s.tile('fence',112,144,10,1)
    if name == 'johto-cherrygrove-city':
        # Coastal service hub; keep the complete Center and Mart, replace Gym.
        s = Scene(region,kind,name).tile('route-grass')
        s.place(center(),64,16).place(mart(),176,32).place(house(),272,16)
        s.tile('shore-sand',32,96,22,2)
        s.tile('shore-water',0,0,2,10)
        s.trees('tree',[(32,0),(240,0),(352,128)])
        s.place(packaged('sign'),144,96)
        s.tile('flowers',96,128,4,1)
    elif name == 'johto-violet-city':
        s.tile('fence',112,144,10,1).place(packaged('sign'),112,96)
    return s


def landscape(region, kind, name=None):
    s = Scene(region,kind,name)
    pine = 'pine' if region == 'johto' else 'tree'
    if kind in ('route','forest'):
        s.tile('route-grass')
        if kind == 'route':
            y = {'kanto':64,'johto':80,'hoenn':96}[region]
            s.tile('shore-sand',0,y,24,2)
            s.tile('long-grass' if region == 'hoenn' else 'tall-grass',64,0,4,3)
            s.trees(pine,[(0,0),(32,16),(192,0),(224,16),(320,0),(352,16),(0,128),(32,128),(256,128),(352,128)])
            s.place(packaged('sign'),160,y-16)
            s.tile('flowers',144,128,3,1)
            if region == 'hoenn': s.tile('shore-water',128,0,3,3)
        else:
            s.tile('route-path',160,0,4,10)
            s.trees(pine,[(x,y) for y in [0,32,64,96,128] for x in [0,32,96,256,320,352]])
            s.tile('tall-grass',64,48,2,3)
            s.place(packaged('sign'),224,112)
    elif kind == 'coast':
        s.tile('shore-water')
        edge = {'kanto':112,'johto':144,'hoenn':176}[region]
        s.place(beach(),edge+16,0,(384-edge-16)//16,10)
        s.place(shoreline(),edge,0,1,10)
        s.trees(pine,[(320,0),(352,0),(352,96)])
        s.place(packaged('route-rock'),edge+32,112).place(packaged('sign'),edge+96,64)
        if region == 'hoenn':
            s.tile('bridge-floor',64,48,10,2)
            s.tile('bridge-rail',64,32,10,1)
    elif kind in ('cave','mountain'):
        s.tile('cave-floor' if kind == 'cave' else 'ash-floor')
        s.place(ridge(),0,0,24,1)
        if kind == 'cave':
            s.place(map_component('GraniteCave_1F',(35,2,1,2),'cave-ladder'),288,16)
            s.place(packaged('cave-rock'),80,64,2,1).place(packaged('cave-rock'),224,112)
            s.place(map_component('GraniteCave_1F',(10,5,5,4),'complete-rock-ledge'),144,48)
        else:
            s.tile('shore-sand',0,96,24,2)
            s.place(packaged('route-rock'),48,48,3,1).place(packaged('route-rock'),272,128,3,1)
            s.trees('pine',[(0,32),(352,32)])
            s.place(packaged('sign'),192,80)
    elif kind == 'tower':
        s.tile('mtpyre-floor').place(wall(),0,0,24,1).place(stairway(),152,0)
        s.place(packaged('column'),64,48).place(packaged('column'),304,48)
        s.place(packaged('column'),64,112).place(packaged('column'),304,112)
        if name: s.tile('lab-floor',128,128,8,2)
    elif kind == 'gym':
        s.tile('gym-floor')
        s.place(packaged('column'),48,32,1,3).place(packaged('column'),320,32,1,3)
        s.tile('mossdeep-floor',128,48,8,5)
        s.place(packaged('mossdeep-pad'),184,80)
        s.place(packaged('sign'),184,128)
    elif kind == 'league':
        s.tile('gym-floor').place(podium(),144,0)
        s.tile('stone-floor',160,96,4,4)
        s.place(packaged('column'),48,32,1,3).place(packaged('column'),320,32,1,3)
        s.tile('mossdeep-floor',80,128,4,2).tile('mossdeep-floor',240,128,4,2)
    else:
        raise ValueError(kind)
    return s


def all_scenes():
    scenes = []
    for region in ['kanto','johto','hoenn']:
        for kind in ['town','city','route','forest','cave','tower','coast','mountain','gym','league']:
            scenes.append(settlement(region,kind) if kind in ('town','city') else landscape(region,kind))
    scenes += [settlement('johto','town','johto-new-bark-town'),
               settlement('johto','city','johto-cherrygrove-city'),
               settlement('johto','city','johto-violet-city'),
               landscape('johto','tower','johto-sprout-tower')]
    return scenes


def build():
    OUT.mkdir(parents=True,exist_ok=True)
    QA.mkdir(parents=True,exist_ok=True)
    scenes = all_scenes()
    entries = {}
    for s in scenes:
        assert s.image.getchannel('A').getextrema() == (255,255), s.id
        path = OUT/(s.id+'.png')
        s.image.save(path,optimize=True)
        entries[s.id] = {**s.descriptor(),'fileSha256':digest(path.read_bytes())}
    USED.update(SRC/p for p in ['data/layouts/layouts.json','src/data/tilesets/graphics.h','include/fieldmap.h','src/fieldmap.c'])
    named = {'johto':{'New Bark Town':'johto-new-bark-town','Cherrygrove City':'johto-cherrygrove-city',
                      'Violet City':'johto-violet-city','Sprout Tower':'johto-sprout-tower'}}
    manifest = {'schema':1,'scenes':entries,
                'categories':{region:{kind:region+'-'+kind for kind in ['town','city','route','forest','cave','tower','coast','mountain','gym','league']} for region in ['kanto','johto','hoenn']},
                'named':named,'places':{key:key for key in named['johto'].values()},
                'source':{'repository':'https://github.com/pret/pokeemerald','commit':PIN,
                          'cache':'data/dash-gen3/upstream/pokeemerald-'+PIN,
                          'sha256':{p.relative_to(SRC).as_posix():digest(p.read_bytes()) for p in sorted(USED)}}}
    (OUT/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n',encoding='utf8')
    js = '(function(root){"use strict";const catalog='+json.dumps(manifest,separators=(',',':'))+';root.LuckyDexLocationScenes=catalog;root.LuckyDexAdventureLocationScenes=catalog;if(typeof module!=="undefined"&&module.exports)module.exports=catalog;})(typeof window!=="undefined"?window:globalThis);\n'
    (ASSETS/'adventure-location-scenes.js').write_text(js,encoding='utf8')
    sheet = Image.new('RGBA',(384*3,184*12),(237,235,222,255))
    draw = ImageDraw.Draw(sheet)
    for i,s in enumerate(scenes):
        x,y = (i%3)*384,(i//3)*184
        sheet.alpha_composite(s.image,(x,y))
        draw.text((x+4,y+164),s.id,fill='black')
    sheet.save(QA/'contact-sheet.png')
    print(f'Built {len(scenes)} native-pixel 384x160 Adventure vignettes; preserved Dash/source cache.')


if __name__ == '__main__':
    build()
