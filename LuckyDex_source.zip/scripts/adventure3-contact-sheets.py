from pathlib import Path
from PIL import Image,ImageDraw
R=Path(__file__).resolve().parents[1];folder=R/'artifacts/v0400/screens'
for size in ['360x640','412x915','768x1024']:
    paths=sorted(folder.glob(size+'-*.png'));thumb=(270,480 if size=='360x640' else 600 if size=='412x915' else 360)
    sheet=Image.new('RGB',(4*(thumb[0]+12),4*(thumb[1]+30)),(230,235,211));d=ImageDraw.Draw(sheet)
    for i,p in enumerate(paths):
        im=Image.open(p).convert('RGB');im.thumbnail(thumb,Image.Resampling.LANCZOS);x=(i%4)*(thumb[0]+12)+6;y=(i//4)*(thumb[1]+30)+23;sheet.paste(im,(x,y));d.text((x,y-17),p.stem[len(size)+1:],fill=(30,53,40))
    sheet.save(folder/('contact-'+size+'.png'))
