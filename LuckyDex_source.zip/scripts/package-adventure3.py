from pathlib import Path
import zipfile,json,hashlib
R=Path(__file__).resolve().parents[1];Z=R.parent/'LuckyDex_source_v0.40.0.zip';V=R.parent/'LuckyDex_v0.40.0_verified_final'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
scratch={'refactor-wild-hunt-v040.py','integrate-adventure3.py'}
def selected(p):
    rel=p.relative_to(R).as_posix();parts=rel.split('/')
    if any(x in {'.git','.gradle','node_modules','__pycache__','build','cache','caches','qa'} for x in parts):return False
    if p.name in scratch or p.name=='local.properties' or p.suffix in {'.apk','.pyc'}:return False
    if parts[0]=='artifacts':
        return rel.startswith('artifacts/v0400/') and p.name!='baseline-app.js' or rel.startswith('artifacts/v0400-apk-')
    return True
files=sorted(p for p in R.rglob('*') if p.is_file() and selected(p))
with zipfile.ZipFile(Z,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
    for p in files:z.write(p,p.relative_to(R).as_posix())
V.mkdir(exist_ok=True)
with zipfile.ZipFile(Z) as z:
    assert z.testzip() is None
    for name in z.namelist():
        assert (V/name).resolve().is_relative_to(V.resolve()),name
        assert (R/name).read_bytes()==z.read(name),'source ZIP drift: '+name
    z.extractall(V)
    for name in z.namelist():assert (V/name).read_bytes()==z.read(name),'extraction drift: '+name
    with zipfile.ZipFile(R/'artifacts/LuckyDex-v0.40.0-debug.apk') as apk:
        assets=list(p for p in (V/'app/src/main/assets').rglob('*') if p.is_file())
        for p in assets:assert apk.read('assets/'+p.relative_to(V/'app/src/main/assets').as_posix())==p.read_bytes(),'APK/ZIP mismatch: '+str(p)
report={'zip':Z.name,'zipBytes':Z.stat().st_size,'zipSha256':sha(Z),'sourceFiles':len(files),'allExtractedAssetsMatchApk':len(assets),'freshExtraction':str(V),'excluded':'Git, node_modules, Gradle/build caches, local SDK properties, scratch scripts, inherited/scratch QA and APKs'}
(R.parent/'LuckyDex_v0.40.0_package-verification.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8')
print(json.dumps(report,indent=2))
