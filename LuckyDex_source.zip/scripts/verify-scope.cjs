// Read-only comparison with the original extracted handoff. The preserved
// functions and scene assets must match exactly; no runtime test scaffolding.
const fs=require('node:fs'),path=require('node:path'),assert=require('node:assert/strict'),crypto=require('node:crypto');
let acorn;try{acorn=require('acorn');}catch(_){acorn=require('../.tools/acorn/package/dist/acorn.js');}
const baseline=process.argv[2];if(!baseline)throw Error('Pass the original extracted handoff directory.');
const relative='app/src/main/assets/';
const original=fs.readFileSync(path.join(baseline,relative,'app-v013.js'),'utf8');
const current=fs.readFileSync(path.resolve(relative,'app-v013.js'),'utf8');
const sceneNode=node=>{
  if(node.type==='FunctionDeclaration')return /clefairy|memory/i.test(node.id.name);
  if(node.type==='VariableDeclaration')return node.declarations.some(d=>/clefairy|memory|__memoryFlash/i.test(d.id.name));
  if(node.type==='ExpressionStatement'&&node.expression.type==='AssignmentExpression')return /clefairy|memory/i.test(node.expression.left.name||'');
  return false;
};
const nodes=source=>acorn.parse(source,{ecmaVersion:'latest'}).body.filter(sceneNode).map(n=>source.slice(n.start,n.end));
assert.deepEqual(nodes(current),nodes(original));
let checked=0;
for(const file of fs.readdirSync(path.join(baseline,relative)).filter(f=>/^clefairy_|^moon_stage_/.test(f))){
  const hash=p=>crypto.createHash('sha256').update(fs.readFileSync(p)).digest('hex');
  assert.equal(hash(path.join(baseline,relative,file)),hash(path.resolve(relative,file)));checked++;
}
// Named Clefairy rule blocks are retained literally, including keyframes.
const oldCss=fs.readFileSync(path.join(baseline,relative,'styles-v013.css'),'utf8'),newCss=fs.readFileSync(path.resolve(relative,'styles-v013.css'),'utf8');
const starts=[...oldCss.matchAll(/(?:\.[\w:# .>-]*?(?:clefairy|moonstage|memory)[^{}]*|@keyframes\s+(?:moon|clefairy|spinSprite|spinReflection|shootingStar|songFloat|starAction|songAction|moonAction|spinAction)[\w]*)\s*\{/gi)];
let rules=0;
for(const match of starts){let end=match.index+match[0].length,depth=1;while(end<oldCss.length&&depth){if(oldCss[end]==='{')depth++;if(oldCss[end]==='}')depth--;end++;}const block=oldCss.slice(match.index,end);assert.ok(newCss.includes(block),'Changed scene CSS: '+match[0]);rules++;}
const oldHtml=fs.readFileSync(path.join(baseline,relative,'index.html'),'utf8'),newHtml=fs.readFileSync(path.resolve(relative,'index.html'),'utf8');
const scene=source=>source.match(/<div id="clefairyGame"[\s\S]*?(?=<div id="berryGame")/)[0];assert.equal(scene(newHtml),scene(oldHtml));
console.log(`Scope verified: ${nodes(current).length} Clefairy/memory JS nodes, ${checked} scene assets, ${rules} CSS blocks, and Clefairy HTML unchanged.`);
