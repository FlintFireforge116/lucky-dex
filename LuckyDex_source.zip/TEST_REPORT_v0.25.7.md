# LuckyDex v0.25.7 verification report

Fresh verification on the v0.25.7 source tree:

- 68 Node test programs checked.
- 53 runnable tests passed.
- 0 runnable failures.
- 15 Playwright/browser tests skipped because the Playwright package is not installed in this local workspace.
- All 23 top-level asset JavaScript files pass `node --check`.
- v0.25.7 asset provenance manifest parses successfully.
- 42 manifest entries exist locally.
- 41 sourced sprites match their recorded upstream Git blob SHA exactly; the remaining TCG-card file is the explicit runtime placeholder.
- Active Fossil Dig / Museum catalogue uses only `arcade/fossil-museum-v0257/items/`.
- applicationId remains `com.example.luckydex`.
- versionCode / versionName are `257` / `0.25.7`.
- permanent keystore SHA256 remains `90de91cea469f0eec5fbd69389cf03adc94ced396fa2ec85e2a51d2365a4f6d3`.
