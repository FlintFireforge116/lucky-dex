const assert=require('node:assert/strict'),fs=require('fs'),path=require('path'),crypto=require('crypto'),root=path.resolve(__dirname,'..'),baseline=require('./adventure3-preservation-baseline.json');
for(const [name,hash] of Object.entries(baseline))assert.equal(crypto.createHash('sha256').update(fs.readFileSync(path.join(root,name))).digest('hex'),hash,'unchanged supplied v0.39.1 file: '+name);
console.log('PASS '+Object.keys(baseline).length+' original offline/Arcade/pack/card/Dust/trade/achievement/Android identity files preserved byte for byte');
