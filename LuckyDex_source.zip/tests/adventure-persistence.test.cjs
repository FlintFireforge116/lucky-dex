'use strict';
const assert=require('node:assert/strict');
const {launch,appPage}=require('../scripts/recovery-browser.cjs');
const M=require('../app/src/main/assets/adventure/adventure-model.js');
const B=require('../app/src/main/assets/adventure/adventure-battle.js');
const partner={key:'7:n',id:7,name:'Squirtle',level:12,types:['water'],maxHp:90,baseStats:{hp:44,attack:48,defense:65,speed:43},shiny:false};
function baseSave(run,overrides={}) {
  return {
    saveVersion:6,settings:{zone:'meadow',vibration:false,reducedMotion:true},
    profile:{coins:2000,xp:19600,tickets:4,firstClears:{},rankRewards:[]},
    inventory:{pokeball:5,greatball:5,ultraball:5,berry:5,potion:5},
    pokemon:{'7:n':{...partner,name:'squirtle',count:1,xp:0,generation:1,firstSeen:123,lastZone:'meadow'}},team:['7:n'],
    adventureV2:{schema:1,destinations:{},activeExpedition:run,activeRoam:null,lastDestination:'meadow',legacySeeded:true,custom:'v2-keep'},
    custom:{sentinel:'preserve'},...overrides
  };
}
function atNode(type,eventId) {
  const run=M.createRun('meadow','persistence:'+type,[partner]);
  const node=run.route.nodes.find(n=>n.depth===(type==='camp'?4:2));
  node.type=type;if(eventId)node.content={eventId};
  run.currentNode=node.id;run.pending={nodeId:node.id,type};run.phase=type==='camp'?'camp':type==='cache'?'cache':'event';run.custom={sentinel:'run-keep'};
  return {run,node};
}
function fightRun(enemyHp=200,seed=33) {
  const run=M.createRun('meadow','battle-persistence',[partner]);
  const node=run.route.nodes.find(n=>n.depth===1);
  M.enterNode(run,node.id);
  run.battle=B.create([{...partner,hp:20}],{id:19,name:'Rattata',level:2,types:['normal'],tier:'normal',shiny:false,maxHp:200,baseStats:{hp:30,attack:1,defense:35,speed:72}},{context:'expedition',destination:'meadow',seed});
  run.battle.enemy.hp=enemyHp;run.hpByKey[partner.key]=20;run.custom={sentinel:'battle-keep'};
  return run;
}
function completedRun(seed='completed',earned=0) {
  const run=M.createRun('meadow',seed,[partner]);
  let id='start';while(id!=='boss'){id=run.route.nodes.find(n=>n.id===id).links[0];run.completed.push(id);}
  run.currentNode='boss';run.phase='complete';run.loot.rooms=7;run.loot.coins=earned;run.custom={sentinel:'clear-keep'};
  return run;
}
async function saved(page) {return page.evaluate(()=>JSON.parse(localStorage.getItem('luckyDexSave')));}
async function resume(page) {await page.reload({waitUntil:'load'});await page.locator('#titleContinueBtn').tap();}
async function openFixture(browser,fixture,errors) {
  // Install before startup once per new context. Reload keeps the real saved
  // transaction rather than silently replacing it with the original fixture.
  const init=`if(!sessionStorage.getItem('adventure-fixture-installed')){localStorage.setItem('luckyDexSave',${JSON.stringify(JSON.stringify(fixture))});sessionStorage.setItem('adventure-fixture-installed','1');}`;
  const result=await appPage(browser,{width:393,height:873},errors,{init});
  await result.page.locator('#titleContinueBtn').tap();
  return result;
}
(async()=>{
  const browser=await launch(),errors=[];
  try {
    // A wrong reward branch, missing resolution flag or early save breaks this.
    for(const eventId of ['meadow-lost-catcher','meadow-beedrill-nest']) {
      const {run,node}=atNode('event',eventId),fixture=baseSave(run),{page,context}=await openFixture(browser,fixture,errors);
      const choice=eventId==='meadow-lost-catcher'?'safe':'capability';
      assert.equal(await page.locator('[data-adv-view="event"]').isVisible(),true);
      if(choice==='safe') {
        assert.equal(await page.locator('[data-adv-action="event"][data-choice="capability"]').isDisabled(),true);
        await page.evaluate(()=>LuckyDexAdventure.resolveEvent('capability'));
        assert.equal((await saved(page)).adventureV2.activeExpedition.resolutions[node.id],undefined);
      }
      await page.locator(`[data-adv-action="event"][data-choice="${choice}"]`).tap();
      const once=await saved(page),outcome=once.adventureV2.activeExpedition.resolutions[node.id].outcome;
      assert.equal(once.profile.coins,fixture.profile.coins+(outcome.coins||0));
      assert.equal(once.profile.xp,fixture.profile.xp+(outcome.xp||0));
      if(choice==='capability'){assert.equal(once.inventory.berry,4);assert.equal(once.inventory.pokeball,6);}
      await page.evaluate(choice=>{LuckyDexAdventure.resolveEvent(choice);LuckyDexAdventure.resolveEvent('risk');},choice);
      assert.deepEqual((await saved(page)).profile,once.profile);assert.deepEqual((await saved(page)).inventory,once.inventory);
      await resume(page);
      const reload=await saved(page);
      assert.deepEqual(reload.profile,once.profile);assert.deepEqual(reload.inventory,once.inventory);assert.deepEqual(reload.adventureV2.activeExpedition.resolutions,once.adventureV2.activeExpedition.resolutions);
      assert.deepEqual(reload.adventureV2.activeExpedition.route,run.route);assert.deepEqual(reload.adventureV2.activeExpedition.custom,{sentinel:'run-keep'});
      assert.equal(await page.locator('[data-adv-action="event"]').count(),0);
      await page.locator('[data-adv-action="next"]').tap();
      assert.equal((await saved(page)).adventureV2.activeExpedition.completed.filter(id=>id===node.id).length,1);
      await context.close();
    }
    console.log('PASS events: gates, coin/item effects once, saved outcome and exact route reload');

    // Removing the rest flag, replaying an offer or implicit replacement breaks these.
    {
      const {run,node}=atNode('camp');run.hpByKey[partner.key]=30;run.perks=['fieldMedic'];
      const {page,context}=await openFixture(browser,baseSave(run),errors);
      await page.locator('[data-adv-action="rest"]').tap();
      const once=await saved(page);assert.equal(once.adventureV2.activeExpedition.hpByKey[partner.key],75);assert.equal(once.adventureV2.activeExpedition.resolutions[node.id].rested,true);
      await page.evaluate(()=>LuckyDexAdventure.rest());await resume(page);
      assert.equal((await saved(page)).adventureV2.activeExpedition.hpByKey[partner.key],75);assert.equal(await page.locator('[data-adv-action="rest"]').isDisabled(),true);
      await page.locator('[data-adv-action="camp-potion"]').tap();
      const potion=await saved(page);assert.equal(potion.inventory.potion,4);assert.equal(potion.adventureV2.activeExpedition.hpByKey[partner.key],90);
      await resume(page);assert.equal((await saved(page)).inventory.potion,4);assert.equal((await saved(page)).adventureV2.activeExpedition.hpByKey[partner.key],90);
      await context.close();
    }
    {
      const run=M.createRun('meadow','cache-full',[partner]),opening=run.route.nodes.find(n=>n.depth===1),cache=run.route.nodes.find(n=>n.depth===2);
      M.enterNode(run,opening.id);M.completeNode(run,opening.id);run.perks=['compass','potionBelt','luckyCharm'];
      cache.type='cache';cache.content={coins:30,xp:8,items:{berry:1},perkIds:['berrySatchel','fieldMedic']};
      const {page,context}=await openFixture(browser,baseSave(run),errors);
      await page.locator(`[data-adv-node="${cache.id}"]`).tap();
      const once=await saved(page);assert.equal(once.profile.coins,2030);assert.equal(once.inventory.berry,6);
      await page.evaluate(id=>LuckyDexAdventure.chooseNode(id),cache.id);await resume(page);
      assert.equal((await saved(page)).profile.coins,2030);assert.equal((await saved(page)).inventory.berry,6);
      assert.deepEqual((await saved(page)).adventureV2.activeExpedition.perkOffer,once.adventureV2.activeExpedition.perkOffer);
      await page.locator('[data-adv-action="perk"][data-perk="berrySatchel"]').tap();
      assert.deepEqual((await saved(page)).adventureV2.activeExpedition.perks,['compass','potionBelt','luckyCharm']);
      await page.locator('[data-adv-action="replace"][data-perk="compass"]').tap();
      const chosen=await saved(page);assert.deepEqual(chosen.adventureV2.activeExpedition.perks,['berrySatchel','potionBelt','luckyCharm']);assert.equal(chosen.adventureV2.activeExpedition.perkOffer.resolved,true);
      await resume(page);await page.evaluate(()=>LuckyDexAdventure.keepPerk('fieldMedic','potionBelt'));
      assert.deepEqual((await saved(page)).adventureV2.activeExpedition.perks,chosen.adventureV2.activeExpedition.perks);assert.equal((await saved(page)).profile.coins,2030);
      await context.close();
    }
    console.log('PASS camp/cache: once-only healing, potion persistence, cached reward/offer and explicit perk replacement');

    // Saving after cosmetics, missing HP propagation or replaying a terminal action breaks these.
    {
      const run=fightRun(),fixture=baseSave(run);fixture.settings.reducedMotion=false;
      const {page,context}=await openFixture(browser,fixture,errors);
      await page.locator('[data-adv-command="battle-bag"]').tap();await page.locator('[data-adv-battle="potion"]').tap();
      const once=await saved(page),fight=once.adventureV2.activeExpedition.battle;
      assert.equal(once.inventory.potion,4);assert.equal(fight.actionSeq,1);assert.ok(fight.party[0].hp>20);assert.equal(once.adventureV2.activeExpedition.hpByKey[partner.key],fight.party[0].hp);
      await resume(page);
      const reload=await saved(page);assert.equal(reload.inventory.potion,4);assert.equal(reload.adventureV2.activeExpedition.battle.actionSeq,1);assert.equal(reload.adventureV2.activeExpedition.battle.rng,fight.rng);assert.deepEqual(reload.adventureV2.activeExpedition.hpByKey,once.adventureV2.activeExpedition.hpByKey);assert.equal(reload.adventureV2.activeExpedition.battle.enemy.hp,fight.enemy.hp);
      await context.close();
    }
    for(const capture of [false,true]) {
      const run=fightRun(1,1),{page,context}=await openFixture(browser,baseSave(run),errors);
      if(capture){await page.locator('[data-adv-command="battle-bag"]').tap();await page.locator('[data-adv-battle="ball"][data-key="pokeball"]').tap();}
      else await page.locator('[data-adv-battle="quick"]').tap();
      await page.waitForFunction(()=>!LuckyDexAdventure.snapshot().busy);
      const once=await saved(page),fight=once.adventureV2.activeExpedition.battle;
      assert.equal(fight.result.kind,capture?'capture':'victory');assert.equal(fight.rewardClaimed,true);assert.equal(once.adventureV2.activeExpedition.loot.battles,1);
      if(capture){assert.equal(once.stats.ballsThrown,1);assert.equal(once.stats.catches,1);assert.equal(once.inventory.pokeball,4);assert.equal(once.pokemon['19:n'].count,1);assert.deepEqual(once.adventureV2.activeExpedition.partyKeys,['7:n']);assert.equal(once.adventureV2.activeExpedition.loot.catches.length,1);}
      else{assert.equal(once.stats.battlesWon,1);assert.equal(once.profile.coins,2016);}
      await page.evaluate(capture=>LuckyDexAdventure.act(capture?'ball':'quick',capture?{key:'pokeball'}:{}),capture);
      await resume(page);const reload=await saved(page);assert.deepEqual(reload.profile,once.profile);assert.deepEqual(reload.inventory,once.inventory);assert.deepEqual(reload.pokemon,once.pokemon);assert.equal(reload.adventureV2.activeExpedition.loot.battles,1);
      await page.locator('[data-adv-action="battle-next"]').tap();assert.equal((await saved(page)).adventureV2.activeExpedition.loot.rooms,1);
      await page.evaluate(()=>LuckyDexAdventure.next());assert.equal((await saved(page)).adventureV2.activeExpedition.loot.rooms,1);
      await context.close();
    }
    console.log('PASS battles: item/action commits before animation, exact HP/RNG reload, terminal victory/capture reward once');

    // A missing legacy first-clear guard or adding the loot ledger again breaks these.
    {
      const run=completedRun('clear-first',77),fixture=baseSave(run);fixture.profile.coins=2077;
      const {page,context}=await openFixture(browser,fixture,errors),once=await saved(page);
      assert.equal(once.profile.coins,2577);assert.equal(once.profile.xp,19900);assert.equal(once.profile.tickets,5);assert.equal(once.profile.firstClears.meadow,true);assert.equal(once.stats.adventureClears,1);assert.equal(once.adventureV2.destinations.meadow.clears,1);assert.equal(once.adventureV2.destinations.meadow.boss,true);assert.equal(once.adventureV2.lastRun.claimed,true);assert.equal(once.adventureV2.lastRun.loot.coins,577);assert.equal(once.adventureV2.activeExpedition,null);
      assert.equal(once.inventory.pokeball,8);assert.equal(once.inventory.berry,7);assert.equal(once.inventory.potion,6);
      await resume(page);assert.deepEqual((await saved(page)).profile,once.profile);assert.equal((await saved(page)).stats.adventureClears,1);
      const second=completedRun('clear-second');
      await page.evaluate(run=>{state.adventureV2.activeExpedition=run;LuckyDexAdventureBridge.save();LuckyDexAdventure.enter();},second);
      const twice=await saved(page);assert.equal(twice.profile.coins,3077);assert.equal(twice.profile.tickets,5);assert.equal(twice.stats.adventureClears,2);assert.equal(twice.adventureV2.lastRun.firstTicket,false);
      await resume(page);assert.deepEqual((await saved(page)).profile,twice.profile);
      await context.close();
    }
    {
      const run=M.createRun('meadow','retreat-earned',[partner]);run.loot.coins=42;run.loot.xp=25;run.loot.items.berry=1;run.loot.catches.push({id:25,name:'Pikachu',shiny:false});
      const fixture=baseSave(run);fixture.profile.coins=2042;fixture.profile.xp=19625;fixture.inventory.berry=6;fixture.pokemon['25:n']={id:25,name:'pikachu',count:1,level:3,xp:0,shiny:false,types:['electric'],baseStats:{hp:35,attack:55,defense:40,speed:90}};
      const {page,context}=await openFixture(browser,fixture,errors);
      await page.locator('[data-adv-action="retreat"]').tap();await page.locator('[data-adv-action="confirm-retreat"]').tap();
      const ended=await saved(page);assert.equal(ended.profile.coins,2042);assert.equal(ended.profile.xp,19625);assert.equal(ended.profile.tickets,4);assert.equal(ended.inventory.berry,6);assert.equal(ended.pokemon['25:n'].count,1);assert.equal(ended.stats.adventureClears,0);assert.equal(ended.profile.firstClears.meadow,undefined);assert.equal(ended.adventureV2.activeExpedition,null);assert.equal(ended.adventureV2.lastRun.phase,'retreated');assert.equal(ended.adventureV2.lastRun.loot.coins,42);assert.equal(ended.stats.expeditionRetreats,1);
      await resume(page);assert.deepEqual((await saved(page)).profile,ended.profile);assert.equal((await saved(page)).inventory.berry,6);assert.equal((await saved(page)).stats.expeditionRetreats,1);
      await context.close();
    }
    console.log('PASS clear/retreat: final rewards and first ticket once, retained earned loot with no forfeit reward');
    assert.deepEqual(errors,[]);
  } finally {await browser.close();}
})().catch(error=>{console.error(error);process.exit(1);});
