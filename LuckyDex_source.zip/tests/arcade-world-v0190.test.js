const assert=require('assert');
const fs=require('fs');
const path=require('path');
const root=path.join(__dirname,'..');
const modPath=path.join(root,'app/src/main/assets/arcade-world-v0190.js');
assert.strictEqual(fs.existsSync(modPath),true,'v0.19 world module must exist');
const world=require(modPath);
assert.strictEqual(world.VENUES.length,8);
assert.strictEqual(new Set(world.VENUES.flatMap(v=>v.games)).size,10);
assert.strictEqual(world.venueForGame('ditto'),null);
assert.strictEqual(world.venueForGame('safari'),null);
for(const v of world.VENUES){
  assert.ok(v.art.startsWith('arcade/venues-v0190/'));
  const p=path.join(root,'app/src/main/assets',v.art);
  assert.ok(fs.existsSync(p)&&fs.statSync(p).size>1000,`missing substantial art ${v.art}`);
}
assert.strictEqual(world.migrateLegacyVenue('amie'),'amieGarden');
assert.strictEqual(world.migrateLegacyVenue('performance'),'lilycoveContest');
const css=fs.readFileSync(path.join(root,'app/src/main/assets/arcade-world-v0190.css'),'utf8');
assert.match(css,/\.arcade-world-stop[^}]*flex:\s*0\s+0\s+min\(88vw,\s*520px\)/s,'world stops should occupy most of a phone viewport');
assert.match(css,/scroll-snap-type:\s*x\s+mandatory/);
assert.doesNotMatch(css,/grid-template-columns:\s*repeat\(8/);
const src=fs.readFileSync(modPath,'utf8');
assert.match(src,/world-route-ribbon/);
assert.match(src,/focusVenueId/);
console.log('PASS v0.19 continuous world route/assets/hierarchy');
