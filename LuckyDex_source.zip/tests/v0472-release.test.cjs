const test=require('node:test');
const assert=require('node:assert/strict');
const fs=require('node:fs');
const path=require('node:path');
const ROOT=path.join(__dirname,'..');
const read=p=>fs.readFileSync(path.join(ROOT,p),'utf8');

test('v0.47.2 release identity is consistent',()=>{
  const pkg=JSON.parse(read('package.json'));
  const lock=JSON.parse(read('package-lock.json'));
  const gradle=read('app/build.gradle');
  const app=read('app/src/main/assets/app-v0167.js');
  const html=read('app/src/main/assets/index.html');
  assert.equal(pkg.version,'0.47.2');
  assert.equal(lock.version,'0.47.2');
  assert.equal(lock.packages[''].version,'0.47.2');
  assert.match(gradle,/versionCode\s+4702\b/);
  assert.match(gradle,/versionName\s+'0\.47\.2'/);
  assert.match(gradle,/LuckyDex-asset-builder\/0\.47\.2/);
  assert.match(app,/__LUCKYDEX_BUILD='0\.47\.2'/);
  assert.equal((html.match(/v0\.47\.2/g)||[]).length,2);
});
