'use strict';
const test=require('node:test');
const assert=require('node:assert/strict');
const fs=require('node:fs');
const path=require('node:path');
const root=path.resolve(__dirname,'..');
const asset=name=>path.join(root,'app/src/main/assets',name);
const read=name=>fs.readFileSync(asset(name),'utf8');
function fresh(name){const p=asset(name);delete require.cache[require.resolve(p)];return require(p);}
function seq(values){let i=0;return()=>values[(i++)%values.length];}

test('Clear Cut core creates a five-log four-cutter match with cosmetic cutter choice',()=>{
  assert.equal(fs.existsSync(asset('arcade-clear-cut-core.js')),true,'Clear Cut core asset must exist');
  const core=fresh('arcade-clear-cut-core.js');
  assert.equal(core.CONFIG.rounds,5);
  assert.deepEqual(core.CUTTERS.map(x=>x.dex),[123,127,212]);
  const match=core.createMatch({difficulty:'normal',playerDex:212,rng:seq([.2,.8,.4,.6,.3,.7]),nowMs:1000});
  assert.equal(match.logs.length,5);
  assert.equal(match.racers.length,4);
  assert.equal(match.player.species.dex,212);
  assert.ok(match.racers.slice(1).every(r=>[123,127,212].includes(r.species.dex)));
  assert.deepEqual(match.racers.map(r=>r.label),['YOU','COM 1','COM 2','COM 3']);
});

test('Clear Cut precision score is continuous, asymmetric and clamps from -10 to 20',()=>{
  const core=fresh('arcade-clear-cut-core.js');
  assert.deepEqual(core.scoreCut(0),{score:20,judgement:'PERFECT'});
  assert.equal(core.scoreCut(1.5).score,20);
  assert.equal(core.scoreCut(4).score,17);
  assert.ok(core.scoreCut(-10).score<core.scoreCut(10).score,'early/high-side cut must be punished more strongly');
  assert.equal(core.scoreCut(-100).score,-10);
  assert.equal(core.scoreCut(100).score,-10);
  assert.equal(core.judgementForScore(19),'GREAT');
  assert.equal(core.judgementForScore(16),'GOOD');
  assert.equal(core.judgementForScore(8),'CLOSE');
  assert.equal(core.judgementForScore(4),'MISS');
});

test('Clear Cut difficulty changes motion and CPU accuracy, never the scoring formula',()=>{
  const core=fresh('arcade-clear-cut-core.js');
  const easy=core.difficultyProfile('easy'),normal=core.difficultyProfile('normal'),hard=core.difficultyProfile('hard');
  assert.ok(hard.durationMinMs<normal.durationMinMs&&normal.durationMinMs<easy.durationMinMs);
  assert.ok(hard.cpuErrorMs<normal.cpuErrorMs&&normal.cpuErrorMs<easy.cpuErrorMs);
  for(const d of ['easy','normal','hard'])assert.equal(core.scoreCut(-12,d).score,core.scoreCut(-12).score);
});

test('Clear Cut CPU cuts route through the same error and scoring model',()=>{
  const core=fresh('arcade-clear-cut-core.js');
  const log=core.generateLog({difficulty:'normal',roundIndex:0,rng:seq([.3,.7,.4,.6]),startAt:1000});
  const out=core.simulateCpuCut(log,'normal',seq([.9,.2,.7,.4]));
  assert.equal(out.score,core.scoreCut(out.errorPct).score);
  assert.equal(out.judgement,core.scoreCut(out.errorPct).judgement);
  assert.ok(Number.isFinite(out.cutAt));
});

test('Clear Cut accepts only one player cut per log and a perfect match totals 100',()=>{
  const core=fresh('arcade-clear-cut-core.js');
  const match=core.createMatch({difficulty:'normal',playerDex:123,rng:()=>.5,nowMs:0});
  for(let i=0;i<5;i++){
    const round=core.startRound(match,i,i*5000);
    const first=core.cutPlayer(match,round.log.idealTimeMs,()=>.5);
    assert.equal(first.accepted,true);assert.equal(first.result.score,20);
    const second=core.cutPlayer(match,round.log.idealTimeMs+10,()=>.5);
    assert.equal(second.accepted,false);assert.equal(second.reason,'already-cut');
  }
  assert.equal(match.player.total,100);
  assert.equal(match.player.perfects,5);
});

test('Clear Cut ranking resolves ties by perfects, then cumulative error, then stable index',()=>{
  const core=fresh('arcade-clear-cut-core.js');
  const match=core.createMatch({difficulty:'normal',rng:()=>.5,nowMs:0});
  const [a,b,c,d]=match.racers;
  Object.assign(a,{total:80,perfects:2,totalAbsError:10});
  Object.assign(b,{total:80,perfects:3,totalAbsError:20});
  Object.assign(c,{total:80,perfects:3,totalAbsError:8});
  Object.assign(d,{total:80,perfects:3,totalAbsError:8});
  assert.deepEqual(core.rankMatch(match).map(r=>r.id),['cpu2','cpu3','cpu1','player']);
});

test('Clear Cut active timing can be shifted safely across pause/resume',()=>{
  const core=fresh('arcade-clear-cut-core.js');
  const match=core.createMatch({difficulty:'normal',rng:()=>.5,nowMs:1000});
  const round=core.startRound(match,0,2000),before={start:round.log.startedAt,ideal:round.log.idealTimeMs,end:round.log.endsAt};
  core.shiftActiveRound(match,1750);
  assert.equal(round.log.startedAt,before.start+1750);
  assert.equal(round.log.idealTimeMs,before.ideal+1750);
  assert.equal(round.log.endsAt,before.end+1750);
});

test('Clear Cut is the tenth Kids Club game with a phone-first Gen III shell',()=>{
  const world=read('arcade-world.js'),html=read('index.html');
  assert.match(world,/games:\['ekansHoop','digDigDig','magikarpSplash','rockHarden','clefairy','thunderingDynamo','snoreWar','runRattataRun','sushiGoRound','clearCutChallenge'\]/);
  assert.match(world,/clearCutChallenge:'Clear Cut Challenge'/);
  assert.match(world,/clearCutChallenge:\(\)=>window\.LuckyDexClearCut/);
  assert.match(world,/clearCutChallenge:\{sprite:'123\.png',mechanic:'Precision · timing · cut'\}/);
  assert.match(world,/id==='clearCutChallenge'\?'clearCutGame'/,'world navigation must open the Clear Cut panel despite its compact DOM id');
  assert.match(html,/<link rel="stylesheet" href="arcade-clear-cut\.css" \/>/);
  const a=html.indexOf('id="clearCutGame"'),b=html.indexOf('id="dashGame"',a),shell=html.slice(a,b);
  assert.ok(a>0,'game shell exists');
  for(const id of ['clearCutGame','clearCutStage','clearCutRound','clearCutTotal','clearCutDifficultyLabel','clearCutLog','clearCutTarget','clearCutActual','clearCutPlayer','clearCutCpu1','clearCutCpu2','clearCutCpu3','clearCutReady','clearCutStart','clearCutButton','clearCutPauseOverlay','clearCutResume'])assert.match(shell,new RegExp(`id="${id}"`),id);
  for(const dex of ['123','127','212'])assert.match(shell,new RegExp(`data-clear-cut-pokemon="${dex}"`));
  for(const d of ['easy','normal','hard'])assert.match(shell,new RegExp(`data-clear-cut-difficulty="${d}"`));
  const coreAt=html.indexOf('<script src="arcade-clear-cut-core.js"></script>'),runtimeAt=html.indexOf('<script src="arcade-clear-cut.js"></script>'),worldAt=html.indexOf('<script src="arcade-world.js"></script>');
  assert.ok(coreAt>0&&runtimeAt>coreAt&&worldAt>runtimeAt);
});

test('Clear Cut records schema and Arcade Records preserve career precision data',()=>{
  global.LuckyDexArcadeRecordsCore=fresh('arcade-records-core.js');
  const platform=fresh('arcade-platform.js');
  const row=platform.ensureArcadeState({clearCutChallenge:{gamesPlayed:4,wins:2,bestScore:91,totalPerfects:7,closestCutPct:.42}}).clearCutChallenge;
  assert.equal(row.gamesPlayed,4);assert.equal(row.wins,2);assert.equal(row.bestScore,91);assert.equal(row.totalPerfects,7);assert.equal(row.closestCutPct,.42);
  assert.deepEqual(row.bestScores,{easy:0,normal:0,hard:0});
  assert.deepEqual(row.winsByDifficulty,{easy:0,normal:0,hard:0});
  const records=read('arcade-records.js');
  assert.match(records,/clearCutChallenge/);assert.match(records,/Clear Cut Challenge/);assert.match(records,/Closest Cut/);assert.match(records,/Perfect Cuts/);
});

test('Clear Cut has the agreed five achievement set',()=>{
  const achievements=fresh('achievements-v0341.js');
  const state={arcade:{clearCutChallenge:{wins:1,winsByDifficulty:{easy:1,normal:1,hard:1},totalPerfects:4,bestScore:100}}};
  const rows=achievements.buildCoreAchievements(()=>state),byId=new Map(rows.map(a=>[a.id,a]));
  for(const id of ['clearcut_first_win','clearcut_hard_win','clearcut_all_difficulties','clearcut_perfect','secret_clearcut_100'])assert.ok(byId.has(id),id);
  assert.deepEqual(byId.get('clearcut_all_difficulties').progress(),[3,3]);
  assert.deepEqual(byId.get('clearcut_perfect').progress(),[1,1]);
  assert.equal(byId.get('secret_clearcut_100').hidden,true);
  assert.equal(byId.get('secret_clearcut_100').reward.tickets,1);
});
