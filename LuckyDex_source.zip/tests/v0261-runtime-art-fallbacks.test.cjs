'use strict';
const assert=require('node:assert/strict');
const fs=require('node:fs');
const path=require('node:path');
const vm=require('node:vm');
const ROOT=path.resolve(__dirname,'..');
const artPath=path.join(ROOT,'app/src/main/assets/booster-art-v0260.js');
const pocketPath=path.join(ROOT,'app/src/main/assets/tcgp-source-v0160.js');

(async()=>{
  // Physical packs: the APK build may be driven by the repository's outer
  // workflow, so missing local materialisation must still resolve exact art.
  const oldFetch=global.fetch;
  const remote='https://raw.githubusercontent.com/1niceroli/ptcg-assets/main/base1/packshots/base-set-charizard.webp';
  global.fetch=async url=>{
    url=String(url);
    if(url.includes('booster-art-index-v0260.json'))return {ok:true,json:async()=>({})};
    if(url.includes('api.github.com/repos/1niceroli/ptcg-assets/contents/base1/packshots'))return {ok:true,json:async()=>[{type:'file',name:'base-set-charizard.webp',download_url:remote}]};
    throw new Error(`unexpected physical art URL ${url}`);
  };
  delete require.cache[require.resolve(artPath)];
  const BoosterArt=require(artPath);
  const resolved=await BoosterArt.resolve({id:'library:base1',_libraryKey:'base1'});
  assert.equal(resolved,remote,'Base Set must fall back to exact ptcg-assets pack art when the local build manifest is empty');
  global.fetch=oldFetch;

  // Pocket: if LuckyDex's generated mirror has not been created yet, use the
  // complete PocketDecks GitHub catalogue directly rather than the old broken
  // card-art chain.
  const source=fs.readFileSync(pocketPath,'utf8');
  const exactCard='https://raw.githubusercontent.com/PocketDecks/pokemon-tcg-pocket-cards/refs/heads/main/images/webp/cards/a2b/005.webp';
  const exactPack='https://raw.githubusercontent.com/PocketDecks/pokemon-tcg-pocket-cards/refs/heads/main/images/webp/packs/a2b-booster.webp';
  const calls=[];
  const context={window:{},globalThis:{},navigator:{onLine:true},console,setTimeout,clearTimeout,AbortController,DOMException,indexedDB:{open(){throw new Error('no db');}}};
  context.globalThis=context.window;
  context.fetch=async url=>{
    url=String(url);calls.push(url);
    if(url.includes('FlintFireforge116/lucky-dex/main/tcgp-card-index.json'))return {ok:false,status:404,json:async()=>({})};
    if(url.endsWith('/data/v5/expansions.json'))return {ok:true,status:200,json:async()=>[{id:'a2b',name:'Shining Revelry',release_date:'2025-03-27',total_cards:1,packs:[{name:'Booster',image:exactPack}]}]};
    if(url.endsWith('/data/v5/a2b/a2b.json'))return {ok:true,status:200,json:async()=>[{id:'a2b-005',name:'Sprigatito',rarity:'◊',shiny:false,pack:'Shining Revelry',image:exactCard}]};
    throw new Error(`unexpected Pocket URL ${url}`);
  };
  vm.createContext(context);vm.runInContext(source,context,{filename:'tcgp-source-v0160.js'});
  const Pocket=context.window.LuckyDexPocket;
  const catalog=await Pocket.catalog();
  assert.equal(catalog[0].id,'A2b');
  assert.equal(catalog[0].boosters[0].artwork_front,exactPack,'direct Pocket GitHub catalogue must carry real booster art');
  const set=await Pocket.setDetail('A2b');
  assert.equal(set.cards[0].name,'Sprigatito');
  assert.equal(set.cards[0].image,exactCard,'direct Pocket GitHub catalogue must carry exact card art');
  assert.ok(calls.some(url=>url.includes('PocketDecks/pokemon-tcg-pocket-cards')&&url.endsWith('/data/v5/expansions.json')),'Pocket direct fallback must read all expansions from GitHub');
  assert.ok(calls.some(url=>url.includes('PocketDecks/pokemon-tcg-pocket-cards')&&url.endsWith('/data/v5/a2b/a2b.json')),'Pocket direct fallback must read the selected set from GitHub');

  console.log('PASS v0.26.1 runtime exact-art fallbacks for physical + Pocket packs');
})().catch(error=>{console.error(error);process.exit(1);});
