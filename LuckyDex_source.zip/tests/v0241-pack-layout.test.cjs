'use strict';
const assert=require('node:assert/strict');
const fs=require('node:fs');
const path=require('node:path');
const html=fs.readFileSync(path.join(__dirname,'../app/src/main/assets/index.html'),'utf8');
const css=fs.readFileSync(path.join(__dirname,'../app/src/main/assets/styles-v013.css'),'utf8');

assert.doesNotMatch(html,/class="sealed-shelf"/,'non-functional Sealed shelf teaser must not consume Packs viewport space');
assert.match(css,/\.pack-selector-card\s*\{[^}]*display:\s*grid[^}]*grid-template-rows:\s*auto\s+auto\s+minmax\(0,\s*1fr\)\s+auto\s+auto\s+auto[^}]*overflow:\s*hidden/s,'pack selector reserves fixed rows for format, price and open controls while set browser owns remaining height');
assert.match(css,/\.pack-set-browser\s*\{[^}]*min-height:\s*0[^}]*max-height:\s*none[^}]*overflow-y:\s*auto/s,'set browser is the flexible scroll region and may shrink on short phones');
assert.match(css,/@media\s*\(max-height:\s*760px\)[\s\S]*?\.pack-set-row\s*\{[^}]*min-height:\s*44px/s,'short-phone mode compacts set rows instead of pushing the open-pack controls off-screen');
assert.match(css,/\.pack-open-main\s*\{[^}]*margin-top:\s*0[^}]*min-height:\s*48px/s,'open-pack button remains a normal reserved grid row rather than relying on auto margin');

console.log('PASS v0.24.1 Packs short-phone layout contract');
