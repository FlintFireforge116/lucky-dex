from pathlib import Path
import re

ROOT=Path(__file__).resolve().parents[1]
ASSETS=ROOT/'app/src/main/assets'
HTML=(ASSETS/'index.html').read_text(encoding='utf-8')
SESSION=(ASSETS/'arcade-session-v0180.js').read_text(encoding='utf-8')
WORLD=(ASSETS/'arcade-world-v0180.js').read_text(encoding='utf-8')
APP=(ASSETS/'app-v0167.js').read_text(encoding='utf-8')
EXPANSION=(ASSETS/'arcade-expansion-v0166.js').read_text(encoding='utf-8')
QUALITY167=(ASSETS/'quality-content-v0167.js').read_text(encoding='utf-8')
QUALITY=(ASSETS/'quality-content-v0168.js').read_text(encoding='utf-8')
CLEFAIRY=(ASSETS/'clefairy-flow.js').read_text(encoding='utf-8')
BLENDER=(ASSETS/'berry-blender-v0164.js').read_text(encoding='utf-8')

VISIBLE={'berryPicker','headIt','tilePuzzle','voltorb','ballDrop','berry','clefairy','fossil','unown','quiz'}
STABLE={'voltorb','berry','clefairy','fossil','unown','quiz'}

def test_session_rules_cover_only_v018_visible_games():
    block=re.search(r'const GAME_RULES=\{(.*?)\n  \};',SESSION,re.S).group(1)
    keys=set(re.findall(r'^\s*([A-Za-z][A-Za-z0-9]*):\{',block,re.M))
    assert keys==VISIBLE

def test_world_excludes_retired_games_and_maps_stable_games():
    for game in VISIBLE:
        assert f"'{game}'" in WORLD
    assert "games:['ditto'" not in WORLD
    assert "games:['safari'" not in WORLD

def test_legacy_finish_paths_use_shared_exact_results():
    # Each stable provider must call the shared result layer after obtaining the actual awarded value.
    combined={'voltorb':APP,'berry':BLENDER,'clefairy':APP+CLEFAIRY,'fossil':EXPANSION,'unown':QUALITY,'quiz':QUALITY167}
    for game,source in combined.items():
        assert 'LuckyDexArcadeSession' in source, f'{game} does not bridge to shared v0.18 results'
        assert 'coinsAwarded' in source, f'{game} result does not expose actual awarded coins'
    assert "showResult?.('voltorb'" in APP
    assert "showResult?.('berry'" in BLENDER
    assert "showResult?.('clefairy'" in APP+CLEFAIRY
    assert "showResult?.('fossil'" in EXPANSION
    assert "showResult?.('unown'" in QUALITY
    assert "showResult?.('quiz'" in QUALITY167

def test_ditto_has_no_visible_launcher_or_loaded_v017_module():
    assert 'arcade-ditto-v0170.js' not in HTML
    assert 'arcade-ditto-v0170.css' not in HTML
    assert 'arcade-zones-v0170.js' not in HTML
    assert 'arcade-zones-v0170.css' not in HTML
    assert 'data-game="ditto"' not in HTML
    assert "games:['ditto'" not in WORLD

def test_ditto_save_compatibility_remains():
    # Dormant state is deliberately retained; only navigation/active module loading is removed.
    assert 'bestDitto' in APP or 'bestDitto' in (ASSETS/'arcade-platform-v0170.js').read_text(encoding='utf-8')

def test_world_is_last_arcade_navigation_owner():
    scripts=re.findall(r'<script src="([^"]+)"',HTML)
    owner='arcade-world-v0190.js' if 'arcade-world-v0190.js' in scripts else 'arcade-world-v0180.js'
    assert scripts[-1]==owner
    assert scripts.index('arcade-session-v0180.js') < scripts.index('arcade-amie-v0180.js') < scripts.index(owner)
    assert scripts.index('arcade-session-v0180.js') < scripts.index('arcade-ball-drop-v0180.js') < scripts.index(owner)

def test_v018_release_metadata_assets_script_order_ids_syntax_and_keystore():
    import hashlib, subprocess
    gradle=(ROOT/'app/build.gradle').read_text(encoding='utf-8')
    assert 'versionCode 200' in gradle
    assert "versionName '0.19.0'" in gradle
    assert "window.__LUCKYDEX_BUILD='0.19.0-arcade-fidelity';" in APP
    assert 'v0.19.0' in HTML
    scripts=re.findall(r'<script src="([^"]+)"',HTML)
    required=['app-v0167.js','arcade-platform-v0170.js','arcade-session-v0180.js','berry-blender-v0164.js','arcade-expansion-v0166.js','quality-content-v0167.js','quality-content-v0168.js','arcade-amie-v0170.js','arcade-amie-v0180.js','arcade-ball-drop-v0180.js','arcade-amie-v0190.js','arcade-classics-v0190.js','arcade-polish-v0190.js','arcade-world-v0190.js']
    positions=[scripts.index(x) for x in required]
    assert positions==sorted(positions)
    assert scripts[-1]=='arcade-world-v0190.js'
    assert 'arcade-world-v0180.js' not in scripts
    assert 'arcade-zones-v0170.js' not in scripts and 'arcade-ditto-v0170.js' not in scripts
    for name in ['amie-garden.webp','goldenrod-game-corner.webp','celadon-prize-machine.webp','lilycove-contest-hall.webp','moon-stage.webp','oreburgh-museum.webp','ruins-of-alph.webp','indigo-quiz-studio.webp']:
        f=ASSETS/'arcade/venues'/name
        assert f.exists() and f.stat().st_size>0
    ids=re.findall(r'\bid="([^"]+)"',HTML)
    assert len(ids)==len(set(ids)), [x for x in ids if ids.count(x)>1]
    for js in ASSETS.glob('*.js'):
        proc=subprocess.run(['node','--check',str(js)],capture_output=True,text=True)
        assert proc.returncode==0, f'{js.name}: {proc.stderr}'
    key=ROOT/'app/luckydex-dev.keystore'
    assert hashlib.sha256(key.read_bytes()).hexdigest()=='90de91cea469f0eec5fbd69389cf03adc94ced396fa2ec85e2a51d2365a4f6d3'
