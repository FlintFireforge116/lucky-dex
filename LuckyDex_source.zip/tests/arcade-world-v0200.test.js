const assert=require('assert');
const fs=require('fs');
const path=require('path');
const root=path.join(__dirname,'..');
const p=path.join(root,'app/src/main/assets/arcade-world-v0200.js');
assert.ok(fs.existsSync(p),'v0.20 world module must exist');
const world=require(p);
assert.strictEqual(world.VENUES.length,8);
assert.strictEqual(new Set(world.VENUES.flatMap(v=>v.games)).size,10);
assert.strictEqual(world.venueForGame('ditto'),null);
for(const v of world.VENUES){
  assert.ok(v.art.startsWith('arcade/authentic-v0200/venues/'),v.art);
  assert.ok(!v.art.includes('venues-v0190'));
}
assert.strictEqual(world.migrateLegacyVenue('amie'),'amieGarden');
assert.strictEqual(world.migrateLegacyVenue('performance'),'lilycoveContest');
const src=fs.readFileSync(p,'utf8');
assert.match(src,/translate3d/);
assert.match(src,/pointerdown/);
assert.match(src,/pointerup/);
assert.doesNotMatch(src,/scrollIntoView/);
console.log('PASS v0.20 transform world/authentic venue ownership');
