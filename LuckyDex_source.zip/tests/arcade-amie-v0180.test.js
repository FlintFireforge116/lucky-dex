const assert=require('assert');
const fs=require('fs');
const path=require('path');
const modPath=path.resolve(__dirname,'../app/src/main/assets/arcade-amie-v0180.js');
delete require.cache[modPath];
let awardCalls=0,resultCalls=0;
global.LuckyDexArcadePlatform={
  caughtParticipants:(limit)=>[25,133,175,183].slice(0,limit).map(id=>({id,name:`P${id}`,image:`sprite://${id}`,shiny:false})),
  awardRun:(args)=>{awardCalls++;return {coinsAwarded:args.coins,itemAwarded:{key:'berry',amount:2}};}
};
global.LuckyDexArcadeSession={showResult:()=>{resultCalls++;return true;},update:()=>{},hideResult:()=>{}};
global.state={arcade:{bestBerryPicker:{easy:0,normal:0,hard:0},bestHeadIt:{easy:0,normal:0,hard:0,unlimited:0,unlimitedStreak:0},bestTilePuzzle:{easy:null,normal:null,hard:null}}};
global.save=()=>{};global.vibrate=()=>{};
const a=require(modPath);
assert.deepStrictEqual(a.BERRY_CONFIGS.easy,{customers:2,berryCount:3,durationMs:45000,patienceMs:7500,dailyTarget:8,coinCap:70});
assert.deepStrictEqual(a.BERRY_CONFIGS.normal,{customers:3,berryCount:5,durationMs:50000,patienceMs:6000,dailyTarget:14,coinCap:100});
assert.deepStrictEqual(a.BERRY_CONFIGS.hard,{customers:4,berryCount:7,durationMs:55000,patienceMs:4500,dailyTarget:20,coinCap:140});
for(const [mode,n] of [['easy',2],['normal',3],['hard',4]]){
  const scene=a.berrySceneModel(mode);
  assert.strictEqual(scene.customers.length,n);
  for(const c of scene.customers){assert.ok(c.request.berryId);assert.ok(c.request.patienceMs>0);assert.strictEqual(c.reaction,'idle');}
}
const src=fs.readFileSync(modPath,'utf8');
for(const needle of ['berry-tree','thought-bubble','happy','wrong','timeout','pointerdown','pointermove','pointerup']) assert.ok(src.includes(needle),needle);
const run={score:900,correct:10,finished:false,config:a.BERRY_CONFIGS.easy};
const first=a.completeBerryRun(run,'easy');
const second=a.completeBerryRun(run,'easy');
assert.strictEqual(first,true);assert.strictEqual(second,false);assert.strictEqual(awardCalls,1);assert.strictEqual(resultCalls,1);
console.log('PASS Berry Picker v0.18 scene/input/reaction/exact-result lifecycle');

// Head It v0.18
assert.deepStrictEqual(a.HEAD_RUN_CONFIGS.easy,{lanes:2,balls:12,fallStartMs:1500,fallFloorMs:900,fallStepMs:50,coinCap:70,dailyTarget:1200});
assert.deepStrictEqual(a.HEAD_RUN_CONFIGS.normal,{lanes:3,balls:18,fallStartMs:1250,fallFloorMs:650,fallStepMs:35,coinCap:100,dailyTarget:2000});
assert.deepStrictEqual(a.HEAD_RUN_CONFIGS.hard,{lanes:4,balls:24,fallStartMs:1000,fallFloorMs:480,fallStepMs:25,coinCap:140,dailyTarget:2800});
assert.deepStrictEqual(a.HEAD_RUN_CONFIGS.unlimited,{lanes:3,balls:null,fallStartMs:1150,fallFloorMs:420,fallStepMs:20,missLimit:3,coinCap:150,dailyTarget:3200,dailyStreak:20});
assert.strictEqual(a.headTimingGrade(90),'perfect');assert.strictEqual(a.headTimingGrade(220),'good');assert.strictEqual(a.headTimingGrade(221),'miss');
assert.strictEqual(a.headFallDuration('hard',0),1000);assert.strictEqual(a.headFallDuration('hard',999),480);assert.strictEqual(a.headFallDuration('easy',3),1350);
let hr=a.headRunModel('easy');hr.activeBall={id:1,lane:0,bonus:false,resolved:false};hr.ballsResolved=11;assert.strictEqual(a.resolveHeadAttempt(hr,{tapLane:0,offsetMs:0}),true);assert.strictEqual(hr.finished,true);assert.strictEqual(hr.ballsResolved,12);
hr=a.headRunModel('unlimited');for(let i=0;i<2;i++){hr.activeBall={id:i,lane:0,bonus:false,resolved:false};assert.strictEqual(a.resolveHeadAttempt(hr,{tapLane:1,offsetMs:0}),true);assert.strictEqual(hr.finished,false);}hr.activeBall={id:3,lane:0,bonus:false,resolved:false};a.resolveHeadAttempt(hr,{tapLane:1,offsetMs:0});assert.strictEqual(hr.misses,3);assert.strictEqual(hr.finished,true);
hr=a.headRunModel('normal');hr.activeBall={id:7,lane:1,bonus:false,resolved:false};const scoreBefore=hr.score;assert.strictEqual(a.resolveHeadAttempt(hr,{tapLane:1,offsetMs:0}),true);assert.ok(hr.score>scoreBefore);const scored=hr.score;assert.strictEqual(a.resolveHeadAttempt(hr,{tapLane:1,offsetMs:0}),false);assert.strictEqual(hr.score,scored);
assert.ok(src.includes('requestAnimationFrame'));
const headAwardBefore=awardCalls,headResultBefore=resultCalls;const doneHead=a.headRunModel('easy');doneHead.score=1500;doneHead.ballsResolved=12;assert.strictEqual(a.completeHeadRun(doneHead,'easy'),true);assert.strictEqual(a.completeHeadRun(doneHead,'easy'),false);assert.strictEqual(awardCalls,headAwardBefore+1);assert.strictEqual(resultCalls,headResultBefore+1);
console.log('PASS Head It v0.18 configs/finite-unlimited/RAF/idempotent result lifecycle');

// Tile Puzzle v0.18
assert.deepStrictEqual(a.TILE_CONFIGS.easy,{size:3,shuffleMoves:80,qualifySec:90,base:20,timeBonus:20,moveBonus:20,coinCap:60});
assert.deepStrictEqual(a.TILE_CONFIGS.normal,{size:4,shuffleMoves:160,qualifySec:180,base:35,timeBonus:30,moveBonus:25,coinCap:90});
assert.deepStrictEqual(a.TILE_CONFIGS.hard,{size:5,shuffleMoves:260,qualifySec:300,base:50,timeBonus:40,moveBonus:40,coinCap:130});
function seeded(seed){let x=seed>>>0;return ()=>{x=(x*1664525+1013904223)>>>0;return x/4294967296;};}
function adjacent(aidx,bidx,size){const ar=Math.floor(aidx/size),ac=aidx%size,br=Math.floor(bidx/size),bc=bidx%size;return Math.abs(ar-br)+Math.abs(ac-bc)===1;}
for(const size of [3,4,5]){for(let seed=1;seed<=200;seed++){const trace=[];const board=a.makeSolvablePuzzle(size,seeded(seed),trace);assert.strictEqual(board.length,size*size);assert.strictEqual(a.isSolvedPuzzle(board),false);for(const step of trace)assert.ok(adjacent(step.emptyBefore,step.tileIndex,size));const replay=board.slice();for(let i=trace.length-1;i>=0;i--){const step=trace[i],empty=replay.indexOf(size*size-1);assert.strictEqual(empty,step.tileIndex);[replay[empty],replay[step.emptyBefore]]=[replay[step.emptyBefore],replay[empty]];}assert.strictEqual(a.isSolvedPuzzle(replay),true);}}
for(const size of [3,4,5]){const first=a.tileCrop(0,size),last=a.tileCrop(size*size-1,size);assert.deepStrictEqual(first,{leftPct:0,topPct:0,widthPct:100/size,heightPct:100/size});assert.strictEqual(last.leftPct,(size-1)*100/size);assert.strictEqual(last.topPct,(size-1)*100/size);}
let board=[0,1,2,3,4,5,6,8,7];assert.strictEqual(a.canSlideTile(board,3,8),true);assert.strictEqual(a.canSlideTile(board,3,5),false);assert.strictEqual(a.swipeTargetsEmpty(board,3,8,-30,2),true);assert.strictEqual(a.swipeTargetsEmpty(board,3,8,30,2),false);assert.strictEqual(a.swipeTargetsEmpty(board,3,8,-10,1),false);assert.strictEqual(a.swipeTargetsEmpty(board,3,5,0,50),false);
assert.ok(a.officialArtworkUrl({id:25,image:'sprite://25'}).includes('/official-artwork/25.png'));assert.strictEqual(a.officialArtworkUrl({image:'sprite://fallback'}),'sprite://fallback');
const tileAwardBefore=awardCalls,tileResultBefore=resultCalls;const tr={mode:'easy',config:a.TILE_CONFIGS.easy,participant:{id:25,name:'Pikachu',image:'sprite://25'},tiles:[0,1,2,3,4,5,6,7,8],moves:20,startedAt:0,elapsedSec:32,finished:false,awarded:false};assert.strictEqual(a.completeTileRun(tr,'easy'),true);assert.strictEqual(a.completeTileRun(tr,'easy'),false);assert.strictEqual(awardCalls,tileAwardBefore+1);assert.strictEqual(resultCalls,tileResultBefore+1);
const src2=fs.readFileSync(modPath,'utf8');for(const needle of ['pointerdown','pointerup','tile-complete-image','650'])assert.ok(src2.includes(needle),needle);
console.log('PASS Tile Puzzle v0.18 solvability/crop/tap-swipe/final-reveal/result lifecycle');
