const assert=require('node:assert/strict');
const {launch,appPage}=require('../scripts/recovery-browser.cjs');
(async()=>{const browser=await launch(),errors=[];try{
for(const viewport of [{width:360,height:800},{width:412,height:915},{width:393,height:873}]){
 const {page,context}=await appPage(browser,viewport,errors);
 await page.locator('#titleContinueBtn').click();await page.locator('#starterChoices button').first().click();await page.locator('.bottom-nav [data-nav="arcade"]').click();
 for(const [id,selector,ratio] of [['voltorb','#voltorbBoard',1],['fossil','.underground-wall-v019',4/3]]){
  await page.evaluate(id=>LuckyDexArcadeWorld.openGame(id),id);
  const duplicates=await page.evaluate(()=>{const counts=new Map();document.querySelectorAll('[id]').forEach(n=>counts.set(n.id,(counts.get(n.id)||0)+1));return [...counts].filter(([,count])=>count>1).map(([id])=>id)});assert.deepEqual(duplicates,[],'HUD IDs must be unique');
  const r=await page.locator(selector).boundingBox();assert(Math.abs(r.width/r.height-ratio)<.04,id+' scene ratio must be preserved: '+JSON.stringify(r));
  assert(r.x>=0&&r.x+r.width<=viewport.width+1,id+' scene must fit horizontally');
 }
 await page.evaluate(()=>LuckyDexArcadeWorld.openGame('berry'));const berry=await page.locator('.berry-machine').boundingBox();assert(berry.x>=0&&berry.x+berry.width<=viewport.width+1,'restored Berry Blender must fit horizontally');
 await page.evaluate(()=>LuckyDexArcadeWorld.openGame('quiz'));
 const sprite=await page.locator('#quizSprite').boundingBox(),wrap=await page.locator('.quiz-silhouette-wrap').boundingBox();assert(sprite.y+sprite.height<=wrap.y+wrap.height+1,'quiz silhouette must fit in its scene without accidental cropping');
 await context.close();
}assert.deepEqual(errors,[]);console.log('PASS source proportions at three phone sizes');
}finally{await browser.close();}})().catch(e=>{console.error(e);process.exit(1)});
