const assert=require('assert');
const path=require('path');

function seeded(seed){let x=seed>>>0;return ()=>{x=(x*1664525+1013904223)>>>0;return x/4294967296;};}
function load(){
  const modPath=path.resolve(__dirname,'../app/src/main/assets/arcade-ditto-v0170.js');
  delete require.cache[modPath];
  global.LuckyDexArcadePlatform={
    caughtParticipants:(limit)=>[25,133,35,54,39,52,37,1].slice(0,limit).map(id=>({id,name:`P${id}`,image:`sprite://${id}`,shiny:false}))
  };
  return require(modPath);
}

const d=load();
assert.deepStrictEqual(d.dittoRoundConfig(1),{candidates:3,dittos:1,revealMs:1400,scrambleSteps:3,scrambleMs:360,selectMs:5000});
assert.deepStrictEqual(d.dittoRoundConfig(4),{candidates:4,dittos:1,revealMs:1200,scrambleSteps:4,scrambleMs:320,selectMs:4400});
assert.deepStrictEqual(d.dittoRoundConfig(6),{candidates:5,dittos:1,revealMs:1000,scrambleSteps:5,scrambleMs:280,selectMs:3900});
assert.deepStrictEqual(d.dittoRoundConfig(8),{candidates:6,dittos:2,revealMs:900,scrambleSteps:6,scrambleMs:245,selectMs:3500});
assert.deepStrictEqual(d.dittoRoundConfig(12),{candidates:6,dittos:2,revealMs:750,scrambleSteps:8,scrambleMs:210,selectMs:3000});
assert.strictEqual(d.dittoRoundGain(1,1),47);
assert.strictEqual(d.dittoRoundGain(8,2),141);
assert.strictEqual(d.dittoRoundGain(99,2),180);

for(const round of [1,4,6,8,12]){
  const config=d.dittoRoundConfig(round);
  const lineup=d.buildDittoLineup(round,seeded(round));
  assert.strictEqual(lineup.length,config.candidates,`round ${round} candidate count`);
  assert.strictEqual(lineup.filter(x=>x.isDitto).length,config.dittos,`round ${round} ditto count`);
  assert.ok(lineup.every(x=>x.pokemon.id!==132),'transformed targets should be non-Ditto Pokémon');
  assert.strictEqual(new Set(lineup.map(x=>x.pokemon.id)).size,lineup.length,'lineup species should be unique');
}

const pos=d.dittoFacePosition(25);
assert.ok(pos.x>=30&&pos.x<=70&&pos.y>=20&&pos.y<=60);
assert.deepStrictEqual(d.dittoFacePosition(9999),{x:50,y:38,scale:1});
console.log('PASS Ditto Transform difficulty/lineup/payout/face fallback logic');

const fs=require('fs');
const html=fs.readFileSync(path.resolve(__dirname,'../app/src/main/assets/index.html'),'utf8');
const zones=fs.readFileSync(path.resolve(__dirname,'../app/src/main/assets/arcade-zones-v0170.js'),'utf8');
assert.ok(html.includes('TRANSFORM RECOGNITION TEST'));
assert.ok(html.includes('dittoScanFill'));
assert.ok(!html.includes('Memorise the capsule containing Ditto'));
assert.ok(zones.includes("name:'Ditto Transform'"));
console.log('PASS Ditto Transform active UI replaces capsule-shuffle copy');
const appSource=fs.readFileSync(path.resolve(__dirname,'../app/src/main/assets/app-v0167.js'),'utf8');
assert.ok(appSource.includes("ditto:'DITTO TRANSFORM'"));
console.log('PASS shared Arcade labels use Ditto Transform name');
