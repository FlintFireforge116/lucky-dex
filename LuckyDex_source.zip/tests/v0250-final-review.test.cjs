const assert=require('node:assert/strict');
const fs=require('node:fs');
const path=require('node:path');
const crypto=require('node:crypto');
const root=path.resolve(__dirname,'..');
const core=require('../app/src/main/assets/arcade-fossil-museum-core.js');
global.LuckyDexFossilMuseumCore=core;
const museum=require('../app/src/main/assets/arcade-fossil-museum.js');

const coinRows=core.CATALOGUE.filter(x=>x.category==='coins');
assert.ok(coinRows.length>=3,'coin caches should exist');
assert.ok(coinRows.every(x=>/relic-gold\.png$/.test(x.sprite)),'Lucky Coin caches should use the coin-like gold relic sprite, not a Nugget sprite');

const zones=[
  [47,53,11,18],[58,64,11,18],[68,74,11,18], // top wall cabinets
  [85,95,31,42],[85,95,47,58],[85,95,63,74], // right glass cases
  [8,23,32,48],[8,23,51,66],                   // added left glass cases
  [64,72,47,56],[64,72,63,72],                 // existing small cases
  [44,52,25,38],                               // relocated v0.25.1 small case
  [35,43,43,53]                                // central pedestal
];
function inDisplay(slot){return zones.some(([x0,x1,y0,y1])=>slot.x>=x0&&slot.x<=x1&&slot.y>=y0&&slot.y<=y1);}
const entries=Object.entries(museum.MUSEUM_SLOTS||{});
assert.equal(entries.length,30,'all 30 museum exhibits need fixed display positions');
for(const [id,slot] of entries)assert.ok(inDisplay(slot),`${id} must be positioned inside a museum display/pedestal, not floating on the floor`);

const room=path.join(root,'app/src/main/assets/arcade/fossil-museum-v0250/oreburgh-museum-dppt-empty.png');
const sha=crypto.createHash('sha256').update(fs.readFileSync(room)).digest('hex');
assert.equal(sha,'0854170284a79dad11dd6929baeca3b34a825b33ee59741bbb230dbe50ceb36a','museum room should be the clean case-filled Oreburgh room reviewed for v0.25.0');
console.log('PASS v0.25.0 final visual-review contract');
