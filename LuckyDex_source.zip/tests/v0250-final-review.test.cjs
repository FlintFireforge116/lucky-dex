const assert=require('node:assert/strict');
const fs=require('node:fs');
const path=require('node:path');
const crypto=require('node:crypto');
const root=path.resolve(__dirname,'..');
const core=require('../app/src/main/assets/arcade-fossil-museum-core.js');
global.LuckyDexFossilMuseumCore=core;
const museum=require('../app/src/main/assets/arcade-fossil-museum.js');

const coinRows=core.CATALOGUE.filter(x=>x.category==='coins');
assert.ok(coinRows.length>=3,'coin caches should exist');
assert.ok(coinRows.every(x=>/relic-gold\.png$/.test(x.sprite)),'Lucky Coin caches should use the coin-like gold relic sprite, not a Nugget sprite');

const zones=[
  [47,54,10,20],[57,65,10,20],[67,75,10,20], // genuine top wall cabinets
  [85,97,30,43],[85,97,47,59],[85,97,63,75], // genuine outer-right glass cases
  [65,74,50,59],[65,74,68,76],                // the two genuine inner-right glass cases
  [35,47,40,56]                                // central pedestal
];
function inDisplay(slot){return zones.some(([x0,x1,y0,y1])=>slot.x>=x0&&slot.x<=x1&&slot.y>=y0&&slot.y<=y1);}
const entries=Object.entries(museum.MUSEUM_PLACEMENT||{});
assert.equal(entries.length,30,'all 30 museum exhibits need case-based placements');
for(const [id] of entries){const slot=museum.museumSlotFor(id);assert.ok(slot,`${id} must resolve to a case slot`);assert.ok(inDisplay(slot),`${id} must be positioned inside a genuine museum display/pedestal, not floating on the floor`);}

const room=path.join(root,'app/src/main/assets/arcade/fossil-museum-v0252/oreburgh-museum-dppt-landscape-v0252.png');
assert.ok(fs.existsSync(room),'v0.25.2 authentic Oreburgh museum room missing');
const sha=crypto.createHash('sha256').update(fs.readFileSync(room)).digest('hex');
assert.match(sha,/^[0-9a-f]{64}$/,'museum room SHA should be valid');
console.log('PASS v0.25.0 final visual-review contract');
