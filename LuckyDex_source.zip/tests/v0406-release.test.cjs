'use strict';
const test=require('node:test');
const assert=require('node:assert/strict');
const fs=require('node:fs');
const path=require('node:path');
const root=path.resolve(__dirname,'..');
const read=p=>fs.readFileSync(path.join(root,p),'utf8');

test('v0.40.6+ release metadata remains aligned and rare Tile Puzzle helpers ship',()=>{
  const pkg=JSON.parse(read('package.json'));
  const lock=JSON.parse(read('package-lock.json'));
  const gradle=read('app/build.gradle');
  const html=read('app/src/main/assets/index.html');
  const app=read('app/src/main/assets/app-v0167.js');
  assert.ok(['0.40.6','0.40.7','0.40.8','0.40.9'].includes(pkg.version));
  const code=pkg.version==='0.40.9'?4009:pkg.version==='0.40.8'?4008:pkg.version==='0.40.7'?4007:4006;
  assert.equal(lock.version,pkg.version);
  assert.equal(lock.packages[''].version,pkg.version);
  assert.match(gradle,new RegExp('versionCode\\s+'+code));
  assert.match(gradle,new RegExp("versionName\\s+'"+pkg.version.replace(/\./g,'\\.')+"'"));
  assert.ok(gradle.includes('LuckyDex-asset-builder/'+pkg.version));
  assert.ok(html.includes('v'+pkg.version));
  assert.ok(app.includes("__LUCKYDEX_BUILD='"+pkg.version+"'"));
  assert.ok(fs.existsSync(path.join(root,'app/src/main/assets/arcade-rare-rewards.js')));
  assert.ok(fs.existsSync(path.join(root,'app/src/main/assets/arcade-tile-puzzle-core.js')));
});
