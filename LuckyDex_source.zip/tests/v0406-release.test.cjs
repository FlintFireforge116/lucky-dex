'use strict';
const test=require('node:test');
const assert=require('node:assert/strict');
const fs=require('node:fs');
const path=require('node:path');
const root=path.resolve(__dirname,'..');
const read=p=>fs.readFileSync(path.join(root,p),'utf8');

test('v0.40.6 release metadata is aligned and rare Tile Puzzle helpers ship',()=>{
  const pkg=JSON.parse(read('package.json'));
  const lock=JSON.parse(read('package-lock.json'));
  const gradle=read('app/build.gradle');
  const html=read('app/src/main/assets/index.html');
  const app=read('app/src/main/assets/app-v0167.js');
  assert.equal(pkg.version,'0.40.6');
  assert.equal(lock.version,'0.40.6');
  assert.equal(lock.packages[''].version,'0.40.6');
  assert.match(gradle,/versionCode\s+4006/);
  assert.match(gradle,/versionName\s+'0\.40\.6'/);
  assert.match(gradle,/LuckyDex-asset-builder\/0\.40\.6/);
  assert.match(html,/v0\.40\.6/);
  assert.match(app,/__LUCKYDEX_BUILD='0\.40\.6'/);
  assert.ok(fs.existsSync(path.join(root,'app/src/main/assets/arcade-rare-rewards.js')));
  assert.ok(fs.existsSync(path.join(root,'app/src/main/assets/arcade-tile-puzzle-core.js')));
});
