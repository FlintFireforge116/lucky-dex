const {test}=require('node:test');
const assert=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path');
const file=path.resolve(__dirname,'../app/src/main/assets/clefairy-scene.js');
const scene=fs.existsSync(file)?require(file):null;
function api(){assert.ok(scene,'The continuous Clefairy scene implementation is missing');return scene;}

test('STAR moves during the overlapping idle/action crossfade and flows back to idle',()=>{
  const s=api(),start=s.motionAt('star',0),early=s.motionAt('star',50),end=s.motionAt('star',s.durationFor('star'));
  assert.equal(start.weights.idle,1);assert.ok(early.weights.star>0&&early.weights.star<1);
  assert.ok(early.weights.idle>0&&early.y<0);assert.ok(s.motionAt('star',400).y<-5);
  const returning=s.motionAt('star',s.durationFor('star')-90);
  assert.ok(returning.weights.star>0&&returning.weights.idle>0);
  assert.equal(end.weights.idle,1);assert.equal(end.y,0);assert.equal(end.rotation,0);
});
test('SPIN uses clean idle art for a full eased 1050 ms twirl and finishes upright',()=>{
  const s=api(),r=t=>s.motionAt('spin',t).rotation;
  assert.equal(r(100),0);assert.equal(r(1150),360);
  assert.ok(r(250)-r(100)<r(700)-r(550));assert.ok(r(1150)-r(1000)<r(700)-r(550));
  let previous=0;for(let t=100;t<=1150;t+=25){const m=s.motionAt('spin',t);assert.ok(m.rotation>=previous);previous=m.rotation;assert.equal(m.weights.idle,1);assert.equal(m.weights.spin||0,0);}
  assert.equal(r(s.durationFor('spin'))%360,0);
});
test('Idle is a rigid character-only shift of at most 1.5 px, with no scale or horizontal drift',()=>{
  const s=api();for(let t=0;t<6000;t+=80){const m=s.motionAt('idle',t);assert.equal(m.x,0);assert.equal(m.rotation,0);assert.equal(m.scale,1);assert.ok(m.y<=0&&m.y>=-1.5);}
});
test('SPIN retargeted from a small positive SONG tilt still makes one full turn, not almost two',()=>{
  const s=api(),from=s.motionAt('song',150),start=s.motionAt('spin',100,from),end=s.motionAt('spin',1150,from);
  assert.ok(from.rotation>0&&from.rotation<2);assert.ok(Math.abs(end.rotation-start.rotation-360)<.0001);
  assert.equal(s.motionAt('spin',s.durationFor('spin'),from).rotation%360,0);
});
test('An interrupted SPIN retargets continuously for one more turn, then settles upright without a snap',()=>{
  const s=api(),from=s.motionAt('spin',560),start=s.motionAt('spin',0,from),finish=s.motionAt('spin',1150,from);
  assert.equal(start.rotation,from.rotation);assert.equal(start.y,from.y);assert.ok(Math.abs(finish.rotation-from.rotation-360)<1e-6);
  // Nearest-upright correction can be up to 180 degrees across 300 ms;
  // smooth easing keeps each 20 ms step below 20 degrees, not an instant snap.
  let previous=finish.rotation;for(let t=1170;t<=1450;t+=20){const angle=s.motionAt('spin',t,from).rotation;assert.ok(Math.abs(angle-previous)<20);previous=angle;}
  assert.equal(previous%360,0);
});
test('A repeated action begins at the exact visible motion and opacity blend, never popping to a new pose',()=>{
  const s=api(),previous=s.motionAt('song',480),first=s.motionAt('moon',0,previous),later=s.motionAt('moon',55,previous);
  assert.deepEqual(first.weights,previous.weights);assert.equal(first.y,previous.y);assert.equal(first.rotation,previous.rotation);
  assert.ok(later.weights.song>0&&later.weights.moon>0);
  for(let t=0;t<=s.durationFor('moon');t+=33){const m=s.motionAt('moon',t,previous);assert.ok(Math.abs(Object.values(m.weights).reduce((a,b)=>a+b,0)-1)<1e-6);}
});
test('Procedural STAR travels only through the sky after the reaction and has a later light response',()=>{
  const s=api();assert.equal(s.effectsAt('star',100).star,null);
  const a=s.effectsAt('star',300).star,b=s.effectsAt('star',700).star;
  assert.ok(a&&b&&a.x>b.x&&a.y<b.y);assert.ok(a.y<.4&&b.y<.4);
  assert.ok(s.motionAt('star',900).light>s.motionAt('star',100).light);
});
test('SONG emits notes over time, and MOON light rises, holds, then fades',()=>{
  const s=api();assert.equal(s.effectsAt('song',0).notes.length,0);
  assert.equal(s.effectsAt('song',300).notes.length,1);assert.ok(s.effectsAt('song',650).notes.length>=2);
  assert.ok(s.motionAt('song',450).y<0);assert.notEqual(s.motionAt('song',450).rotation,s.motionAt('song',850).rotation);
  assert.equal(s.motionAt('moon',0).light,0);assert.ok(s.motionAt('moon',700).light>.8);assert.equal(s.motionAt('moon',s.durationFor('moon')).light,0);
});
