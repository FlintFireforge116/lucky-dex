const {test,before,after}=require('node:test');
const assert=require('node:assert/strict');
const fs=require('node:fs'),path=require('node:path'),http=require('node:http');
const runtime='C:/Users/sjwal/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/node_modules';
let playwright;try{playwright=require('playwright');}catch(_){playwright=require(require.resolve('playwright',{paths:[runtime]}));}
const {chromium}=playwright;
let server,browser,origin;
const assets=path.resolve(__dirname,'../app/src/main/assets');
const svg='<svg xmlns="http://www.w3.org/2000/svg" width="245" height="342"><rect width="245" height="342" fill="#293f68"/><rect x="10" y="10" width="225" height="322" rx="10" fill="#b9773a"/><rect x="20" y="45" width="205" height="170" fill="#30583c"/><text x="25" y="33" font-size="18" fill="white">OFFLINE TEST CARD</text><text x="25" y="244" fill="white">Artwork cached in IndexedDB</text><!--'+ 'cached '.repeat(200)+'--></svg>';
const cards=Array.from({length:5},(_,i)=>({id:`fixture-${i}`,name:`Cached Card ${i+1}`,rarity:i===4?'Crown':'Common',localId:String(i+1),image:`https://art.invalid/${i}`,setId:'fixture',setName:'Offline fixture',source:'tcgp'}));
const set={id:'fixture',name:'Offline fixture',releaseDate:'2026-06-01',cardCount:{total:200},cards,serie:{id:'tcgp'}};
before(async()=>{
  server=http.createServer((req,res)=>{
    const requested=decodeURIComponent(new URL(req.url,'http://localhost').pathname);
    const file=path.resolve(assets,'.'+(requested==='/'?'/index.html':requested));
    if(!file.startsWith(assets+path.sep)){res.writeHead(403).end();return;}
    fs.readFile(file,(err,data)=>{if(err){res.writeHead(404).end();return;}res.setHeader('Content-Type',file.endsWith('.js')?'application/javascript':file.endsWith('.css')?'text/css':file.endsWith('.png')?'image/png':'text/html');res.end(data);});
  });
  await new Promise(r=>server.listen(0,'127.0.0.1',r));origin=`http://127.0.0.1:${server.address().port}`;
  const installedChrome='C:/Program Files/Google/Chrome/Application/chrome.exe';
  browser=await chromium.launch({...(process.env.CHROME_PATH?{executablePath:process.env.CHROME_PATH}:fs.existsSync(installedChrome)?{executablePath:installedChrome}:{}),headless:true});
});
after(async()=>{await browser?.close();await new Promise(r=>server?.close(r));});
async function setup(viewport={width:360,height:800}) {
  const context=await browser.newContext({viewport,isMobile:true,hasTouch:true,deviceScaleFactor:1});
  await context.route('**/*',route=>route.request().url().startsWith(origin)?route.continue():route.fulfill({headers:{'access-control-allow-origin':'*'},json:route.request().url().includes('/type/')?{pokemon:[]}:{results:[],sets:[]}}));
  const page=await context.newPage(),errors=[];page.on('pageerror',e=>errors.push(e.message));
  await page.goto(origin);await page.waitForTimeout(200);
  page.setDefaultTimeout(6000);
  await context.setOffline(true);
  await page.evaluate(({cards,set,svg})=>new Promise((resolve,reject)=>{
    const request=indexedDB.open('LuckyDexOfflinePackV13',1);
    request.onupgradeneeded=()=>request.result.createObjectStore('images');
    request.onsuccess=()=>{
      const db=request.result,tx=db.transaction('images','readwrite');cards.forEach(c=>tx.objectStore('images').put(new Blob([svg],{type:'image/svg+xml'}),c.id));
      tx.oncomplete=()=>{db.close();cacheSetV13(set,'tcgp');cacheCardsV13(cards,set,'tcgp');saveCatalogCacheV13('tcgp',[set]);document.getElementById('titleScreen').classList.add('hidden-title');document.getElementById('cardSource').value='tcgp';navigate('packs');resolve();};tx.onerror=()=>reject(tx.error);
    };request.onerror=()=>reject(request.error);
  }),{cards,set,svg});
  await context.setOffline(true);
  await page.evaluate(()=>loadSets('tcgp'));
  return {context,page,errors};
}
async function swipe(page,dx) {
  await page.evaluate(dx=>{
    const el=document.getElementById('packTheatre'),rect=el.getBoundingClientRect();
    const touch=(x)=>new Touch({identifier:1,target:el,clientX:x,clientY:rect.y+rect.height/2});
    el.dispatchEvent(new TouchEvent('touchstart',{changedTouches:[touch(180)],bubbles:true}));
    el.dispatchEvent(new TouchEvent('touchend',{changedTouches:[touch(180+dx)],bubbles:true}));
  },dx);
}
for(const viewport of [{width:360,height:800},{width:412,height:915}])test(`offline pack, gated gestures, Skip, previous/next, full screen and summary at ${viewport.width}x${viewport.height}`,async()=>{
  const {context,page,errors}=await setup(viewport);
  try{
    const before=await page.evaluate(()=>JSON.stringify(state));
    await page.evaluate(()=>preparePack());await page.locator('#sealedPack').click();
    await page.waitForSelector('#packTheatre',{timeout:5000});
    assert.equal(await page.locator('#nextPackCard').isDisabled(),true);
    await swipe(page,-100);assert.equal(await page.evaluate(()=>preparedPack.currentIndex),0);
    await page.locator('#packSkipBtn').click();
    assert.equal(await page.locator('#nextPackCard').isDisabled(),false);
    assert.ok(await page.locator('#packCardFront img').getAttribute('src').then(u=>u.startsWith('blob:')));
    const snapshot=await page.evaluate(()=>({packs:state.stats.packs,pulls:state.stats.cardsPulled,counts:Object.values(state.cards).map(c=>c.count),coins:state.profile.coins,tickets:state.profile.tickets}));
    const original=JSON.parse(before);assert.equal(snapshot.packs,original.stats.packs+1);assert.equal(snapshot.pulls,original.stats.cardsPulled+5);assert.deepEqual(snapshot.counts,[1,1,1,1,1]);assert.equal(snapshot.coins,original.profile.coins);assert.equal(snapshot.tickets,original.profile.tickets);
    await page.locator('#zoomCurrentCard').click();assert.equal(await page.locator('#cardDialog').evaluate(el=>el.open),true);
    assert.ok(await page.locator('#cardDialogImage').getAttribute('src').then(u=>u.startsWith('blob:')));await page.locator('#closeCardDialog').click();
    await swipe(page,-100);await page.waitForSelector('#packSkipBtn');await page.locator('#packSkipBtn').click();
    assert.equal(await page.evaluate(()=>preparedPack.currentIndex),1);await swipe(page,100);await page.waitForSelector('#packSkipBtn');await page.locator('#packSkipBtn').click();assert.equal(await page.evaluate(()=>preparedPack.currentIndex),0);
    const bounds=await page.locator('.pack-reveal-actions').boundingBox();assert.ok(bounds.y+bounds.height<=viewport.height);
    for(let i=0;i<5;i++){await page.locator('#nextPackCard').click();if(i<4){await page.waitForSelector('#packSkipBtn');await page.locator('#packSkipBtn').click();}}
    assert.equal(await page.locator('[data-summary-card]').count(),5);
    await page.waitForFunction(()=>Array.from(document.querySelectorAll('[data-summary-card] img')).every(i=>i.complete&&i.naturalWidth>0));
    assert.ok(await page.locator('[data-summary-card] img').evaluateAll(images=>images.every(i=>i.src.startsWith('blob:')&&i.complete&&i.naturalWidth>0)));
    assert.equal(await page.evaluate(()=>state.stats.packs),snapshot.packs);assert.equal(await page.evaluate(()=>state.stats.cardsPulled),snapshot.pulls);assert.deepEqual(errors,[]);
  }finally{await context.close();}
});
test('debug replay is local, renders real depth motion/ribbons, and has zero save/economy changes',async()=>{
  const {context,page,errors}=await setup();
  try{
    assert.equal(await page.evaluate(()=>typeof window.LuckyDexDebug?.playPackTier),'function');
    const before=await page.evaluate(()=>localStorage.getItem('luckyDexSave'));
    const probe=await page.evaluate(async()=>{
      await LuckyDexDebug.playPackTier('crown');
      return await new Promise(resolve=>{
        const samples=[],phases=new Set();let pixels=0;
        function sample(time){
          const stage=document.getElementById('packStage'),el=document.getElementById('packFlight'),matrix=getComputedStyle(el).transform;
          phases.add(stage.dataset.packPhase);samples.push({time,width:el.getBoundingClientRect().width,z:new DOMMatrix(matrix).m43});
          if(stage.dataset.packPhase==='flip'&&!pixels){const c=stage.querySelector('.pack-fx-front'),data=c.getContext('2d').getImageData(0,0,c.width,c.height).data;for(let i=3;i<data.length;i+=4)if(data[i]>0)pixels++;}
          if(stage.dataset.packPhase==='ready')resolve({phases:[...phases],first:samples[0],maxWidth:Math.max(...samples.map(s=>s.width)),pixels,frameIntervals:samples.slice(1).map((s,i)=>s.time-samples[i].time)});
          else requestAnimationFrame(sample);
        }
        requestAnimationFrame(sample);
      });
    });
    assert.ok(probe.first.z<-2000);assert.ok(probe.maxWidth>probe.first.width*5);
    for(const phase of ['approach','settling','flip','payoff','ready'])assert.ok(probe.phases.includes(phase),JSON.stringify(probe));
    assert.ok(probe.pixels>100);
    const meanFrame=probe.frameIntervals.reduce((a,b)=>a+b,0)/probe.frameIntervals.length;
    console.log('crown RAF mean ms:',meanFrame.toFixed(2));assert.ok(meanFrame<25,`Crown reveal averaged ${meanFrame.toFixed(2)} ms/frame`);
    fs.mkdirSync(path.resolve(__dirname,'../artifacts'),{recursive:true});
    assert.equal(await page.evaluate(()=>document.getAnimations().filter(a=>a.effect?.target?.closest('#packStage')).length),0);
    assert.equal(await page.evaluate(()=>localStorage.getItem('luckyDexSave')),before);assert.deepEqual(errors,[]);
    await page.screenshot({path:path.resolve(__dirname,'../artifacts/crown-settled-360.png')});
    await page.locator('#packExitBtn').click();assert.equal(await page.locator('#packStage').isVisible(),false);
  }finally{await context.close();}
});
test('online pack artwork uses existing IndexedDB before network, then caches a network miss for airplane mode',async()=>{
  const {context,page}=await setup();
  try{
    await context.setOffline(false);let artRequests=0;
    await context.route('https://art.invalid/**',r=>{artRequests++;return r.fulfill({headers:{'access-control-allow-origin':'*'},contentType:'image/svg+xml',body:svg});});
    // Card/set data are genuine persisted fixtures; limit mocking to the remote API boundary.
    await context.route('**/cards/fixture-*',r=>{const card=cards.find(c=>r.request().url().endsWith(c.id));return r.fulfill({headers:{'access-control-allow-origin':'*'},json:card});});
    await page.evaluate(()=>preparePack());await page.locator('#sealedPack').click();await page.waitForSelector('#packTheatre');await page.locator('#packSkipBtn').click();assert.equal(artRequests,0);
    await page.evaluate(()=>closePackOpening(true));
    await page.evaluate(()=>new Promise(resolve=>{packDbV131().then(db=>{const tx=db.transaction('images','readwrite');tx.objectStore('images').clear();tx.oncomplete=resolve;});}));
    await page.evaluate(()=>preparePack());await page.locator('#sealedPack').click();await page.waitForSelector('#packTheatre');await page.locator('#packSkipBtn').click();assert.ok(artRequests>0);
    await page.waitForFunction(()=>packRun.art.size===5);
    await page.evaluate(()=>Promise.all([...packRun.art.values()]));
    const count=artRequests;await page.evaluate(()=>closePackOpening(true));await context.setOffline(true);
    await page.evaluate(()=>preparePack());await page.locator('#sealedPack').click();await page.waitForSelector('#packTheatre');await page.locator('#packSkipBtn').click();assert.equal(artRequests,count);
    assert.ok(await page.locator('#packCardFront img').getAttribute('src').then(u=>u.startsWith('blob:')));
  }finally{await context.close();}
});
test('leaving during tear cancels pending commits; duplicate tear commits exactly once',async()=>{
  const {context,page,errors}=await setup();
  try{
    const packs=await page.evaluate(()=>state.stats.packs);
    await page.evaluate(()=>preparePack());await page.evaluate(()=>{tearPack();closePackOpening(true);});await page.waitForTimeout(850);
    assert.equal(await page.evaluate(()=>state.stats.packs),packs);assert.equal(await page.locator('#packStage').isVisible(),false);
    await page.evaluate(()=>preparePack());await page.evaluate(()=>Promise.all([tearPack(),tearPack()]));await page.waitForSelector('#packTheatre');await page.locator('#packSkipBtn').click();
    await page.evaluate(()=>{commitPreparedPack();commitPreparedPack();});assert.equal(await page.evaluate(()=>state.stats.packs),packs+1);assert.deepEqual(errors,[]);
  }finally{await context.close();}
});
test('set picker enriches dates, preserves unknown source order, and is deterministic offline',async()=>{
  const {context,page}=await setup();
  try{
    await context.setOffline(false);
    await context.route('**/series/tcgp',r=>r.fulfill({headers:{'access-control-allow-origin':'*'},json:{sets:[{id:'z',name:'Zulu',cardCount:{total:10}},{id:'old',name:'Old',cardCount:{total:10}},{id:'new',name:'New',cardCount:{total:10}},{id:'a',name:'Alpha',cardCount:{total:10}}]}}));
    await context.route('**/sets/*',r=>{const id=r.request().url().split('/').pop();r.fulfill({headers:{'access-control-allow-origin':'*'},json:{id,releaseDate:id==='new'?'2026-06-01':id==='old'?'1999-01-09':null}});});
    await page.evaluate(()=>loadSets('tcgp'));assert.deepEqual(await page.locator('#setSelect option').evaluateAll(os=>os.map(o=>o.value)),['new','old','z','a']);
    await context.setOffline(true);await page.evaluate(()=>loadSets('tcgp'));assert.deepEqual(await page.locator('#setSelect option').evaluateAll(os=>os.map(o=>o.value)),['new','old','z','a']);
  }finally{await context.close();}
});
test('offline readiness includes durable artwork, not just cached card metadata',async()=>{
  const {context,page}=await setup();
  try{
    await page.evaluate(()=>updateOfflineHintV13());
    await page.waitForFunction(()=>document.getElementById('offlinePackHint').classList.contains('ready'));
    await page.evaluate(()=>new Promise((resolve,reject)=>{packDbV131().then(db=>{const tx=db.transaction('images','readwrite');tx.objectStore('images').delete('fixture-4');tx.oncomplete=resolve;tx.onerror=()=>reject(tx.error);});}));
    await page.evaluate(()=>updateOfflineHintV13());
    assert.equal(await page.locator('#offlinePackHint').evaluate(el=>el.classList.contains('ready')),false);
  }finally{await context.close();}
});
test('offline-ready indicator rejects corrupt persisted artwork',async()=>{
  const {context,page}=await setup();
  try{
    await page.evaluate(()=>new Promise(resolve=>{packDbV131().then(db=>{const tx=db.transaction('images','readwrite');tx.objectStore('images').put(new Blob(['broken'],{type:'image/webp'}),'fixture-4');tx.oncomplete=resolve;});}));
    await page.evaluate(()=>updateOfflineHintV13());assert.equal(await page.locator('#offlinePackHint').evaluate(el=>el.classList.contains('ready')),false);
  }finally{await context.close();}
});
test('exit during approach cancels WAAPI/RAF, and missing offline art still reaches ready without HTTP',async()=>{
  const {context,page}=await setup();
  try{
    let network=0;page.on('request',req=>{if(req.url().startsWith('https://art.invalid'))network++;});
    await page.evaluate(()=>LuckyDexDebug.playPackTier('crown'));await page.waitForTimeout(120);await page.locator('#packExitBtn').click();
    await page.waitForTimeout(1600);assert.equal(await page.locator('#packStage').isVisible(),false);
    assert.equal(await page.evaluate(()=>document.getAnimations().filter(a=>a.effect?.target?.closest('#packStage')).length),0);
    await page.evaluate(()=>new Promise(resolve=>{packDbV131().then(db=>{const tx=db.transaction('images','readwrite');tx.objectStore('images').clear();tx.oncomplete=resolve;});}));
    await page.evaluate(()=>preparePack());await page.locator('#sealedPack').click();await page.waitForSelector('#packTheatre');await page.waitForFunction(()=>document.getElementById('packStage').dataset.packPhase==='ready');
    assert.ok(await page.locator('#packCardFront img').getAttribute('src').then(u=>u.startsWith('data:')));assert.equal(network,0);
  }finally{await context.close();}
});
test('corrupt high artwork tries valid low artwork and persists only decodable bytes',async()=>{
  const {context,page}=await setup();
  try{
    await context.setOffline(false);let lowRequests=0;
    await context.route('https://art.invalid/**',r=>{const low=r.request().url().endsWith('/low.png');if(low)lowRequests++;return r.fulfill({headers:{'access-control-allow-origin':'*'},contentType:low?'image/svg+xml':'image/webp',body:low?svg:'corrupt-image'});});
    await context.route('**/cards/fixture-*',r=>r.fulfill({headers:{'access-control-allow-origin':'*'},json:cards.find(c=>r.request().url().endsWith(c.id))}));
    await page.evaluate(()=>new Promise(resolve=>{packDbV131().then(db=>{const tx=db.transaction('images','readwrite');tx.objectStore('images').clear();tx.oncomplete=resolve;});}));
    await page.evaluate(()=>preparePack());await page.locator('#sealedPack').click();await page.waitForSelector('#packTheatre');await page.locator('#packSkipBtn').click();
    assert.ok(lowRequests>0);assert.ok(await page.locator('#packCardFront img').getAttribute('src').then(u=>u.startsWith('blob:')));
    const cached=await page.evaluate(async()=>{const c=preparedPack.cards[0];return await (await packCachedBlob(c.id)).text();});assert.ok(cached.startsWith('<svg'));
  }finally{await context.close();}
});
test('valid catalog date survives an invalid full-set date without requesting detail',async()=>{
  const {context,page}=await setup();
  try{
    await context.setOffline(false);let details=0;
    await context.route('**/series/tcgp',r=>r.fulfill({headers:{'access-control-allow-origin':'*'},json:{sets:[{id:'old',name:'Old',cardCount:{total:10}},{id:'new',name:'New',cardCount:{total:10}}]}}));
    await context.route('**/sets/*',r=>{details++;return r.fulfill({headers:{'access-control-allow-origin':'*'},status:404,body:'not found'});});
    await page.evaluate(()=>{cacheSetV13({id:'new',releaseDate:'2025-02-30'},'tcgp');cacheSetV13({id:'old',releaseDate:'bad'},'tcgp');saveCatalogCacheV13('tcgp',[{id:'new',name:'New',releaseDate:'2026-06-01',cardCount:{total:10}},{id:'old',name:'Old',releaseDate:'1999-01-09',cardCount:{total:10}}]);});
    await page.evaluate(()=>loadSets('tcgp'));assert.deepEqual(await page.locator('#setSelect option').evaluateAll(os=>os.map(o=>o.value)),['new','old']);assert.equal(details,0);
  }finally{await context.close();}
});
test('exit cancels preparation while a card-detail request is pending',async()=>{
  const {context,page}=await setup();
  try{
    await context.setOffline(false);let cardRequest;
    const requested=new Promise(resolve=>cardRequest=resolve);
    await context.route('**/cards/fixture-*',async r=>{cardRequest();await new Promise(resolve=>setTimeout(resolve,1500));try{await r.fulfill({headers:{'access-control-allow-origin':'*'},json:cards.find(c=>r.request().url().endsWith(c.id))});}catch(_){}});
    await page.evaluate(()=>{packCacheV13.cards={};cardDetailCache.clear();window.prepPending=preparePack();});await requested;
    await page.evaluate(()=>closePackOpening(true));
    const cancelled=await page.evaluate(()=>Promise.race([window.prepPending.then(()=>true),new Promise(resolve=>setTimeout(()=>resolve(false),350))]));
    assert.equal(cancelled,true);assert.equal(await page.evaluate(()=>preparedPack),null);
  }finally{await context.close();}
});
test('offline catalog enrichment uses full-set dates already cached locally',async()=>{
  const {context,page}=await setup();
  try{
    await page.evaluate(()=>{cacheSetV13({id:'old',releaseDate:'1999-01-09'},'tcgp');cacheSetV13({id:'new',releaseDate:'2026-06-01'},'tcgp');saveCatalogCacheV13('tcgp',[{id:'old',name:'Old',cardCount:{total:10}},{id:'unknown',name:'Unknown',cardCount:{total:10}},{id:'new',name:'New',cardCount:{total:10}}]);});
    await page.evaluate(()=>loadSets('tcgp'));assert.deepEqual(await page.locator('#setSelect option').evaluateAll(os=>os.map(o=>o.value)),['new','old','unknown']);
  }finally{await context.close();}
});
test('the back remains painted when the approach rotates to its opposite side without exposing art',async()=>{
  const {context,page}=await setup();
  try{
    await page.evaluate(()=>LuckyDexDebug.playPackTier('common'));
    await page.evaluate(()=>packRun.reveal.session.animations.forEach(a=>{a.pause();a.currentTime=100;}));
    assert.equal(await page.locator('.pack-unrevealed-cover').count(),1);
    assert.equal(await page.locator('#packCardFront').evaluate(el=>getComputedStyle(el).visibility),'visible');
    assert.equal(await page.locator('.pack-unrevealed-cover').isVisible(),true);
    assert.equal(await page.locator('#packCardFront img').evaluate(el=>getComputedStyle(el).visibility),'hidden');
    await page.locator('#packSkipBtn').click();assert.equal(await page.locator('.pack-unrevealed-cover').isVisible(),false);
  }finally{await context.close();}
});
test('leaving the packs page through navigation cancels the reveal and releases its session',async()=>{
  const {context,page}=await setup();
  try{
    await page.evaluate(()=>LuckyDexDebug.playPackTier('crown'));await page.evaluate(()=>navigate('adventure'));
    assert.equal(await page.evaluate(()=>preparedPack),null);assert.equal(await page.locator('#packStage').isVisible(),false);
    assert.equal(await page.evaluate(()=>document.getAnimations().filter(a=>a.effect?.target?.closest('#packStage')).length),0);
  }finally{await context.close();}
});
