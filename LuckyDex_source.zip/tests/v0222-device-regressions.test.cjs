const fs=require('fs');
const assert=require('assert');
const main=fs.readFileSync('app/src/main/java/com/example/luckydex/MainActivity.java','utf8');
const amie=fs.readFileSync('app/src/main/assets/arcade-amie.js','utf8');
const classics=fs.readFileSync('app/src/main/assets/arcade-classics.js','utf8');
const css=fs.readFileSync('app/src/main/assets/arcade.css','utf8');

assert(main.includes('FrameLayout'), 'WebView should live inside a safe-area root');
assert(main.includes('setMargins(safe.left, safe.top, safe.right, safe.bottom)'), 'system insets must resize the WebView viewport with margins');
assert(!main.includes('view.setPadding(safe.left, safe.top, safe.right, safe.bottom)'), 'fixed UI must not rely on WebView padding for system bars');

assert(amie.includes("addEventListener('touchstart'"), 'Berry Picker needs an Android touch fallback');
assert(amie.includes("addEventListener('touchmove'"), 'Berry Picker needs touchmove drag tracking');
assert(amie.includes("addEventListener('touchend'"), 'Berry Picker needs touchend drop detection');
assert(amie.includes('changedTouches'), 'Berry touch drop should use changedTouches coordinates');

assert(classics.includes('rows=6,cols=7'), 'Fossil site should use the simplified 6x7 one-tap board');
assert(classics.includes('digs:12,maxDigs:12'), 'Fossil site should use reduced one-tap durability');
assert(!classics.includes("cells=[[0,0],[0,1],[1,0],[1,1],[2,1]]"), 'Fossils must not use broken multi-cell sliced backgrounds');
assert(classics.includes("itemIndex"), 'Each fossil find should occupy one explicit cell');
assert(css.includes('aspect-ratio:7/6'), 'Fossil board should preserve square cells');
assert(css.includes('.dig-cell-v019.treasure img'), 'Fossil finds should render as centered intact item sprites');

assert(css.includes('.world-scene>img{') && css.includes('object-fit:cover'), 'World art should fill the scene rather than float inside blur bars');
console.log('v0.22.2 device regression contract OK');
