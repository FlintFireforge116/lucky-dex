
'use strict';
const test=require('node:test'),assert=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path');
const root=path.resolve(__dirname,'..'),read=p=>fs.readFileSync(path.join(root,p),'utf8');
test('v0.40.20 release identity and Snore War ranking/duration tuning are aligned',()=>{
  const pkg=JSON.parse(read('package.json')),lock=JSON.parse(read('package-lock.json')),gradle=read('app/build.gradle'),html=read('app/src/main/assets/index.html'),app=read('app/src/main/assets/app-v0167.js'),core=read('app/src/main/assets/arcade-snore-war-core.js');
  assert.equal(pkg.version,'0.40.20'); assert.equal(lock.version,pkg.version); assert.equal(lock.packages[''].version,pkg.version);
  assert.match(gradle,/versionCode\s+4020/); assert.match(gradle,/versionName\s+'0\.40\.20'/); assert.ok(gradle.includes('LuckyDex-asset-builder/0.40.20'));
  assert.ok((html.match(/v0\.40\.20/g)||[]).length>=2); assert.ok(app.includes("__LUCKYDEX_BUILD='0.40.20'"));
  assert.match(core,/sleepThroughCrossing=index\+CONFIG\.sleepCrossings-1/,'sleep duration is exactly two crossings total');
  assert.match(core,/if\(finalRanking\)\{const as=Number\(a\.lastSleepAt/,'sleep timestamps only participate in finalized ordering');
  assert.match(core,/if\(b\.bestStreak!==a\.bestStreak\)return b\.bestStreak-a\.bestStreak/,'live ranking uses best streak after hits and misses');
});
