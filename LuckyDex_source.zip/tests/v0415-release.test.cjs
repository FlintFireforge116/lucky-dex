'use strict';
const test=require('node:test'),assert=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path');
const root=path.resolve(__dirname,'..'),read=p=>fs.readFileSync(path.join(root,p),'utf8');
test('v0.40.15 release identity and Kids Club scroll hotfix are aligned',()=>{
 const pkg=JSON.parse(read('package.json')),lock=JSON.parse(read('package-lock.json')),gradle=read('app/build.gradle'),html=read('app/src/main/assets/index.html'),app=read('app/src/main/assets/app-v0167.js'),css=read('app/src/main/assets/arcade.css');
 assert.equal(pkg.version,'0.40.15'); assert.equal(lock.version,pkg.version); assert.equal(lock.packages[''].version,pkg.version);
 assert.match(gradle,/versionCode\s+4015/); assert.match(gradle,/versionName\s+'0\.40\.15'/); assert.ok(gradle.includes('LuckyDex-asset-builder/0.40.15'));
 assert.ok((html.match(/v0\.40\.15/g)||[]).length>=2); assert.ok(app.includes("__LUCKYDEX_BUILD='0.40.15'"));
 assert.match(css,/\.arcade-venue-games\{[^}]*flex:1[^}]*min-height:0[^}]*overflow-y:auto[^}]*overscroll-behavior:contain/);
});
