'use strict';
const assert = require('node:assert/strict');
const test = require('node:test');
const fs = require('node:fs');
const path = require('node:path');
const modelPath = path.resolve(__dirname, '../app/src/main/assets/adventure/adventure-model.js');
const M = fs.existsSync(modelPath) ? require(modelPath) : {};
const party = [{key:'p1',id:7,name:'Squirtle',level:12,types:['water'],maxHp:62},{key:'p2',id:16,name:'Pidgey',level:10,types:['normal','flying'],maxHp:51}];
const copy = x => JSON.parse(JSON.stringify(x));

test('model is available to offline CommonJS callers', () => {
  assert.equal(typeof M.generateRoute, 'function');
  assert.equal(typeof M.resolveEvent, 'function');
});

test('1000 seeds per destination have connected deterministic routes, support on every path and bounded elite chains', () => {
  let rareAbsent = 0, rarePresent = 0;
  for (const destination of ['meadow','cave','haunted','coast','volcano']) {
    for (let seed=0;seed<1000;seed++) {
      const route=M.generateRoute(seed,destination);
      assert.deepEqual(route,M.generateRoute(seed,destination));
      const nodes=route.nodes, byId=new Map(nodes.map(n=>[n.id,n]));
      assert.equal(byId.size,nodes.length);
      assert.equal(byId.get('start').depth,0);
      assert.equal(byId.get('boss').depth,7);
      assert.equal(byId.get('start').links.length,1);
      assert.equal(byId.get(byId.get('start').links[0]).type,'wild');
      for (const n of nodes) {
        assert.ok(M.NODE_TYPES.includes(n.type));
        assert.ok(Number.isInteger(n.seed));
        assert.ok(n.content && typeof n.content==='object');
        if (n.content.eventId) assert.ok(M.EVENTS[destination].some(e=>e.id===n.content.eventId));
        if (n.type==='boss') assert.equal(n.content.enemyId,M.DESTINATIONS[destination].bossId);
        for (const link of n.links) assert.equal(byId.get(link).depth,n.depth+1);
        if(n.type==='elite') assert.ok(n.links.every(id=>byId.get(id).type!=='elite'));
      }
      const reached=new Set();
      function visit(id,support,played) {
        const n=byId.get(id); reached.add(id);
        support ||= n.type==='camp';
        if(id==='boss') {assert.equal(played,7);assert.ok(support);return;}
        assert.ok(n.links.length);
        for(const next of n.links) visit(next,support,played+1);
      }
      visit('start',false,0);
      assert.equal(reached.size,nodes.length);
      assert.ok(nodes.some(n=>n.links.length>=2));
      assert.ok(nodes.some(n=>n.links.length===3));
      if(nodes.some(n=>n.type==='rare')) rarePresent++; else rareAbsent++;
    }
  }
  assert.ok(rareAbsent>0 && rarePresent>0);
});

test('node progression commits one pending node and disallows branches after committing a route', () => {
  const run=M.createRun('meadow',42,party);
  assert.equal(run.currentNode,'start'); assert.equal(run.phase,'route');
  const opening=M.availableNodes(run)[0];
  assert.equal(M.enterNode(run,'boss'),false);
  assert.equal(M.completeNode(run,opening.id),false);
  assert.equal(M.enterNode(run,opening.id),true);
  assert.equal(M.enterNode(run,opening.id),false);
  assert.equal(M.availableNodes(run).length,0);
  assert.equal(M.completeNode(run,'boss'),false);
  assert.equal(M.completeNode(run,opening.id),true);
  assert.equal(M.completeNode(run,opening.id),false);
  assert.equal(run.loot.rooms,1);
  while(run.currentNode!=='boss') {
    const next=M.availableNodes(run)[0];
    assert.ok(next);assert.equal(M.enterNode(run,next.id),true);assert.equal(M.completeNode(run,next.id),true);
  }
  assert.equal(run.phase,'complete'); assert.equal(run.loot.rooms,7);
  assert.equal(M.availableNodes(run).length,0);
});

test('active runs round trip exact party HP, loot, RNG, unknown metadata and event choices', () => {
  const save={coins:999,firstClears:{meadow:true},legacy:{custom:'keep'},adventureV2:{customFlag:7}};
  const v2=M.ensureState(save), run=M.createRun('coast','saved-seed',party);
  run.hpByKey.p1=21;run.loot.coins=34;run.loot.catches.push({id:120,key:'new'});run.customMetadata={keep:true};
  run.battle={turn:4,enemyHp:19};v2.activeExpedition=run;
  const restored=copy(save), before=copy(restored);
  M.ensureState(restored);
  assert.deepEqual(restored,before);
  assert.equal(save.coins,999);assert.deepEqual(save.firstClears,{meadow:true});assert.deepEqual(save.legacy,{custom:'keep'});
  assert.equal(v2.customFlag,7);
});

test('malformed additive save values normalize safely while retaining unknown fields', () => {
  const save={adventureV2:{schema:1,destinations:{meadow:{encounters:-3,custom:9}},activeRoam:'broken',activeExpedition:[],lastDestination:'wrong',custom:8},inventory:{potion:4}};
  const v2=M.ensureState(save);
  assert.equal(v2.activeRoam,null);assert.equal(v2.activeExpedition,null);
  assert.equal(v2.destinations.meadow.encounters,0);assert.equal(v2.destinations.meadow.custom,9);
  assert.equal(v2.custom,8);assert.equal(v2.lastDestination,'meadow');assert.deepEqual(save.inventory,{potion:4});
});

test('malformed nested active-run values repair without crashing or losing run metadata', () => {
  const run=M.createRun('cave',18,party);
  run.party=null;run.loot=null;run.hpByKey={p1:-22,p2:Infinity};run.pending={nodeId:'boss'};run.currentNode='missing';run.phase='battle';run.custom='preserve';
  const v2=M.ensureState({adventureV2:{activeExpedition:run}});
  assert.equal(v2.activeExpedition.custom,'preserve');
  assert.deepEqual(v2.activeExpedition.party,[]);
  assert.equal(v2.activeExpedition.hpByKey.p1,0);assert.equal(v2.activeExpedition.hpByKey.p2,0);
  assert.equal(v2.activeExpedition.currentNode,'start');assert.equal(v2.activeExpedition.pending,null);assert.equal(v2.activeExpedition.phase,'route');
  assert.equal(v2.activeExpedition.loot.coins,0);
});

test('discarding an invalid pending node restores a usable route and keeps unknown RNG metadata', () => {
  const run=M.createRun('cave',19,party),opening=M.availableNodes(run)[0];
  M.enterNode(run,opening.id);M.completeNode(run,opening.id);
  run.pending={nodeId:'bogus',type:'battle'};run.phase='battle';run.rng={state:-23,seed:22,custom:'keep'};
  const v2=M.ensureState({adventureV2:{activeExpedition:run}});
  assert.equal(v2.activeExpedition.pending,null);assert.equal(v2.activeExpedition.phase,'route');
  assert.ok(M.availableNodes(run).length>=2);
  assert.equal(run.rng.custom,'keep');assert.ok(run.rng.state>0);
});

test('claimed or terminal runs cannot create new effects or continue route exploration', () => {
  const event=M.EVENTS.meadow[0],fixture=eventRun('meadow',event.id),run=fixture.run;
  run.claimed=true;
  assert.equal(M.resolveEvent(run,fixture.node.id,'safe',{}).applied,false);
  assert.equal(M.completeNode(run,fixture.node.id),false);
  assert.equal(M.offerPerk(run,['compass']).applied,false);
  assert.deepEqual(M.availableNodes(run),[]);
});

test('each location has six contextual events with a safe choice and capability gate', () => {
  const ids=new Set();
  for(const dest of ['meadow','cave','haunted','coast','volcano']) {
    assert.equal(M.EVENTS[dest].length,6);
    for(const event of M.EVENTS[dest]) {
      assert.ok(!ids.has(event.id));ids.add(event.id);
      assert.ok(event.title && event.text);
      assert.ok(event.choices.some(c=>c.id==='safe' && M.choiceAvailable(c,{})));
      assert.ok(event.choices.some(c=>c.requires));
      assert.equal(new Set(event.choices.map(c=>c.id)).size,event.choices.length);
    }
  }
});

function eventRun(dest,eventId) {
  const run=M.createRun(dest,36,party);
  const node=run.route.nodes.find(n=>n.depth===2);
  node.type='event';node.content={eventId};run.currentNode=node.id;run.pending={nodeId:node.id,type:'event'};run.phase='event';
  return {run,node};
}

test('events reject invalid/gated/noncurrent choices and return effects once without touching HP or loot', () => {
  const event=M.EVENTS.meadow[0], {run,node}=eventRun('meadow',event.id);
  const gated=event.choices.find(c=>c.requires);
  assert.equal(M.choiceAvailable(gated,{party:[]}),false);
  assert.equal(M.resolveEvent(run,node.id,gated.id,{party:[]}).applied,false);
  assert.equal(M.resolveEvent(run,'boss','safe',{}).applied,false);
  assert.equal(M.resolveEvent(run,node.id,'not-a-choice',{}).applied,false);
  const before=copy({hp:run.hpByKey,loot:run.loot});
  const result=M.resolveEvent(run,node.id,'safe',{});
  assert.equal(result.applied,true);assert.ok(result.outcome);
  assert.deepEqual({hp:run.hpByKey,loot:run.loot},before);
  assert.deepEqual(M.resolveEvent(run,node.id,'risk',{}),{applied:false,outcome:null});
  const loaded=copy(run);
  assert.deepEqual(M.resolveEvent(loaded,node.id,'safe',{}),{applied:false,outcome:null});
  assert.ok(loaded.resolutions[node.id]);
});

test('event outcomes remain deterministic across reload and capability choice can spend an item once', () => {
  for(const dest of Object.keys(M.EVENTS)) for(const event of M.EVENTS[dest]) {
    const {run,node}=eventRun(dest,event.id), cloned=copy(run);
    const ctx={party:party.concat([{types:['fire','psychic','ghost','rock','ground','grass']}]),inventory:{potion:2,berry:2,pokeball:2}};
    const choice=event.choices.find(c=>c.requires);
    assert.equal(M.choiceAvailable(choice,ctx),true);
    const left=M.resolveEvent(run,node.id,'risk',ctx),right=M.resolveEvent(cloned,node.id,'risk',ctx);
    assert.deepEqual(left,right);
    for(const n of ['coins','xp']) assert.ok((left.outcome[n]||0)<=70);
    const fresh=eventRun(dest,event.id);
    const cap=M.resolveEvent(fresh.run,fresh.node.id,choice.id,ctx);
    assert.equal(cap.applied,true);
    if(choice.requires.item) assert.equal(cap.outcome.items[choice.requires.item],-1);
    assert.deepEqual(ctx.inventory,{potion:2,berry:2,pokeball:2});
  }
});

test('perks persist an offer, enforce capacity, and require an explicit valid replacement', () => {
  const run=M.createRun('cave',7,party);
  for(const id of ['compass','potionBelt','luckyCharm']) {
    assert.equal(M.offerPerk(run,[id]).applied,true);
    assert.equal(M.keepPerk(run,id).applied,true);
    assert.equal(M.keepPerk(run,id).applied,false);
  }
  assert.equal(M.offerPerk(run,['berrySatchel','quickClaw']).applied,true);
  const loaded=copy(run);
  assert.equal(M.offerPerk(loaded,['fieldMedic']).applied,false);
  assert.equal(M.keepPerk(loaded,'berrySatchel').requiresReplacement,true);
  assert.deepEqual(loaded.perks,['compass','potionBelt','luckyCharm']);
  assert.equal(M.keepPerk(loaded,'fieldMedic','compass').applied,false);
  assert.equal(M.keepPerk(loaded,'berrySatchel','missing').applied,false);
  assert.equal(M.keepPerk(loaded,'berrySatchel','compass').applied,true);
  assert.deepEqual(loaded.perks,['berrySatchel','potionBelt','luckyCharm']);
  assert.equal(M.keepPerk(loaded,'quickClaw','potionBelt').applied,false);
  assert.equal(M.offerPerk(loaded,['invalid']).applied,false);
});

test('encounter/catch field records preserve metadata and mastery is cosmetic bounded progression', () => {
  const v2=M.ensureState({adventureV2:{destinations:{meadow:{custom:'keep'}}}});
  assert.equal(M.mastery(v2.destinations.meadow),0);
  M.recordEncounter(v2,'meadow',{id:25,rare:true,shiny:true});
  M.recordEncounter(v2,'meadow',{id:25});
  M.recordCatch(v2,'meadow',{id:25});
  const record=v2.destinations.meadow;
  assert.equal(record.encounters,2);assert.equal(record.seen[25],2);assert.equal(record.caught[25],1);assert.equal(record.rare[25],1);assert.equal(record.shiny,1);assert.equal(record.custom,'keep');
  assert.ok(M.mastery(record)>0);
  const rich={encounters:100,seen:{1:1,2:1,3:1,4:1,5:1,6:1,7:1,8:1},caught:{1:1,2:1,3:1,4:1,5:1},rare:{25:1},shiny:1,clears:1,boss:true};
  assert.equal(M.mastery(rich),5);
  assert.equal(M.mastery({}),0);
});
