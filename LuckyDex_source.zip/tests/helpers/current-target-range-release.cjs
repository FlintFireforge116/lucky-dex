const assert=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path');
module.exports=function(){
  const root=path.resolve(__dirname,'../..'),read=f=>fs.readFileSync(path.join(root,f),'utf8');
  const pkg=JSON.parse(read('package.json')),lock=JSON.parse(read('package-lock.json')),gradle=read('app/build.gradle'),version=pkg.version;
  assert.ok(['0.42.1','0.42.2','0.42.3','0.42.4'].includes(version));assert.equal(lock.version,version);assert.equal(lock.packages[''].version,version);
  assert.equal(Number(gradle.match(/versionCode\s+(\d+)/)[1]),4200+Number(version.split('.')[2]));
  assert.equal(gradle.match(/versionName '([^']+)'/)[1],version);
  assert.ok(gradle.includes('LuckyDex-asset-builder/'+version));
  assert.ok(read('app/src/main/assets/app-v0167.js').includes("__LUCKYDEX_BUILD='"+version+"'"));
  assert.ok(read('app/src/main/assets/index.html').split('v'+version).length>=3);
};
