const assert=require('node:assert/strict');
const {launch,appPage}=require('../scripts/recovery-browser.cjs');
(async()=>{const browser=await launch(),errors=[];try{
const {page,context}=await appPage(browser,{width:360,height:800},errors);
await page.locator('#titleContinueBtn').tap();await page.locator('#starterChoices button').first().tap();
assert.equal(await page.evaluate(()=>typeof window.LuckyDexAdventure),'object','one Adventure 2.0 owner must be loaded');
assert.equal(await page.locator('[data-adv-view="map"]').isVisible(),true,'Adventure opens on a connected map');
assert.equal(await page.locator('#searchBtn').count(),0,'old Search card/owner DOM must be removed');
await page.locator('[data-adv-destination="meadow"]').tap();
await page.locator('[data-adv-action="roam"]').tap();
await page.waitForFunction(()=>document.querySelectorAll('[data-adv-hotspot]').length>=3);
await page.locator('[data-adv-hotspot]').first().tap();
assert.equal(await page.locator('[data-adv-view="reveal"],[data-adv-view="discovery"]').count(),1,'hotspot resolves to a scene once');
// An encounter seed that rolls legendary must not be consumed by the item-discovery stream.
await page.evaluate(()=>{const r=LuckyDexAdventureBridge.getState().adventureV2.activeRoam;r.reveal=null;r.hotspots=[{id:'legendary-fixture',seed:1,slot:0,clue:3,energy:'glint',x:18,y:22,consumed:false}];LuckyDexAdventure.hotspot('legendary-fixture');});
assert.equal(await page.evaluate(()=>LuckyDexAdventureBridge.getState().adventureV2.activeRoam.reveal.enemy.tier),'legendary','separate discovery RNG keeps legacy 1/400 legendary chance reachable');
const encountered=await page.evaluate(()=>state.stats.encounters);
await page.evaluate(()=>LuckyDexAdventure.hotspot('legendary-fixture'));
assert.equal(await page.evaluate(()=>state.stats.encounters),encountered,'consumed hotspot cannot count an encounter twice');
await page.evaluate(()=>LuckyDexAdventure.leave());
await page.evaluate(()=>navigate('trade'));assert.equal(await page.locator('.page.active').getAttribute('data-page'),'trade');assert.deepEqual(errors,[]);
await context.close();console.log('PASS Adventure map, contextual hotspot, owner cleanup and shared navigation');
}finally{await browser.close();}})().catch(e=>{console.error(e);process.exit(1)});
