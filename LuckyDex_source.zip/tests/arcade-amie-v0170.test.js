const assert=require('assert');
const path=require('path');

function loadAmie(){
  const modPath=path.resolve(__dirname,'../app/src/main/assets/arcade-amie-v0170.js');
  delete require.cache[modPath];
  global.LuckyDexArcadePlatform={
    caughtParticipants:(limit)=>[25,133,175,183].slice(0,limit).map(id=>({id,name:`P${id}`,image:`sprite://${id}`,shiny:false})),
    awardRun:()=>({coinsAwarded:0,itemAwarded:null})
  };
  global.API={sprite:id=>`sprite://${id}`};
  global.state={arcade:{bestBerryPicker:{easy:0,normal:0,hard:0},bestHeadIt:{easy:0,normal:0,hard:0,unlimited:0,unlimitedStreak:0},bestTilePuzzle:{easy:null,normal:null,hard:null}}};
  global.save=()=>{}; global.vibrate=()=>{};
  return require(modPath);
}

const a=loadAmie();

assert.deepStrictEqual(a.BERRY_CONFIGS.easy,{customers:2,berryCount:3,durationMs:45000,patienceMs:7500,dailyTarget:8,coinCap:70});
assert.deepStrictEqual(a.BERRY_CONFIGS.normal,{customers:3,berryCount:5,durationMs:50000,patienceMs:6000,dailyTarget:14,coinCap:100});
assert.deepStrictEqual(a.BERRY_CONFIGS.hard,{customers:4,berryCount:7,durationMs:55000,patienceMs:4500,dailyTarget:20,coinCap:140});
assert.strictEqual(a.berryDeliveryScore(0,1),150);
assert.strictEqual(a.berryDeliveryScore(5,0.5),175);
assert.strictEqual(a.berryDeliveryScore(99,0),200);
assert.strictEqual(a.berryPayout(100,'easy'),20);
assert.strictEqual(a.berryPayout(1400,'easy'),70);
assert.strictEqual(a.berryPayout(2800,'hard'),140);
assert.deepStrictEqual(a.berryReward('easy'),{key:'berry',amount:2});
assert.deepStrictEqual(a.berryReward('normal'),{key:'berry',amount:3});
assert.deepStrictEqual(a.berryReward('hard'),{key:'berry',amount:4});
const fallback=a.safeParticipants(4);
assert.strictEqual(fallback.length,4);
assert.deepStrictEqual(fallback.map(x=>x.id),[25,133,175,183]);
console.log('PASS Berry Picker config/scoring/payout/fallback participants');

assert.deepStrictEqual(a.HEAD_CONFIGS.easy,{lanes:2,durationMs:45000,fallStartMs:2500,fallFloorMs:1400,dailyTarget:1200,coinCap:70});
assert.deepStrictEqual(a.HEAD_CONFIGS.normal,{lanes:3,durationMs:60000,fallStartMs:2200,fallFloorMs:1100,dailyTarget:2000,coinCap:100});
assert.deepStrictEqual(a.HEAD_CONFIGS.hard,{lanes:4,durationMs:60000,fallStartMs:1900,fallFloorMs:800,dailyTarget:2800,coinCap:140});
assert.deepStrictEqual(a.HEAD_CONFIGS.unlimited,{lanes:3,durationMs:null,fallStartMs:2100,fallFloorMs:700,dailyTarget:3200,dailyStreak:20,coinCap:150});
assert.strictEqual(a.headTimingGrade(90),'perfect');
assert.strictEqual(a.headTimingGrade(-89),'perfect');
assert.strictEqual(a.headTimingGrade(220),'good');
assert.strictEqual(a.headTimingGrade(221),'miss');
assert.strictEqual(a.headScore('perfect',0,false),100);
assert.strictEqual(a.headScore('good',4,false),80);
assert.strictEqual(a.headScore('perfect',30,false),200);
assert.strictEqual(a.headScore('perfect',5,true),325);
assert.strictEqual(a.headUnlimitedEnded(2),false);
assert.strictEqual(a.headUnlimitedEnded(3),true);
assert.strictEqual(a.headFallDuration('hard',0),1900);
assert.strictEqual(a.headFallDuration('hard',999),800);
assert.deepStrictEqual(a.headReward('easy',2000,10),{key:'potion',amount:1});
assert.deepStrictEqual(a.headReward('hard',4199,20),{key:'potion',amount:1});
assert.deepStrictEqual(a.headReward('hard',4200,20),{key:'greatball',amount:1});
assert.deepStrictEqual(a.headReward('unlimited',5000,29),{key:'potion',amount:1});
assert.deepStrictEqual(a.headReward('unlimited',5000,30),{key:'greatball',amount:1});
console.log('PASS Head It timing/termination/speed/scoring/reward logic');

function seeded(seed){let x=seed>>>0;return ()=>{x=(x*1664525+1013904223)>>>0;return x/4294967296;};}
function adjacent(a,b,size){const ar=Math.floor(a/size),ac=a%size,br=Math.floor(b/size),bc=b%size;return Math.abs(ar-br)+Math.abs(ac-bc)===1;}
for(const size of [3,4,5]){
  for(let seed=1;seed<=200;seed++){
    const trace=[];
    const board=a.makeSolvablePuzzle(size,seeded(seed),trace);
    assert.strictEqual(board.length,size*size);
    assert.strictEqual(a.isSolvedPuzzle(board),false,`size ${size} seed ${seed} started solved`);
    for(const step of trace)assert.ok(adjacent(step.emptyBefore,step.tileIndex,size),`illegal shuffle step ${JSON.stringify(step)}`);
    const replay=board.slice();
    for(let i=trace.length-1;i>=0;i--){
      const step=trace[i];
      const empty=replay.indexOf(size*size-1);
      assert.strictEqual(empty,step.tileIndex);
      [replay[empty],replay[step.emptyBefore]]=[replay[step.emptyBefore],replay[empty]];
    }
    assert.strictEqual(a.isSolvedPuzzle(replay),true,`inverse replay failed size ${size} seed ${seed}`);
  }
}
assert.strictEqual(a.isSolvedPuzzle([0,1,2,3,4,5,6,7,8]),true);
assert.strictEqual(a.isSolvedPuzzle([0,1,2,3,4,5,6,8,7]),false);
assert.strictEqual(a.tilePayout('easy',0,0),60);
assert.strictEqual(a.tilePayout('normal',180,640),35);
assert.ok(a.tilePayout('hard',100,100)<=130);
assert.deepStrictEqual(a.tileReward('easy'),{key:'pokeball',amount:2});
assert.deepStrictEqual(a.tileReward('normal'),{key:'pokeball',amount:3});
assert.deepStrictEqual(a.tileReward('hard'),{key:'greatball',amount:1});
console.log('PASS Tile Puzzle solvable generation/completion/payout/reward logic');
