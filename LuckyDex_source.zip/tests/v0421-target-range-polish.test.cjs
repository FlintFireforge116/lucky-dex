const test=require('node:test');
const assert=require('node:assert/strict');
const fs=require('node:fs');
const path=require('node:path');
const ROOT=path.resolve(__dirname,'..');
const asset=n=>path.join(ROOT,'app/src/main/assets',n);
const js=()=>fs.readFileSync(asset('arcade-target-range.js'),'utf8');
const css=()=>fs.readFileSync(asset('arcade-target-range.css'),'utf8');

test('active Target Range is a no-scroll single-screen mobile composition with redundant session strip hidden',()=>{
  const s=js(),c=css();
  assert.match(s,/classList\.toggle\('is-playing',!!v\)/);
  assert.match(c,/\.target-range-game\.is-playing\{[^}]*overflow:\s*hidden/i);
  assert.match(c,/\.target-range-game\.is-playing\s*>\s*\.arcade-session-strip\{[^}]*display:\s*none\s*!important/i);
  assert.match(c,/\.target-range-game\.is-playing\s+\.target-range-shell\{[^}]*flex:\s*1/i);
  assert.match(c,/\.target-range-play\{[^}]*grid-template-rows:\s*auto\s+minmax\(0,1fr\)\s+auto/i);
  assert.doesNotMatch(c,/\.target-range-gallery\{[^}]*min-height:\s*330px/i);
});

test('live HUD is compact and high contrast rather than stacked pale status cards',()=>{
  const s=js(),c=css();
  assert.match(s,/id="targetRangeTargetCount"/);
  assert.match(c,/\.target-range-hud\{[^}]*grid-template-columns:\s*repeat\(3/i);
  assert.match(c,/\.target-range-hud[^}]*color:\s*#f/i);
  assert.match(c,/\.target-range-hud[^}]*background:\s*#1/i);
  assert.doesNotMatch(s,/class="target-range-meta"/);
});

test('aiming lane is raised, Pokemon is smaller, and controls remain comfortably above the safe area',()=>{
  const s=js(),c=css();
  assert.match(s,/aimY=\.32/);
  assert.match(s,/Math\.min\(\.68,aimY\+dy\*1\.35\)/);
  assert.match(c,/\.target-range-pokemon\{[^}]*width:\s*clamp\([^,]+,[^,]+,58px\)/i);
  assert.match(c,/\.target-range-control\{[^}]*min-height:\s*64px/i);
  assert.match(c,/padding-bottom:\s*max\([^;]*env\(safe-area-inset-bottom\)/i);
});

test('range background is selected from the packaged Gen III type environments',()=>{
  const s=js(),c=css();
  assert.match(s,/arcade\/dash\/gen3\/previews\/\$\{attackType\}\.png/);
  assert.match(s,/--range-bg/);
  assert.match(c,/var\(--range-bg\)/);
  assert.match(c,/image-rendering:\s*pixelated/i);
});

test('generated targets stay in the upper shooting lane instead of crowding the touch controls',()=>{
  const core=require(asset('arcade-target-range-core.js'));
  const round=core.createRound({participant:{baseStat:80},profile:core.difficultyProfile('hard'),seed:123});
  assert.ok(round.targets.every(t=>t.y>=.14&&t.y<=.52),round.targets.map(t=>t.y));
});

test('visual projectile path leaves the Pokemon, passes through the aim line, and finishes at solved impact',()=>{
  const core=require(asset('arcade-target-range-core.js'));
  assert.equal(typeof core.projectileVisualPoint,'function');
  const opts={startX:.5,startY:.84,aimX:.37,aimY:.28,impactX:.42,impactY:.35};
  assert.deepEqual(core.projectileVisualPoint({...opts,progress:0}),{x:.5,y:.84});
  const aim=core.projectileVisualPoint({...opts,progress:.55});
  assert.ok(Math.abs(aim.x-.37)<1e-9,aim);
  assert.ok(Math.abs(aim.y-.28)<1e-9,aim);
  assert.deepEqual(core.projectileVisualPoint({...opts,progress:1}),{x:.42,y:.35});
});

test('runtime animates each shot frame-by-frame through the calibrated visual path',()=>{
  const s=js(),c=css();
  assert.match(s,/function animateProjectile\(/);
  assert.match(s,/core\.projectileVisualPoint\(/);
  assert.match(s,/raf\(step\)/);
  assert.doesNotMatch(c,/transition:left var\(--shot-ms\)/i);
});

test('normal target prompts no longer occupy a permanent instruction card over the playfield',()=>{
  const s=js(),c=css();
  assert.match(s,/feedback\('',\s*''\)/);
  assert.match(s,/n\.hidden=!title&&!body/);
  assert.match(c,/\.target-range-feedback\[hidden\]\{display:none!important\}/i);
});
