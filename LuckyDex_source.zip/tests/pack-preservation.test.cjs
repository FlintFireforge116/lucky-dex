// Explicit user contract: these accepted v0.14 files must stay byte-for-byte.
const {test}=require('node:test'),assert=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path'),crypto=require('node:crypto');
test('Accepted v0.14 pack implementation and regression tests remain byte-for-byte unchanged',()=>{
  const expected={
    'app/src/main/assets/pack-opening.js':'3EED814E1D0EA728FAA644ECE747E517AF070D81BC453DDD7340EFBE71171F5F',
    'app/src/main/assets/pack-flow.js':'75BD236B30229E5A4039A7D72037B2441F0F1C15F6230A8FF26317D014DCEAAE',
    'app/src/main/assets/pack-opening.css':'98165BBFBC8E6D194FE3DCF071B163CCB6930F81002E23557F59698302E4D296',
    'tests/pack-opening.test.cjs':'1837D822E83884FF9EF4A072E236A3E1C7B8A011C10C0DB1298D5942B817C9D6',
    'tests/browser-smoke.test.cjs':'68D48F94024ECF29DB1620FE0D4FE091A9AC759E1467B49795BA88B86B8C0AC2'
  };
  for(const [file,hash] of Object.entries(expected))assert.equal(crypto.createHash('sha256').update(fs.readFileSync(path.resolve(__dirname,'..',file))).digest('hex').toUpperCase(),hash,file);
});
