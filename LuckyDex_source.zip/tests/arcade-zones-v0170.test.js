const assert=require('assert');
const path=require('path');
const modPath=path.resolve(__dirname,'../app/src/main/assets/arcade-zones-v0170.js');
delete require.cache[modPath];
global.LuckyDexArcadePlatform={ZONES:{
  amie:{id:'amie',name:'Kalos Amie Garden',icon:'🌸',games:['berryPicker','headIt','tilePuzzle']},
  gameCorner:{id:'gameCorner',name:'Game Corner',icon:'🎰',games:['voltorb','ballDrop']},
  discovery:{id:'discovery',name:'Discovery District',icon:'🔬',games:['fossil','ditto','unown','quiz']},
  performance:{id:'performance',name:'Performance Stage',icon:'🎭',games:['berry','clefairy']}
}};
const z=require(modPath);
const expectedLegacy=['voltorb','ballDrop','fossil','ditto','unown','quiz','berry','clefairy'];
for(const game of expectedLegacy){
  const hits=Object.values(z.ZONE_MAP).filter(zone=>zone.games.includes(game));
  assert.strictEqual(hits.length,1,`${game} should appear in exactly one zone`);
  assert.strictEqual(z.zoneForGame(game),hits[0].id);
}
for(const game of ['berryPicker','headIt','tilePuzzle'])assert.strictEqual(z.zoneForGame(game),'amie');
for(const zone of Object.values(z.ZONE_MAP))assert.ok(!zone.games.includes('safari'));
assert.strictEqual(z.zoneForGame('safari'),null);
assert.strictEqual(new Set(Object.values(z.ZONE_MAP).flatMap(x=>x.games)).size,11);
console.log('PASS zone mapping contains every visible game once and excludes Safari');
