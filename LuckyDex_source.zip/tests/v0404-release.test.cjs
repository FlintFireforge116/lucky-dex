'use strict';
const test=require('node:test');
const assert=require('node:assert/strict');
const fs=require('node:fs');
const path=require('node:path');
const root=path.resolve(__dirname,'..');
const read=p=>fs.readFileSync(path.join(root,p),'utf8');

test('v0.40.4 release metadata is aligned',()=>{
  const pkg=JSON.parse(read('package.json'));
  const lock=JSON.parse(read('package-lock.json'));
  const gradle=read('app/build.gradle');
  const html=read('app/src/main/assets/index.html');
  const app=read('app/src/main/assets/app-v0167.js');
  assert.equal(pkg.version,'0.40.4');
  assert.equal(lock.version,'0.40.4');
  assert.equal(lock.packages[''].version,'0.40.4');
  assert.match(gradle,/versionCode\s+4004/);
  assert.match(gradle,/versionName\s+'0\.40\.4'/);
  assert.match(gradle,/LuckyDex-asset-builder\/0\.40\.4/);
  assert.match(html,/v0\.40\.4/);
  assert.match(app,/__LUCKYDEX_BUILD='0\.40\.4'/);
});
