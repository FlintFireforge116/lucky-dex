from pathlib import Path
import re

ROOT = Path(__file__).resolve().parents[1]
ASSETS = ROOT / 'app/src/main/assets'


def css_rule(css: str, selector: str) -> str:
    m = re.search(re.escape(selector) + r'\s*\{([^}]*)\}', css, re.S)
    assert m, f'Missing CSS rule for {selector}'
    return m.group(1)


def test_ball_drop_canvas_preserves_intrinsic_aspect_and_machine_does_not_stretch():
    css = (ASSETS / 'quality-content-v0167.css').read_text(encoding='utf-8') + '\n' + (ASSETS / 'quality-content-v0168.css').read_text(encoding='utf-8')
    canvas = css_rule(css, '#ballDropCanvas')
    machine = css_rule(css, '.ball-drop-machine')
    assert re.search(r'height\s*:\s*auto\s*!important', canvas), canvas
    assert re.search(r'aspect-ratio\s*:\s*18\s*/\s*19\s*!important', canvas), canvas
    assert re.search(r'min-height\s*:\s*0\s*!important', canvas), canvas
    assert re.search(r'flex\s*:\s*0\s+0\s+auto\s*!important', machine), machine


def test_trade_animation_has_no_mid_sequence_narration_but_keeps_final_result():
    js = (ASSETS / 'trade-v0163.js').read_text(encoding='utf-8')
    banned = ['Trading…', 'Checking cards…', 'Turning cards over…', 'Linking…', 'Receiving…']
    for phrase in banned:
        assert phrase not in js, f'Visible narration still present: {phrase}'
    assert "Trade complete!" in js
    # The result copy is hidden until the received card has actually been revealed.
    assert re.search(r'class="trade-fx-copy"[^>]*hidden', js), 'Trade result copy should start hidden'
    assert re.search(r"copy\.hidden\s*=\s*false", js), 'Trade result copy should only be shown for final result'
