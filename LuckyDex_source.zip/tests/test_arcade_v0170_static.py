from pathlib import Path
import re

ROOT = Path(__file__).resolve().parents[1]
ASSETS = ROOT / 'app/src/main/assets'
APP = ASSETS / 'app-v0167.js'
INDEX = ASSETS / 'index.html'
GRADLE = ROOT / 'app/build.gradle'


def test_v0170_save_defaults_and_platform_script_order():
    js = APP.read_text(encoding='utf-8')
    html = INDEX.read_text(encoding='utf-8')
    assert re.search(r'saveVersion\s*:\s*6', js)
    assert re.search(r'migrated\.saveVersion\s*=\s*6', js)
    assert re.search(r'state\.saveVersion\s*=\s*6', js)
    for key in ['dailyRewards','bestBerryPicker','bestHeadIt','bestTilePuzzle','lastArcadeZone']:
        assert key in js, f'missing Arcade default {key}'
    app_pos = html.index('<script src="app-v0167.js"></script>')
    platform_pos = html.index('<script src="arcade-platform-v0170.js"></script>')
    next_script = re.search(r'<script src="([^"]+)"', html[app_pos + len('<script src="app-v0167.js"></script>'):])
    assert platform_pos > app_pos
    assert next_script and next_script.group(1) == 'arcade-platform-v0170.js'


def test_v0170_signing_config_preserved():
    gradle = GRADLE.read_text(encoding='utf-8')
    assert "storeFile file('luckydex-dev.keystore')" in gradle
    assert "keyAlias 'luckydex'" in gradle
    assert "storePassword 'luckydex-dev'" in gradle
    assert "keyPassword 'luckydex-dev'" in gradle


def test_berry_picker_shell_and_accessible_input_paths():
    html = INDEX.read_text(encoding='utf-8')
    js = (ASSETS / 'arcade-amie-v0170.js').read_text(encoding='utf-8') if (ASSETS / 'arcade-amie-v0170.js').exists() else ''
    for needle in ['id="berryPickerGame"','id="berryPickerModes"','id="berryPickerCustomers"','id="berryPickerTray"','id="berryPickerTimer"','id="berryPickerScore"','id="berryPickerCombo"','id="berryPickerStartBtn"','id="berryPickerRestartBtn"']:
        assert needle in html
    assert 'pointerdown' in js and 'pointermove' in js and 'pointerup' in js
    assert 'selectedBerry' in js and 'data-berry-customer' in js


def test_head_it_shell_has_modes_lanes_and_tap_controls():
    html = INDEX.read_text(encoding='utf-8')
    js_path = ASSETS / 'arcade-amie-v0170.js'
    js = js_path.read_text(encoding='utf-8') if js_path.exists() else ''
    for needle in ['id="headItGame"','id="headItModes"','id="headItPlayfield"','id="headItLanes"','id="headItScore"','id="headItCombo"','id="headItMisses"','id="headItStartBtn"']:
        assert needle in html
    assert 'data-head-lane' in js
    assert 'dragstart' not in js


def test_tile_puzzle_shell_has_grid_preview_timer_moves_and_restart():
    html = INDEX.read_text(encoding='utf-8')
    for needle in ['id="tilePuzzleGame"','id="tilePuzzleModes"','id="tilePuzzleBoard"','id="tilePuzzleTarget"','id="tilePuzzleTargetName"','id="tilePuzzleTimer"','id="tilePuzzleMoves"','id="tilePuzzleStartBtn"','id="tilePuzzleRestartBtn"']:
        assert needle in html


def test_arcade_world_and_venue_shells_replace_v0170_zone_cards():
    html = INDEX.read_text(encoding='utf-8')
    for needle in ['id="arcadeWorldView"','id="arcadeWorldRoute"','id="arcadeVenueView"','id="arcadeVenueTitle"','id="arcadeVenueGames"','id="arcadeWorldBack"']:
        assert needle in html
    assert '‹ WORLD' in html
    assert 'class="arcade-zone-card"' not in html
    assert 'id="arcadeMap"' not in html
    assert 'id="arcadeLegacyHooks"' in html and 'hidden' in html


def test_arcade_zone_html_ids_are_unique():
    html = INDEX.read_text(encoding='utf-8')
    ids = re.findall(r'\bid="([^"]+)"', html)
    assert len(ids) == len(set(ids)), [x for x in ids if ids.count(x) > 1]


def test_ball_drop_v0170_uses_platform_payout_without_changing_slot_scores():
    js = (ASSETS / 'quality-content-v0168.js').read_text(encoding='utf-8')
    assert 'Math.round(g.score*.62)' not in js
    assert 'ordinaryPoints' in js and 'jackpots' in js
    assert 'BALL_SLOT_SCORE_V168 = [150,250,400,1000,400,250,150]' in js
    assert 'g.jackpots++' in js
    assert 'g.ordinaryPoints+=pinBonus' in js
    assert 'g.ordinaryPoints+=slotPoints' in js
    assert 'ballDropPayout' in js
    assert "awardRun({gameId:'ballDrop'" in js


def test_v0170_release_metadata_script_order_syntax_and_signing_keystore():
    import hashlib
    import subprocess
    gradle = GRADLE.read_text(encoding='utf-8')
    app_js = APP.read_text(encoding='utf-8')
    html = INDEX.read_text(encoding='utf-8')
    assert 'versionCode 201' in gradle
    assert "versionName '0.19.1'" in gradle
    assert "window.__LUCKYDEX_BUILD='0.19.1-startup-hotfix';" in app_js
    assert 'v0.19.1' in html
    order = [
        'app-v0167.js',
        'arcade-platform-v0170.js',
        'arcade-session-v0180.js',
        'berry-blender-v0164.js',
        'arcade-expansion-v0166.js',
        'quality-content-v0167.js',
        'quality-content-v0168.js',
        'arcade-amie-v0170.js',
        'arcade-amie-v0180.js',
        'arcade-ball-drop-v0180.js',
        'arcade-amie-v0190.js',
        'arcade-classics-v0190.js',
        'arcade-polish-v0190.js',
        'arcade-world-v0190.js',
    ]
    positions = [html.index(f'<script src="{name}"></script>') for name in order]
    assert positions == sorted(positions), list(zip(order, positions))
    ids = re.findall(r'\bid="([^"]+)"', html)
    assert len(ids) == len(set(ids)), [x for x in ids if ids.count(x) > 1]
    for js_path in ASSETS.glob('*.js'):
        result = subprocess.run(['node', '--check', str(js_path)], capture_output=True, text=True)
        assert result.returncode == 0, f'{js_path.name}: {result.stderr}'
    keystore = ROOT / 'app/luckydex-dev.keystore'
    assert keystore.exists()
    assert hashlib.sha256(keystore.read_bytes()).hexdigest() == '90de91cea469f0eec5fbd69389cf03adc94ced396fa2ec85e2a51d2365a4f6d3'
    assert "storeFile file('luckydex-dev.keystore')" in gradle
    assert "keyAlias 'luckydex'" in gradle
    assert "storePassword 'luckydex-dev'" in gradle
    assert "keyPassword 'luckydex-dev'" in gradle
