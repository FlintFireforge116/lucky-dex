const {test,before,after}=require('node:test');
const assert=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path'),http=require('node:http');
const zlib=require('node:zlib');
// Decode Chromium screenshot pixels for real composited-reflection contrast.
function pixels(png){
  let width,height,channels;const chunks=[];
  for(let offset=8;offset<png.length;){const length=png.readUInt32BE(offset),type=png.toString('ascii',offset+4,offset+8),data=png.subarray(offset+8,offset+8+length);if(type==='IHDR'){width=data.readUInt32BE(0);height=data.readUInt32BE(4);assert.equal(data[8],8);channels=data[9]===6?4:3;}if(type==='IDAT')chunks.push(data);offset+=length+12;}
  const raw=zlib.inflateSync(Buffer.concat(chunks)),stride=width*channels,out=Buffer.alloc(height*stride);
  const paeth=(a,b,c)=>{const p=a+b-c,pa=Math.abs(p-a),pb=Math.abs(p-b),pc=Math.abs(p-c);return pa<=pb&&pa<=pc?a:pb<=pc?b:c;};
  for(let y=0;y<height;y++){const filter=raw[y*(stride+1)];for(let x=0;x<stride;x++){const i=y*stride+x,left=x>=channels?out[i-channels]:0,up=y?out[i-stride]:0,upperLeft=y&&x>=channels?out[i-stride-channels]:0;const prediction=[0,left,up,Math.floor((left+up)/2),paeth(left,up,upperLeft)][filter];out[i]=(raw[y*(stride+1)+x+1]+prediction)&255;}}
  return {width,height,channels,data:out};
}
let pw;try{pw=require('playwright');}catch(_){pw=require(require.resolve('playwright',{paths:['C:/Users/sjwal/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/node_modules']}));}
let server,browser,origin;const assets=path.resolve(__dirname,'../app/src/main/assets');
before(async()=>{
  server=http.createServer((req,res)=>{
    const name=decodeURIComponent(new URL(req.url,'http://localhost').pathname),file=path.resolve(assets,'.'+(name==='/'?'/index.html':name));
    if(!file.startsWith(assets+path.sep)){res.writeHead(403).end();return;}
    fs.readFile(file,(err,data)=>{if(err){res.writeHead(404).end();return;}res.setHeader('Content-Type',file.endsWith('.js')?'application/javascript':file.endsWith('.css')?'text/css':file.endsWith('.png')?'image/png':'text/html');res.end(data);});
  });
  await new Promise(r=>server.listen(0,'127.0.0.1',r));origin=`http://127.0.0.1:${server.address().port}`;
  const chrome='C:/Program Files/Google/Chrome/Application/chrome.exe';
  browser=await pw.chromium.launch({headless:true,...(process.env.CHROME_PATH?{executablePath:process.env.CHROME_PATH}:fs.existsSync(chrome)?{executablePath:chrome}:{})});
});
after(async()=>{await browser?.close();await new Promise(r=>server.close(r));});
async function setup(viewport={width:360,height:800},blocked=[]){
  const context=await browser.newContext({viewport,isMobile:true,hasTouch:true,deviceScaleFactor:1}),page=await context.newPage(),errors=[];
  page.on('pageerror',e=>errors.push(e.message));
  await context.route('**/*',r=>blocked.some(f=>r.request().url().endsWith(f))?r.abort():r.request().url().startsWith(origin)?r.continue():r.fulfill({headers:{'access-control-allow-origin':'*'},json:{sets:[],results:[],pokemon:[]}}));
  await page.goto(origin);await page.waitForTimeout(180);
  assert.equal(await page.evaluate(()=>typeof LuckyDexDebug?.playClefairyAction),'function','Production Clefairy debug replay is missing');
  await page.evaluate(()=>{document.getElementById('titleScreen').classList.add('hidden-title');navigate('arcade');openArcadeGame('clefairy');});
  await page.evaluate(()=>clefairyScene.ready);return {context,page,errors};
}
async function snapshot(page){return page.evaluate(()=>{
  const stage=document.getElementById('clefairyStage'),actor=stage.querySelector('.clefairy-character .clefairy-motion'),reflection=stage.querySelector('.clefairy-reflection .clefairy-motion');
  const poses=root=>[...root.querySelectorAll('[data-pose]')].map(el=>({pose:el.dataset.pose,opacity:+getComputedStyle(el).opacity,src:el.querySelector('img').getAttribute('src')}));
  return {state:stage.dataset.state,action:stage.dataset.action,actor:getComputedStyle(actor).transform,reflection:getComputedStyle(reflection).transform,actorPoses:poses(actor),reflectionPoses:poses(reflection),background:getComputedStyle(document.getElementById('clefairyBackground')).transform,light:+stage.dataset.light,highlight:[...document.querySelectorAll('[data-memory][aria-pressed="true"]')].map(b=>+b.dataset.memory)};
});}
for(const viewport of [{width:360,height:800},{width:412,height:915}])test(`offline actions, stable scenery, reflection sync and debug isolation at ${viewport.width}x${viewport.height}`,async()=>{
  const {context,page,errors}=await setup(viewport);
  try{
    const before=await page.evaluate(()=>({state:JSON.stringify(state),game:JSON.stringify(memoryGame),save:localStorage.getItem('luckyDexSave')}));
    await context.setOffline(true);
    const probe=await page.evaluate(async()=>{
      const all=[];
      for(const action of ['star','song','moon','spin']){
        const start=performance.now(),done=LuckyDexDebug.playClefairyAction(action),samples=[];
        await new Promise(resolve=>{function tick(){
          const stage=document.getElementById('clefairyStage'),actor=stage.querySelector('.clefairy-character .clefairy-motion'),refl=stage.querySelector('.clefairy-reflection .clefairy-motion');
          const weights=root=>[...root.querySelectorAll('[data-pose]')].map(p=>+getComputedStyle(p).opacity);
          samples.push({t:performance.now()-start,transform:getComputedStyle(actor).transform,refl:getComputedStyle(refl).transform,weights:weights(actor),reflWeights:weights(refl),rotation:+stage.dataset.rotation,state:stage.dataset.state,background:getComputedStyle(document.getElementById('clefairyBackground')).transform,light:+stage.dataset.light});
          if(stage.dataset.state==='idle'&&performance.now()-start>200)resolve();else requestAnimationFrame(tick);
        }requestAnimationFrame(tick);});
        await done;all.push({action,samples});
      }return all;
    });
    for(const {action,samples} of probe){
      console.log(`${viewport.width} ${action} RAF frames: ${samples.length}, first timings: ${samples.slice(0,8).map(s=>s.t.toFixed(1)).join(', ')}`);
      assert.ok(samples.length>30,`${action}: only ${samples.length} frames, last ${JSON.stringify(samples.at(-1))}`);assert.ok(new Set(samples.map(s=>s.transform)).size>20,`${action}: transforms ${new Set(samples.map(s=>s.transform)).size}`);
      for(const s of samples){assert.equal(s.background,'none');assert.equal(s.transform,s.refl,action);assert.deepEqual(s.weights,s.reflWeights);}
      if(action!=='spin')assert.ok(samples.some(s=>s.weights.filter(v=>v>0&&v<1).length===2),`${action} has no overlapping pose crossfade`);
      if(action==='moon')assert.ok(samples.some(s=>s.light>.8));
      if(action==='spin'){assert.ok(samples.some(s=>s.rotation>170&&s.rotation<220));assert.equal(Math.round(samples.at(-1).rotation)%360,0);assert.ok(samples.find(s=>s.rotation>=359).t>=1000);}
    }
    const after=await page.evaluate(()=>({state:JSON.stringify(state),game:JSON.stringify(memoryGame),save:localStorage.getItem('luckyDexSave')}));assert.deepEqual(after,before);assert.deepEqual(errors,[]);
    const layout=await page.evaluate(()=>[...document.querySelectorAll('#clefairyStage,#memoryPad button,#memoryStartBtn,#memoryCashBtn')].map(e=>{const r=e.getBoundingClientRect();return {width:r.width,x:r.x,right:r.right,bottom:r.bottom};}));
    for(const r of layout){assert.ok(r.width>0&&r.x>=0&&r.right<=viewport.width&&r.bottom<=viewport.height,JSON.stringify(r));}
    fs.mkdirSync(path.resolve(__dirname,'../artifacts'),{recursive:true});await page.screenshot({path:path.resolve(__dirname,`../artifacts/clefairy-idle-${viewport.width}.png`)});
  }finally{await context.close();}
});
test('Repeated action retargeting crossfades without src changes, and idle/reset/exit cancel stale work',async()=>{
  const {context,page,errors}=await setup();try{
    await page.evaluate(()=>{window.poseMutations=[];new MutationObserver(m=>poseMutations.push(...m.filter(x=>x.attributeName==='src').map(x=>x.target.src))).observe(document.getElementById('clefairyStage'),{subtree:true,attributes:true});LuckyDexDebug.playClefairyAction('song');});
    await page.waitForTimeout(400);const old=await snapshot(page);
    await page.evaluate(()=>LuckyDexDebug.playClefairyAction('moon')); // Promise resolves at completion; next test probes cancellation separately.
    assert.equal(old.action,'song');assert.deepEqual(await page.evaluate(()=>poseMutations),[]);
    await page.evaluate(()=>{LuckyDexDebug.playClefairyAction('spin');});await page.waitForTimeout(180);await page.evaluate(()=>LuckyDexDebug.playClefairyAction('idle'));
    assert.equal((await snapshot(page)).state,'idle');
    await page.evaluate(()=>{LuckyDexDebug.playClefairyAction('star');resetMemoryGame();});assert.equal((await snapshot(page)).state,'idle');
    await page.evaluate(()=>{LuckyDexDebug.playClefairyAction('spin');closeArcadeGame(true);});
    const frame=await page.evaluate(()=>document.getElementById('clefairyStage').dataset.frame);
    await page.waitForTimeout(1800);assert.equal(await page.evaluate(()=>document.getElementById('clefairyStage').dataset.frame),frame);
    assert.equal(await page.evaluate(()=>document.getAnimations().filter(a=>a.effect?.target?.closest('#clefairyStage')).length),0);
    assert.equal(await page.evaluate(()=>memoryGame),null);assert.deepEqual(errors,[]);
  }finally{await context.close();}
});
test('Missing action artwork falls back to usable idle without a blank stage or contaminated Spin PNG',async()=>{
  const {context,page,errors}=await setup(undefined,['clefairy_pose_star.png','clefairy_pose_moon.png','clefairy_pose_spin.png']);try{
    await context.setOffline(true);await page.evaluate(()=>{LuckyDexDebug.playClefairyAction('star');});await page.waitForTimeout(250);
    const p=await snapshot(page);assert.equal(p.actorPoses.find(p=>p.pose==='idle').opacity,1);
    assert.ok(await page.evaluate(()=>[...document.querySelectorAll('.clefairy-character img')].some(i=>i.complete&&i.naturalWidth>0)));
    assert.ok(p.actorPoses.every(p=>!p.src.includes('spin.png')));assert.deepEqual(errors,[]);
  }finally{await context.close();}
});
test('Generated sequence waits for each scene cue and highlights it; player input highlights and rewards stay exactly once',async()=>{
  const {context,page,errors}=await setup();try{
    await page.evaluate(()=>{memoryGame.sequence=[0,1,2,3];memoryGame.round=4;window.sequenceDone=false;flashMemorySequence().then(()=>sequenceDone=true);});
    for(const [action,n] of [['star',0],['song',1],['moon',2],['spin',3]]){
      await page.waitForFunction(action=>document.getElementById('clefairyStage').dataset.action===action,action);
      await page.waitForTimeout(150);const s=await snapshot(page);assert.deepEqual(s.highlight,[n]);
      assert.equal(await page.evaluate(()=>sequenceDone),false);
      await page.waitForFunction(action=>document.getElementById('clefairyStage').dataset.action!==action,action);
    }
    await page.waitForFunction(()=>sequenceDone);assert.equal((await snapshot(page)).state,'idle');
    await page.evaluate(()=>{resetMemoryGame();memoryGame.sequence=[0,1];memoryGame.round=1;memoryGame.accepting=true;memoryTap(0);});
    assert.deepEqual((await snapshot(page)).highlight,[0]);
    await page.evaluate(()=>memoryTap(1));assert.deepEqual((await snapshot(page)).highlight,[1]);
    assert.equal(await page.evaluate(()=>memoryGame.bank),80);
    const coins=await page.evaluate(()=>state.profile.coins);await page.evaluate(()=>{cashMemory();cashMemory();});
    assert.equal(await page.evaluate(()=>state.profile.coins),coins+80);assert.deepEqual(errors,[]);
  }finally{await context.close();}
});
test('Leaving during sequence playback or a delayed miss reset cannot resurrect the game',async()=>{
  const {context,page,errors}=await setup();try{
    await page.evaluate(()=>{nextMemoryRound();});await page.waitForTimeout(100);await page.evaluate(()=>closeArcadeGame(true));
    await page.waitForTimeout(1800);assert.equal(await page.evaluate(()=>memoryGame),null);
    await page.evaluate(()=>{openArcadeGame('clefairy');memoryGame.sequence=[0];memoryGame.accepting=true;memoryTap(1);closeArcadeGame(true);});
    await page.waitForTimeout(1700);assert.equal(await page.evaluate(()=>memoryGame),null);
    await page.evaluate(()=>{openArcadeGame('clefairy');LuckyDexDebug.playClefairyAction('moon');navigate('adventure');});
    assert.equal(await page.evaluate(()=>document.getElementById('clefairyGame').hidden),true);assert.deepEqual(errors,[]);
  }finally{await context.close();}
});
test('Backgrounding a sequence replays its existing round on return instead of leaving input permanently disabled',async()=>{
  const {context,page,errors}=await setup();try{
    await page.evaluate(()=>{nextMemoryRound();});await page.waitForTimeout(200);
    await page.evaluate(()=>{Object.defineProperty(document,'hidden',{configurable:true,value:true});document.dispatchEvent(new Event('visibilitychange'));});
    await page.waitForTimeout(100);await page.evaluate(()=>{Object.defineProperty(document,'hidden',{configurable:true,value:false});document.dispatchEvent(new Event('visibilitychange'));});
    await page.waitForFunction(()=>memoryGame?.accepting,{},{timeout:6000});
    assert.equal(await page.evaluate(()=>memoryGame.accepting),true);assert.equal(await page.evaluate(()=>memoryGame.round),1);assert.equal(await page.evaluate(()=>memoryGame.bank),0);assert.deepEqual(errors,[]);
  }finally{await context.close();}
});
test('Second Sight cannot reopen a completed round and award its bank twice',async()=>{
  const {context,page,errors}=await setup();try{
    await page.evaluate(()=>{memoryGame.sequence=[0];memoryGame.round=1;memoryGame.accepting=true;memoryTap(0);});
    assert.equal(await page.evaluate(()=>memoryGame.bank),80);
    await page.evaluate(()=>replayMemory());await page.evaluate(()=>memoryTap(0));
    assert.equal(await page.evaluate(()=>memoryGame.bank),80);assert.deepEqual(errors,[]);
  }finally{await context.close();}
});
test('The rendered reflection is actually visible below the waterline, mirrored and compressed',async()=>{
  const {context,page,errors}=await setup();try{
    const bounds=await page.evaluate(()=>{
      const rect=e=>{const r=e.getBoundingClientRect();return {x:r.x,y:r.y,width:r.width,height:r.height,bottom:r.bottom};};
      const actor=document.querySelector('.clefairy-character [data-pose="idle"]'),reflection=document.querySelector('.clefairy-reflection [data-pose="idle"]'),mirror=document.querySelector('.clefairy-mirror'),water=document.querySelector('.clefairy-reflection');
      return {actor:rect(actor),reflection:rect(reflection),water:rect(water),mirror:getComputedStyle(mirror).transform,opacity:+getComputedStyle(water).opacity};
    });console.log('Reflection projection bounds:',JSON.stringify(bounds));
    assert.ok(bounds.reflection.width>100&&bounds.reflection.height>40);
    assert.ok(Math.abs(bounds.reflection.height/bounds.actor.height-.46)<.01);
    assert.ok(bounds.reflection.y>=bounds.water.y-1&&bounds.reflection.bottom<=bounds.water.bottom+1);assert.ok(bounds.opacity>=.2);assert.deepEqual(errors,[]);
  }finally{await context.close();}
});
test('Water reflection has visible composited contrast rather than just an invisible DOM rectangle',async()=>{
  const {context,page}=await setup();try{
    const rect=await page.locator('.clefairy-reflection').boundingBox(),shown=pixels(await page.screenshot());
    await page.locator('.clefairy-reflection').evaluate(e=>{e.style.visibility='hidden';});
    const hidden=pixels(await page.screenshot());let visible=0,total=0;
    for(let y=Math.ceil(rect.y)+3;y<Math.floor(rect.y+rect.height);y++)for(let x=110;x<250;x++){
      const i=(y*shown.width+x)*shown.channels,delta=Math.abs(shown.data[i]-hidden.data[i])+Math.abs(shown.data[i+1]-hidden.data[i+1])+Math.abs(shown.data[i+2]-hidden.data[i+2]);if(delta>20)visible++;total+=delta;
    }
    console.log('Reflection visible pixels:',visible,'summed RGB contrast:',total);
    assert.ok(visible>650,`Only ${visible} reflected pixels have readable contrast`);
  }finally{await context.close();}
});
test('Missing idle artwork has a decoded local fallback in both the character and water reflection',async()=>{
  const {context,page,errors}=await setup(undefined,['clefairy_pose_idle.png']);try{
    const images=await page.evaluate(()=>[...document.querySelectorAll('.clefairy-motion [data-pose="idle"] img')].map(i=>({src:i.src,width:i.naturalWidth})));
    assert.equal(images.length,2);for(const i of images){assert.ok(i.src.startsWith('data:image/svg+xml,')&&i.width>0);}
    await page.evaluate(()=>LuckyDexDebug.playClefairyAction('spin'));assert.equal((await snapshot(page)).state,'idle');assert.deepEqual(errors,[]);
  }finally{await context.close();}
});
test('Reduced motion keeps idle and actions rigid and removes moving foreground trails',async()=>{
  const {context,page,errors}=await setup();try{
    await page.emulateMedia({reducedMotion:'reduce'});await page.waitForTimeout(150);
    const initial=(await snapshot(page)).actor;await page.waitForTimeout(450);assert.equal((await snapshot(page)).actor,initial);
    await page.evaluate(()=>{LuckyDexDebug.playClefairyAction('spin');});await page.waitForTimeout(500);
    const sample=await snapshot(page);assert.equal(sample.actor,'matrix(1, 0, 0, 1, 0, 0)');
    const painted=await page.evaluate(()=>{const c=document.querySelector('.clefairy-fx-front'),data=c.getContext('2d').getImageData(0,0,c.width,c.height).data;let n=0;for(let i=3;i<data.length;i+=4)if(data[i])n++;return n;});assert.equal(painted,0);assert.deepEqual(errors,[]);
  }finally{await context.close();}
});
test('SPIN gold trails move through both composited depth planes and procedural cues remain distinct',async()=>{
  const {context,page,errors}=await setup();try{
    const read=()=>page.evaluate(()=>[...document.querySelectorAll('.clefairy-fx-rear,.clefairy-fx-front')].map(c=>{
      const d=c.getContext('2d').getImageData(0,0,c.width,c.height).data;let gold=0,sum=0;for(let i=0;i<d.length;i+=4){if(d[i]>d[i+2]*1.4&&d[i+1]>d[i+2]*1.1&&d[i+3]>40)gold++;sum=(sum+d[i]*i+d[i+3])%1000000007;}return {gold,sum};
    }));
    await page.evaluate(()=>{LuckyDexDebug.playClefairyAction('spin');});await page.waitForTimeout(400);const early=await read();
    await page.waitForTimeout(350);const late=await read();for(const plane of early)assert.ok(plane.gold>30,JSON.stringify(early));assert.notDeepEqual(early,late);
    const layers=await page.evaluate(()=>['.clefairy-fx-rear','.clefairy-character','.clefairy-fx-front'].map(s=>+getComputedStyle(document.querySelector(s)).zIndex));assert.ok(layers[0]<layers[1]&&layers[1]<layers[2]);
    fs.mkdirSync(path.resolve(__dirname,'../artifacts'),{recursive:true});await page.screenshot({path:path.resolve(__dirname,'../artifacts/clefairy-spin-360.png')});
    await page.evaluate(()=>LuckyDexDebug.playClefairyAction('idle'));
    await page.evaluate(()=>{LuckyDexDebug.playClefairyAction('song');});await page.waitForTimeout(850);const notes=await read();assert.ok(notes[1].sum>0);
    await page.screenshot({path:path.resolve(__dirname,'../artifacts/clefairy-song-360.png')});assert.deepEqual(errors,[]);
  }finally{await context.close();}
});
