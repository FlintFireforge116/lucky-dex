const test=require('node:test');
const assert=require('node:assert/strict');
const fs=require('node:fs');
const path=require('node:path');
const corePath=path.join(__dirname,'..','app','src','main','assets','arcade-pokemon-seek-core.js');

function loadCore(){
  assert.ok(fs.existsSync(corePath),'Pokémon Seek core module must exist');
  delete require.cache[require.resolve(corePath)];
  return require(corePath);
}

function seq(values){let i=0;return ()=>values[Math.min(i++,values.length-1)]??0;}

test('Pokemon Seek core uses a 90 second search and faithful score components',()=>{
  const core=loadCore();
  assert.equal(core.CONFIG.durationMs,90000);
  assert.equal(core.CONFIG.foundScore,5000);
  assert.equal(core.CONFIG.lostItemScore,5000);
  const run=core.createRun({difficulty:'normal',rng:seq([0,.4,.2,.7,.1,.8,.3,.6,.5]),dreamRate:0});
  run.elapsedMs=30000;
  run.foundTarget=true;
  run.itemFound=true;
  assert.equal(core.finalScore(run),40000); // 5k found + 60s*500 + 5k item
});

test('Listen Carefully reports Manhattan distance bands from the current room',()=>{
  const core=loadCore();
  const run=core.createRun({difficulty:'normal',rng:()=>0,dreamRate:0});
  run.targetRoom=8;
  run.currentRoom=8;
  assert.match(core.listenHint(run).message,/very close/i);
  run.currentRoom=7;
  assert.match(core.listenHint(run).message,/near here/i);
  run.currentRoom=6;
  assert.match(core.listenHint(run).message,/not far/i);
  run.currentRoom=0;
  assert.match(core.listenHint(run).message,/can't hear/i);
});

test('movement stays inside the 3 by 3 map and exposes two searchable hiding places per room',()=>{
  const core=loadCore();
  const run=core.createRun({difficulty:'normal',rng:seq([.1,.2,.3,.4,.5,.6,.7,.8,.9]),dreamRate:0});
  assert.equal(run.rooms.length,9);
  assert.ok(run.rooms.every(room=>Array.isArray(room.spots)&&room.spots.length===2));
  run.currentRoom=0;
  assert.equal(core.move(run,'left'),false);
  assert.equal(core.move(run,'up'),false);
  assert.equal(core.move(run,'right'),true);
  assert.equal(run.currentRoom,1);
  assert.equal(core.move(run,'down'),true);
  assert.equal(run.currentRoom,4);
});

test('searching a wrong Pokemon never completes the run while finding the target does',()=>{
  const core=loadCore();
  const run=core.createRun({difficulty:'normal',rng:seq([.2,.4,.6,.8,.1,.3,.5,.7,.9]),dreamRate:0});
  const wrongRoom=run.rooms.find(r=>r.index!==run.targetRoom&&r.spots.some(s=>s.kind==='pokemon'));
  if(wrongRoom){
    run.currentRoom=wrongRoom.index;
    const wrongSpot=wrongRoom.spots.find(s=>s.kind==='pokemon');
    const wrong=core.search(run,wrongSpot.id);
    assert.equal(wrong.foundTarget,false);
    assert.equal(run.complete,false);
    assert.equal(run.wrongFinds,1);
  }
  run.currentRoom=run.targetRoom;
  const targetSpot=run.rooms[run.targetRoom].spots.find(s=>s.kind==='target');
  const found=core.search(run,targetSpot.id);
  assert.equal(found.foundTarget,true);
  assert.equal(run.foundTarget,true);
  assert.equal(run.complete,true);
});

test('lost item stays within two rooms of the target and rare Dream Sparkle can be forced',()=>{
  const core=loadCore();
  const run=core.createRun({difficulty:'normal',rng:seq([0,.2,.4,.6,.8,.1,.3,.5,.7,.9]),dreamRate:1});
  assert.equal(run.dreamEvent,true);
  assert.ok(core.roomDistance(run.itemRoom,run.targetRoom)<=2);
  assert.ok(core.roomDistance(run.dreamRoom,run.targetRoom)<=2);
  run.currentRoom=run.itemRoom;
  assert.equal(core.collectLostItem(run).collected,true);
  assert.equal(run.itemFound,true);
  run.currentRoom=run.dreamRoom;
  assert.equal(core.collectDreamSparkle(run).collected,true);
  assert.equal(run.dreamFound,true);
});
