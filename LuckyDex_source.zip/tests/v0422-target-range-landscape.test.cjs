'use strict';
const test=require('node:test');
const assert=require('node:assert/strict');
const fs=require('node:fs');
const path=require('node:path');
const ROOT=path.resolve(__dirname,'..');
const asset=n=>path.join(ROOT,'app/src/main/assets',n);
const read=n=>fs.readFileSync(asset(n),'utf8');

const core=require(asset('arcade-target-range-core.js'));

test('range depth maps distance into a downrange landscape instead of an overhead lane',()=>{
  assert.equal(typeof core.rangeYForDistance,'function');
  assert.ok(core.rangeYForDistance(10)>core.rangeYForDistance(50));
  assert.ok(Math.abs(core.rangeYForDistance(10)-.62)<1e-9);
  assert.ok(Math.abs(core.rangeYForDistance(50)-.34)<1e-9);
  const round=core.createRound({participant:{baseStat:80},profile:core.difficultyProfile('normal'),seed:422});
  for(const target of round.targets){
    assert.ok(target.y>=.31&&target.y<=.65,`${target.distanceM}m -> ${target.y}`);
  }
});

test('projectiles are deliberately slower than the v0.42.1 tuning',()=>{
  const near=core.projectileSolution({distanceM:20,focus:1,spAtk:80});
  const far=core.projectileSolution({distanceM:50,focus:1,spAtk:80});
  assert.ok(near.travelMs>=520,near);
  assert.ok(far.travelMs>=950,far);
  assert.ok(far.travelMs>near.travelMs);
});

test('moving targets use calm archery-gallery motion rather than race pacing',()=>{
  const profile={...core.divisionProfile('master',2),motionChance:1,targetCount:12};
  const round=core.createRound({participant:{baseStat:100},profile,seed:88});
  const moving=round.targets.filter(t=>t.motion?.type!=='stationary');
  assert.ok(moving.length>0);
  assert.ok(moving.every(t=>t.motion.periodMs>=2400),moving.map(t=>t.motion.periodMs));
  assert.ok(round.targets.every(t=>t.exposureMs>=3600),round.targets.map(t=>t.exposureMs));
});

test('ballistic visual path launches from the foreground and arcs toward impact rather than passing through the reticle as a waypoint',()=>{
  const opts={startX:.18,startY:.72,aimX:.55,aimY:.30,impactX:.59,impactY:.39};
  const start=core.projectileVisualPoint({...opts,progress:0});
  const mid=core.projectileVisualPoint({...opts,progress:.5});
  const end=core.projectileVisualPoint({...opts,progress:1});
  assert.deepEqual(start,{x:.18,y:.72});
  assert.deepEqual(end,{x:.59,y:.39});
  assert.notDeepEqual(mid,{x:.55,y:.30});
  const linearMid=(opts.startY+opts.impactY)/2;
  assert.ok(mid.y<linearMid,`${mid.y} should arc above ${linearMid}`);
});

test('live range is a horizontal scenic frame with foreground shooter and perspective layers',()=>{
  const js=read('arcade-target-range.js'),css=read('arcade-target-range.css');
  assert.match(js,/target-range-horizon/);
  assert.match(js,/target-range-ground/);
  assert.match(css,/\.target-range-gallery\{[^}]*aspect-ratio:\s*16\s*\/\s*10/i);
  assert.match(css,/\.target-range-horizon\{[^}]*--range-bg/i);
  assert.match(css,/\.target-range-ground\{/i);
  assert.match(css,/\.target-range-pokemon\{[^}]*left:\s*(?:10|11|12|13|14|15|16|17|18)%/i);
});

test('reticle is smaller and visibly tightens while focus settles',()=>{
  const js=read('arcade-target-range.js'),css=read('arcade-target-range.css');
  assert.match(css,/\.target-range-reticle\{[^}]*width:\s*26px[^}]*height:\s*26px/i);
  assert.match(css,/--focus-scale/);
  assert.match(js,/--focus-scale/);
  assert.match(js,/core\.focusQuality\(t-drawStartedAt\)/);
});

test('there is no target escape timer while the player is lining up a shot',()=>{
  const js=read('arcade-target-range.js');
  assert.match(js,/targetDeadline=Infinity/);
  assert.doesNotMatch(js,/feedback\('TOO SLOW'/);
  assert.doesNotMatch(js,/t>=targetDeadline/);
});

test('runtime launches from the left-side Pokemon and uses the slower ballistic path',()=>{
  const js=read('arcade-target-range.js');
  assert.match(js,/startX=\.18,startY=\.72/);
  assert.match(js,/core\.projectileVisualPoint\(/);
});
