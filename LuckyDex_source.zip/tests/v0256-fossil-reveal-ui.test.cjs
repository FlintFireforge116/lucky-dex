const assert=require('node:assert/strict');
const fs=require('node:fs');
const path=require('node:path');
const root=path.resolve(__dirname,'..');
const core=require('../app/src/main/assets/arcade-fossil-museum-core.js');
const runtime=fs.readFileSync(path.join(root,'app/src/main/assets/arcade-fossil-museum.js'),'utf8');

assert.equal(core.RECOVERY_CLEAR_RATIO,0.75,'artifact recovery should use a 75% occupied-cell threshold');

const mostlyClear={depths:[0,0,0,0,1],finds:[],awardedFindIds:[]};
const fiveCellFind={id:'shape',cells:[0,1,2,3,4]};
assert.equal(core.isFindRecovered(mostlyClear,fiveCellFind),true,'one small edge cell may remain covered once the artifact is visibly exposed');

const stillBuried={depths:[0,0,0,1,1],finds:[],awardedFindIds:[]};
assert.equal(core.isFindRecovered(stillBuried,fiveCellFind),false,'an artifact should not count while too much of its occupied shape remains buried');

const smallMostlyClear={depths:[0,0,0,1],finds:[],awardedFindIds:[]};
assert.equal(core.isFindRecovered(smallMostlyClear,{id:'small',cells:[0,1,2,3]}),true,'small 2x2-style finds should not require the final empty-looking corner');

assert(!runtime.includes('UNBANKED'),'dig UI should not label recovered finds as UNBANKED');
assert.match(runtime,/showFindBanner\(name,'RECOVERED'\)/,'recovery banner should simply say RECOVERED');

console.log('PASS v0.25.6 tighter artifact reveal + simplified recovery copy');
