'use strict';
const assert=require('node:assert/strict');
const fs=require('node:fs');
const path=require('node:path');
const ROOT=path.resolve(__dirname,'..');
const builder=fs.readFileSync(path.join(ROOT,'scripts/build-booster-art-index.py'),'utf8');

assert.doesNotMatch(builder,/api\.github\.com\/repos\/1niceroli\/ptcg-assets\/contents/i,
  'APK booster-art build must not enumerate every set through GitHub Contents API; that hits anonymous API rate limits');
assert.match(builder,/git[\s\S]{0,700}fetch[\s\S]{0,400}--filter=blob:none/i,
  'Builder should fetch only Git tree metadata using the Git protocol rather than REST contents calls');
assert.match(builder,/ls-tree[\s\S]{0,180}--name-only/i,
  'Builder should enumerate packshot paths from the fetched Git tree metadata');
assert.match(builder,/raw\.githubusercontent\.com/i,
  'Selected pack images should download directly from raw GitHub URLs');
assert.match(builder,/retry|attempt/i,
  'Raw asset downloads should retry transient failures rather than fail the entire APK build immediately');
console.log('PASS v0.26.3 booster artwork builder avoids GitHub API rate limits');
const cp=require('node:child_process');
const py=`
import importlib.util
from pathlib import Path
p=Path(r'${path.join(ROOT,'scripts/build-booster-art-index.py').replaceAll('\\','\\\\')}')
spec=importlib.util.spec_from_file_location('booster_builder',p)
m=importlib.util.module_from_spec(spec); spec.loader.exec_module(m)
selected=m.choose_packshots(['base2','me3'],[
 'base2/packshots/Jungle_Booster_Scyther.webp',
 'base2/packshots/Jungle_Booster_Flareon.webp',
 'me3/packshots/Perfect_Order_Mega_Clefable.png'])
assert selected['base2']['ext']=='.webp'
assert selected['base2']['source_path'].endswith('Flareon.webp')
assert selected['me3']['ext']=='.png'
assert 'raw.githubusercontent.com' in selected['me3']['url']
print('fixture ok')
`;
const run=cp.spawnSync('python3',['-c',py],{encoding:'utf8'});
assert.equal(run.status,0,run.stderr||run.stdout);
