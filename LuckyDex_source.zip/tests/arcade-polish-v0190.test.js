const assert=require('assert');const fs=require('fs');const path=require('path');
const root=path.join(__dirname,'..'),p=path.join(root,'app/src/main/assets/arcade-polish-v0190.js'),cssp=path.join(root,'app/src/main/assets/arcade-polish-v0190.css');
assert.ok(fs.existsSync(p));assert.ok(fs.existsSync(cssp));const src=fs.readFileSync(p,'utf8'),css=fs.readFileSync(cssp,'utf8');
assert.match(src,/MutationObserver/);assert.match(src,/jackpot-live-v019/);assert.match(src,/quiz-reveal-v019/);
assert.match(css,/\.ball-drop-machine[^}]*cabinet/s);assert.match(css,/radial-gradient/);assert.match(css,/\.unown-chamber/);assert.match(css,/\.quiz-stage/);assert.match(css,/quizRevealV019/);
console.log('PASS v0.19 Ball Drop / Unown / Quiz scene polish hooks');
