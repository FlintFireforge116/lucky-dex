const assert=require('assert');
const fs=require('fs');
const path=require('path');

const root=path.resolve(__dirname,'..');
const fresh=(rel)=>{const p=path.join(root,rel);delete require.cache[p];return require(p);};

// Arcade payout normalization should bring representative successful runs into
// one comparable band while preserving Ball Drop's explicit jackpot exception.
{
  global.state={arcade:{},inventory:{},pokemon:{},profile:{coins:0},stats:{}};
  global.awardArcadeCoins=(n)=>n;global.save=()=>{};global.showToast=()=>{};
  const p=fresh('app/src/main/assets/arcade-platform.js');
  assert.equal(typeof p.balanceCoins,'function','arcade platform must expose balanceCoins');
  const samples={
    berryPicker:p.balanceCoins('berryPicker',100),
    tilePuzzle:p.balanceCoins('tilePuzzle',90),
    voltorb:p.balanceCoins('voltorb',1000),
    ballDrop:p.balanceCoins('ballDrop',90),
    berry:p.balanceCoins('berry',400),
    clefairy:p.balanceCoins('clefairy',330),
    fossil:p.balanceCoins('fossil',180),
    unown:p.balanceCoins('unown',1000),
    quiz:p.balanceCoins('quiz',1400)
  };
  for(const [game,coins] of Object.entries(samples))assert.ok(coins>=60&&coins<=210,`${game} representative payout ${coins} outside balanced band`);
  assert.equal(p.balanceCoins('ballDrop',1072),1072,'Ball Drop jackpot must remain a special 1000-coin event');
  console.log('PASS Arcade representative payouts share a comparable reward band while jackpot stays special');
}

// Tile Puzzle needs a much larger visual pool than the old three backgrounds /
// three compositions.
{
  const amie=fresh('app/src/main/assets/arcade-amie.js');
  assert.ok(amie.TILE_BACKDROPS.length>=8,`expected >=8 tile backdrops, got ${amie.TILE_BACKDROPS.length}`);
  assert.ok(amie.TILE_SCENE_RECIPES.length>=16,`expected >=16 tile layouts, got ${amie.TILE_SCENE_RECIPES.length}`);
  assert.ok(Array.isArray(amie.TILE_PROP_SETS)&&amie.TILE_PROP_SETS.length>=6,'expected multiple tile prop sets');
  assert.ok(amie.TILE_BACKDROPS.some(x=>x.includes('adventure/art/meadow-scene.png')),'Adventure scene art should expand the puzzle pool');
  console.log('PASS Tile Puzzle exposes a large local scene/backdrop/prop pool');
}

// The foil system must exist as a reusable module and be loaded by the app.
{
  const index=fs.readFileSync(path.join(root,'app/src/main/assets/index.html'),'utf8');
  assert.match(index,/card-foil-v0231\.css/);
  assert.match(index,/card-foil-v0231\.js/);
  const foil=fresh('app/src/main/assets/card-foil-v0231.js');
  assert.equal(foil.kind({_foil:'Reverse Holo'}),'reverse');
  assert.equal(foil.kind({_foil:'Foil'}),'holo');
  assert.equal(foil.kind({rarity:'Rare Holo'}),'holo');
  const stored={count:0};
  foil.recordPull(stored,{_foil:'Reverse Holo'});
  foil.recordPull(stored,{_foil:'Foil'});
  assert.deepStrictEqual(stored.foilCounts,{normal:0,reverse:1,holo:1});
  assert.equal(stored.foilKind,'holo');
  assert.equal(foil.className(stored),'foil-holo');
  assert.deepStrictEqual(foil.badges(stored),['Holo ×1','Reverse Holo ×1']);
  console.log('PASS Holo/Reverse-Holo identity persists and maps to distinct visual classes');
}

console.log('PASS v0.23.1 polish contracts');
