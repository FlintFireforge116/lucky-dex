from pathlib import Path
import hashlib
import re
import subprocess

ROOT = Path(__file__).resolve().parents[1]
ASSETS = ROOT / 'app/src/main/assets'
HTML = (ASSETS / 'index.html').read_text(encoding='utf-8')
APP = (ASSETS / 'app-v0167.js').read_text(encoding='utf-8')
WORLD = (ASSETS / 'arcade-world-v0190.js').read_text(encoding='utf-8')
WORLD_CSS = (ASSETS / 'arcade-world-v0190.css').read_text(encoding='utf-8')
AMIE = (ASSETS / 'arcade-amie-v0190.js').read_text(encoding='utf-8')
AMIE_CSS = (ASSETS / 'arcade-amie-v0190.css').read_text(encoding='utf-8')
CLASSICS = (ASSETS / 'arcade-classics-v0190.js').read_text(encoding='utf-8')
POLISH = (ASSETS / 'arcade-polish-v0190.js').read_text(encoding='utf-8')
SESSION = (ASSETS / 'arcade-session-v0180.js').read_text(encoding='utf-8')


def scripts():
    return re.findall(r'<script src="([^"]+)"', HTML)


def styles():
    return re.findall(r'<link rel="stylesheet" href="([^"]+)"', HTML)


def test_v019_release_metadata_and_active_owner():
    gradle = (ROOT / 'app/build.gradle').read_text(encoding='utf-8')
    assert 'versionCode 210' in gradle
    assert "versionName '0.20.0'" in gradle
    assert "window.__LUCKYDEX_BUILD='0.20.0-authentic-arcade';" in APP
    assert 'v0.20.0' in HTML
    ordered = scripts()
    assert ordered[-1] == 'arcade-world-v0200.js'
    assert 'arcade-world-v0180.js' not in ordered
    assert 'clefairy-scene.js' not in ordered
    assert 'clefairy-flow.js' not in ordered
    for name in ['arcade-amie-v0190.js','arcade-classics-v0190.js','arcade-polish-v0190.js','arcade-fidelity-v0200.js','arcade-world-v0200.js']:
        assert name in ordered
    assert ordered.index('arcade-ball-drop-v0180.js') < ordered.index('arcade-amie-v0190.js') < ordered.index('arcade-classics-v0190.js') < ordered.index('arcade-polish-v0190.js') < ordered.index('arcade-fidelity-v0200.js') < ordered.index('arcade-world-v0200.js')


def test_v019_styles_and_world_are_viewport_scale_not_eight_card_strip():
    css = styles()
    for name in ['arcade-world-v0200.css','arcade-amie-v0190.css','arcade-classics-v0190.css','arcade-polish-v0190.css','arcade-fidelity-v0200.css']:
        assert name in css
    assert 'arcade-world-v0190.css' not in css
    assert re.search(r'\.arcade-world-stop\s*\{[^}]*flex\s*:\s*0\s+0\s+min\(88vw,\s*520px\)', WORLD_CSS, re.S)
    assert 'repeat(8' not in WORLD_CSS
    assert 'world-route-ribbon' in WORLD
    assert 'stadiumClassroom' in WORLD
    assert 'moonStage' in WORLD  # migration only


def test_v019_landmark_art_is_local_and_nontrivial():
    names = [
        'amie-garden.webp','goldenrod-game-corner.webp','celadon-prize-machine.webp',
        'lilycove-contest-hall.webp','stadium-classroom.webp','oreburgh-museum.webp',
        'ruins-of-alph.webp','indigo-quiz-studio.webp'
    ]
    base = ASSETS / 'arcade/venues-v0190'
    for name in names:
        p = base / name
        assert p.exists(), name
        assert p.stat().st_size > 10_000, f'{name} is suspiciously tiny'
        assert f'arcade/venues-v0190/{name}' in WORLD


def test_amie_games_match_retail_layout_models():
    assert 'durationMs:60000,berries:3,maxCustomers:1' in AMIE
    assert 'durationMs:60000,berries:5,maxCustomers:2' in AMIE
    assert 'durationMs:60000,berries:7,maxCustomers:3' in AMIE
    assert "YARN_TYPES=[{id:'pink'" in AMIE and "id:'purple'" in AMIE and "id:'bonus'" in AMIE
    assert 'FEVER_COMBO=15' in AMIE
    assert 'easy:{rows:4,cols:5}' in AMIE
    assert 'normal:{rows:5,cols:6}' in AMIE
    assert 'hard:{rows:6,cols:8}' in AMIE
    assert 'swapTiles' in AMIE and 'tilePuzzleCanvas' in AMIE
    assert 'EASY · 4×5' in HTML and 'NORMAL · 5×6' in HTML and 'HARD · 6×8' in HTML
    assert 'Moving-picture Pokémon tile puzzle' in HTML
    assert 'data-berry-mode="unlimited"' in HTML
    assert re.search(r'\.amie-game>\.amie-hud\s*\{[^}]*display\s*:\s*none', AMIE_CSS, re.S)
    assert re.search(r'\.tile-target-mini\s*\{[^}]*display\s*:\s*none', AMIE_CSS, re.S)


def test_classic_games_expose_signature_retail_mechanics():
    assert "VOLTORB_MEMO_OPTIONS=['bomb','1','2','3']" in CLASSICS
    assert 'memoToggle' in CLASSICS and 'vf-memo' in CLASSICS
    assert "maxHits:5,maxRounds:5" in CLASSICS
    assert 'teacher-clefairy-v019' in CLASSICS and 'pupil-v019' in CLASSICS
    assert "FOSSIL_TOOLS={pick:{radius:0,damage:2,stability:1},hammer:{radius:1,damage:1,stability:3}}" in CLASSICS
    assert 'wall-stability-v019' in CLASSICS
    # The genuine Hoenn-style continuous spinner remains the existing engine, now visually wrapped by v0.19.
    assert 'LuckyDexBerryBlender' in CLASSICS


def test_custom_games_receive_scene_polish_without_new_reward_owners():
    assert 'cabinet-v019' in POLISH
    assert 'ruins-chamber-v019' in POLISH
    assert 'quiz-reveal-v019' in POLISH
    assert 'awardRun' not in POLISH
    assert 'showResult' not in POLISH


def test_session_copy_reflects_v019_run_rules():
    assert '60 seconds · Unlimited ends after 3 misses' in SESSION
    assert '60 seconds + final bonus yarn · Unlimited ends after 3 misses' in SESSION
    assert 'Swap the moving picture back together' in SESSION
    assert '5 classroom rounds · 5 bonks ends the lesson' in SESSION
    assert 'wall stability reaches zero' in SESSION



def test_v019_replaced_legacy_arcade_controls_are_null_safe():
    # v0.19 replaces the Voltorb and Clefairy DOM after app-v0167 wires it.
    # Later helper refreshes must tolerate those legacy perk buttons being gone.
    assert re.search(r'if\s*\(vb\)\s*vb\.hidden', APP)
    assert re.search(r'if\s*\(mb\)\s*mb\.hidden', APP)
    assert re.search(r'if\s*\(voltorb\?\.perkUsed\s*&&\s*vb\)', APP)
    assert re.search(r'if\s*\(memoryGame\?\.perkUsed\s*&&\s*mb\)', APP)
    # v0.19 deliberately does not load the legacy clefairy-flow.js owner.
    # app-v0167 must therefore not dereference its globals during startup.
    for legacy_fn in ['nextMemoryRound','cashMemory','replayMemory','memoryTap']:
        assert f"typeof {legacy_fn}==='function'" in APP

def test_v019_static_integrity_syntax_ids_signing_and_release_report():
    ids = re.findall(r'\bid="([^"]+)"', HTML)
    assert len(ids) == len(set(ids)), [x for x in ids if ids.count(x) > 1]
    for js in ASSETS.glob('*.js'):
        proc = subprocess.run(['node','--check',str(js)], capture_output=True, text=True)
        assert proc.returncode == 0, f'{js.name}: {proc.stderr}'
    key = ROOT / 'app/luckydex-dev.keystore'
    assert hashlib.sha256(key.read_bytes()).hexdigest() == '90de91cea469f0eec5fbd69389cf03adc94ced396fa2ec85e2a51d2365a4f6d3'
    report = ROOT / 'TEST_REPORT_v0.19.1.md'
    assert report.exists()
    text = report.read_text(encoding='utf-8')
    assert 'v0.19.1' in text and 'device' in text.lower()
