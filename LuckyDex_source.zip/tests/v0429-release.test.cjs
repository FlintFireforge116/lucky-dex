'use strict';
const test=require('node:test'),assert=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path');
const root=path.resolve(__dirname,'..'),read=p=>fs.readFileSync(path.join(root,p),'utf8');
test('v0.40.29 release identity and user-tweak assets are aligned',()=>{
  const pkg=JSON.parse(read('package.json')),lock=JSON.parse(read('package-lock.json')),gradle=read('app/build.gradle'),html=read('app/src/main/assets/index.html'),app=read('app/src/main/assets/app-v0167.js');
  assert.equal(pkg.version,'0.40.29');assert.equal(lock.version,pkg.version);assert.equal(lock.packages[''].version,pkg.version);
  assert.match(gradle,/versionCode\s+4029/);assert.match(gradle,/versionName\s+'0\.40\.29'/);assert.ok(gradle.includes('LuckyDex-asset-builder/0.40.29'));
  assert.ok((html.match(/v0\.40\.29/g)||[]).length>=2);assert.ok(app.includes("__LUCKYDEX_BUILD='0.40.29'"));
  assert.ok(fs.existsSync(path.join(root,'app/src/main/assets/pokemon-go-ditto-v04029.js')));
  assert.ok(fs.existsSync(path.join(root,'tests/v0429-user-tweaks.test.cjs')));
});
