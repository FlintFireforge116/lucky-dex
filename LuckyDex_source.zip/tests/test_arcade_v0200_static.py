from pathlib import Path
import re

ROOT=Path(__file__).resolve().parents[1]
ASSETS=ROOT/'app/src/main/assets'
HTML=(ASSETS/'index.html').read_text(encoding='utf-8')

def text(name):
    p=ASSETS/name
    return p.read_text(encoding='utf-8') if p.exists() else ''

def test_v0200_release_and_active_owners():
    gradle=(ROOT/'app/build.gradle').read_text(encoding='utf-8')
    assert "versionName '0.20.0'" in gradle
    assert 'versionCode 210' in gradle
    assert 'v0.20.0' in HTML
    assert 'arcade-world-v0200.css' in HTML
    assert 'arcade-fidelity-v0200.css' in HTML
    assert 'arcade-world-v0200.js' in HTML
    assert 'arcade-fidelity-v0200.js' in HTML
    assert 'arcade-world-v0190.css' not in HTML
    assert 'arcade-world-v0190.js' not in HTML

def test_world_has_no_native_horizontal_scroller():
    css=text('arcade-world-v0200.css')
    js=text('arcade-world-v0200.js')
    assert re.search(r'\.arcade-world-viewport\s*\{[^}]*overflow\s*:\s*hidden', css, re.S)
    assert re.search(r'\.arcade-world-track\s*\{[^}]*transform', css, re.S)
    assert 'overflow-x:auto' not in css.replace(' ', '')
    assert 'scroll-snap-type' not in css
    assert 'scrollIntoView' not in js
    assert 'translate3d' in js
    assert 'pointerdown' in js and 'pointerup' in js

def test_world_uses_actual_game_asset_directory_only():
    js=text('arcade-world-v0200.js')
    expected=['amie-garden','goldenrod-game-corner','celadon-game-corner','lilycove-contest-hall','stadium-classroom','oreburgh-museum','ruins-of-alph','indigo-plateau']
    for stem in expected:
        assert f'arcade/authentic-v0200/venues/{stem}' in js
    assert 'venues-v0190' not in js
    assert 'indigo-quiz-studio' not in js
    assert "stadium-classroom.webp" in js
    assert "ratio:'5 / 3'" in js

def test_asset_fetch_manifest_is_required_before_gradle():
    fetch=(ROOT/'scripts/fetch_arcade_v0200_assets.py').read_text(encoding='utf-8') if (ROOT/'scripts/fetch_arcade_v0200_assets.py').exists() else ''
    workflow=(ROOT/'.github/workflows/build-apk.yml').read_text(encoding='utf-8')
    for key in ['amie_berry_picker','amie_head_it','amie_tile_puzzle','voltorb_screen','berry_blender_center','clefairy_classroom','underground_digging']:
        assert key in fetch
    assert 'authentic-v0200' in fetch
    assert '"voltorb_background"' not in fetch
    assert 'fetch_arcade_v0200_assets.py' in workflow
    assert workflow.index('fetch_arcade_v0200_assets.py') < workflow.index(':app:assembleDebug')
    assert 'LuckyDex-v0.20.0-debug.apk' in workflow

def test_phone_game_frames_override_large_fixed_heights_and_keep_start_in_frame():
    css=text('arcade-fidelity-v0200.css')
    js=text('arcade-fidelity-v0200.js')
    # These exact active surfaces were the source of Start falling below the phone viewport.
    for selector in ['.berry-picker-stage-v019','.head-it-stage','.berry-authentic-v019 .berry-machine','.clefairy-classroom-v019']:
        pattern=re.escape(selector)+r'[^\{]*\{[^}]*min-height\s*:\s*0\s*!important'
        assert re.search(pattern,css,re.S),selector
    assert css.count('aspect-ratio:4/3') >= 4
    assert '.arcade-start-shelf-v0200' in css
    assert re.search(r'\.arcade-start-shelf-v0200\s*\{[^}]*position\s*:\s*absolute',css,re.S)
    assert 'installStartShelves' in js
    for bid in ['berryPickerStartBtn','headItStartBtn','tilePuzzleStartBtn','clefairyStartV019']:
        assert bid in js

def test_retail_surfaces_reference_authentic_assets():
    css=text('arcade-fidelity-v0200.css')
    required=[
        'amie/berry-picker.jpg','amie/head-it.jpg','amie/tile-puzzle.jpg',
        'voltorb/screen.jpg','berry-blender/center.png','berry-blender/outer.png',
        'clefairy/clefairy-says.webp','mining/underground-digging.jpg'
    ]
    for rel in required:
        assert f'arcade/authentic-v0200/{rel}' in css
    assert 'linear-gradient(#7ac9f1' not in css
    classics=(ASSETS/'arcade-classics-v0190.js').read_text(encoding='utf-8')
    assert 'data-vf-value' in classics

def test_fetch_manifest_prefers_verified_actual_game_venue_images():
    fetch=(ROOT/'scripts/fetch_arcade_v0200_assets.py').read_text(encoding='utf-8')
    assert '15-pokemon-oras-outside-lilycoves-contest-hall.jpg' in fetch
    lily_block=fetch.split('\"venue_lilycove\"',1)[1].split('\"venue_stadium\"',1)[0]
    assert 'assets.st-note.com' not in lily_block
    assert '01-goldenrod-game-corner-in-golden-city-pokemon-hgss-screenshot.jpg' in fetch

def test_asset_sources_documented():
    p=ASSETS/'arcade/authentic-v0200/ASSET_SOURCES.md'
    assert p.exists()
    src=p.read_text(encoding='utf-8')
    for source in ['Pokémon-Amie','HeartGold','Berry Blender','Pokémon Stadium','Underground']:
        assert source in src

def test_legacy_arcade_entry_is_null_safe_without_removed_clefairy_owner():
    for name in ['app-v0167.js','arcade-expansion-v0166.js','quality-content-v0167.js']:
        src=(ASSETS/name).read_text(encoding='utf-8')
        assert "typeof stopClefairyGame==='function'" in src, name
        assert "if(name!=='clefairy')stopClefairyGame();" not in src, name
        assert "return;stopClefairyGame();if(berryRaf)" not in src, name

def test_world_hides_every_other_game_before_launch():
    world=(ASSETS/'arcade-world-v0200.js').read_text(encoding='utf-8')
    assert "querySelectorAll('.arcade-game')" in world
    assert "n.hidden=true" in world

def test_source_game_aspect_ratios_are_preserved():
    css=text('arcade-fidelity-v0200.css')
    assert re.search(r'\.berry-picker-stage-v019[^\{]*\{[^}]*aspect-ratio\s*:\s*5/3',css,re.S)
    assert re.search(r'\.head-it-stage\s*\{[^}]*aspect-ratio\s*:\s*5/3',css,re.S)
    assert re.search(r'\.tile-authentic-frame-v0200\s*\{[^}]*aspect-ratio\s*:\s*5/3',css,re.S)
    assert re.search(r'\.berry-authentic-v019 \.berry-machine\s*\{[^}]*aspect-ratio\s*:\s*3/2',css,re.S)
    assert re.search(r'\.clefairy-classroom-v019\s*\{[^}]*aspect-ratio\s*:\s*4/3',css,re.S)
    assert re.search(r'\.underground-wall-v019\s*\{[^}]*aspect-ratio\s*:\s*4/3',css,re.S)
