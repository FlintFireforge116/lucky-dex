'use strict';
const assert=require('node:assert/strict'),fs=require('fs'),path=require('path');
const root=path.join(__dirname,'..'),read=p=>fs.readFileSync(path.join(root,p),'utf8');
const pkg=require('../package.json'),lock=require('../package-lock.json'),gradle=read('app/build.gradle'),app=read('app/src/main/assets/app-v0167.js'),html=read('app/src/main/assets/index.html');
assert.equal(pkg.version,'0.37.0');assert.equal(lock.version,'0.37.0');assert.equal(lock.packages[''].version,'0.37.0');
assert.match(gradle,/versionCode\s+3700/);assert.match(gradle,/versionName\s+'0\.37\.0'/);assert.match(gradle,/LuckyDex-asset-builder\/0\.37\.0/);
assert.match(app,/__LUCKYDEX_BUILD='0\.37\.0'/);assert.match(html,/v0\.37\.0/);
for(const f of ['app/src/main/assets/arcade-magikarp-splash-core.js','app/src/main/assets/arcade-magikarp-splash.js','app/src/main/assets/arcade-magikarp-splash.css'])assert.ok(fs.existsSync(path.join(root,f)),f);
console.log('PASS v0.37.0 release identity');
