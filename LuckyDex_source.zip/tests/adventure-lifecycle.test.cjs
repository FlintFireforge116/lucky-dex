'use strict';
const assert=require('node:assert/strict');
const {launch,appPage}=require('../scripts/recovery-browser.cjs');

// Observe the real native scheduler, restricted to callbacks owned by Adventure.
// Wrapping preserves callback/timing behavior; it detects jobs left behind even
// when the controller's own resource summary would accidentally report zero.
function observeAdventureResources(){
  window.adventureSchedulerProbe={frames:new Set(),timers:new Set(),introWaits:0};
  const originalRequest=window.requestAnimationFrame.bind(window),originalCancel=window.cancelAnimationFrame.bind(window),originalLater=window.setTimeout.bind(window),originalClear=window.clearTimeout.bind(window);
  window.requestAnimationFrame=callback=>{
    const owned=callback.toString().includes('own.isActive()');
    let id=originalRequest(now=>{adventureSchedulerProbe.frames.delete(id);callback(now);});
    if(owned)adventureSchedulerProbe.frames.add(id);return id;
  };
  window.cancelAnimationFrame=id=>{adventureSchedulerProbe.frames.delete(id);return originalCancel(id);};
  window.setTimeout=(callback,time,...args)=>{
    if(typeof callback!=='function')return originalLater(callback,time,...args);
    const owned=callback.toString().includes('jobs.delete(id)');
    let id=originalLater(()=>{adventureSchedulerProbe.timers.delete(id);callback(...args);},time);
    if(owned){adventureSchedulerProbe.timers.add(id);if(time===320)adventureSchedulerProbe.introWaits++;}return id;
  };
  window.clearTimeout=id=>{adventureSchedulerProbe.timers.delete(id);return originalClear(id);};
}
async function snapshot(page){return page.evaluate(()=>LuckyDexAdventure.snapshot());}
async function resources(page){return page.evaluate(()=>({owner:LuckyDexAdventure.snapshot().resources,native:{raf:adventureSchedulerProbe.frames.size,jobs:adventureSchedulerProbe.timers.size}}));}
async function expectInactive(page){assert.deepEqual(await resources(page),{owner:{raf:0,jobs:0},native:{raf:0,jobs:0}},'inactive Adventure cannot retain scoped frames or waits');}
async function goHome(page){await page.locator('#titleContinueBtn').tap();const starter=page.locator('#starterChoices button').first();if(await starter.isVisible())await starter.tap();}
async function loadedBackground(locator,expected){
  const result=await locator.evaluate(async element=>{
    const value=getComputedStyle(element).backgroundImage;
    const paths=Array.from(value.matchAll(/url\(["']?([^"')]+)["']?\)/g),match=>match[1]);
    const images=await Promise.all(paths.map(src=>new Promise(resolve=>{
      const image=new Image();image.onload=()=>resolve({src,width:image.naturalWidth,height:image.naturalHeight});image.onerror=()=>resolve({src,width:0,height:0});image.src=src;
    })));
    return {value,images};
  });
  assert.ok(result.images.length,`missing computed background for ${expected}: ${result.value}`);
  assert.ok(result.images.some(image=>image.src.endsWith(expected)),`wrong resolved background for ${expected}: ${result.value}`);
  assert.ok(result.images.every(image=>image.width>0&&image.height>0),`computed CSS background must load locally: ${JSON.stringify(result)}`);
}
async function battle(page,destination='meadow'){
  await page.locator(`[data-adv-destination="${destination}"]`).tap();
  await page.locator('[data-adv-action="roam"]').tap();
  for(let attempts=0;attempts<12;attempts++){
    await page.locator('[data-adv-hotspot]').last().tap();
    if(await page.locator('[data-adv-action="engage"]').count()){await page.locator('[data-adv-action="engage"]').tap();return;}
    await page.locator('[data-adv-action="return"]').tap();
  }
  assert.fail('a real habitat should reveal a Pokémon within twelve hotspots');
}
async function currentFight(page){return page.evaluate(()=>JSON.parse(JSON.stringify(state.adventureV2.activeExpedition?.battle||state.adventureV2.activeRoam?.battle)));}
async function settled(page){await page.waitForFunction(()=>!LuckyDexAdventure.snapshot().busy);}

(async()=>{
  const browser=await launch();
  try {
    for(const motion of ['reduce','no-preference']){
      const errors=[],{page,context}=await appPage(browser,{width:360,height:700},errors,{init:observeAdventureResources});
      try {
        await page.emulateMedia({reducedMotion:motion});
        await goHome(page);
        assert.equal((await snapshot(page)).view,'map');
        const unlocked=await page.locator('[data-adv-destination="meadow"]').getAttribute('class');assert.ok(!unlocked.includes('is-locked'));
        await page.locator('[data-adv-destination="volcano"]').tap();
        assert.equal((await snapshot(page)).view,'map');assert.equal((await snapshot(page)).destination,'meadow','rank-locked destination must not change active destination');
        assert.ok((await page.locator('[data-adv-destination="volcano"]').getAttribute('class')).includes('is-locked'));
        await loadedBackground(page.locator('.adv-environment'),'adventure/art/adventure-map.png');

        // Unlock destinations in this browser fixture, then traverse actual UI
        // scenes and battles. Computed CSS URLs can resolve relative to a CSS
        // file, so checking DOM <img> elements or custom-property strings alone
        // misses broken map/scene/backdrop art.
        await page.evaluate(()=>{state.profile.xp=4000;});
        for(const destination of ['meadow','cave','haunted','coast','volcano']){
          await page.locator(`[data-adv-destination="${destination}"]`).tap();
          assert.equal((await snapshot(page)).view,'destination');
          await loadedBackground(page.locator('.adv-environment'),`adventure/art/${destination}-scene.png`);
          assert.equal(await page.evaluate(()=>handleLuckyBack()),true);
          await battle(page,destination);
          await loadedBackground(page.locator('.adv-battle-scene'),`adventure/art/${destination}-battle.png`);
          await page.locator('[data-adv-battle="flee"]').tap();await settled(page);
          await page.locator('[data-adv-action="battle-next"]').tap();
          assert.equal((await snapshot(page)).view,'roam');
          assert.equal(await page.evaluate(()=>handleLuckyBack()),true);
          assert.equal(await page.evaluate(()=>handleLuckyBack()),true);
          assert.equal((await snapshot(page)).view,'map');
        }

        // Twenty-four live entry/exit cycles exercise root RAF and hotspot waits.
        for(let cycle=0;cycle<24;cycle++){
          await page.locator('[data-adv-destination="meadow"]').tap();
          await page.locator('[data-adv-action="roam"]').tap();
          const live=await resources(page);
          assert.equal(live.owner.raf,motion==='reduce'?0:1);assert.equal(live.native.raf,motion==='reduce'?0:1);
          assert.ok(live.owner.jobs>=1);assert.equal(live.owner.jobs,live.native.jobs);
          // Native Back returns through destination/map before tapping shared nav.
          assert.equal(await page.evaluate(()=>handleLuckyBack()),true);
          assert.equal((await snapshot(page)).view,'destination');
          assert.equal(await page.evaluate(()=>handleLuckyBack()),true);
          assert.equal((await snapshot(page)).view,'map');
          await page.locator('.bottom-nav [data-nav="collection"]').tap();
          await expectInactive(page);
          await page.locator('.bottom-nav [data-nav="adventure"]').tap();
          assert.equal((await snapshot(page)).view,'map');
        }

        await battle(page);
        await page.waitForFunction(()=>Array.from(document.querySelectorAll('.adventure-battle img')).every(i=>i.complete&&i.naturalWidth>0));
        const imagePaths=await page.locator('.adventure-battle img').evaluateAll(images=>images.map(i=>i.getAttribute('src')));
        assert.ok(imagePaths.length>=3);assert.ok(imagePaths.every(src=>!/^https?:/.test(src)),'all battle actors must resolve offline from packaged files');
        const background=await page.locator('.adventure-battle').evaluate(el=>getComputedStyle(el).getPropertyValue('--adv-battle-backdrop'));
        assert.ok(background.includes('adventure/art/meadow-battle.png'));
        await loadedBackground(page.locator('.adv-battle-scene'),'adventure/art/meadow-battle.png');

        // Back dismisses each drawer without leaving or modifying the encounter.
        const beforeDrawer=await currentFight(page);
        for(const drawer of ['bag','switch']){
          const toggle=page.locator(`[data-adv-command="battle-${drawer}"]`);
          await toggle.tap();assert.equal(await page.locator(`[data-battle-drawer="${drawer}"]`).isVisible(),true);
          assert.equal(await toggle.getAttribute('aria-expanded'),'true','open drawer must expose its expanded state');
          assert.equal(await page.evaluate(()=>handleLuckyBack()),true);
          assert.equal(await page.locator(`[data-battle-drawer="${drawer}"]`).isVisible(),false);
          assert.equal(await toggle.getAttribute('aria-expanded'),'false');
          assert.equal((await snapshot(page)).view,'battle');
        }
        assert.deepEqual(await currentFight(page),beforeDrawer);

        // Dispatch two real click events in one JS task to exercise the lock.
        await page.locator('[data-adv-command="battle-bag"]').tap();
        const before=await currentFight(page),berries=await page.evaluate(()=>state.inventory.berry);
        const actionInfo=await page.locator('[data-adv-battle="berry"]').evaluate(button=>{
          button.click();button.click();
          const busy=LuckyDexAdventure.snapshot().busy,committed=JSON.parse(JSON.stringify(state.adventureV2.activeRoam.battle));
          const back=matchMedia('(prefers-reduced-motion: reduce)').matches?null:handleLuckyBack();
          return {busy,back,committed,berries:state.inventory.berry};
        });
        const committed=actionInfo.committed;
        assert.equal(committed.actionSeq,before.actionSeq+1);assert.equal(actionInfo.berries,berries-1);
        if(motion==='no-preference'){
          assert.equal(actionInfo.busy,true,'normal Berry presentation must run under the root action lock');
          assert.equal(actionInfo.back,true);
          assert.equal((await snapshot(page)).busy,false,'native Back cancels cosmetics after committing the action');
        }
        await settled(page);assert.deepEqual(await currentFight(page),committed);

        // Leave through the shared navigation bridge while battle is resumable.
        await page.evaluate(()=>navigate('collection'));await expectInactive(page);
        await page.locator('.bottom-nav [data-nav="adventure"]').tap();
        assert.equal((await snapshot(page)).view,'battle');assert.deepEqual(await currentFight(page),committed);
        await page.reload({waitUntil:'load'});await goHome(page);
        assert.equal((await snapshot(page)).view,'battle');assert.deepEqual(await currentFight(page),committed,'reload must preserve the resolved turn/RNG/item outcome');
        const attackInfo=await page.locator('[data-adv-battle="quick"]').evaluate(button=>{
          button.click();button.click();const hit=JSON.parse(JSON.stringify(state.adventureV2.activeRoam.battle));
          const back=matchMedia('(prefers-reduced-motion: reduce)').matches?null:handleLuckyBack();return {hit,back};
        });
        const hit=attackInfo.hit;assert.equal(hit.actionSeq,committed.actionSeq+1);
        if(motion==='no-preference'){assert.equal(attackInfo.back,true);assert.deepEqual(await currentFight(page),hit);}
        await settled(page);
        if(!hit.result){await page.locator('[data-adv-battle="flee"]').tap();await settled(page);}
        await page.locator('[data-adv-action="battle-next"]').tap();
        assert.equal(await page.evaluate(()=>handleLuckyBack()),true);
        await page.locator('[data-adv-action="expedition"]').tap();
        assert.equal((await snapshot(page)).view,'route');
        const previousIntros=await page.evaluate(()=>adventureSchedulerProbe.introWaits);
        await page.locator('[data-adv-node]:not([disabled])').first().tap();
        const expeditionFight=await currentFight(page);
        assert.equal(expeditionFight.context,'expedition');assert.equal(expeditionFight.actionSeq,0);
        assert.equal(await page.evaluate(()=>adventureSchedulerProbe.introWaits),previousIntros+(motion==='reduce'?0:1),'the opening Expedition encounter must run its intro without an explicit engage flag');
        const expedition=await page.evaluate(()=>JSON.parse(JSON.stringify(state.adventureV2.activeExpedition)));
        assert.equal(await page.evaluate(()=>handleLuckyBack()),true);
        assert.equal((await snapshot(page)).view,'retreat');
        await page.locator('[data-adv-action="resume"]').tap();
        assert.deepEqual(await currentFight(page),expeditionFight,'canceling retreat must preserve the opening encounter');
        await page.evaluate(()=>navigate('collection'));await expectInactive(page);
        await page.locator('.bottom-nav [data-nav="adventure"]').tap();
        assert.equal((await snapshot(page)).view,'battle');
        assert.deepEqual(await page.evaluate(()=>state.adventureV2.activeExpedition),expedition,'leaving Adventure must preserve route, node, RNG, party HP and battle');
        await page.reload({waitUntil:'load'});await goHome(page);
        assert.deepEqual(await page.evaluate(()=>state.adventureV2.activeExpedition),expedition,'reloading must restore the complete persisted Expedition');
        await page.evaluate(()=>navigate('trade'));await expectInactive(page);
        assert.deepEqual(errors,[],'repeated lifecycle and offline battle must not emit runtime errors');
        console.log(`PASS Adventure lifecycle ${motion}: all destination/battle CSS backgrounds load, 24 entry/exit cycles, resource disposal, drawer Back, atomic duplicate clicks, animation Back, persisted resume and offline actors`);
      }finally{await context.close();}
    }
  }finally{await browser.close();}
})().catch(error=>{console.error(error);process.exit(1);});
