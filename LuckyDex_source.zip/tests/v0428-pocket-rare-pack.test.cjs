'use strict';
const test=require('node:test');
const assert=require('node:assert/strict');
const fs=require('node:fs');
const path=require('node:path');
const root=path.resolve(__dirname,'..');
const asset=name=>path.join(root,'app/src/main/assets',name);
const read=name=>fs.readFileSync(asset(name),'utf8');
function fresh(name){const p=asset(name);delete require.cache[require.resolve(p)];return require(p);}

test('TCG Pocket Rare Pack excludes ordinary 4-diamond ex cards and uses star/shiny/crown classes only',()=>{
  const policy=fresh('pack-policy-v0343.js');
  const rarity=fresh('card-rarity-v0253.js');
  assert.equal(rarity.classify({source:'tcgp',rarity:'Four Diamond'}).rarityClass,'double-rare');
  assert.equal(rarity.classify({source:'tcgp',rarity:'One Star'}).rarityClass,'illustration');
  const slots=policy.slotPlan({id:'A1',name:'Genetic Apex'},{source:'tcgp',luckyPack:true,random:()=>.99});
  assert.equal(slots.length,5);
  for(const slot of slots){
    assert.deepEqual(slot.allowedClasses,['ultra','illustration','special-illustration','secret']);
    assert.equal(slot.allowedClasses.includes('double-rare'),false,'normal ex cards must not enter Rare Packs');
    assert.equal(slot.allowedClasses.includes('rare'),false);
  }
});

test('TCG Pocket Rare Pack gets a dedicated reveal intro and summary instead of silently looking like a normal pack',()=>{
  const flow=read('pack-flow-v0165.js');
  assert.match(flow,/RARE PACK/);
  assert.match(flow,/pack\.source==='tcgp'&&pack\.luckyPack/);
  assert.match(flow,/RARE PACK COMPLETE/);
  assert.match(flow,/playSpecialPackIntroV04028/);
});
