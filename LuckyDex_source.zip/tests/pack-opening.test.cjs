const {test} = require('node:test');
const assert = require('node:assert/strict');
// Removing date validation/enrichment or reversing the comparator breaks these.
const pack = (() => { try {return require('../app/src/main/assets/pack-opening.js');} catch {return {};} })();

test('dated sets sort newest first; invalid/unknown dates stay last in source order', () => {
  assert.equal(typeof pack.orderSets, 'function');
  const sets = [
    {id:'z',name:'Zulu'}, {id:'old',releaseDate:'1999-01-09'},
    {id:'bad',releaseDate:'2025-02-30'}, {id:'new',releaseDate:'2026-06-01'},
    {id:'a',name:'Alpha'}, {id:'tie',releaseDate:'2026-06-01'}
  ];
  assert.deepEqual(pack.orderSets(sets).map(s=>s.id), ['new','tie','old','z','bad','a']);
  assert.equal(sets[0].id, 'z');
});

test('enrichment uses cached dates, fetches missing dates, persists usable dates', async () => {
  assert.equal(typeof pack.enrichSets, 'function');
  const cache={cached:{releaseDate:'2024-01-01'}}, persisted=[];
  const ordered=await pack.enrichSets([{id:'cached'},{id:'fresh'},{id:'unknown'},{id:'old',releaseDate:'1999-01-09'}], {
    cached:id=>cache[id], online:true,
    detail:async id=> {if(id==='cached')throw Error('must use cache'); if(id==='unknown')throw Error('404');return {id,releaseDate:'2026-01-01'};},
    persist:s=>persisted.push(s)
  });
  assert.deepEqual(ordered.map(s=>s.id), ['fresh','cached','old','unknown']);
  assert.deepEqual(persisted.map(s=>s.id), ['fresh']);
});

test('offline enrichment makes no detail requests and retains undated source order', async () => {
  assert.equal(typeof pack.enrichSets, 'function');
  const ordered=await pack.enrichSets([{id:'z'},{id:'a'}], {online:false,cached:()=>null,detail:()=>{throw Error('network');}});
  assert.deepEqual(ordered.map(s=>s.id), ['z','a']);
});

test('artwork prefers IndexedDB over network and returns a usable local URL', async () => {
  assert.equal(typeof pack.resolveArtwork, 'function');
  const result=await pack.resolveArtwork({id:'cached',image:'https://example.invalid/art'}, {
    cached:async()=>new Blob(['cached']), online:true,
    decode:async()=>true, objectUrl:()=> 'blob:cached', revoke:()=>{},
    network:()=>{throw Error('cache must win');}, placeholder:'data:placeholder'
  });
  assert.deepEqual(result,{url:'blob:cached',owned:true,source:'cache'});
});

test('airplane mode never requests network artwork, even on cache miss', async () => {
  assert.equal(typeof pack.resolveArtwork, 'function');
  const result=await pack.resolveArtwork({id:'missing',image:'https://example.invalid/art'}, {
    cached:async()=>null,online:false,network:()=>{throw Error('network');},placeholder:'data:placeholder'
  });
  assert.equal(result.url,'data:placeholder'); assert.equal(result.source,'placeholder');
});

test('bad cached artwork falls through to network; bad network falls through to placeholder', async () => {
  assert.equal(typeof pack.resolveArtwork, 'function');
  const revoked=[];
  const result=await pack.resolveArtwork({id:'bad'}, {
    cached:async()=>new Blob(['bad']),online:true,objectUrl:()=> 'blob:bad',revoke:u=>revoked.push(u),
    decode:async()=>false,network:async()=>null,placeholder:'data:placeholder'
  });
  assert.equal(result.source,'placeholder'); assert.deepEqual(revoked,['blob:bad']);
});

test('approach grows through Z-space while rotating all three axes, then settles before flip', () => {
  assert.equal(typeof pack.motionAt, 'function');
  const start=pack.motionAt(0),middle=pack.motionAt(325),overshoot=pack.motionAt(650),settled=pack.motionAt(820),flip=pack.motionAt(1080),front=pack.motionAt(1340);
  assert.ok(start.z < -2000); assert.ok(start.scale < .35);
  for(const axis of ['x','y','roll'])assert.notEqual(middle[axis],start[axis]);
  assert.ok(overshoot.z>0); assert.equal(settled.z,0); assert.equal(settled.flip,0);
  assert.ok(flip.flip>0&&flip.flip<180); assert.equal(front.flip,180);
});

test('rarity tiers scale from clean common to high-tier ribbons and crown rainbow', () => {
  assert.equal(typeof pack.profileFor, 'function');
  const profiles=['Common','Rare','One Star','Two Star','Three Star','Crown'].map(rarity=>pack.profileFor({rarity}));
  assert.equal(profiles[0].particles,0); assert.equal(profiles[0].flash,0);
  assert.ok(profiles[1].particles>0);assert.equal(profiles[1].ribbons,0);
  assert.ok(profiles[2].particles>profiles[1].particles);
  assert.equal(profiles[3].ribbons,2);assert.equal(profiles[4].ribbons,2);
  assert.equal(profiles[5].ribbons,3);assert.equal(profiles[5].rainbow,true);
  assert.ok(profiles[5].duration>profiles[4].duration);
  assert.equal(pack.profileFor({rarity:'★★'}).ribbons,2);
});

test('ribbon segments travel and cross behind/front depth planes over two revolutions', () => {
  assert.equal(typeof pack.ribbonPoint, 'function');
  const a=pack.ribbonPoint(0,0,100,140),b=pack.ribbonPoint(Math.PI,0,100,140),c=pack.ribbonPoint(Math.PI/2,0,100,140);
  assert.notEqual(a.depth>0,b.depth>0);assert.notEqual(a.x,c.x);
  assert.ok(Math.hypot(a.x/100,a.y/140)>1);
});

test('Skip settles once, unlocks navigation, and cancels every owned animation loop', () => {
  assert.equal(typeof pack.RevealSession,'function');
  let callback,settles=0,cancels=0,animationCancels=0;
  const session=new pack.RevealSession({duration:3000,raf:f=>(callback=f,7),caf:()=>cancels++,frame:()=>{},settle:()=>settles++});
  session.ownAnimation({cancel:()=>animationCancels++});session.start();
  assert.equal(session.ready,false);session.skip();session.skip();callback(10000);
  assert.equal(settles,1);assert.equal(session.ready,true);assert.equal(cancels,1);assert.equal(animationCancels,1);
  session.cancel();assert.equal(session.ready,false);
});

test('exit cancels without settling, including a queued RAF callback', () => {
  assert.equal(typeof pack.RevealSession,'function');
  let callback,settles=0;
  const session=new pack.RevealSession({duration:3000,raf:f=>(callback=f,7),caf:()=>{},frame:()=>{},settle:()=>settles++});
  session.start();session.cancel();callback(9000);assert.equal(settles,0);assert.equal(session.ready,false);
});
